# ASH — MASTER HANDOFF PROMPT

> **Kaise use karna hai (Roman Urdu):**
> Naye chat mein **is poori file ka text copy karke paste kar dein**, aur upar ek line likh dein:
> *"Ye mera chalta hua project hai. Pehle padho, phir batao agla kaam kya karna hai. Dobara se mat banana."*
> Project `/home/user/ash` mein pehle se maujood hai — agla agent sirf **padhe, chalaye aur aage barhaye**.

---

## 0. READ THIS FIRST — WHAT THIS DOCUMENT IS

This is the complete specification **and** the current state of a **finished, working** application called **Ash**.

**The project already exists at `/home/user/ash`. It is built, it compiles, it runs, it has real data in it.**

Your job in the new session is to **continue** this project — read the code, run it, fix or extend what the owner asks for next. Your job is **NOT** to:

- scaffold a new Next.js app
- rebuild Ash from scratch
- replace the existing design with a generic chatbot UI
- delete and recreate files you have not read

**Before changing one line, do this:**

```bash
cd /home/user/ash
ls -A
cat package.json
find src -type f \( -name "*.ts" -o -name "*.tsx" \) | sort
npm install            # node_modules does NOT survive between sessions
npm run dev            # binds 0.0.0.0:3000
```

Then read the files relevant to the request. Only then edit.

---

## 1. WHAT ASH IS

Ash is a **complete, free, self-hosted multi-model AI workspace**. One clean interface in front of many free AI engines, with its own memory, its own voice, its own tools, and a full owner Control Panel — so the owner never has to touch code to run it.

It has **two modes**:

- **Chat** — ask, get an answer, with search, images, clips and code execution.
- **Cowork** — hand it an *outcome* instead of a question. It plans, works step by step, writes real files, runs real code, asks before anything destructive, and hands back finished artifacts you can open, edit and download as a zip.

And it can be driven **entirely by voice** — dictation plus ~30 spoken commands in English, Roman Urdu and Urdu script.

Design goals, in priority order:

1. **It must always answer.** Keys missing, quota dead, internet down — there is always a working engine.
2. **It must never lie.** No guessing, no padding, no invented facts. If it doesn't know, it says so in one line and queues the question for learning.
3. **It must be free.** No engine that requires a credit card may ever be a default.
4. **The owner must never need the terminal.** Everything is configurable from `/owner`.
5. **It must never leak its vendors.** The words "Gemini", "OpenAI", "OpenRouter" etc. must never reach the browser.

---

## 2. HARD RULES — NEVER VIOLATE THESE

These are standing instructions from the owner. They override your defaults.

| # | Rule |
|---|---|
| 1 | **Do not start coding blindly.** Inspect the whole existing project before modifying. Repair / refactor / upgrade — never throw away and rebuild a toy version. |
| 2 | **No fake features.** Every button must do exactly what its label says. No placeholder handlers, no `TODO`, no "coming soon", no dead UI. |
| 3 | **Never nag about the owner password.** The Control Panel is fully usable while unclaimed. The owner will set a password in their own time. Do not add banners, modals, or warnings about it. |
| 4 | **Never reveal the underlying vendor** in any HTML, JSON, label, error, or stream the browser can see. `vendor` fields are server-side only. |
| 5 | **Voice must stay provider-swappable.** Never hard-wire one STT/TTS provider. A provider dying must be a dropdown change in Settings, not a rebuild. |
| 6 | **Reply to the owner in Roman Urdu.** They write Roman Urdu; mirror it. |
| 7 | **Never re-add the deleted items** (see §3.1). They were explicitly removed and must stay removed. |
| 8 | **Paid engines are never defaults** and are never auto-selected in a fallback chain. |
| 9 | **Build whole features in one go**, in the order asked. Do not deliver half a feature and ask whether to continue. |

### 2.1 Permanently deleted — do NOT recreate

- ❌ A "Server — shut the server down" card
- ❌ Any `.bat` / `START-WINDOWS.bat` / "double-click this file" references
- ❌ A "Where your data lives / copy knowledge to Firebase" migration card
- ❌ Separate `/brain` and `/learn` pages — **everything they did now lives inside the Control Panel at `/owner`**
- ❌ "From internet" scraped-answer counters
- ❌ Credit-card / paid engines as defaults

---

## 3. CURRENT STATE — ALREADY BUILT AND VERIFIED

Everything in this section **exists and works**. Do not re-implement it.

### 3.1 Feature checklist (all ✅ done)

**Chat core**
- ✅ Streaming chat over SSE, token-by-token
- ✅ Markdown: GFM tables, headings, lists, links, fenced code with syntax highlighting
- ✅ Stop / Regenerate (regenerate replaces, does not append)
- ✅ Edit your own message and resend
- ✅ Copy message, copy code block
- ✅ Auto-title a chat from its first message
- ✅ Conversation list: new, rename, pin, archive, delete, search, export
- ✅ Per-message timestamps
- ✅ Token-aware history trimming (`fitContext()`), `meta.trimmed` notice to the client
- ✅ Image upload → vision engines
- ✅ Visitor isolation by `owner_key` cookie — nobody can read anyone else's chats, not even the owner (unless `ownerCanViewChats` is explicitly turned on)
- ✅ `aria-live` / `role="log"` accessibility on the transcript

**Engines & routing**
- ✅ 13 providers in the catalog + 3 offline engines (§6)
- ✅ Gemini is **Ash Pro** and leads by default
- ✅ When the leader runs out of quota, hand over to the **best-trained** engine (answers saved per provider), owner's manual order as tie-breaker
- ✅ Quota vs bad-key correctly distinguished (`RATE_LANGUAGE` tested before 401/403; HTTP 402 → daily cap)
- ✅ Health/parking state persisted in `provider_state`
- ✅ `defaultModelId()` never returns an engine without a key — a returning visitor is never stuck offline
- ✅ Custom OpenAI-compatible engines addable from the Control Panel
- ✅ Hand-over notice shown to the user in plain language

**Honesty**
- ✅ `unknownAnswer(script)` — one short apology + "I'm working on it", in Urdu / Roman Urdu / English
- ✅ The unknown question is pushed to `harvest_queue`, so the promise is literally true
- ✅ Offline identity brain: who are you / who made you / where are you from / greetings — answered with zero keys, in the user's script

**Learning**
- ✅ Background trainer: parallel worker pool, serialized queue claim, cached provider chain (15s), cached knowledge index
- ✅ Speeds: Gentle 2 / Normal 4 / Fast 8 / Turbo 12 workers
- ✅ Adaptive governor re-tunes every 20s
- ✅ Quality gates — refusals, stubs and short junk are never saved
- ✅ Live activity feed in the Control Panel
- ✅ Auto-resume on server boot via `src/instrumentation.ts`

**Agents / tools**
- ✅ `src/lib/agents/registry.ts` with `math` (p10), `memory` (p20, smart/brain only), `search` (p30)
- ✅ `orchestrate()` stops at the first complete answer; tool errors are swallowed, never surfaced as crashes
- ✅ Web search with real citations; DuckDuckGo + Wikipedia keyless, SearXNG/Tavily/Brave/Serper optional

**Voice (full spec)**
- ✅ STT + TTS **provider abstraction** (`src/lib/voice/types.ts`)
- ✅ Browser Web Speech as the zero-key default for both
- ✅ Server upgrades: STT `groq-whisper` / `hf-whisper` / `local-whisper`; TTS `elevenlabs` / `hf-speech` / `local-speech` / `openai-speech`
- ✅ Barge-in (user speaks → TTS stops instantly)
- ✅ Push-to-talk, hands-free continuous mode, per-message read-aloud
- ✅ Separate **text language** vs **voice language**; `replyLanguage` wired end-to-end
- ✅ All of it configurable from Settings + Control Panel card 8

**Media**
- ✅ Image generation, keyless (Pollinations) with an adaptive pacer for the ~55s/IP anonymous limit
- ✅ Clips: keyless **motion clip** (one frame + a real camera move), or true frame-by-frame with a key
- ✅ `/api/video` is SSE with live progress
- ✅ Clips persist in the transcript as fenced ```ash-clip blocks, rendered by `Markdown.tsx` → `VideoClip.tsx`

**Code**
- ✅ Real execution via Wandbox for Python, JavaScript, C++, Java and more; compiler ids resolved at runtime (1h cache) with a fallback table
- ✅ Live preview for HTML / CSS / JSX in a sandboxed blob iframe

**Cowork — the agentic workspace (mode 2)**
- ✅ A Chat / Cowork switch in the header. Cowork takes a GOAL, not a question
- ✅ Agentic loop: plan → act → observe → adjust → finish, streamed live over SSE
- ✅ 10 real tools: `write_file`, `append_file`, `read_file`, `list_files`, `delete_file`, `run_code`, `web_search`, `make_image`, `note`, `finish`
- ✅ Artifacts appear in a file panel: open, preview (markdown / CSV table / image / code), **edit by hand**, download, delete
- ✅ Download the whole task as a **.zip** (dependency-free ZIP writer) including a `TASK-LOG.md`
- ✅ Plan checklist ticks itself as real work lands
- ✅ Steer it mid-run: type a new instruction and it is folded into the next step
- ✅ Pause / resume / restart; an interrupted run is reconciled honestly on resume
- ✅ **Approval gate**: destructive tools stop and wait for a human yes/no
- ✅ Fail-fast with the real reason when every engine is down — never burns the step budget on a wall
- ✅ Per-visitor isolation, path sandboxing, step and file ceilings

**Spoken control of the whole app**
- ✅ ~30 intents in English, Roman Urdu and Urdu script (`src/lib/voice/commands.ts`)
- ✅ Dictation stays the default; a sentence only becomes a command with the wake word, with Command mode on, or for a few unmistakable words (`stop`, `ruk jao`)
- ✅ Commands cover chats, the reply, theme, engine choice, media, search, and all of Cowork

**Owner**
- ✅ `/owner` Control Panel, 10 cards (§10), open while unclaimed
- ✅ Backup: download / restore chats + settings (never the keys)
- ✅ Rate limits per visitor-hour and per IP-minute; login throttle 5/min
- ✅ Optional visitor login gate

**Polish**
- ✅ Custom animated `Splash.tsx` — time-based easing, frame-rate independent, zero overshoot, 3 draw calls/frame, precomputed neighbour web, CSS cross-fade exit, replay with `?splash=1`
- ✅ Dark/light theme with **no flash of wrong theme** and **no hydration mismatch** (§12)
- ✅ Security headers via `src/proxy.ts`

### 3.2 Verified live data in the database

`data/app.db` currently holds:

| table | rows |
|---|---|
| conversations | 20 |
| messages | 98 |
| knowledge | 83 |
| harvest_queue | 4 |
| app_settings | 3 |
| provider_state | 1 |

Training is currently **paused** (`learning.running = false`) so the free quota goes to real chats.

---

## 4. TECH STACK (exact)

```
Next.js        16.3.8  (App Router, Turbopack)
React          19.3
TypeScript     5.9  — strict
Tailwind CSS   4.3  (@tailwindcss/postcss)
Drizzle ORM    0.45
@libsql/client 0.18   (SQLite file / Turso)
postgres       3.4    (optional Postgres backend)
react-markdown 10 + remark-gfm 4 + rehype-highlight 7 + highlight.js 11
eslint 9 + eslint-config-next 16.3.8 (flat config, native exports)
```

Scripts:

```json
"dev": "next dev -H 0.0.0.0",
"build": "next build",
"start": "next start -H 0.0.0.0",
"lint": "eslint .",
"typecheck": "tsc --noEmit"
```

---

## 5. FILE MAP (82 source files)

```
/home/user/ash
├── package.json  tsconfig.json  next.config.ts  eslint.config.mjs  postcss.config.mjs
├── .env.example  .env.local (real keys, gitignored)  .gitignore
├── README.md  DEPLOY.md  Dockerfile  vercel.json
├── data/app.db                      SQLite database (live data)
├── public/theme.js                  pins an explicit theme choice pre-paint
└── src
    ├── proxy.ts                     security headers (NOT middleware.ts — Next 16 deprecated that name)
    ├── instrumentation.ts           resumes training on server boot
    ├── app
    │   ├── layout.tsx  globals.css  page.tsx
    │   ├── login/page.tsx           optional visitor gate
    │   ├── owner/page.tsx           Control Panel host
    │   └── api/                     18 routes — see §9
    ├── components                   24 files
    │   ├── ChatApp.tsx              top-level state machine: chats, streaming, models, voice
    │   ├── Sidebar.tsx              conversation list, search, pin/archive/rename/delete
    │   ├── Composer.tsx             input, image attach, mic, send/stop
    │   ├── MessageItem.tsx          one bubble + copy/regen/edit/read-aloud + timestamp
    │   ├── Markdown.tsx             GFM renderer; routes ```ash-clip → VideoClip
    │   ├── CodeBlock.tsx            highlight + copy + Run
    │   ├── CodePreview.tsx          sandboxed blob-iframe preview for html/css/jsx
    │   ├── ModelPicker.tsx          public engine names only
    │   ├── SettingsDialog.tsx       visitor-side settings incl. VoiceSettings
    │   ├── VoiceSettings.tsx        STT/TTS provider, voice, rate, language
    │   ├── VoiceOrb.tsx             listening / speaking indicator, barge-in
    │   ├── CoworkPanel.tsx          Cowork UI: task list, plan, step feed, files, steering
    │   ├── CoworkFileView.tsx       artifact preview + inline editor (md / csv / image / text)
    │   ├── EmptyState.tsx  Splash.tsx  ThemeToggle.tsx  Icons.tsx  VideoClip.tsx
    │   ├── LoginGate.tsx  OwnerGate.tsx
    │   └── ControlPanel.tsx         the 9 owner cards (§10)
    └── lib
        ├── providers/  index.ts catalog.ts types.ts sse.ts gemini.ts
        │                openai-compatible.ts demo.ts health.ts
        ├── agents/registry.ts       math / memory / search + orchestrate()
        ├── cowork/     types.ts store.ts tools.ts agent.ts zip.ts
        ├── voice/      types.ts stt.ts tts.ts client.ts commands.ts
        ├── useVoiceCommands.ts      spoken sentence → an action on the app
        ├── knowledge/  index.ts trainer.ts
        ├── search/index.ts          DDG, Wikipedia, SearXNG, Tavily, Brave, Serper
        ├── images/index.ts          keyless generation + adaptive pacer
        ├── code/index.ts            language table, preview + runnable checks
        ├── code/run.ts              the one shared Wandbox runner (route + Cowork)
        ├── db/         index.ts (driver + MIGRATIONS) schema.ts repo.ts
        ├── auth/       owner.ts visitor.ts
        ├── settings/index.ts        Settings type + defaults + load/save
        ├── useVoiceSession.ts       the whole voice state machine (client hook)
        ├── stream-client.ts  prefs.ts  types.ts  identity.ts  ratelimit.ts  stats.ts
```

---

## 6. ENGINE CATALOG

`src/lib/providers/catalog.ts` is **the one editable data file for engines**. Free quotas and model names drift constantly — edit this file (or add a custom engine from the Control Panel) and nothing else.

`vendor` is owner-only and must never reach the browser. `publicName` / `label` is what visitors see.

### 6.1 Online providers

| id | vendor (owner-only) | public name | kind | env key | default |
|---|---|---|---|---|---|
| `gemini` | Google Gemini (AI Studio) | **Ash Pro** | gemini | `GEMINI_API_KEY` | ✅ leader |
| `openrouter` | OpenRouter | **Ash Open** | openai | `OPENROUTER_API_KEY` | ✅ |
| `groq` | Groq | Ash Turbo | openai | `GROQ_API_KEY` | ✅ |
| `cerebras` | Cerebras | Ash Turbo X | openai | `CEREBRAS_API_KEY` | ✅ |
| `mistral` | Mistral | Ash Swift | openai | `MISTRAL_API_KEY` | ✅ |
| `zai` | Z.ai (GLM) | Ash Flash | openai | `ZAI_API_KEY` | ✅ `disableThinking` |
| `nvidia` | NVIDIA NIM | Ash Nitro | openai | `NVIDIA_API_KEY` | ✅ |
| `cohere` | Cohere | Ash Sage | openai | `COHERE_API_KEY` | ✅ |
| `scaleway` | Scaleway | Ash Euro | openai | `SCALEWAY_API_KEY` | ✅ |
| `huggingface` | HF Router | Ash Open+ | openai | `HF_TOKEN` | ✅ |
| `cloudflare` | Workers AI | Ash Edge | openai | `CLOUDFLARE_API_TOKEN` + `CLOUDFLARE_ACCOUNT_ID` | ✅ |
| `local` | Ollama / LM Studio | Ash Local | openai | `OPENAI_BASE_URL` (+`OPENAI_API_KEY`) | ✅ |
| `openai` | OpenAI platform (paid) | Ash Plus | openai | `OPENAI_PLATFORM_API_KEY` | ❌ `paid: true` |

### 6.2 Offline engines (zero keys, always available)

| id | public name | behaviour |
|---|---|---|
| `smart` | **Ash Smart** | memory first, then the live engines |
| `brain` | **Ash Memory** | only what Ash has already learned — fully offline |
| `demo` | **Ash Basic** | maths, time, identity. Tiny built-in engine, never fails |

### 6.3 Live-verified model ids (tested, working)

**Gemini**
- `gemini-3.6-flash` → **Ash Pro** — the main engine, ~1.2s, vision ✅
- `gemini-3.5-flash-lite` → Ash Pro Lite — ~0.5s, vision ✅
- `gemini-3.8-flash` → Ash Pro Max — vision ✅

**OpenRouter (all `:free`)**
- `qwen/qwen3.8-27b:free` → **Ash Open**, vision ✅
- `nvidia/nemotron-3-ultra-550b-a55b:free` → Ash Open Max
- `nvidia/nemotron-3-super-120b-a12b:free` → Ash Open Deep
- `cohere/north-mini-code:free` → Ash Open Coder
- `dots-studio/dots-3-note-preview:free` → Ash Open Mini, vision ✅

### 6.4 Naming scheme

Everything the visitor sees is **"Ash <word>"**. Base = `Ash X`, small/fast = `Ash X Lite` or `Ash X Mini`, strongest = `Ash X Max`, reasoning = `Ash X Think` / `Deep`, code = `Ash X Coder`, vision = `Ash X Vision`. Any new engine must follow this.

---

## 7. ROUTING & FALLBACK — the most important logic

```
incoming message
  ├─ identity question?            → identityAnswer(kind, branding, script)   [0 keys, 0 network]
  ├─ orchestrate(agents)           → math (p10) → memory (p20) → search (p30)
  │     └─ first complete answer wins, engine is never called
  ├─ knowledge hit?                → saved answer, instantly
  └─ buildChain() → try engines in order
        ├─ 200  → stream it
        ├─ quota/rate/402/daily → park provider in provider_state, next in chain,
        │                          send a plain-language "X was busy, Y answered" notice
        ├─ 401/403 bad key      → mark key invalid (NOT quota), next in chain
        └─ chain exhausted      → unknownAnswer(script) + enqueueQuestion()
```

**`buildChain()` order:**
1. The visitor's explicitly chosen engine, if it has a key and is healthy
2. `settings.primaryProvider` (default `gemini` = Ash Pro)
3. If `preferTrainedFallback` (default **on**): remaining engines sorted by **`trainingScores()`** — how many saved answers each provider contributed — descending
4. Ties broken by the owner's manual `fallbackOrder`
5. `smart` → `brain` → `demo` always terminate the chain
6. `paid: true` providers are **never** inserted automatically

**`defaultModelId()`** uses the same ranking and **must never return a keyless engine** — a returning visitor is never dropped onto a dead model.

Proven: with Mistral 26 / Cohere 11 / Groq 4 answers trained, a healthy Gemini yields `ash-pro`; a parked Gemini yields `ash-swift`. A real chat walked Gemini → Mistral → Cohere → Groq → Ash Basic without the user seeing an error.

---

## 8. DATA MODEL (`src/lib/db/schema.ts`)

```ts
conversations  id, title, model, system_prompt, pinned, created_at, updated_at, owner_key
               idx_conversations_updated(updated_at)
messages       id, conversation_id, role, content, model, created_at
               idx_messages_conv(conversation_id, created_at)
knowledge      id, question, question_norm UNIQUE, answer, topic,
               provider, model, quality, hits, created_at
harvest_queue  id, question, topic, status(pending|claimed|done|failed), attempts, created_at
provider_state id, state, until, last_error
app_settings   key PRIMARY KEY, value          // all JSON blobs live here

cowork_sessions id, owner_key, title, goal, status, plan(JSON), summary,
                model, auto_approve, created_at, updated_at
                idx_cowork_owner(owner_key, updated_at)
cowork_steps    id, session_id FK CASCADE, seq, title, tool, args(JSON),
                output, status, created_at
cowork_files    id, session_id FK CASCADE, path, kind, content, bytes,
                updated_at     UNIQUE(session_id, path)
```

Cowork artifacts live **in the database**, not on disk (images as base64 data-URLs), so a
read-only serverless filesystem — Vercel, Turso, Postgres — changes nothing.

Storage backends share one repo implementation: **SQLite file** (`./data/app.db`, default, zero setup), **Turso** (`libsql://…`), **Postgres** (`postgres://…`). Column names are identical across all three.

Schema changes go in the **additive `MIGRATIONS` array in `src/lib/db/index.ts`** — never a destructive rewrite.

Settings keys inside `app_settings`: `app_settings_json` (the whole `Settings` object), `env_keys_json` (keys pasted in the Control Panel), owner credential.

---

## 9. API SURFACE (23 routes)

| route | methods | purpose |
|---|---|---|
| `/api/chat` | POST | the main SSE stream |
| `/api/conversations` | GET POST DELETE | list / create / clear all |
| `/api/conversations/[id]` | GET PATCH DELETE | read / rename·pin·archive / delete |
| `/api/models` | GET | public engine list + `defaultModelId` (no vendor names) |
| `/api/settings` | GET POST | visitor-visible settings |
| `/api/owner` | GET POST | Control Panel read/write — 401 when locked |
| `/api/auth` | GET POST | owner login, throttled 5/min |
| `/api/knowledge` | GET DELETE | browse / delete learned answers |
| `/api/learn` | GET POST | trainer status, start/stop, speed, enqueue |
| `/api/image` | POST | image generation |
| `/api/video` | POST | clip generation (SSE progress) |
| `/api/run` | POST | execute code via Wandbox |
| `/api/system` | GET | health, counts, versions |
| `/api/storage` | GET | which backend is active |
| `/api/backup` | GET POST | export / import |
| `/api/voice` | GET | capability report |
| `/api/voice/stt` | POST | server transcription |
| `/api/voice/tts` | POST | server speech |
| `/api/cowork` | GET POST | list / create a Cowork task |
| `/api/cowork/[id]` | GET PATCH DELETE | read / control / delete a task |
| `/api/cowork/[id]/run` | POST | **SSE** — run or resume the agent loop |
| `/api/cowork/[id]/files` | GET | list artifacts · `?path=` one file · `&download=1` |
| `/api/cowork/[id]/export` | GET | the whole task as a `.zip` |

`PATCH /api/cowork/[id]` actions: `pause`, `cancel`, `approve`, `reject`, `rename`,
`autoApprove`, `writeFile`, `deleteFile`.
`POST …/run` body: `{ steer?, restart?, goal? }` — `steer` is folded into the next step.

### 9.1 `/api/chat` SSE event contract

| event | payload |
|---|---|
| `model` | which public engine is actually answering (can fire twice on hand-over) |
| `delta` | a chunk of text |
| `notice` | plain-language note: hand-over, trimmed context, quota |
| `sources` | search citations array |
| `meta` | `{ trimmed, agents, conversationId, messageId }` |
| `done` | stream finished |
| `error` | fatal — client shows a human sentence, never a stack trace |

Client side: `src/lib/stream-client.ts`.

### 9.2 `/api/cowork/[id]/run` SSE event contract

| event | payload |
|---|---|
| `session` | the task row (status, title, model) |
| `plan` | the step checklist, re-sent whenever an item changes state |
| `thinking` | a one-line note about what it is about to do |
| `step` | a step started — `{ seq, title, tool, args }` |
| `step-update` | that step finished — `{ status, output }` |
| `file` / `file-removed` | an artifact appeared or was deleted |
| `approval` | a destructive action is waiting for a human yes/no |
| `notice` | hand-over, budget, or a limit in plain language |
| `status` | `idle · planning · running · awaiting · paused · done · failed · cancelled` |
| `done` | `{ summary }` |
| `error` | fatal, in a human sentence |

---

## 10. CONTROL PANEL — `/owner`, 10 cards

Open while unclaimed (`isUnclaimed()`); **no password nagging**.

| # | Card | What it does |
|---|---|---|
| 1 | **Free engine keys (N active)** | Paste a key per engine, test it live, remove it. Every engine listed has a free tier and asks for no credit card. Keys are stored in the DB, never shown to visitors. |
| 2 | **Which engine leads, and what takes over** | Pick the leader. Toggle "prefer the best-trained engine". Drag the manual fallback order. Each row shows *"answers this engine has taught Ash"*. |
| 3 | **Tools & web access** | Enable/disable `math`, `memory`, `search`. Search mode auto/always/never, max results, read-pages, per-provider enable + order + custom URL. |
| 4 | **Chat limits & access** | per-visitor/hour, per-IP/minute, max message chars, **context tokens** (default 12000), max images, require login, allow media, owner-can-view-chats. |
| 5 | **Training / Learning** | Start/stop. Speed Gentle 2 / Normal 4 / Fast 8 / Turbo 12. Live activity feed. Browse and delete learned answers. Add questions to the queue. *(This replaced the old `/learn` and `/brain` pages.)* |
| 6 | **Branding** | name, creator, country, city — also feeds the offline identity answers and the system prompt. |
| 7 | **Lock this panel** / **Your password** | Set a password when the owner chooses. Title flips based on `isUnclaimed()`. |
| 8 | **Voice** | STT provider, TTS provider, voice, rate, volume, language, auto-speak, continuous. Clearly states browser voice is free and needs no key. |
| 9 | **Cowork & spoken control** | Turn Cowork on/off, step budget per task (4–60), auto-approve destructive actions (off by default), spoken commands on/off, wake word, and the full printed command list. |
| 10 | **Backup** | Download everything (chats + settings, **never** keys) or restore it. |

---

## 11. SETTINGS SHAPE (`src/lib/settings/index.ts`)

```ts
interface Settings {
  branding: { name; creator; country; city }
  systemPrompt: string                      // "" = use DEFAULT_SYSTEM_PROMPT_TEMPLATE
  providers: Record<string, { enabled: boolean; models: string[] }>
  customEngines: CustomEngine[]             // id,label,baseUrl,model,note,enabled
  fallbackOrder: string[]                   // non-paid catalog ids
  primaryProvider: "gemini"
  preferTrainedFallback: true
  allowMemoryFallback: true
  search: { mode:"auto"; maxResults:5; readPages:true; providers:{…} }
  limits: { perVisitorHour:60, perIpMinute:12, maxMessageChars:8000,
            contextTokens:12000, maxImages:4,
            requireLogin:false, allowMedia:true, ownerCanViewChats:false }
  learning: { running:false, concurrency:4 }
  agents: { math:{enabled:true}, memory:{enabled:true}, search:{enabled:true} }
  voice: { enabled:true, sttProvider:"browser", ttsProvider:"browser", ttsVoice:"",
           voiceLang:"auto", rate:1, volume:1, autoSpeak:false, continuous:false,
           commands:true, wakeWord:"" }
  cowork: { enabled:true, autoApprove:false, maxSteps:24 }
}
```

---

## 12. IDENTITY, LANGUAGE & THE SYSTEM PROMPT

`src/lib/identity.ts` holds the offline identity brain and **`DEFAULT_SYSTEM_PROMPT_TEMPLATE`** — a long, carefully tuned prompt. **Do not casually rewrite it.** Its non-negotiable clauses:

- Never introduce yourself unless asked; greet back warmly instead of reciting your name every time
- Never name or hint at the company / lab / underlying model
- **Always reply in the user's own language *and script***. Roman Urdu in → Roman Urdu out (never silently switch to Urdu script). Mixed languages in → mirror the mix. Never apologise for a language
- Local context for Pakistan: PKR, local cities, metric
- Strong programmer: working code first, then a short explanation; always fenced with a language tag because **the app can actually run it**; complete and self-contained with imports and a runnable example; Java main class not `public`; front-end code as one self-contained file so it can be previewed
- **Never waste the reader's time.** If unsure: ONE short apology line, then stop. No "Great question", no restating the question, no double apology, no vaguely related filler, no invented names/numbers/dates/links/quotes

Script detection: `detectScript()` → `arabic` | `roman-urdu` | `latin`, using an RTL range test plus a ~70-word Roman-Urdu hint list.

`unknownAnswer(script)` — the only thing Ash says when it truly doesn't know:

- **ur:** `معاف کیجیے، اس بارے میں مجھے ابھی ٹھیک سے معلوم نہیں۔ میں اس پر کام کر رہا ہوں اور جلد سیکھ لوں گا۔`
- **roman-urdu:** `Maaf kijiye, is baare mein mujhe abhi theek se nahi pata. Main is par kaam kar raha hun aur jald seekh lunga.`
- **en:** `Sorry — I don't properly know this one yet. I'm working on it and will have it soon.`

---

## 13. VOICE ARCHITECTURE

Contracts in `src/lib/voice/types.ts`: `SpeechToTextProvider` and `TextToSpeechProvider`, each with `id`, `label`, `note`, `requiresKey`, `isConfigured()`, and the work method. **Adding a provider = adding one object to the array.** Nothing else changes. This is the rule that keeps voice from ever being locked to one vendor.

- **Default:** browser Web Speech for both — free, instant, no key, nothing leaves the device
- **Server STT:** `groq-whisper`, `hf-whisper`, `local-whisper`
- **Server TTS:** `elevenlabs` (`eleven_multilingual_v2`), `hf-speech`, `local-speech`, `openai-speech`
- `MAX_TTS_CHARS = 1200`, `MAX_STT_BYTES = 12MB`
- `speakableText(markdown)` strips code blocks → `" … code block … "`, strips markdown noise, and cuts at a sentence boundary
- With no key, `/api/voice` correctly reports: *"No server voice is set up — the browser voice will be used instead."*
- `useVoiceSession.ts` is the whole state machine: idle → listening → thinking → speaking, with barge-in, push-to-talk and hands-free
- Reply-language pinning is proven: the same English question returns Roman Urdu or Urdu script on demand

### 13.1 Spoken control — `src/lib/voice/commands.ts`

```ts
matchCommand(raw, { commandMode, wakeWords }) -> { intent, arg, heard } | null
```

Returning `null` is the **normal** case: the sentence is dictation and goes into the composer.
A sentence is only treated as a command when one of these is true:

1. it starts with a wake word (the app name, or the owner's own wake word), **or**
2. Command mode is switched on in the voice menu, **or**
3. it is one of the few `alwaysOn` intents that must never be ignored — `stop`, `stop reading`, `ruk jao`, `bas karo`.

~30 intents, each with English, Roman Urdu **and** Urdu-script phrasings:

| group | intents |
|---|---|
| chats | `new_chat` `delete_chat` `rename_chat` `scroll_bottom` |
| the reply | `stop` `regenerate` `read_last` `stop_reading` `copy_last` `send` |
| app | `open_settings` `open_panel` `close` `theme_dark` `theme_light` `select_model` `help` |
| modes | `mode_chat` `mode_cowork` |
| cowork | `cowork_new` `cowork_run` `cowork_pause` `cowork_approve` `cowork_reject` `cowork_export` |
| making things | `make_image` `make_clip` `web_search` `run_code` |

`src/lib/useVoiceCommands.ts` turns an intent into a real action through a `VoiceActions`
object supplied by `ChatApp`. `COMMAND_HELP` / `helpSentence()` are what "what can I say"
reads out and what Control Panel card 9 prints.

---

## 14. COWORK ARCHITECTURE (`src/lib/cowork/`)

Chat answers a question. **Cowork accepts an outcome and delivers finished files.**

**The loop** — `agent.ts`
1. `planSystemPrompt()` (plain prose, no protocol) asks the engine for ≤6 plan items.
   `parsePlan` strips sentinels, fences and any `PROTOCOL_LINE`, then de-duplicates.
2. Each turn the engine returns **exactly one action**. The protocol is deliberately
   **not JSON** — small free models produce broken JSON, but this they get right:

```
STEP: short title of what I am doing
TOOL: write_file
PATH: notes/day1.md
<<<ASH
file body goes here
ASH>>>
```

   Optional headers: `PATH`, `LANG`, `QUERY`, `PROMPT`, `STDIN`. The parser also lifts a
   stray header line found at the top of the body (max 4) — models drift and this costs
   nothing to forgive.
3. The tool runs; the result comes back as `OBSERVATION: …` (capped at 4 000 chars).
4. Repeat until `finish`, the step budget, a strike-out, or a human pause.

**Tools** — `tools.ts`: `write_file` `append_file` `read_file` `list_files` `delete_file`
`run_code` `web_search` `make_image` `note` `finish`.

**Limits** — `types.ts`: `maxSteps 24` (owner-settable 4–60), `maxFiles 60`,
`maxFileChars 400 000`, `maxImageBytes 2.5 MB`, `maxObservationChars 4 000`,
`maxBodyChars 120 000`, `maxGoalChars 4 000`, `memoryWindow 8`.

**`safePath()`** rejects absolute paths, drive letters and `~` **before** stripping anything,
then rejects `..`, dotfiles, more than 4 segments and names over 180 chars.

**Approval gate** — `DESTRUCTIVE = ["delete_file"]`. With auto-approve off the step is saved
as `awaiting`, an `approval` event is sent and the stream ends cleanly. `PATCH …approve`
then `POST …/run` resumes with a **one-shot `preApproved` flag** so the gate does not
re-fire. Any step left `running` by a killed run is reconciled to `error` on resume with
*"This step did not finish — the run was interrupted."* — the engine is never allowed to
believe phantom work happened.

**Engines** — `complete()` returns `{ text, model, problem? }`, parks failures, skips
cooling providers, and builds its chain with `{ realEnginesOnly: true, allModels: true }`.
A dead engine is **not** retried inside the loop; the run fails fast with the real reason.
`strikes` ends a run after 2 empty replies or 4 non-action replies.

**Export** — `zip.ts` is a dependency-free store-only ZIP writer (CRC-32 + local headers).
The archive carries every artifact plus a generated `TASK-LOG.md`.

---

## 15. INSTALLABILITY (PWA) — `public/` + `src/lib/pwa.ts`

Ash installs as a real app on Android, iOS and desktop with no store involved.

| Piece | File |
|---|---|
| Manifest | `public/manifest.webmanifest` — standalone, 3 icons, 3 shortcuts |
| Icons | `public/icons/` — 192, 512, maskable 512, apple-touch 180 (generated with PIL, brand `#bd5d3a`) |
| Worker | `public/sw.js` |
| Offline page | `public/offline.html` — self-contained, inline CSS |
| Wiring | `src/lib/pwa.ts`, `src/components/InstallApp.tsx` (Settings row + `PwaBoot` in the layout) |
| Play Store link file | `src/app/.well-known/assetlinks.json/route.ts` |

**Service-worker rules that must not be broken:**
- `/api/**` is **never** intercepted — Chat and Cowork are SSE streams, and a
  cached answer would be a lie.
- Only `GET`, only same-origin, never a `range` request.
- Cache-first for `/_next/static/`, `/icons/`, `/theme.js`; network-first with a
  cached fallback for pages; `offline.html` as the last resort.
- **Registered in production only.** In development the worker is actively
  *unregistered*, because Turbopack reuses chunk URLs with new contents and a
  cache-first worker would poison them.

`/.well-known/assetlinks.json` answers **404 until** `ANDROID_PACKAGE_NAME` and
`ANDROID_SHA256_FINGERPRINT` are set — an honest 404, not an empty file.

The full packaging guide (TWA, Capacitor, Tauri, costs) is `MOBILE-AND-DESKTOP.md`.

---

## 16. ACCEPTANCE TESTS — these must keep passing

Run these after any significant change.

| # | Input | Required behaviour |
|---|---|---|
| 1 | `12*7+3` | `87`, answered by the math agent, no engine call |
| 2 | `main 25-30 saal ka hun` | NOT treated as arithmetic |
| 3 | `date format in python` | NOT treated as a "what time is it" question |
| 4 | `tumhara naam kya hai` | Roman Urdu identity answer |
| 5 | `تمہارا نام کیا ہے` | Urdu-script identity answer |
| 6 | two different cookie jars | each sees only its own chats |
| 7 | owner routes while locked | HTTP 401 |
| 8 | 6 logins in a minute | throttled after 5 |
| 9 | Regenerate | replaces the reply, does not append |
| 10 | pin / rename / delete / archive | all persist |
| 11 | Python, Java, C++ snippets | actually execute and print |
| 12 | view-source + every API response | no vendor name anywhere |
| 13 | `144/12+8` | `agents:['math']` |
| 14 | `what is a for loop` | `agents:[]` — no search |
| 15 | `latest AI news today` | `agents:['search']` + real citations |
| 16 | 60 long turns @ 12000 tokens | trimmed to 46, `meta.trimmed` true |
| 17 | first paint, dark OS theme | no white flash, no hydration warning |
| 18 | Cowork: *"make mars.md with 3 facts"* | plan appears, file is written, plan ticks to done |
| 19 | Cowork plan text | contains no `TOOL:` / `<<<ASH` protocol junk |
| 20 | Cowork: *"write fib.py, run it, save the output"* | `output.txt` holds the **real** program output |
| 21 | Cowork delete | asks first; approve → the file actually goes; reject → it stays |
| 22 | approve then resume | does **not** ask a second time, no duplicate step row |
| 23 | `safePath` with `/etc/passwd`, `../x`, `C:/x`, `~/s`, `.env` | all rejected |
| 24 | `GET …/files?path=x.csv&download=1` | `content-type: text/csv`, `content-disposition: attachment` |
| 25 | `GET …/export` | a valid zip containing the artifacts + `TASK-LOG.md` |
| 26 | another visitor's task id | 404 |
| 27 | *"Ash, new chat"* vs *"I should start a new chat tomorrow"* | command / dictation |
| 28 | *"ruk jao"* with no wake word | still stops — `alwaysOn` |
| 29 | production build, headless Chrome | manifest 200, 4 icons 200, worker `activated`, `/api/*` not intercepted |
| 30 | reload with the network cut | the real offline page, not the browser error |
| 31 | phone viewport 390px | no sideways scroll, no tap target under 36px |
| 32 | an engine that hangs | parked after `engineTimeoutMs`, the chain moves on |
| 33 | the "Working with X" notice | only appears once X has actually produced text |

Test conversations with a shared cookie jar or every request becomes a new visitor:

```bash
curl -c /tmp/jar -b /tmp/jar ...
```

---

## 17. KNOWN TRAPS — DO NOT REPEAT THESE MISTAKES

**Build / tooling**
- `node_modules` does **not** survive between sessions. Always `npm install` first. A partial install once lost `lightningcss.linux-x64-gnu.node` → fixed with `npm install lightningcss`.
- `npm run build` while `next dev` is running → **Killed (OOM)**. Stop dev first, and use `NODE_OPTIONS="--max-old-space-size=3072"`.
- Deleting `.next` while dev is running forces a restart.
- `npx tsc` can resolve the wrong `tsc@2.0.4` package — use `npm run typecheck`.
- ESLint: `FlatCompat` + `eslint-config-next@16` throws *"Converting circular structure to JSON"*. Use the native flat exports `eslint-config-next/core-web-vitals` and `/typescript`.
- `next.config.ts` no longer accepts an `eslint` key in Next 16.
- `react-hooks/set-state-in-effect` is deliberately set to **warn** (mount-time sync is intentional). `react-hooks/refs` and `static-components` were fixed properly, not silenced. Current state: **0 errors, 14 warnings**.
- `middleware.ts` is deprecated in Next 16 → the file is `src/proxy.ts`.

**Theme & hydration (both bugs are fixed — don't reintroduce them)**
- A raw `<script dangerouslySetInnerHTML>` in `layout.tsx` triggers a console error. It was removed.
- `next/script` with **inline** content queues into `self.__next_s` and runs *after* paint (theme flash); with `src` it only emits a `<link rel=preload>`. Neither gives a blocking pre-paint script.
- **The solution in place:** theme is painted by CSS alone — `@media (prefers-color-scheme: dark) { :root:not(.light) { … } }` in `globals.css`. The app uses **zero** `dark:` utilities and 50 CSS-variable references. `public/theme.js` only pins an *explicit* choice; `ThemeToggle` writes explicit `light`/`dark` classes.
- **Hydration mismatch root cause:** `useVoiceSession.ts` called `hasBrowserStt()/hasRecorder()/hasBrowserTts()` *during render* (false on the server, true on the client → the mic button was missing from the SSR HTML). Fixed by moving those into post-mount `useState` + `useEffect`. The same guard is in `VoiceSettings.tsx`. **Never read browser capabilities during render.**

**Network / providers**
- **Every outbound `fetch` must pass `cache: "no-store"`.** The framework fetch cache was corrupting binary bodies and breaking all media.
- Wandbox compiler ids drift → resolve the newest per language at runtime (1h cache) with `WANDBOX_FALLBACK`. **Kotlin is not offered** by Wandbox — it is excluded from runnable languages.
- `html.duckduckgo.com` blocks datacenter IPs by TLS fingerprint (curl works, undici gets a 202 anomaly page). Fall back to the keyless official `api.duckduckgo.com` Instant Answer API.
- `image.pollinations.ai` anonymous tier = **one image per ~55s per IP**, HTTP 402 in between. The `referrer` param does not help. This drives the adaptive pacer and the whole motion-clip design.
- Dead/keyed and **rejected**: Pollinations audio TTS (404/402), StreamElements (401), Mojeek (403). Google Translate TTS works but is an undocumented scraping endpoint → **rejected on principle, do not add it**.
- Gemini's `v1beta/models` list includes retired models; `gemini-2.5-*` all 404 on `generateContent`. The daily quota is **per model** (`GenerateRequestsPerDayPerProjectPerModel-FreeTier`, retryDelay ~58038s).
- OpenRouter: the free daily cap is 50 req/day without credits and is reported as **HTTP 403** with the body text `free-models-per-day` — not 429. All 5 originally catalogued `:free` ids were retired; §6.3 lists the tested replacements.

**Agent loops (every one of these was hit for real while building Cowork)**
- Retrying a dead engine **inside** the step loop eats the entire step budget before the user sees anything. Park it and fail fast with the true reason.
- Reusing the action-protocol system prompt for *planning* leaks `TOOL:` and `<<<ASH` into the plan the user reads. Planning needs its own plain prompt **and** a filter on the parse — do both, not one.
- Re-running the approval check on a **resumed** step loops forever. Carry a one-shot `preApproved` flag.
- A step left in `running` by a killed run makes the model believe the work already happened and it hallucinates the result. Reconcile stale steps to `error` before replaying history.
- A vague tool error ("that file name is not allowed") when the argument is simply **absent** makes the model retry the exact same broken action. Always distinguish *missing argument* from *invalid argument*, and echo the offending value back.
- A sanitiser must test for absolute paths **before** it strips leading separators, or `/etc/passwd` quietly becomes the perfectly valid relative path `etc/passwd`.
- **`X-Frame-Options: SAMEORIGIN` blanks out every hosted preview panel** (they embed the dev server from another origin). Use `Content-Security-Policy: frame-ancestors` instead — it can hold an allowlist — and only send XFO when the answer really is "self only". `ASH_FRAME_ANCESTORS` carries the production allowlist.
- A service worker that caches `/_next/static/` **cache-first in development** serves stale chunks forever, because Turbopack reuses those URLs. Register in production only, and unregister on sight in dev.
- Announcing an engine *before* it has produced a character turns a dead provider into a UI that looks frozen. Announce on first output; report attempts separately.
- An engine call with **no timeout** lets one hanging provider eat a whole Cowork task. Every attempt needs its own `AbortController` and a deadline.
- Skipping a cooling provider **silently** leaves the owner with "no engine was available" and no clue. Push the reason into the problem list.
- Next.js **ignores** `src/app/api/_name` directories (the underscore means private) — a scratch test route there 404s. Name it without the underscore, and delete it before shipping.

---

## 18. COMMANDS

```bash
cd /home/user/ash

npm install                  # ALWAYS first — node_modules is not persisted
npm run typecheck            # not npx tsc
npx eslint .                 # expect 0 errors / ~14 warnings

pkill -f "next dev"          # stop any stray dev server BEFORE building
rm -rf .next && NODE_OPTIONS="--max-old-space-size=3072" npm run build

npm run dev                  # binds 0.0.0.0:3000 → live preview
```

Quick health probe:

```bash
curl -s -c /tmp/j -b /tmp/j localhost:3000/api/models  | head -c 400
curl -s -b /tmp/j            localhost:3000/api/learn  | head -c 400
python3 -c "import sqlite3;c=sqlite3.connect('data/app.db');\
print([ (t,c.execute('select count(*) from '+t).fetchone()[0]) for t in \
['conversations','messages','knowledge','harvest_queue',\
'cowork_sessions','cowork_steps','cowork_files']])"
```

Driving a Cowork run from the terminal (this is how every Cowork bug was found):

```bash
SID=$(curl -s -b /tmp/j -X POST localhost:3000/api/cowork \
  -H 'content-type: application/json' \
  -d '{"goal":"write fib.py, run it, save the output to output.txt"}' \
  | python3 -c "import sys,json;print(json.load(sys.stdin)['session']['id'])")

curl -sN -b /tmp/j -X POST localhost:3000/api/cowork/$SID/run \
  -H 'content-type: application/json' -d '{}'      # SSE, watch it work

curl -s  -b /tmp/j localhost:3000/api/cowork/$SID/files
curl -s  -b /tmp/j "localhost:3000/api/cowork/$SID/export" -o task.zip
```

Deployment: `Dockerfile` and `vercel.json` are present; `DEPLOY.md` has the walkthrough.

---

## 19. ENVIRONMENT

Every variable is **optional** — with zero keys the app still runs on Ash Basic. Keys can also be pasted in the Control Panel instead of editing files (they are then stored in the DB).

```
GEMINI_API_KEY  OPENROUTER_API_KEY  GROQ_API_KEY  CEREBRAS_API_KEY  MISTRAL_API_KEY
ZAI_API_KEY  NVIDIA_API_KEY  COHERE_API_KEY  SCALEWAY_API_KEY  HF_TOKEN
CLOUDFLARE_API_TOKEN  CLOUDFLARE_ACCOUNT_ID
OPENAI_BASE_URL  OPENAI_API_KEY          # Ollama / LM Studio
TOGETHER_API_KEY                         # image extras (Pollinations needs none)
SEARXNG_URL  TAVILY_API_KEY  BRAVE_API_KEY  SERPER_API_KEY
DATABASE_URL  DATABASE_AUTH_TOKEN        # empty = ./data/app.db
FIREBASE_API_KEY                         # only when "Require login" is ON
AI_NAME=Ash  AI_CREATOR=Ash Labs  AI_COUNTRY=Pakistan  AI_CITY=Rawalpindi
APP_URL=http://localhost:3000  PORT=3000
```

`.env.local` already contains the owner's **real, working Gemini and OpenRouter keys** and is gitignored. Do not print its contents and do not commit it.

---

## 20. IF THE OWNER ASKS FOR SOMETHING NEW

1. Re-read the relevant files first. Quote what is already there before proposing a change.
2. Check §15 — the idea may already have been tried and rejected for a good reason.
3. New engine → edit `catalog.ts` only. New tool → add one object to `AGENTS`. New voice provider → add one object to `stt.ts`/`tts.ts`. New setting → extend `Settings` + `defaultSettings()` + the right Control Panel card. New table/column → append to `MIGRATIONS`.
4. Ship the whole feature with a working UI control. No placeholders.
5. Re-run §14 acceptance tests, then `typecheck` → `eslint` → `build`.
6. Report back to the owner in **Roman Urdu**, short, no bloat.

---

*Snapshot taken 2026-10-08. 74 source files · 18 API routes · 21 components · 20 chats · 98 messages · 83 learned answers.*
