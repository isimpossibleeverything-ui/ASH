# Deploying Ash

Ash runs anywhere Node 20.9+ runs. Pick one.

---

## 1. Vercel (free tier)

1. Push this folder to GitHub.
2. On Vercel: **Add New → Project → Import**. Framework is detected as Next.js; leave the
   build settings alone.
3. **Add a database.** Vercel's filesystem is read-only, so SQLite will not persist there.
   Create a free [Turso](https://turso.tech) or [Neon](https://neon.tech) database and set:

   ```
   DATABASE_URL=libsql://your-db.turso.io      # or postgres://…
   DATABASE_AUTH_TOKEN=…                        # Turso only
   ```

4. Deploy, then open `/owner`, set your password, and paste your free engine keys **in the
   Control Panel**. They are stored in the database, so you never have to redeploy to rotate
   a key.

`vercel.json` already raises `maxDuration` to 300 s for `/api/chat`, `/api/image` and
`/api/video`, which long answers and image generation need.

> On the Hobby plan, streaming responses are capped by your plan's function duration. If long
> answers get cut off, lower the engine's `max_tokens` or move to a host without that cap.

---

## 2. Docker (anywhere)

```bash
docker build -t ash .
docker run -d --name ash -p 3000:3000 -v ash-data:/app/data --restart unless-stopped ash
```

Everything lives in the `ash-data` volume (`/app/data/app.db`). Back it up by copying that
volume, or use the Control Panel's **Download backup** button.

With an `.env` file:

```bash
docker run -d --name ash -p 3000:3000 -v ash-data:/app/data --env-file .env ash
```

---

## 3. A plain VPS (Ubuntu + Caddy)

```bash
git clone <your-repo> ash && cd ash
npm ci
npm run build
```

Run it under systemd — `/etc/systemd/system/ash.service`:

```ini
[Unit]
Description=Ash
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/srv/ash
Environment=NODE_ENV=production
Environment=PORT=3000
ExecStart=/usr/bin/npx next start -H 0.0.0.0
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable --now ash
```

`/etc/caddy/Caddyfile` — HTTPS and streaming-safe:

```caddy
chat.example.com {
    encode zstd gzip
    reverse_proxy 127.0.0.1:3000 {
        flush_interval -1
    }
}
```

`flush_interval -1` matters: without it the proxy buffers and streaming looks frozen.
The nginx equivalent is `proxy_buffering off;` plus `proxy_read_timeout 300s;`.

---

## 4. Local AI with no limits at all

Install [Ollama](https://ollama.com/download), then:

```bash
ollama pull llama3.1
```

Set in `.env` (or the Control Panel):

```
OPENAI_BASE_URL=http://127.0.0.1:11434/v1
OPENAI_API_KEY=ollama
```

"Ash Local" turns on. No quotas, no keys, no internet needed.

---

## Environment variables

Every one of them is optional — see `.env.example` for the full annotated list.

| Variable | Why |
| --- | --- |
| `DATABASE_URL` | Empty = local SQLite. `postgres://…` or `libsql://…` to go remote. |
| `DATABASE_AUTH_TOKEN` | Turso only. |
| `GEMINI_API_KEY`, `GROQ_API_KEY`, … | Free engines. Can be set in the Control Panel instead. |
| `OPENAI_BASE_URL` / `OPENAI_API_KEY` | A local or self-hosted OpenAI-compatible server. |
| `SEARXNG_URL`, `TAVILY_API_KEY`, `BRAVE_API_KEY`, `SERPER_API_KEY` | Optional extra web search. |
| `FIREBASE_API_KEY` | Only needed if you switch "Require login" on. |
| `AI_NAME`, `AI_CREATOR`, `AI_COUNTRY`, `AI_CITY` | Branding defaults (the Control Panel overrides them). |
| `AI_TIMEZONE` | Time zone for the offline time/date answers. Defaults to `Asia/Karachi`. |
| `APP_URL` | Used as the referer for engines that ask for one. |

---

## After deploying — a 60-second checklist

1. Open `/owner` and set a password. **Do this immediately**: the first visitor to that page
   is the one who claims it.
2. Paste one free key, press **Test**, and look for a green `✓` with a millisecond count.
3. Back on `/`, send "hello" and check the answer streams in.
4. Ask for a Python snippet and press **Run**.
5. Press **Download backup** once so you know where your data lives.
