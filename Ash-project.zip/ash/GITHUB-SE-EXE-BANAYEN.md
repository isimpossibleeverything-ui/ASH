# Ash ka Windows app — GitHub se banayen

Aap ke computer par **kuch bhi install nahi karna**. GitHub khud `.exe` bana ke de ga.
Poora kaam **10 minute** ka hai, phir har baar sirf 1 click.

---

## Pehle ye samajh lein

Sab code tayyar hai aur commit ho chuka hai. Jo bacha hai wo sirf ye hai:
repo GitHub par chala jaye — baqi kaam GitHub ka robot (Actions) karega.

| Kaun | Kya karega |
|---|---|
| **Aap** | GitHub par ek repo banayenge, do command chalayenge |
| **GitHub** | Windows machine par Rust + Node lagayega, app build karega |
| **Aap** | `Ash_1.0.0_x64-setup.exe` download kar ke install karenge |

---

## Step 1 — GitHub account aur repo

1. [github.com](https://github.com) par jayen. Account nahi hai to **Sign up** — free hai.
2. Upar dayen (right) **+** → **New repository**.
3. Bharein:
   - **Repository name:** `ash`
   - **Private** chunein (ye aap ka zaati app hai, public karne ki zarurat nahi)
   - Neeche koi bhi checkbox **na** lagayen — README, .gitignore, license, kuch nahi
4. **Create repository** dabayen.

Ab jo page khulega, us par aisa URL likha hoga:

```
https://github.com/AAP-KA-USERNAME/ash.git
```

Ye URL copy kar lein. Agli step mein chahiye.

---

## Step 2 — Code GitHub par bhejen

Terminal mein, project folder ke andar:

```bash
cd /home/user/ash

git remote add origin https://github.com/AAP-KA-USERNAME/ash.git
git branch -M main
git push -u origin main
```

> **Username/password poochhe to:** GitHub ab password qubool nahi karta.
> **Token** chahiye hoga:
> GitHub → apni tasveer (top right) → **Settings** → neeche **Developer settings** →
> **Personal access tokens** → **Tokens (classic)** → **Generate new token (classic)** →
> naam `ash-push`, **repo** wala checkbox lagayen → **Generate**.
> Jo lamba code mile wo copy karen aur **password ki jagah paste** karen.
> (Ye code dobara nahi dikhega — kahin mehfooz likh lein.)

---

## Step 3 — GitHub ko build karne dein

Push hote hi build **khud shuru** ho jata hai.

1. Apne repo par jayen → upar **Actions** tab.
2. **"Build the Windows app"** naam ka run chal raha hoga (peela goal = chal raha hai).
3. **8 se 15 minute** lagte hain pehli baar. (Rust pehli dafa sab kuch compile karta hai.
   Agli dafa 2–3 minute.)
4. Jab nishan **hara ✓** ho jaye — ho gaya.

Agar Actions tab par likha aye ke workflows band hain, to **"I understand my workflows,
go ahead and enable them"** par click kar dein.

---

## Step 4 — `.exe` download karen

1. Us hare run par click karen.
2. Page ke bilkul neeche **Artifacts** section hoga.
3. **`Ash-Windows-installer`** par click → ek `.zip` download hoga.
4. Zip kholen → andar **`Ash_1.0.0_x64-setup.exe`** milega.
5. Us par double-click → install → done. Ash ab Start Menu mein normal app ki tarah hoga.

> Windows "Unknown publisher" ki warning de sakta hai. Ye normal hai — installer par
> paid code-signing certificate nahi hai (saal ka ~$200). **More info** → **Run anyway**.

---

## App ke andar kya milega

App khulte hi upar teen tab honge: **Chat · Cowork · Computer**.

**Computer** wala naya hai. Pehli baar wahan ek permission screen aye gi:

- **"Let Ash use this computer"** dabayen
- Windows apna folder picker kholega — **aap** folder chunenge
- Bas wahi ek folder Ash ki poori duniya hai

Us folder ke andar Ash ye kar sakta hai:

- files parhna, likhna, rename karna, sort karna
- folders banana
- **commands chalana** — `winget install`, scripts, cleanup
- Chrome, files, links kholna

Jo **nahi** kar sakta:

- us folder se bahar kuch bhi chhoona
- bina dobara poochhe kuch delete karna (har dafa Windows ka apna dialog aye ga)
- app band hone ke baad permission yaad rakhna — har dafa naye sire se poochhega

Jo abhi **nahi hai** (jaan boojh kar, agli baar):

- screenshot lena, mouse/keyboard khud chalana — ye native libraries mangti hain
  jo pehli hi build ko tornay ka khatra barha deti hain. Pehle ye wala theek chal
  jaye, phir ye add karenge.

---

## Aage koi tabdeeli karni ho to

```bash
cd /home/user/ash
git add -A
git commit -m "jo change kiya uska naam"
git push
```

Push karte hi GitHub naya `.exe` bana de ga. Bas.

---

## Agar build laal (❌) ho jaye

Ghabrane ki baat nahi. Laal run par click karen → jo step laal hai use kholen →
neeche ki aakhri 20 lines copy kar ke mujhe de dein. Main dekh kar theek kar dun ga.

---

## Chhota sa sach

Aap ka data aap ke paas rehta hai. App ka database aap ke computer par
`C:\Users\AAP\AppData\Roaming\com.ashlabs.ash\data\app.db` mein banta hai —
installer ke andar nahi. (Build script ne ye bhi pakra tha ke Next.js galti se
is sandbox ka purana database bundle mein daal raha tha; wo ab nikal diya jata hai.)
