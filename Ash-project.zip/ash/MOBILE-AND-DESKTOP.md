# Ash on a phone and on a desktop

Ash is already installable. This file explains what is done, and what each
further step actually costs you — in money, in accounts, and in machines you
need to own.

---

## 0. The one thing that decides everything

**Ash is not a web page. It is a web page plus a server.**

The server holds the database, the engine keys, the learning memory, and the
Cowork workspace, and it streams answers over SSE. A phone app cannot hold any
of that on its own — your API keys must never ship inside an APK, where anyone
can unzip them out.

So every option below is one of two shapes:

| Shape | What the app contains | What it needs |
| --- | --- | --- |
| **A — thin shell** (recommended) | Just a window pointed at your Ash server | One deploy. Every device, one update. |
| **B — self-contained desktop** | The whole Node server bundled inside the app | No hosting bill, works on your own machine. Only sensible on a computer, never on a phone. |

Pick A unless you specifically want Ash to run with no server at all on your own PC.

---

## 1. Already done — install it today, free, no store

Ash is a **PWA**. That is not a plan for later, it is in the build right now:

| Piece | Where | State |
| --- | --- | --- |
| Web app manifest | `public/manifest.webmanifest` | name, icons, `standalone`, 3 app shortcuts |
| Icons | `public/icons/` | 192, 512, maskable 512, 180 for iOS |
| Service worker | `public/sw.js` | caches the shell, **never** touches `/api/**` |
| Offline page | `public/offline.html` | real page, shown with no connection |
| Registration | `src/lib/pwa.ts` | production only — dev workers are actively removed |
| Install button | Settings → *Install as an app* | fires the real prompt, or shows the real steps on iOS |

**Verified in a real headless Chrome against the production build:** manifest
`200 application/manifest+json`, all four icons `200 image/png`, service worker
`activated` at scope `/`, `/api/*` still untouched by the worker, and a reload
with the network cut shows the offline page.

### How you install it

| Device | Steps |
| --- | --- |
| **Android (Chrome)** | Open Ash → Settings → **Install as an app**. Or the browser menu → *Install app*. |
| **iPhone / iPad (Safari)** | Share button → **Add to Home Screen** → Add. Safari has no install prompt; Settings shows these exact steps. |
| **Windows / Mac / Linux (Chrome, Edge, Brave)** | The install icon in the address bar, or Settings → **Install as an app**. You get a real window with no browser bars. |

**HTTPS is required.** On `http://localhost` it works for testing; anywhere else
you need a real certificate. Vercel, Netlify, Cloudflare and Caddy all give you
one for free — see `DEPLOY.md`.

What you get: own icon, own window, full screen, opens from the home screen, and
it still loads on a bad connection. What you do **not** get: a Play Store
listing. That is section 2.

---

## 2. Android — a real Play Store app

Google supports shipping a PWA as a **Trusted Web Activity**: a real Android app
that runs your site in Chrome's engine with no browser UI. This is the cheap,
supported, officially-blessed route.

**Cost:** $25 once, for a Google Play developer account. Nothing else.
**You need:** the PWA live on HTTPS (section 1 — done), and Java + the Android SDK, or just a browser if you use PWABuilder.

```bash
# easiest: the GUI. Paste your URL at https://www.pwabuilder.com
#   → Package for stores → Android → Download Package

# or the CLI it uses underneath
npm i -g @bubblewrap/cli
bubblewrap init --manifest https://your-ash-domain.com/manifest.webmanifest
bubblewrap build          # produces a signed .aab for the Play Console
```

**Then the step everyone forgets.** Bubblewrap prints a package name and a
SHA-256 signing fingerprint. Ash already serves the file Google checks for —
just give it those two values and redeploy:

```bash
ANDROID_PACKAGE_NAME=com.yourname.ash
ANDROID_SHA256_FINGERPRINT=AB:CD:EF:...        # comma-separate if more than one
```

Confirm it with:

```bash
curl https://your-ash-domain.com/.well-known/assetlinks.json
```

Until those are set the endpoint answers **404 on purpose** — nothing has been
linked yet. Without it your app opens with a browser address bar stuck across
the top, or refuses to launch.

Two current Play rules worth knowing before you submit: apps must target
**Android API 36**, and PWA-based apps may not target children, so set the age
rating to 13+.

---

## 3. iPhone — the App Store is the awkward one

**Apple does not accept repackaged websites.** App Review guideline 4.2 rejects
an app whose only content is your website in a WebView. So:

- **Free and works today:** Safari → Share → *Add to Home Screen*. Full screen,
  own icon, indistinguishable from an App Store app for most people. For a
  personal or a small-team tool this is the honest answer: do this and stop.
- **If you genuinely need an App Store listing**, you must add native things the
  web cannot do — push notifications, share-sheet integration, widgets,
  background audio. Wrap Ash with **Capacitor**, then build those features
  natively so the app is more than a wrapper.
  Cost: **$99 a year**, plus a Mac with Xcode. There is no way around either.

```bash
npm i @capacitor/core @capacitor/cli @capacitor/ios
npx cap init Ash com.yourname.ash --web-dir=public
# point the shell at your hosted Ash (shape A)
#   capacitor.config.ts →  server: { url: "https://your-ash-domain.com", cleartext: false }
npx cap add ios && npx cap open ios      # needs macOS + Xcode
```

The same Capacitor project also produces an Android build if you would rather
have one codebase for both than use the TWA route.

---

## 4. Desktop — a real .exe / .dmg / .AppImage

### 4a. Thin shell (shape A) — minutes of work

A **Tauri** window pointed at your hosted Ash. The installer is a few megabytes
because it uses the system webview instead of shipping a browser.

```bash
npm i -D @tauri-apps/cli
npx tauri init          # frontend dist: anything; we override the URL below
```

```json
// src-tauri/tauri.conf.json
{
  "productName": "Ash",
  "identifier": "com.yourname.ash",
  "app": {
    "windows": [
      { "title": "Ash", "url": "https://your-ash-domain.com", "width": 1200, "height": 820 }
    ]
  }
}
```

```bash
npx tauri build         # → .msi/.exe, .dmg, .deb/.AppImage
```

Electron does the same job and is easier to find help for, but ships a whole
Chromium — roughly 150 MB against Tauri's ~10 MB.

### 4b. Self-contained (shape B) — Ash with no server at all

The desktop app carries the Node server inside it and talks to `127.0.0.1`.
Your keys stay on your machine, there is no hosting bill, and the only thing
that still needs the internet is the AI engines themselves.

1. Build Ash in standalone mode and turn the server into one executable
   (Node's built-in **SEA**, or `pkg`).
2. Drop that executable into `src-tauri/binaries/` named with the target triple
   Tauri expects — `ash-server-x86_64-pc-windows-msvc.exe`. Find your triple
   with `rustc -Vv`.
3. Register it as a sidecar in `tauri.conf.json`:

```json
{ "bundle": { "externalBin": ["binaries/ash-server"] } }
```

4. Spawn it on launch, wait for the port, then point the window at
   `http://127.0.0.1:<port>`.
5. Put `data/app.db` in the OS app-data folder, not next to the binary, or the
   next update wipes the user's chats.

One real warning: a plain `127.0.0.1` server is reachable by **any** program on
that computer. Generate a random secret when the shell starts, hand it to the
server over stdin — never over argv or an env var, both are readable from the
task manager — and require it on every request.

---

## 5. What I would actually do

1. **Deploy Ash once** (`DEPLOY.md` — Vercel is free and takes about five minutes).
2. **Install the PWA** on your phone and your laptop. Zero cost, zero accounts, today.
3. Live with it for a couple of weeks. If nothing is missing, you are finished —
   most people never need a store listing.
4. If you want it on Play: $25, Bubblewrap, set the two `ANDROID_*` variables. Half a day.
5. Only build the Tauri sidecar version if you want Ash running with no server at all.

| Route | Cost | Needs | Time |
| --- | --- | --- | --- |
| PWA install | free | nothing | now |
| Play Store (TWA) | $25 once | Play account | half a day |
| App Store (Capacitor) | $99 / year | Mac + native features | days |
| Desktop thin shell | free | Rust toolchain | an hour |
| Desktop self-contained | free | Rust + packaging work | a weekend |
