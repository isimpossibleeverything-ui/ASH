# Ash

A complete, free, multi-model AI workspace. Streaming answers, saved history, markdown,
code you can actually run, image understanding, web search, voice input, and a learning
memory — all behind one warm paper-and-ink interface.

It works in **two modes**:

- **Chat** — ask a question, get an answer.
- **Cowork** — give it a job instead of a question. It makes a plan, works through it step
  by step, writes real files, runs real code, asks you before it deletes anything, and hands
  back finished work you can open, edit and download as a zip.

And you can drive the whole thing by voice, in English, Roman Urdu or Urdu script.

**It runs with zero configuration and zero API keys.** With no keys at all you still get a
working chat (maths, time, identity, and anything Ash has already learned). Paste one free
key in the Control Panel and the full engines switch on.

---

## Quick start

```bash
npm install
npm run dev
```

Open <http://localhost:3000>. That is the whole setup — the database file is created for you
at `./data/app.db` on the first request.

Then open <http://localhost:3000/owner> and paste one free key. The Control Panel is open
until you decide to lock it — there is no password to invent before you can use anything.

### Scripts

| Script | What it does |
| --- | --- |
| `npm run dev` | Development server on `0.0.0.0:3000` |
| `npm run build` | Production build |
| `npm run start` | Serve the production build |
| `npm run lint` | ESLint (flat config, `eslint-config-next`) |
| `npm run typecheck` | `tsc --noEmit` |

Requires **Node 20.9+**.

---

## Where to get free keys

Every engine below has a genuinely free tier. You only need **one**. Paste it at `/owner` →
card 1, or put it in `.env` (see `.env.example`). Keys pasted in the Control Panel are stored
in your own database and merged into the server environment on every request, so they also
work on read-only hosts such as Vercel.

| Shown to users as | Service | Get a key |
| --- | --- | --- |
| **Ash Pro** *(leads)* | Google Gemini (AI Studio) | <https://aistudio.google.com/app/apikey> |
| Ash Open | OpenRouter (`:free` models) | <https://openrouter.ai/keys> |
| Ash Turbo | Groq | <https://console.groq.com/keys> |
| Ash Turbo X | Cerebras | <https://cloud.cerebras.ai/> |
| Ash Swift | Mistral | <https://console.mistral.ai/api-keys> |
| Ash Flash | Z.ai (GLM) | <https://z.ai/manage-apikey/apikey-list> |
| Ash Nitro | NVIDIA NIM | <https://build.nvidia.com/> |
| Ash Sage | Cohere | <https://dashboard.cohere.com/api-keys> |
| Ash Euro | Scaleway | <https://console.scaleway.com/generative-api/models> |
| Ash Open+ | Hugging Face Router | <https://huggingface.co/settings/tokens> |
| Ash Edge | Cloudflare Workers AI | <https://dash.cloudflare.com/profile/api-tokens> |
| Ash Local | Ollama / LM Studio | <https://ollama.com/download> (set `OPENAI_BASE_URL`) |

Visitors never see any of those service names. The browser only ever receives public codes
such as `ash-core`, `ash-turbo` or `ash-basic`.

### Always-available engines (no key, no network)

| Engine | What it does |
| --- | --- |
| **Ash Smart** | Answers instantly from memory, otherwise calls the live engines. |
| **Ash Memory** | Only what Ash has already learned. Fully offline. |
| **Ash Basic** | Maths, time and date, and identity questions. Always works. |

---

## When Ash does not know

Ash never pads the chat to look busy. If it is not confident, it replies with **one short
line** — an apology and an honest promise — and then stops:

> Sorry — I don't properly know this one yet. I'm working on it and will have it soon.
>
> *Maaf kijiye, is baare mein mujhe abhi theek se nahi pata. Main is par kaam kar raha hun aur jald seekh lunga.*
>
> معاف کیجیے، اس بارے میں مجھے ابھی ٹھیک سے معلوم نہیں۔ میں اس پر کام کر رہا ہوں اور جلد سیکھ لوں گا۔

That promise is real: every unanswered question is pushed onto the learning queue, so the
training loop picks it up and Ash knows it next time. The same rule is written into the
system prompt for the live engines — no "Great question!", no restating the question, no
vaguely related filler, no invented names, numbers, dates or links.

## Agents — only what the question needs

Ash runs a small capability layer instead of throwing every tool at every message.
A central orchestrator asks each agent *"should you run?"*, runs the few that say yes in
priority order, and stops the moment one has a complete answer.

| Agent | Runs when | What it does |
| --- | --- | --- |
| **Calculator** | the whole message is a sum | Answers instantly, costs no engine quota |
| **Memory** | Ash Smart / Ash Memory | Checks what Ash already learned first |
| **Web search** | the question needs current facts | Fetches live results and keeps the links as real citations |

Each one is a switch in Control Panel card 3, and a failing agent can never break an
answer — the orchestrator swallows the tool error and carries on without it. New tools
(file analysis, code execution, calculators) drop into `src/lib/agents/registry.ts`
without touching the chat engine.

## How answering works

**Ash Pro (Gemini) leads.** Every visitor opens on it, and it is the first engine tried.
If Ash Pro has no key yet, the app opens on whichever engine *does* have one — and anyone
who was left on an offline engine is moved up automatically the moment a key is added.
When its quota runs out, Ash does not just take the next name on a list — it hands over to
the engine that has **trained Ash the most**, measured by how many answers that engine has
contributed to the knowledge memory.

```
your message
   └─ identity question?        → answered locally, instantly
   └─ Ash Smart / Ash Memory?   → checked against the learned memory first
   └─ otherwise
        Ash Pro  (the leader — whichever engine you set as primary)
          → other models from the same engine
          → the best-trained remaining engine, then the next best…
          → your manual order breaks ties
          → Ash Basic, last
```

Both the engine that opens first and the "hand over to the best-trained engine" rule live in
Control Panel card 2, with a live table showing each engine's trained count, health and the
exact hand-over order Ash will use.

* Streaming uses Server-Sent Events: `meta → notice? → model → delta* → error? → done`.
* An engine is skipped on `400/401/403/404/408/429/5xx`, network errors, or if it has not sent
  a first token in 30 s (45 s when images are attached). A 400 never ends the chain — several
  providers (Gemini included) answer 400 when the key itself is wrong, so the next engine
  still gets its turn.
* Once text has started arriving, Ash never swaps engines mid-answer.
* Failing engines are parked in a circuit breaker (`provider_state`) with a cooldown you can
  watch and clear from the Control Panel.

---

## Cowork — give it a job, not a question

Switch the header from **Chat** to **Cowork**, write what you want to end up with, and press
Start. Then watch it work.

> *"Make a CSV of the five biggest cities in Pakistan with their populations, then write a
> short summary.md explaining what the numbers show."*

**What you see while it runs**

- the **plan** it wrote for itself, ticking off as each piece actually lands
- a **live feed** of every step: the tool it chose, what it wrote, what came back
- the **files** it has made so far, updating as they appear

**What it can actually do** — write, append, read, list and delete files · run code in
Python, JavaScript, C, C++, Java, Go, Rust, Ruby, PHP and more · search the web · generate
images · and finish with a summary of what it produced.

**You stay in charge**

- **Steer it mid-run** — type a correction while it is working and it folds it into the next step
- **Pause**, resume, or restart from the top
- **Deleting anything stops and asks you first.** Approve or reject. (You can turn
  auto-approve on in the Control Panel if you trust it.)
- **Edit any file it made**, by hand, right in the panel
- **Download** a single file, or the whole task as a `.zip` with a `TASK-LOG.md` of
  everything that happened

Each task is private to you, sandboxed to its own workspace, and capped (24 steps and 60
files by default — both adjustable).

---

## The Control Panel (`/owner`)

Open from the first visit. **Lock it with a password whenever you want to** — until then
nothing nags you. Once set, the password is scrypt-hashed in the database, with an
HMAC-signed `httpOnly` cookie valid for 30 days and 5 login attempts per minute per IP.

1. **Free engine keys** — paste, mask, test, enable/disable, choose which models are exposed,
   add any custom OpenAI-compatible engine.
2. **Which engine leads, and what takes over** — pick the engine that opens first (Ash Pro by
   default), switch the best-trained hand-over on or off, see each engine's trained count,
   drag to set the tie-breaker order, watch the cooldown table and reset it.
3. **Free web access** — DuckDuckGo and Wikipedia need no key; SearXNG, Tavily, Brave and
   Serper are optional. Auto / Always / Never, plus "read the best page".
4. **Chat limits & access** — per-visitor and per-IP limits, message length, image count,
   require login, allow media, today's counters.
5. **Training / Learning** — start or stop the background learner, queue your own questions,
   test the memory, export the dataset as JSONL, clear everything.
6. **Branding** — AI name, creator, country, city and the default system prompt.
7. **Lock this panel** — set a password when you feel like it; every old login is signed out.
8. **Voice** — listening engine, speaking engine, voice, speed, volume, language, auto-speak,
   hands-free.
9. **Cowork & spoken control** — turn Cowork on or off, set the step budget per task,
   auto-approve destructive actions, turn spoken commands on or off, set your own wake word,
   and read the full list of things you can say.
10. **Backup** — download everything (never the keys) or restore it.

---

## Talking to Ash

Ash listens and speaks. Press the microphone in the header (or the small one in the
composer), say something, and the answer comes back written **and** spoken.

**It needs no key and no setup.** The default engines are the ones already inside the
browser — Web Speech recognition and the device's own voices — so it is free, instant and
works offline. Everything is swappable from Settings:

| | Default (no key) | Upgrades you can switch on |
| --- | --- | --- |
| **Listening** | This device's recogniser | Fast Whisper (reuses `GROQ_API_KEY`), Open Whisper (`HF_TOKEN`), or any Whisper server you run |
| **Speaking** | This device's voices | Natural Voice (`ELEVENLABS_API_KEY`), Open Voice (`HF_TOKEN`, has real Urdu/Hindi/Arabic/Persian voices), or a local Kokoro/Piper server |

Both sides fall back on their own: if a server engine errors or hits a free-tier limit, Ash
drops to the device engine mid-sentence rather than going quiet. If speech fails entirely,
the text chat carries on untouched.

**Controls** — big animated microphone with clear *listening / thinking / speaking* states,
a read-aloud button on every answer, tap-to-talk or push-to-talk, and **hands-free mode**
where the microphone reopens by itself after Ash finishes speaking. Talking over Ash
interrupts it immediately. Code blocks, tables and markdown are stripped before speaking so
it reads like a person, not a document.

**Spoken commands** — you can run the app without touching it. Say *"Ash, new chat"*,
*"read that again"*, *"dark mode"*, *"stop"*, *"make a picture of a snow leopard"*,
*"search the web for today's gold rate"*, *"switch to cowork"*, *"start the task"*,
*"approve"*, *"download the zip"* — about thirty commands, each understood in English,
Roman Urdu (*"nayi chat"*, *"ruk jao"*, *"tasveer banao"*) and Urdu script.

Dictation stays the default, so ordinary sentences are typed, not obeyed. A sentence only
becomes a command when you start it with a wake word (*"Ash, …"* or your own), or when you
turn Command mode on — except *stop*, which always works. Say *"what can I say"* and Ash
reads the list out.

**Languages** — text language and voice language are set separately. Leave the reply
language on *Match my message* and Ash mirrors whatever you wrote; pin it to Urdu, Roman
Urdu, Hindi, Arabic, Persian, Punjabi or English and it stays there whatever you type. The
voice locale list covers 15 languages for both listening and speaking.

## Pictures and clips

| | Without any key | With one free key |
| --- | --- | --- |
| **Image** | Works. The keyless service allows about one picture a minute; Ash shows the exact countdown instead of a vague error. | Instant, no gate. |
| **Clip** | A **motion clip**: one generated still with a real slow push-in and drift, rendered on a canvas and saved as WebM. Ready in a few seconds. | A true **frame-by-frame** clip, six frames generated three at a time. |

Add `HF_TOKEN` (free, 30 seconds to create at <https://huggingface.co/settings/tokens>),
`TOGETHER_API_KEY` or `GEMINI_API_KEY` in the Control Panel to unlock the faster path.
Clips are stored in the conversation as a fenced `ash-clip` block, so they still play after
a reload and travel inside a backup.

> Every outbound request uses `cache: "no-store"`. The framework's fetch cache corrupts
> binary bodies, which silently broke image generation until it was pinned down.

## Learning (memory, not fine-tuning)

Ash saves good answers so it can reply instantly next time, even offline. Nothing is saved
unless it passes every quality gate: at least 200 characters, from a real engine (never the
offline one), not an apology or an error, not a disambiguation page, and it must actually
address the question. Duplicates are merged by a normalised question key — the longer answer
wins. Recall uses BM25 plus term coverage, and only answers above a 0.72 similarity score.

Scraped web text is **never** stored as an AI answer. Search results are used to ground a
live answer and are then discarded.

Learning runs as a **pool of parallel workers**, each starting at a different engine in the
fallback order so no single free key gets hammered. Pick a speed in card 5:

| Speed | Workers at once |
| --- | --- |
| Gentle | 2 |
| Normal | 4 |
| Fast | 8 |
| Turbo | 12 |

The card shows live throughput (saved per minute), what each worker is doing right now, and
why anything was rejected. The search index behind recall is built once and reused until a
write changes it, so neither chat nor training rescans the table per question.

Export the dataset at any time from card 5 — one JSONL line per example, ready for a real
fine-tune elsewhere.

---

## Running code

Fenced code blocks get a **Run** button for Python, JavaScript, TypeScript, C, C++, Java,
Rust, Go, PHP, Ruby, C#, SQL, Lua, Perl, Swift, R, Haskell, Scala and Bash. Execution happens
on the free [Wandbox](https://wandbox.org) service — the newest working compiler is resolved
at runtime, so the buttons keep working as versions change. Limits: 20 runs/minute/IP, a 30 s
timeout and 20 KB of output.

HTML, CSS, SVG, JSX/TSX and browser JavaScript get a **Preview** button instead, which renders
in a sandboxed `<iframe sandbox="allow-scripts">` side panel — plus a **Run** pill in the
header for the newest previewable block.

---

## Context and memory

History is trimmed by a **token budget**, not a message count. Ash keeps the newest turns
that fit, always keeps the first message as an anchor so a long chat does not forget its own
subject, and tells you in the notice bar when older turns were dropped. The budget is a
number in Control Panel card 4 (12,000 tokens by default).

Long-term memory is separate from conversation history, and the person chatting controls it:
**Settings → Memory** turns it off entirely for them, independently of the owner's switch.

## Storage

Storage is automatic. There is nothing to choose.

| `DATABASE_URL` | What happens |
| --- | --- |
| *(empty)* | SQLite file at `./data/app.db`, created on first use |
| `postgres://…` | Postgres |
| `libsql://…` | Turso (set `DATABASE_AUTH_TOKEN` too) |

Tables (`conversations`, `messages`, `knowledge`, `harvest_queue`, `provider_state`,
`app_settings`) are created automatically on the first request. There is no migration step.

Each visitor gets an `httpOnly` `ash_vid` cookie and every conversation is scoped by
`owner_key`, so nobody can see anyone else's chats — not even the owner, unless that switch
is turned on.

---

## Privacy

* Vendor names, model ids and API keys never reach the browser. Only public codes do.
* Error messages are scrubbed of anything that looks like a key before being shown.
* Security headers are set in `src/middleware.ts`.
* Page reading is SSRF-guarded: private, loopback and link-local addresses are refused.

---

## Project layout

```
src/
  app/            routes + the three pages (/, /login, /owner)
    api/          chat, conversations, models, settings, image, video, run,
                  auth, owner, backup, learn, knowledge, system, storage,
                  voice, cowork
  components/     ChatApp, Sidebar, Composer, MessageItem, Markdown, CodeBlock,
                  CodePreview, ModelPicker, SettingsDialog, EmptyState, Splash,
                  ThemeToggle, Icons, VideoClip, LoginGate, OwnerGate, ControlPanel,
                  VoiceOrb, VoiceSettings, CoworkPanel, CoworkFileView
  lib/
    providers/    catalog (edit this to add engines), gemini, openai-compatible,
                  demo, health, sse
    cowork/       the agent loop, its tools, its store, and the zip writer
    voice/        listening + speaking engines, and the spoken-command parser
    pwa.ts        install prompt + service-worker registration
public/
  manifest.webmanifest, sw.js, offline.html, icons/
    search/       DuckDuckGo, Wikipedia, SearXNG, Tavily, Brave, Serper + page reader
    knowledge/    quality gates, BM25 recall, question generator, trainer
    images/       Pollinations, Hugging Face, Together, Gemini
    code/         runnable languages + the preview document builder
    db/           schema, dialect-aware driver, repository
    auth/         owner password, visitor identity
    settings/     settings + key storage
```

**To add or change an engine, edit `src/lib/providers/catalog.ts`** — or just add a custom
OpenAI-compatible engine from the Control Panel, no code needed.

---

## Install it as an app

Ash is a progressive web app, so it installs on a phone and on a computer with
no store and no account.

| Device | How |
| --- | --- |
| **Android** | Settings → **Install as an app**, or the Chrome menu → *Install app* |
| **iPhone / iPad** | Safari → Share → **Add to Home Screen** |
| **Windows / Mac / Linux** | The install icon in the address bar, or Settings → **Install as an app** |

You get your own icon, your own window with no browser bars, three app shortcuts
(new chat, new Cowork task, Control Panel), and a real offline page instead of
the browser's dinosaur. Installing needs HTTPS — any of the hosts in
[DEPLOY.md](./DEPLOY.md) give you that free.

Want it in the Play Store, the App Store, or as a `.exe`?
[MOBILE-AND-DESKTOP.md](./MOBILE-AND-DESKTOP.md) has each route with its real
cost and the exact commands.

---

## Deploying

See [DEPLOY.md](./DEPLOY.md) for Vercel, Docker, a plain VPS, and Turso/Postgres.
