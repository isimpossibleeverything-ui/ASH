Built by scripts/assemble-desktop.mjs — not checked in.
