import nextCoreWebVitals from "eslint-config-next/core-web-vitals";
import nextTypescript from "eslint-config-next/typescript";

const asArray = (config) => (Array.isArray(config) ? config : [config]);

const eslintConfig = [
  {
    ignores: [".next/**", "node_modules/**", "data/**", "out/**", "build/**", "public/**", "next-env.d.ts"],
  },
  ...asArray(nextCoreWebVitals),
  ...asArray(nextTypescript),
  {
    rules: {
      "@typescript-eslint/no-explicit-any": "off",
      "@typescript-eslint/no-unused-vars": ["error", { argsIgnorePattern: "^_", varsIgnorePattern: "^_" }],
      "react-hooks/exhaustive-deps": "warn",
      // Mount-time synchronisation with the DOM / localStorage / feature
      // detection is intentional here, so keep this as advice, not an error.
      "react-hooks/set-state-in-effect": "warn",
    },
  },
];

export default eslintConfig;
