import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  // The desktop app carries its own server, which has to be self-contained.
  // The hosted build is untouched.
  ...(process.env.ASH_DESKTOP ? { output: "standalone" as const } : {}),
  serverExternalPackages: ["@libsql/client", "libsql", "postgres"],
  allowedDevOrigins: ["*.e2b.app", "*.app.github.dev", "*.vercel.app"],
  typescript: { ignoreBuildErrors: false },
  // the floating dev badge sits on top of the sidebar footer — it is dev-only anyway
  devIndicators: false,
};

export default nextConfig;
