# Ash Lite — the no-Tauri Windows build

The full desktop app (`../src-tauri`) is a Tauri 2 shell that GitHub Actions
builds into a signed-ready installer. This folder is the fallback: a Windows
installer that can be produced **on any machine, including this Linux sandbox**,
with nothing but mingw and NSIS.

What is the same as the full app: Chat, Cowork, voice, training, settings —
the whole Ash server ships inside, with its own private copy of Node, and the
database lives in `%APPDATA%\Ash`.

What is missing: the **Computer** mode. That needs the Tauri shell's IPC and
permission gate, which this launcher does not have. The panel in the app says
so honestly instead of pretending.

## Layout

```
portable/
  Cargo.toml       launcher — pure std Rust, cross-compiles in seconds
  src/main.rs      starts payload Node, waits, opens the browser; Enter stops
  installer.nsi    NSIS script: per-user install, Start Menu + optional
                   desktop shortcut, Add/Remove entry, uninstaller
```

## Building (from the repo root)

```bash
# 1 — the launcher .exe
cd portable
CARGO_TARGET_X86_64_PC_WINDOWS_GNU_LINKER=x86_64-w64-mingw32-gcc \
  cargo build --release --target x86_64-pc-windows-gnu
cd ..

# 2 — the payload (standalone server + private Node for Windows)
ASH_DESKTOP=1 npm run build
ASH_TARGET_OS=win32 node scripts/assemble-desktop.mjs

# 3 — the installer
mkdir -p /tmp/lite && cd /tmp/lite
cp ../ash/portable/target/x86_64-pc-windows-gnu/release/ash-lite.exe Ash.exe
cp ../ash/src-tauri/icons/icon.ico .
cp -r ../ash/desktop/payload payload
cp ../ash/portable/installer.nsi .
makensis installer.nsi        # -> Ash-Setup.exe
```

The same NSIS payload is what `scripts/assemble-desktop.mjs` produces for the
Tauri build, so the two paths never drift apart.
