; Ash — Lite installer (no Tauri shell; Chat, Cowork, voice and training all included)
;
; Build it from a staging folder that contains:
;   Ash.exe  icon.ico  payload/  installer.nsi
; then run:  makensis installer.nsi

!include "MUI2.nsh"

Name "Ash"
OutFile "Ash-Setup.exe"
Unicode true
SetCompressor /SOLID lzma

; Per-user install: no admin prompt, no UAC.
InstallDir "$LOCALAPPDATA\Programs\Ash"
InstallDirRegKey HKCU "Software\AshLite" "InstallDir"
RequestExecutionLevel none

!define MUI_ICON "icon.ico"
!define MUI_UNICON "icon.ico"
!define MUI_ABORTWARNING

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_COMPONENTS
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!define MUI_FINISHPAGE_RUN "$INSTDIR\Ash.exe"
!define MUI_FINISHPAGE_RUN_TEXT "Launch Ash now"
!insertmacro MUI_PAGE_FINISH

!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

!insertmacro MUI_LANGUAGE "English"

Section "Ash (required)" SEC_CORE
  SectionIn RO
  SetOutPath "$INSTDIR"
  File "Ash.exe"
  File "icon.ico"
  File /r "payload"

  CreateShortCut "$SMPROGRAMS\Ash.lnk" "$INSTDIR\Ash.exe" "" "$INSTDIR\icon.ico" 0
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  WriteRegStr HKCU "Software\AshLite" "InstallDir" "$INSTDIR"

  ; Shows up in Add/Remove Programs as "Ash (Lite)"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\Ash Lite" "DisplayName" "Ash (Lite)"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\Ash Lite" "DisplayVersion" "1.0.0"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\Ash Lite" "Publisher" "Ash Labs"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\Ash Lite" "InstallLocation" "$INSTDIR"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\Ash Lite" "UninstallString" "$\"$INSTDIR\Uninstall.exe$\""
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\Ash Lite" "NoModify" 1
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\Ash Lite" "NoRepair" 1
SectionEnd

Section "Desktop shortcut" SEC_DESKTOP
  CreateShortCut "$DESKTOP\Ash.lnk" "$INSTDIR\Ash.exe" "" "$INSTDIR\icon.ico" 0
SectionEnd

Section "Uninstall"
  Delete "$SMPROGRAMS\Ash.lnk"
  Delete "$DESKTOP\Ash.lnk"
  Delete "$INSTDIR\Ash.exe"
  Delete "$INSTDIR\icon.ico"
  Delete "$INSTDIR\Uninstall.exe"
  RMDir /r "$INSTDIR\payload"
  RMDir "$INSTDIR"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\Ash Lite"
  DeleteRegKey HKCU "Software\AshLite"
  ; Your chats and knowledge live in %APPDATA%\Ash and are intentionally kept.
SectionEnd
