// Ash Lite — the small Windows launcher for the no-Tauri build.
//
// It starts the private copy of Node that ships next to it, runs the Ash
// server on a free loopback port, waits for it to be ready, and opens the
// browser. The console window doubles as the stop button: press Enter (or
// close the window) and Ash stops.
//
// Pure std — no windows crates, so it cross-compiles from Linux in seconds
// and there is nothing in here that can trip a first build.

use std::io::{self, BufRead, Write};
use std::net::{SocketAddr, TcpListener, TcpStream};
use std::path::{Path, PathBuf};
use std::process::{Child, Command};
use std::time::{Duration, Instant};

fn main() {
    if let Err(msg) = run() {
        eprintln!();
        eprintln!("Ash could not start: {}", msg);
        eprintln!();
        eprintln!("You can close this window. If this keeps happening, ask for help.");
        pause();
    }
}

fn run() -> Result<(), String> {
    let root = std::env::current_exe()
        .ok()
        .and_then(|p| p.parent().map(|p| p.to_path_buf()))
        .ok_or_else(|| "could not locate this program".to_string())?;

    let node = root.join("payload").join("node").join("node.exe");
    let server = root.join("payload").join("server").join("server.js");
    if !node.is_file() {
        return Err(format!("missing {}", node.display()));
    }
    if !server.is_file() {
        return Err(format!("missing {}", server.display()));
    }

    let data = data_root();
    std::fs::create_dir_all(&data)
        .map_err(|e| format!("could not create {}: {}", data.display(), e))?;

    // Already running from an earlier double-click? Just open the browser.
    if let Some(port) = saved_port(&data) {
        println!("Ash is already running. Opening it in your browser...");
        open_browser(port);
        pause();
        return Ok(());
    }

    let port = free_port().ok_or_else(|| "could not find a free port".to_string())?;
    std::fs::write(data.join("port.txt"), port.to_string())
        .map_err(|e| format!("could not write the port file: {}", e))?;

    println!("Ash is waking up. The first run can take a little while...");
    flush();

    let server_dir = server.parent().map(|p| p.to_path_buf()).unwrap_or(root);
    let mut child: Child = Command::new(&node)
        .arg(&server)
        .env("PORT", port.to_string())
        .env("HOSTNAME", "127.0.0.1")
        .env("NODE_ENV", "production")
        .env("ASH_DATA_DIR", &data)
        .current_dir(&server_dir)
        .spawn()
        .map_err(|e| format!("could not start the server: {}", e))?;

    let start = Instant::now();
    let mut ready = false;
    while start.elapsed() < Duration::from_secs(90) {
        match child.try_wait() {
            Ok(Some(_)) => {
                let _ = std::fs::remove_file(data.join("port.txt"));
                return Err("the server stopped on its own".to_string());
            }
            Ok(None) => {}
            Err(_) => {}
        }
        if TcpStream::connect_timeout(&addr(port), Duration::from_millis(300)).is_ok() {
            ready = true;
            break;
        }
        std::thread::sleep(Duration::from_millis(300));
    }

    if !ready {
        let _ = child.kill();
        let _ = std::fs::remove_file(data.join("port.txt"));
        return Err("the server did not come up within 90 seconds".to_string());
    }

    println!();
    println!("Ash is ready.");
    println!("A browser window should open at http://127.0.0.1:{}", port);
    println!("If it does not, open that address yourself in any browser.");
    println!();
    println!("Keep this window open while you use Ash.");
    println!("Press Enter here (or close this window) to stop Ash.");
    flush();

    let _ = io::stdin().lock().read_line(&mut String::new());
    let _ = child.kill();
    let _ = std::fs::remove_file(data.join("port.txt"));
    println!("Ash has stopped. You can close this window.");
    pause();
    Ok(())
}

fn data_root() -> PathBuf {
    if let Ok(ad) = std::env::var("APPDATA") {
        if !ad.trim().is_empty() {
            return PathBuf::from(ad).join("Ash");
        }
    }
    std::env::current_dir().unwrap_or_default().join("data")
}

fn saved_port(data: &Path) -> Option<u16> {
    let txt = std::fs::read_to_string(data.join("port.txt")).ok()?;
    let port: u16 = txt.trim().parse().ok()?;
    let live = TcpStream::connect_timeout(&addr(port), Duration::from_millis(400)).is_ok();
    if live {
        Some(port)
    } else {
        None
    }
}

fn free_port() -> Option<u16> {
    let l = TcpListener::bind(("127.0.0.1", 0)).ok()?;
    Some(l.local_addr().ok()?.port())
}

fn addr(port: u16) -> SocketAddr {
    SocketAddr::from(([127, 0, 0, 1], port))
}

fn open_browser(port: u16) {
    let _ = Command::new("cmd")
        .arg("/C")
        .arg("start")
        .arg("")
        .arg(format!("http://127.0.0.1:{}", port))
        .spawn();
}

fn flush() {
    let _ = io::stdout().flush();
}

fn pause() {
    println!();
    println!("Press Enter to close this window...");
    flush();
    let _ = io::stdin().lock().read_line(&mut String::new());
}
