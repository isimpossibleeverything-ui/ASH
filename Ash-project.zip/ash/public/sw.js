/* Ash service worker.
   Deliberately conservative: it must never serve a stale answer and must never
   get in the way of a stream.

   Rules
   • Anything that is not a same-origin GET is passed straight through.
   • /api/** is ALWAYS network — chat and Cowork are SSE streams; caching them
     would break them, and a cached answer would be a lie.
   • Hashed build assets are cache-first (their URL changes when they change).
   • Pages are network-first with a cached copy as the safety net, and a real
     offline page if there is nothing at all.
*/

const VERSION = "ash-v1";
const SHELL = `${VERSION}-shell`;   // offline page, icons, manifest
const ASSETS = `${VERSION}-assets`; // hashed /_next/static files
const PAGES = `${VERSION}-pages`;   // last good HTML per route

const PRECACHE = ["/offline.html", "/icons/icon-192.png", "/icons/icon-512.png", "/manifest.webmanifest"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(SHELL)
      .then((c) => c.addAll(PRECACHE))
      .then(() => self.skipWaiting())
      .catch(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k)));
      await self.clients.claim();
    })(),
  );
});

// lets the page tell a waiting worker to take over immediately
self.addEventListener("message", (event) => {
  if (event.data === "skip-waiting") self.skipWaiting();
});

const isHashedAsset = (url) =>
  url.pathname.startsWith("/_next/static/") || url.pathname.startsWith("/icons/") || url.pathname === "/theme.js";

async function cacheFirst(request, cacheName) {
  const cache = await caches.open(cacheName);
  const hit = await cache.match(request);
  if (hit) return hit;
  const res = await fetch(request);
  if (res && res.ok) cache.put(request, res.clone());
  return res;
}

async function networkFirstPage(request) {
  const cache = await caches.open(PAGES);
  try {
    const res = await fetch(request);
    if (res && res.ok) cache.put(request, res.clone());
    return res;
  } catch {
    const hit = (await cache.match(request)) || (await cache.match("/"));
    if (hit) return hit;
    const shell = await caches.open(SHELL);
    const offline = await shell.match("/offline.html");
    return (
      offline ??
      new Response("<h1>Offline</h1>", { status: 503, headers: { "content-type": "text/html; charset=utf-8" } })
    );
  }
}

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  // never touch the API: streams, auth, uploads, downloads
  if (url.pathname.startsWith("/api/")) return;

  // range requests (audio/video seeking) must not be cached
  if (req.headers.has("range")) return;

  if (isHashedAsset(url)) {
    event.respondWith(cacheFirst(req, ASSETS).catch(() => fetch(req)));
    return;
  }

  if (req.mode === "navigate" || (req.headers.get("accept") || "").includes("text/html")) {
    event.respondWith(networkFirstPage(req));
    return;
  }

  event.respondWith(
    fetch(req).catch(async () => {
      const hit = await caches.match(req);
      if (hit) return hit;
      throw new Error("offline");
    }),
  );
});
