/* Optional. CSS already paints the right theme from prefers-color-scheme, so
   nothing here can cause a flash. This only pins an explicit choice the user
   made earlier, and keeps it out of the React tree (React 19 warns about
   <script> elements rendered inside components). */
(function () {
  try {
    var t = localStorage.getItem("theme");
    if (t === "dark" || t === "light") {
      document.documentElement.classList.add(t);
      document.documentElement.classList.remove(t === "dark" ? "light" : "dark");
    }
  } catch {
    /* storage blocked: CSS already picked the right theme */
  }
})();
