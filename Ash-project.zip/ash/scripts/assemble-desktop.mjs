#!/usr/bin/env node
/* Build the payload the desktop app carries inside it.
 *
 *   desktop/payload/
 *     server/            ← the Next.js standalone server, ready to run
 *       server.js
 *       .next/static/
 *       public/
 *     node/node.exe      ← a private copy of Node, so nothing has to be installed
 *
 * Run AFTER `ASH_DESKTOP=1 npm run build`.
 *   node scripts/assemble-desktop.mjs            (host platform)
 *   node scripts/assemble-desktop.mjs --no-node  (skip the runtime download)
 */

import { createWriteStream } from "node:fs";
import { cp, mkdir, rm, access, readFile, writeFile, chmod, readdir } from "node:fs/promises";
import { createRequire } from "node:module";
import { pipeline } from "node:stream/promises";
import { execFileSync } from "node:child_process";
import path from "node:path";
import os from "node:os";

const require = createRequire(import.meta.url);
const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const PAYLOAD = path.join(ROOT, "desktop", "payload");
const SERVER = path.join(PAYLOAD, "server");
const NODE_DIR = path.join(PAYLOAD, "node");

const NODE_VERSION = process.env.ASH_NODE_VERSION || "v20.18.1";
const skipNode = process.argv.includes("--no-node");

const exists = async (p) => {
  try {
    await access(p);
    return true;
  } catch {
    return false;
  }
};

const say = (m) => console.log(`  ${m}`);

async function assembleServer() {
  const standalone = path.join(ROOT, ".next", "standalone");
  if (!(await exists(standalone))) {
    throw new Error(
      'No standalone build found. Run:  ASH_DESKTOP=1 npm run build   (on Windows: set ASH_DESKTOP=1 && npm run build)',
    );
  }

  await rm(SERVER, { recursive: true, force: true });
  await mkdir(SERVER, { recursive: true });

  // 1 — the traced server and its node_modules
  await cp(standalone, SERVER, { recursive: true });

  // 2 — Next deliberately leaves these two out of the trace
  const staticFrom = path.join(ROOT, ".next", "static");
  if (await exists(staticFrom)) {
    await cp(staticFrom, path.join(SERVER, ".next", "static"), { recursive: true });
    say("copied .next/static");
  }
  const publicFrom = path.join(ROOT, "public");
  if (await exists(publicFrom)) {
    await cp(publicFrom, path.join(SERVER, "public"), { recursive: true });
    say("copied public/");
  }

  // 3 — @libsql ships a native binding that tracing sometimes misses
  for (const pkg of ["@libsql/client", "libsql"]) {
    try {
      const from = path.dirname(require.resolve(`${pkg}/package.json`));
      const to = path.join(SERVER, "node_modules", pkg);
      if (!(await exists(to))) {
        await cp(from, to, { recursive: true });
        say(`copied ${pkg} by hand`);
      }
    } catch {
      /* not installed on this platform — the trace will have handled it */
    }
  }

  // 4 — Next's file tracing happily sweeps up the developer's own database
  //     and env files. Those must never ride along inside an installer.
  for (const leak of ["data", ".env", ".env.local", ".env.production", ".env.production.local"]) {
    const at = path.join(SERVER, leak);
    if (await exists(at)) {
      await rm(at, { recursive: true, force: true });
      say(`removed ${leak} — that belongs to this machine, not the installer`);
    }
  }

  if (!(await exists(path.join(SERVER, "server.js")))) {
    throw new Error("standalone/server.js is missing — the build did not produce a server.");
  }

  // 5 — native bindings must match the TARGET, not this machine. A payload
  //     assembled on Linux carries the Linux .node file; the Windows build
  //     needs the Windows one. Swap them so the payload always matches.
  await fixNatives();
  say(`server ready at desktop/payload/server`);
}

function nodeArchive() {
  const platform = process.env.ASH_TARGET_OS || os.platform();
  const arch = process.env.ASH_TARGET_ARCH || os.arch();
  const a = arch === "arm64" ? "arm64" : "x64";
  if (platform === "win32") return { name: `node-${NODE_VERSION}-win-${a}`, ext: "zip", bin: "node.exe" };
  if (platform === "darwin") return { name: `node-${NODE_VERSION}-darwin-${a}`, ext: "tar.gz", bin: "bin/node" };
  return { name: `node-${NODE_VERSION}-linux-${a}`, ext: "tar.gz", bin: "bin/node" };
}

const TARGET_OS = process.env.ASH_TARGET_OS || os.platform();
const TARGET_ARCH = process.env.ASH_TARGET_ARCH || os.arch();
const LIBSQL_BINDING =
  TARGET_OS === "win32" && TARGET_ARCH === "x64"
    ? "@libsql/win32-x64-msvc"
    : TARGET_OS === "darwin" && TARGET_ARCH === "x64"
      ? "@libsql/darwin-x64"
      : TARGET_OS === "darwin" && TARGET_ARCH === "arm64"
        ? "@libsql/darwin-arm64"
        : null;

async function fixNatives() {
  if (!LIBSQL_BINDING) return; // host-target build — the trace is already right
  const hosts = {
    "linux-x64": "@libsql/linux-x64-gnu",
    "win32-x64": "@libsql/win32-x64-msvc",
    "darwin-x64": "@libsql/darwin-x64",
    "darwin-arm64": "@libsql/darwin-arm64",
  };
  if (hosts[`${os.platform()}-${os.arch()}`] === LIBSQL_BINDING) return;

  const bindingName = LIBSQL_BINDING.split("/")[1];
  const scopes = [
    path.join(SERVER, "node_modules", "@libsql"),
    path.join(SERVER, "node_modules", "libsql", "node_modules", "@libsql"),
    path.join(SERVER, "node_modules", "@libsql", "client", "node_modules", "@libsql"),
  ];
  let haveIt = false;
  for (const scope of scopes) {
    if (!(await exists(scope))) continue;
    for (const ent of await readdir(scope, { withFileTypes: true })) {
      if (!ent.isDirectory() || !/^(win32|darwin|linux|freebsd|android)-/.test(ent.name)) continue;
      if (ent.name === bindingName) {
        haveIt = true;
        continue;
      }
      await rm(path.join(scope, ent.name), { recursive: true, force: true });
      say(`removed the ${ent.name} binding — wrong platform for this payload`);
    }
  }

  // sharp rides along in the trace but Ash never calls next/image, so the
  // platform binaries are dead weight (and broken ones at that). Drop them.
  const imgScope = path.join(SERVER, "node_modules", "@img");
  if (await exists(imgScope)) {
    for (const ent of await readdir(imgScope, { withFileTypes: true })) {
      if (!ent.isDirectory() || !ent.name.startsWith("sharp-")) continue;
      await rm(path.join(imgScope, ent.name), { recursive: true, force: true });
      say(`removed ${ent.name} — image optimization is not used at runtime`);
    }
  }

  if (haveIt) {
    say(`native binding ${bindingName} already present`);
    return;
  }

  let version = "latest";
  try {
    version = JSON.parse(
      await readFile(path.join(SERVER, "node_modules", "libsql", "package.json"), "utf8"),
    ).version;
  } catch {
    /* fall back to whatever npm picks */
  }
  const work = path.join(os.tmpdir(), `ash-native-${Date.now()}`);
  await mkdir(work, { recursive: true });
  say(`fetching ${LIBSQL_BINDING}@${version}`);
  execFileSync(
    "npm",
    ["pack", `${LIBSQL_BINDING}@${version}`, "--pack-destination", work],
    { cwd: work, encoding: "utf8", stdio: ["ignore", "pipe", "inherit"] },
  );
  const packed = (await readdir(work)).find((f) => f.endsWith(".tgz"));
  if (!packed) throw new Error(`npm pack produced no tarball for ${LIBSQL_BINDING}`);
  execFileSync("tar", ["-xzf", path.join(work, packed), "-C", work], { stdio: "inherit" });
  const to = path.join(SERVER, "node_modules", "@libsql", bindingName);
  await mkdir(path.dirname(to), { recursive: true });
  await cp(path.join(work, "package"), to, { recursive: true });
  await rm(work, { recursive: true, force: true }).catch(() => {});
  say(`installed the ${bindingName} binding`);
}

async function fetchNode() {
  const { name, ext, bin } = nodeArchive();
  const url = `https://nodejs.org/dist/${NODE_VERSION}/${name}.${ext}`;
  const tmp = path.join(os.tmpdir(), `${name}.${ext}`);

  say(`downloading ${url}`);
  const res = await fetch(url, { redirect: "follow" });
  if (!res.ok) throw new Error(`Node download failed: ${res.status} ${res.statusText}`);
  await pipeline(res.body, createWriteStream(tmp));

  const workDir = path.join(os.tmpdir(), `ash-node-${Date.now()}`);
  await mkdir(workDir, { recursive: true });
  if (ext === "zip") {
    // bsdtar (what Windows runners ship) reads zips; plain GNU tar does not
    try {
      execFileSync("tar", ["-xf", tmp, "-C", workDir], { stdio: "inherit" });
    } catch {
      execFileSync(
        "python3",
        ["-c", "import sys,zipfile;zipfile.ZipFile(sys.argv[1]).extractall(sys.argv[2])", tmp, workDir],
        { stdio: "inherit" },
      );
    }
  } else {
    execFileSync("tar", ["-xzf", tmp, "-C", workDir], { stdio: "inherit" });
  }

  await rm(NODE_DIR, { recursive: true, force: true });
  await mkdir(NODE_DIR, { recursive: true });
  const from = path.join(workDir, name, bin);
  const outName = bin.endsWith(".exe") ? "node.exe" : "node";
  const to = path.join(NODE_DIR, outName);
  await cp(from, to);
  if (!outName.endsWith(".exe")) await chmod(to, 0o755);
  await rm(workDir, { recursive: true, force: true }).catch(() => {});
  await rm(tmp, { force: true }).catch(() => {});
  say(`bundled ${outName} (${NODE_VERSION})`);
}

async function stamp() {
  await writeFile(
    path.join(PAYLOAD, "BUILD.json"),
    JSON.stringify(
      {
        builtAt: new Date().toISOString(),
        node: NODE_VERSION,
        app: JSON.parse(await readFile(path.join(ROOT, "package.json"), "utf8")).version,
      },
      null,
      2,
    ),
  );
}

console.log("Assembling the Ash desktop payload");
await mkdir(PAYLOAD, { recursive: true });
await assembleServer();
if (skipNode) say("skipped the Node runtime (--no-node)");
else await fetchNode();
await stamp();
console.log("Done. Now run:  npx tauri build");
