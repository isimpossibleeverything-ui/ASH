#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

//! Ash Desktop.
//!
//! Two jobs:
//!   1. Start the bundled Ash server on loopback and show it in a window.
//!   2. Offer the page a small, audited set of commands that touch the real
//!      computer — and refuse every one of them until the person has said yes.
//!
//! The permission model is deliberately boring: nothing is allowed until
//! `desktop_grant` succeeds, the grant dies with the process, file work is
//! fenced inside the one folder that was picked, and anything irreversible
//! asks again even while a grant is live.

use std::{
    fs,
    io::Read,
    net::{SocketAddr, TcpListener, TcpStream},
    path::{Component, Path, PathBuf},
    process::{Child, Command, Stdio},
    sync::{
        atomic::{AtomicBool, Ordering},
        Mutex,
    },
    time::{Duration, Instant, SystemTime, UNIX_EPOCH},
};

use serde::Serialize;
use tauri::{Emitter, Manager, State};
use tauri_plugin_dialog::{DialogExt, MessageDialogButtons, MessageDialogKind};

const MAX_READ_BYTES: u64 = 2 * 1024 * 1024;
const MAX_WRITE_CHARS: usize = 2 * 1024 * 1024;
const MAX_OUTPUT: usize = 20_000;
const COMMAND_TIMEOUT: Duration = Duration::from_secs(120);

/* ─────────────────────────── state ─────────────────────────── */

#[derive(Default)]
struct Shell {
    granted: AtomicBool,
    root: Mutex<Option<PathBuf>>,
    log: Mutex<Vec<Entry>>,
    server: Mutex<Option<Child>>,
    port: Mutex<u16>,
}

#[derive(Clone, Serialize)]
struct Entry {
    at: u64,
    action: String,
    detail: String,
    ok: bool,
}

#[derive(Serialize)]
struct Status {
    available: bool,
    granted: bool,
    root: Option<String>,
    os: String,
    app_version: String,
    port: u16,
}

fn now_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}

impl Shell {
    fn note(&self, action: &str, detail: &str, ok: bool) {
        if let Ok(mut log) = self.log.lock() {
            log.push(Entry {
                at: now_ms(),
                action: action.to_string(),
                detail: detail.chars().take(400).collect(),
                ok,
            });
            let len = log.len();
            if len > 500 {
                log.drain(0..len - 500);
            }
        }
    }

    fn require(&self) -> Result<PathBuf, String> {
        if !self.granted.load(Ordering::SeqCst) {
            return Err(
                "Ash has not been given permission to use this computer yet. Press “Let Ash use this computer” first."
                    .into(),
            );
        }
        self.root
            .lock()
            .ok()
            .and_then(|r| r.clone())
            .ok_or_else(|| "No working folder has been chosen.".to_string())
    }
}

/* ─────────────────────── path fencing ─────────────────────── */

/// Resolve `rel` inside `root` and refuse anything that climbs out.
/// Checked textually first (so a missing file is still fenced) and then
/// again after canonicalising (so a symlink cannot smuggle us out).
fn resolve(root: &Path, rel: &str) -> Result<PathBuf, String> {
    let candidate = Path::new(rel);
    if candidate.is_absolute() {
        // an absolute path is only allowed when it is already inside the root
        let c = candidate.to_path_buf();
        if !c.starts_with(root) {
            return Err(format!(
                "That path is outside the folder you chose. Ash may only work inside {}.",
                root.display()
            ));
        }
        return guard(root, c);
    }
    for part in candidate.components() {
        match part {
            Component::ParentDir => {
                return Err("Paths may not contain “..”.".into());
            }
            Component::Prefix(_) | Component::RootDir => {
                return Err("That path is not allowed.".into());
            }
            _ => {}
        }
    }
    guard(root, root.join(candidate))
}

fn guard(root: &Path, joined: PathBuf) -> Result<PathBuf, String> {
    let real_root = fs::canonicalize(root).unwrap_or_else(|_| root.to_path_buf());
    // canonicalise the deepest part that exists
    let mut probe = joined.clone();
    loop {
        if probe.exists() {
            let real = fs::canonicalize(&probe).unwrap_or_else(|_| probe.clone());
            if !real.starts_with(&real_root) {
                return Err(format!(
                    "That path leaves the folder you chose ({}).",
                    root.display()
                ));
            }
            break;
        }
        match probe.parent() {
            Some(p) if p != probe => probe = p.to_path_buf(),
            _ => break,
        }
    }
    Ok(joined)
}

fn show(path: &Path, root: &Path) -> String {
    path.strip_prefix(root)
        .unwrap_or(path)
        .to_string_lossy()
        .replace('\\', "/")
}

/* ─────────────────────────── commands ─────────────────────────── */

fn status_of(app: &tauri::AppHandle, shell: &Shell) -> Status {
    Status {
        available: true,
        granted: shell.granted.load(Ordering::SeqCst),
        root: shell
            .root
            .lock()
            .ok()
            .and_then(|r| r.clone())
            .map(|p| p.to_string_lossy().to_string()),
        os: std::env::consts::OS.to_string(),
        app_version: app.package_info().version.to_string(),
        port: shell.port.lock().map(|p| *p).unwrap_or(0),
    }
}

#[tauri::command]
fn desktop_status(app: tauri::AppHandle, shell: State<Shell>) -> Status {
    status_of(&app, &shell)
}

/// The permission moment. Opens the real OS folder picker — Ash cannot choose
/// for you, and it cannot see anything until you have picked.
#[tauri::command]
fn desktop_grant(app: tauri::AppHandle, shell: State<Shell>) -> Result<Status, String> {
    let picked = app
        .dialog()
        .file()
        .set_title("Choose the folder Ash may work in")
        .blocking_pick_folder();

    let Some(folder) = picked else {
        shell.note("grant", "cancelled", false);
        return Err("No folder was chosen, so nothing was granted.".into());
    };

    let path: PathBuf = folder
        .into_path()
        .map_err(|e| format!("That folder could not be used: {e}"))?;

    if !path.is_dir() {
        return Err("That is not a folder.".into());
    }

    *shell.root.lock().map_err(|_| "busy")? = Some(path.clone());
    shell.granted.store(true, Ordering::SeqCst);
    shell.note("grant", &path.to_string_lossy(), true);
    let _ = app.emit("desktop-permission", true);

    Ok(status_of(&app, &shell))
}

#[tauri::command]
fn desktop_revoke(app: tauri::AppHandle, shell: State<Shell>) -> Status {
    shell.granted.store(false, Ordering::SeqCst);
    if let Ok(mut r) = shell.root.lock() {
        *r = None;
    }
    shell.note("revoke", "permission withdrawn", true);
    let _ = app.emit("desktop-permission", false);
    status_of(&app, &shell)
}

#[derive(Serialize)]
struct DirEntry {
    name: String,
    path: String,
    is_dir: bool,
    bytes: u64,
}

#[tauri::command]
fn desktop_list(shell: State<Shell>, path: Option<String>) -> Result<Vec<DirEntry>, String> {
    let root = shell.require()?;
    let target = resolve(&root, path.as_deref().unwrap_or(""))?;
    let mut out = Vec::new();
    let read = fs::read_dir(&target).map_err(|e| format!("Could not open that folder: {e}"))?;
    for item in read.flatten() {
        let meta = match item.metadata() {
            Ok(m) => m,
            Err(_) => continue,
        };
        out.push(DirEntry {
            name: item.file_name().to_string_lossy().to_string(),
            path: show(&item.path(), &root),
            is_dir: meta.is_dir(),
            bytes: if meta.is_dir() { 0 } else { meta.len() },
        });
    }
    out.sort_by(|a, b| (b.is_dir, a.name.to_lowercase()).cmp(&(a.is_dir, b.name.to_lowercase())));
    out.truncate(500);
    shell.note("list", &show(&target, &root), true);
    Ok(out)
}

#[tauri::command]
fn desktop_read(shell: State<Shell>, path: String) -> Result<String, String> {
    let root = shell.require()?;
    let target = resolve(&root, &path)?;
    let meta = fs::metadata(&target).map_err(|e| format!("Could not open that file: {e}"))?;
    if meta.len() > MAX_READ_BYTES {
        return Err(format!(
            "That file is {:.1} MB — too big to read in one go (limit 2 MB).",
            meta.len() as f64 / 1_048_576.0
        ));
    }
    let mut buf = Vec::new();
    fs::File::open(&target)
        .and_then(|mut f| f.read_to_end(&mut buf))
        .map_err(|e| format!("Could not read it: {e}"))?;
    shell.note("read", &show(&target, &root), true);
    Ok(String::from_utf8_lossy(&buf).to_string())
}

#[tauri::command]
fn desktop_write(shell: State<Shell>, path: String, contents: String) -> Result<String, String> {
    let root = shell.require()?;
    if contents.len() > MAX_WRITE_CHARS {
        return Err("That is too much text to write at once (limit 2 MB).".into());
    }
    let target = resolve(&root, &path)?;
    if let Some(parent) = target.parent() {
        fs::create_dir_all(parent).map_err(|e| format!("Could not make the folder: {e}"))?;
    }
    fs::write(&target, contents.as_bytes()).map_err(|e| format!("Could not write it: {e}"))?;
    shell.note("write", &show(&target, &root), true);
    Ok(show(&target, &root))
}

#[tauri::command]
fn desktop_mkdir(shell: State<Shell>, path: String) -> Result<String, String> {
    let root = shell.require()?;
    let target = resolve(&root, &path)?;
    fs::create_dir_all(&target).map_err(|e| format!("Could not make that folder: {e}"))?;
    shell.note("mkdir", &show(&target, &root), true);
    Ok(show(&target, &root))
}

/// Deleting is irreversible, so it asks every single time — a session grant
/// buys convenience, never the right to destroy something quietly.
#[tauri::command]
fn desktop_delete(app: tauri::AppHandle, shell: State<Shell>, path: String) -> Result<String, String> {
    let root = shell.require()?;
    let target = resolve(&root, &path)?;
    let pretty = show(&target, &root);

    let ok = app
        .dialog()
        .message(format!("Permanently delete “{pretty}”?"))
        .title("Ash wants to delete something")
        .kind(MessageDialogKind::Warning)
        .buttons(MessageDialogButtons::OkCancelCustom(
            "Delete".into(),
            "Keep it".into(),
        ))
        .blocking_show();

    if !ok {
        shell.note("delete", &format!("{pretty} — refused"), false);
        return Err("You said no, so nothing was deleted.".into());
    }

    let meta = fs::metadata(&target).map_err(|e| format!("Could not find it: {e}"))?;
    if meta.is_dir() {
        fs::remove_dir_all(&target)
    } else {
        fs::remove_file(&target)
    }
    .map_err(|e| format!("Could not delete it: {e}"))?;

    shell.note("delete", &pretty, true);
    Ok(pretty)
}

fn catastrophic(line: &str) -> bool {
    let l = line.to_lowercase();
    [
        "format ", "rd /s", "rmdir /s", "del /f /s /q c:", "diskpart", "vssadmin delete",
        "bcdedit", "shutdown", "reg delete hklm", "cipher /w", "mkfs", "rm -rf /",
    ]
    .iter()
    .any(|bad| l.contains(bad))
}

#[derive(Serialize)]
struct RunResult {
    code: i32,
    stdout: String,
    stderr: String,
    timed_out: bool,
}

/// Runs a command inside the chosen folder. Session permission covers ordinary
/// commands; anything on the catastrophic list asks first anyway.
#[tauri::command]
fn desktop_run(app: tauri::AppHandle, shell: State<Shell>, line: String) -> Result<RunResult, String> {
    let root = shell.require()?;
    let trimmed = line.trim();
    if trimmed.is_empty() {
        return Err("There was no command to run.".into());
    }

    if catastrophic(trimmed) {
        let ok = app
            .dialog()
            .message(format!(
                "Ash wants to run a command that can destroy data:\n\n{trimmed}\n\nRun it anyway?"
            ))
            .title("That command looks dangerous")
            .kind(MessageDialogKind::Warning)
            .buttons(MessageDialogButtons::OkCancelCustom("Run it".into(), "Stop".into()))
            .blocking_show();
        if !ok {
            shell.note("run", &format!("{trimmed} — refused"), false);
            return Err("You stopped that command.".into());
        }
    }

    let mut cmd = if cfg!(target_os = "windows") {
        let mut c = Command::new("cmd");
        c.args(["/C", trimmed]);
        c
    } else {
        let mut c = Command::new("sh");
        c.args(["-c", trimmed]);
        c
    };
    cmd.current_dir(&root)
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .stdin(Stdio::null());

    #[cfg(target_os = "windows")]
    {
        use std::os::windows::process::CommandExt;
        cmd.creation_flags(0x0800_0000); // CREATE_NO_WINDOW
    }

    let mut child = cmd.spawn().map_err(|e| format!("Could not start it: {e}"))?;
    let started = Instant::now();
    let timed_out = loop {
        match child.try_wait() {
            Ok(Some(_)) => break false,
            Ok(None) => {
                if started.elapsed() > COMMAND_TIMEOUT {
                    let _ = child.kill();
                    break true;
                }
                std::thread::sleep(Duration::from_millis(80));
            }
            Err(e) => return Err(format!("Lost track of it: {e}")),
        }
    };

    let out = child
        .wait_with_output()
        .map_err(|e| format!("Could not read the output: {e}"))?;

    let cut = |b: &[u8]| {
        let s = String::from_utf8_lossy(b).to_string();
        if s.len() > MAX_OUTPUT {
            format!("{}\n… (trimmed)", &s[..MAX_OUTPUT])
        } else {
            s
        }
    };

    shell.note("run", trimmed, !timed_out);
    Ok(RunResult {
        code: out.status.code().unwrap_or(-1),
        stdout: cut(&out.stdout),
        stderr: cut(&out.stderr),
        timed_out,
    })
}

/// Open a file, folder, app or link with whatever Windows normally uses.
#[tauri::command]
fn desktop_open(shell: State<Shell>, target: String) -> Result<String, String> {
    let root = shell.require()?;
    let t = target.trim().to_string();
    if t.is_empty() {
        return Err("There was nothing to open.".into());
    }

    let is_url = t.starts_with("http://") || t.starts_with("https://");
    let resolved = if is_url { t.clone() } else {
        resolve(&root, &t)?.to_string_lossy().to_string()
    };

    let result = if cfg!(target_os = "windows") {
        let mut c = Command::new("cmd");
        c.args(["/C", "start", "", &resolved]);
        #[cfg(target_os = "windows")]
        {
            use std::os::windows::process::CommandExt;
            c.creation_flags(0x0800_0000);
        }
        c.spawn().map(|_| ())
    } else if cfg!(target_os = "macos") {
        Command::new("open").arg(&resolved).spawn().map(|_| ())
    } else {
        Command::new("xdg-open").arg(&resolved).spawn().map(|_| ())
    };

    result.map_err(|e| format!("Could not open it: {e}"))?;
    shell.note("open", &resolved, true);
    Ok(resolved)
}

#[tauri::command]
fn desktop_log(shell: State<Shell>) -> Vec<Entry> {
    shell
        .log
        .lock()
        .map(|l| l.iter().rev().take(200).cloned().collect())
        .unwrap_or_default()
}

/* ─────────────────────── the bundled server ─────────────────────── */

fn free_port() -> u16 {
    TcpListener::bind("127.0.0.1:0")
        .ok()
        .and_then(|l| l.local_addr().ok())
        .map(|a| a.port())
        .unwrap_or(39_517)
}

fn wait_for(port: u16, limit: Duration) -> bool {
    let addr: SocketAddr = ([127, 0, 0, 1], port).into();
    let start = Instant::now();
    while start.elapsed() < limit {
        if TcpStream::connect_timeout(&addr, Duration::from_millis(400)).is_ok() {
            return true;
        }
        std::thread::sleep(Duration::from_millis(250));
    }
    false
}

fn start_server(app: &tauri::AppHandle) -> Result<u16, String> {
    let shell = app.state::<Shell>();
    let resources = app
        .path()
        .resource_dir()
        .map_err(|e| format!("Could not find the app's files: {e}"))?;
    let payload = resources.join("payload");
    let server = payload.join("server").join("server.js");
    if !server.exists() {
        return Err(format!(
            "The Ash server is missing from this build ({}).",
            server.display()
        ));
    }

    // node.exe travels with the app, so nothing has to be installed first
    let bundled_node = payload.join("node").join(if cfg!(windows) { "node.exe" } else { "node" });
    let node = if bundled_node.exists() {
        bundled_node
    } else {
        PathBuf::from("node")
    };

    let data_dir = app
        .path()
        .app_data_dir()
        .map_err(|e| format!("Could not find a place to keep your data: {e}"))?;
    fs::create_dir_all(&data_dir).ok();

    let port = free_port();
    let mut cmd = Command::new(node);
    cmd.arg(&server)
        .current_dir(payload.join("server"))
        .env("PORT", port.to_string())
        .env("HOSTNAME", "127.0.0.1")
        .env("NODE_ENV", "production")
        .env("ASH_DATA_DIR", &data_dir)
        .env("ASH_DESKTOP", "1")
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null());

    #[cfg(target_os = "windows")]
    {
        use std::os::windows::process::CommandExt;
        cmd.creation_flags(0x0800_0000); // no flashing console window
    }

    let child = cmd.spawn().map_err(|e| format!("Ash's server would not start: {e}"))?;
    *shell.server.lock().map_err(|_| "busy")? = Some(child);
    *shell.port.lock().map_err(|_| "busy")? = port;
    Ok(port)
}

/// Make sure the bundled server dies with the window that owns it.
fn stop_server(shell: &Shell) {
    if let Ok(mut slot) = shell.server.lock() {
        if let Some(child) = slot.as_mut() {
            let _ = child.kill();
            let _ = child.wait();
        }
        *slot = None;
    }
}

fn main() {
    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_opener::init())
        .manage(Shell::default())
        .invoke_handler(tauri::generate_handler![
            desktop_status,
            desktop_grant,
            desktop_revoke,
            desktop_list,
            desktop_read,
            desktop_write,
            desktop_mkdir,
            desktop_delete,
            desktop_run,
            desktop_open,
            desktop_log,
        ])
        .setup(|app| {
            let handle = app.handle().clone();
            std::thread::spawn(move || {
                match start_server(&handle) {
                    Ok(port) => {
                        let ready = wait_for(port, Duration::from_secs(60));
                        let window = handle.get_webview_window("main");
                        if let Some(w) = window {
                            if ready {
                                let url = format!("http://127.0.0.1:{port}/");
                                if let Ok(parsed) = tauri::Url::parse(&url) {
                                    let _ = w.navigate(parsed);
                                }
                            } else {
                                let _ = w.emit(
                                    "ash-boot-failed",
                                    "Ash's server did not answer in time. Close the app and open it again.",
                                );
                            }
                        }
                    }
                    Err(message) => {
                        if let Some(w) = handle.get_webview_window("main") {
                            let _ = w.emit("ash-boot-failed", message);
                        }
                    }
                }
            });
            Ok(())
        })
        .on_window_event(|window, event| {
            if let tauri::WindowEvent::Destroyed = event {
                // never leave an orphaned node.exe behind
                stop_server(&window.state::<Shell>());
            }
        })
        .run(tauri::generate_context!())
        .expect("Ash could not start");
}
