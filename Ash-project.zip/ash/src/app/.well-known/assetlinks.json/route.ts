import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

/**
 * Digital Asset Links — what makes an Android app a *Trusted* Web Activity.
 *
 * When you package Ash for the Play Store (Bubblewrap / PWABuilder), Google
 * gives you a package name and a SHA-256 signing fingerprint. Put both in the
 * environment and this endpoint starts answering; without them it stays a 404,
 * which is the honest reply — no links have been declared.
 *
 *   ANDROID_PACKAGE_NAME=com.ashlabs.ash
 *   ANDROID_SHA256_FINGERPRINT=AB:CD:...:EF        (one or more, comma separated)
 *
 * Without this file the app still runs, but Android shows a browser address
 * bar across the top instead of opening full screen.
 */
export async function GET() {
  const pkg = (process.env.ANDROID_PACKAGE_NAME ?? "").trim();
  const prints = (process.env.ANDROID_SHA256_FINGERPRINT ?? "")
    .split(",")
    .map((s) => s.trim().toUpperCase())
    .filter(Boolean);

  if (!pkg || !prints.length) {
    return NextResponse.json(
      {
        error: "No Android app has been linked to this site yet.",
        how: "Set ANDROID_PACKAGE_NAME and ANDROID_SHA256_FINGERPRINT, then redeploy.",
      },
      { status: 404, headers: { "cache-control": "no-store" } },
    );
  }

  const body = [
    {
      relation: ["delegate_permission/common.handle_all_urls"],
      target: {
        namespace: "android_app",
        package_name: pkg,
        sha256_cert_fingerprints: prints,
      },
    },
  ];

  return NextResponse.json(body, {
    headers: {
      "content-type": "application/json",
      // Google re-reads this; a day is plenty and keeps fixes quick to land
      "cache-control": "public, max-age=3600",
    },
  });
}
