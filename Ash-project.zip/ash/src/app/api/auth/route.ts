import { hydrateEnv, getSettings } from "@/lib/settings";
import { clearUserCookie, resolveVisitor, userCookie } from "@/lib/auth/visitor";
import { clientIp, hit } from "@/lib/ratelimit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Optional email login. Only used when "Require login" is ON. */
export async function GET(req: Request) {
  await hydrateEnv();
  const settings = await getSettings();
  const visitor = resolveVisitor(req);
  return Response.json({
    required: settings.limits.requireLogin,
    available: !!(process.env.FIREBASE_API_KEY || "").trim(),
    signedIn: !!visitor.userId,
    email: visitor.userId ? decodeURIComponent(visitor.userId).split("|")[1] ?? null : null,
  });
}

export async function POST(req: Request) {
  await hydrateEnv();
  const ip = clientIp(req);
  const limit = hit(`auth:${ip}`, 10, 60_000, "Too many attempts. Please wait a minute.");
  if (!limit.ok) return Response.json({ error: limit.message }, { status: 429 });

  const body = await req.json().catch(() => ({}) as any);
  const action = String(body.action ?? "");

  if (action === "signout") {
    const res = Response.json({ ok: true });
    res.headers.append("set-cookie", clearUserCookie());
    return res;
  }

  const apiKey = (process.env.FIREBASE_API_KEY || "").trim();
  if (!apiKey) {
    return Response.json(
      { error: "Login is not set up. Add FIREBASE_API_KEY, or switch 'Require login' off in the Control Panel." },
      { status: 503 },
    );
  }

  const email = String(body.email ?? "").trim().toLowerCase();
  const password = String(body.password ?? "");
  if (!email.includes("@") || password.length < 6) {
    return Response.json({ error: "Enter a valid email and a password of at least 6 characters." }, { status: 400 });
  }

  const endpoint =
    action === "signup"
      ? `https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${apiKey}`
      : `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${apiKey}`;

  try {
    const res = await fetch(endpoint, {
      method: "POST",
      cache: "no-store",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email, password, returnSecureToken: true }),
    });
    const data = (await res.json()) as any;
    if (!res.ok) {
      const code = String(data?.error?.message ?? "");
      const friendly =
        code.includes("EMAIL_EXISTS")
          ? "That email already has an account. Try signing in."
          : code.includes("INVALID_LOGIN_CREDENTIALS") || code.includes("INVALID_PASSWORD")
            ? "Email or password is not right."
            : code.includes("EMAIL_NOT_FOUND")
              ? "No account with that email yet."
              : "Could not sign you in right now.";
      return Response.json({ error: friendly }, { status: 401 });
    }
    const uid = `${data.localId}|${email}`;
    const response = Response.json({ ok: true, email });
    response.headers.append("set-cookie", userCookie(uid));
    return response;
  } catch {
    return Response.json({ error: "Could not reach the login service." }, { status: 502 });
  }
}
