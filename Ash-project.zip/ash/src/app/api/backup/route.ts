import { hydrateEnv, getSettings, saveSettings } from "@/lib/settings";
import { requireOwner } from "@/lib/auth/owner";
import { addMessage, createConversation, listAllConversations, listMessages } from "@/lib/db/repo";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 120;

/** Download everything except the API keys. */
export async function GET() {
  await hydrateEnv();
  const guard = await requireOwner();
  if (guard) return guard;

  const settings = await getSettings();
  const conversations = await listAllConversations();
  const withMessages = [];
  for (const c of conversations) {
    withMessages.push({ ...c, messages: await listMessages(c.id) });
  }
  const payload = {
    kind: "ash-backup",
    version: 1,
    exportedAt: new Date().toISOString(),
    settings: { ...settings },
    conversations: withMessages,
  };
  return new Response(JSON.stringify(payload, null, 2), {
    headers: {
      "content-type": "application/json; charset=utf-8",
      "content-disposition": `attachment; filename="ash-backup-${new Date().toISOString().slice(0, 10)}.json"`,
      "cache-control": "no-store",
    },
  });
}

export async function POST(req: Request) {
  await hydrateEnv();
  const guard = await requireOwner();
  if (guard) return guard;

  const body = await req.json().catch(() => null);
  if (!body || body.kind !== "ash-backup") {
    return Response.json({ error: "That file is not an Ash backup." }, { status: 400 });
  }

  let restoredChats = 0;
  let restoredMessages = 0;
  if (body.settings) await saveSettings(body.settings);
  if (Array.isArray(body.conversations)) {
    for (const c of body.conversations.slice(0, 2000)) {
      const created = await createConversation({
        title: String(c.title || "Restored chat").slice(0, 120),
        model: c.model ?? null,
        systemPrompt: c.systemPrompt ?? null,
        ownerKey: String(c.ownerKey || "restored"),
      });
      restoredChats++;
      for (const m of Array.isArray(c.messages) ? c.messages.slice(0, 1000) : []) {
        if (!m?.role || typeof m.content !== "string") continue;
        await addMessage({
          conversationId: created.id,
          role: m.role,
          content: m.content,
          model: m.model ?? null,
          createdAt: Number(m.createdAt) || Date.now(),
        });
        restoredMessages++;
      }
    }
  }
  return Response.json({ ok: true, restoredChats, restoredMessages });
}
