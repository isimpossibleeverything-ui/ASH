import { hydrateEnv, getSettings } from "@/lib/settings";
import { resolveVisitor } from "@/lib/auth/visitor";
import { clientIp, hit } from "@/lib/ratelimit";
import {
  addMessage,
  createConversation,
  deleteFromMessage,
  enqueueQuestion,
  getConversation,
  listMessages,
  updateConversation,
} from "@/lib/db/repo";
import { buildChain, defaultModelId, providerFor, resolveModel, runtimeModels, type RuntimeModel } from "@/lib/providers";
import { park } from "@/lib/providers/health";
import { isNetworkError, ProviderError, scrubSecrets } from "@/lib/providers/sse";
import { buildSystemPrompt, classifyIdentity, detectScript, identityAnswer } from "@/lib/identity";
import { remember } from "@/lib/knowledge";
import { orchestrate } from "@/lib/agents/registry";
import { bumpStat } from "@/lib/stats";
import type { ChatRequestBody, InlineImage, SearchHit } from "@/lib/types";
import type { ProviderMessage } from "@/lib/providers/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 300;

const HISTORY_WINDOW = 60;
/** Rough cross-script estimate: Urdu/Arabic pack fewer chars per token. */
const CHARS_PER_TOKEN = 3.4;
const DEFAULT_CONTEXT_TOKENS = 12_000;

const estimateTokens = (text: string) => Math.ceil(text.length / CHARS_PER_TOKEN);

/**
 * Keep the newest turns that fit the budget, and keep the very first user
 * message as an anchor so long chats do not forget what they are about.
 */
function fitContext(messages: ProviderMessage[], budgetTokens: number): { kept: ProviderMessage[]; dropped: number } {
  if (!messages.length) return { kept: [], dropped: 0 };
  const anchor = messages.find((m) => m.role === "user");
  const anchorCost = anchor ? estimateTokens(anchor.content) + 8 : 0;
  let used = anchorCost;
  const tail: ProviderMessage[] = [];

  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i];
    if (anchor && m === anchor) continue;
    const cost = estimateTokens(m.content) + 8;
    if (used + cost > budgetTokens && tail.length >= 2) break;
    used += cost;
    tail.unshift(m);
  }

  const kept = anchor && !tail.includes(anchor) ? [anchor, ...tail] : tail;
  return { kept, dropped: messages.length - kept.length };
}
const FIRST_TOKEN_MS = 30_000;
const FIRST_TOKEN_MS_IMAGES = 45_000;
const BETWEEN_TOKEN_MS = 60_000;
const TOTAL_BUDGET_MS = 110_000;
const TOTAL_BUDGET_MS_IMAGES = 90_000;
const ALLOWED_MIME = new Set(["image/jpeg", "image/png", "image/webp", "image/gif"]);

function titleFrom(message: string): string {
  let t = message
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/`[^`]*`/g, " ")
    .replace(/https?:\/\/\S+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  t = t.replace(
    /^(hi|hey|hello|salam|salaam|assalam[ou]?[ -]?alaikum|aoa|please|plz|can you|could you|would you|kindly|mujhe|mujhay|mera|i want to|i need to|help me|tell me|batao|bataen)\b[\s,:-]*/i,
    "",
  );
  t = t.replace(/^(to|the|a|an)\s+/i, "");
  if (!t) return "New chat";
  const words = t.split(" ").slice(0, 8).join(" ");
  let out = words.length > 52 ? `${words.slice(0, 52).trim()}…` : words;
  out = out.charAt(0).toUpperCase() + out.slice(1);
  return out.replace(/[.,;:!?]+$/, "") || "New chat";
}

function sse(event: string, data: unknown): Uint8Array {
  return new TextEncoder().encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
}

async function nextWithTimeout<T>(
  it: AsyncIterator<T>,
  ms: number,
): Promise<{ kind: "value"; value: IteratorResult<T> } | { kind: "timeout" }> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  const timeout = new Promise<{ kind: "timeout" }>((resolve) => {
    timer = setTimeout(() => resolve({ kind: "timeout" }), ms);
  });
  try {
    const result = await Promise.race([it.next().then((value) => ({ kind: "value" as const, value })), timeout]);
    return result;
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export async function POST(req: Request) {
  await hydrateEnv();
  const settings = await getSettings();
  const visitor = resolveVisitor(req);
  const ip = clientIp(req);

  let body: ChatRequestBody;
  try {
    body = (await req.json()) as ChatRequestBody;
  } catch {
    return Response.json({ error: "That request could not be read." }, { status: 400 });
  }

  const limits = settings.limits;
  const perIp = hit(`chat:ip:${ip}`, limits.perIpMinute, 60_000, "You are sending messages very quickly. Please wait a moment.");
  if (!perIp.ok) return Response.json({ error: perIp.message, retryAfter: perIp.retryAfter }, { status: 429 });
  const perVisitor = hit(
    `chat:v:${visitor.key}`,
    limits.perVisitorHour,
    60 * 60_000,
    "You have reached this hour's message limit. Please try again a little later.",
  );
  if (!perVisitor.ok) return Response.json({ error: perVisitor.message, retryAfter: perVisitor.retryAfter }, { status: 429 });

  const rawMessage = (body.message ?? "").toString();
  const message = rawMessage.slice(0, Math.max(200, limits.maxMessageChars));
  const images: InlineImage[] = Array.isArray(body.images) ? body.images.slice(0, Math.max(0, limits.maxImages)) : [];
  for (const img of images) {
    if (!ALLOWED_MIME.has(img.mimeType) || typeof img.data !== "string" || img.data.length > 7_200_000) {
      return Response.json({ error: "One of those images could not be used. Use JPEG, PNG, WebP or GIF under 5 MB." }, { status: 400 });
    }
  }
  if (!message.trim() && !images.length && !body.regenerateFrom) {
    return Response.json({ error: "Write something first." }, { status: 400 });
  }

  const temperature = Math.min(2, Math.max(0, typeof body.temperature === "number" ? body.temperature : 0.7));

  /* ── conversation ─────────────────────────────────────────────── */
  let conversation = body.conversationId ? await getConversation(body.conversationId, visitor.key) : null;
  let isFirstMessage = false;
  if (!conversation) {
    conversation = await createConversation({
      title: titleFrom(message || "New chat"),
      model: body.model ?? null,
      systemPrompt: body.systemPrompt?.trim() || null,
      ownerKey: visitor.key,
    });
    isFirstMessage = true;
  }

  if (body.regenerateFrom) {
    await deleteFromMessage(conversation.id, body.regenerateFrom);
  }

  const prior = await listMessages(conversation.id);
  if (!prior.length) isFirstMessage = true;

  let userMessageId = "";
  if (message.trim() || images.length) {
    const saved = await addMessage({
      conversationId: conversation.id,
      role: "user",
      content: message + (images.length ? `\n\n_[${images.length} image${images.length > 1 ? "s" : ""} attached]_` : ""),
      model: null,
    });
    userMessageId = saved.id;
  }

  if (body.model) await updateConversation(conversation.id, visitor.key, { model: body.model });

  const history = await listMessages(conversation.id);
  const windowed = history.slice(-HISTORY_WINDOW);
  const allTurns: ProviderMessage[] = windowed
    .filter((m) => m.role === "user" || m.role === "assistant")
    .map((m) => ({ role: m.role as "user" | "assistant", content: m.content }));
  const budget = Math.max(2_000, settings.limits.contextTokens || DEFAULT_CONTEXT_TOKENS);
  const { kept: providerMessages, dropped: droppedTurns } = fitContext(allTurns, budget);
  const trimmedNote =
    droppedTurns > 0 ? `Trimmed ${droppedTurns} older message${droppedTurns > 1 ? "s" : ""} to fit the context window.` : "";
  const lastUserText = message || [...windowed].reverse().find((m) => m.role === "user")?.content || "";

  /* ── which engine ─────────────────────────────────────────────── */
  const requested =
    (await resolveModel(body.model || conversation.model)) ?? (await resolveModel(await defaultModelId()));
  const needsVision = images.length > 0;
  const mode = requested?.providerId ?? "smart";

  /* ── agents: only the capabilities this question actually needs ── */
  const agents = await orchestrate({
    question: lastUserText,
    mode,
    hasImages: needsVision,
    searchChoice: typeof body.search === "boolean" ? body.search : undefined,
    useMemory: body.useMemory !== false,
    settings,
    signal: req.signal,
  });
  const searchContext = agents.context;
  const sources: SearchHit[] = agents.sources;

  const branding = settings.branding;
  const customPrompt = body.systemPrompt?.trim() || conversation.systemPrompt || settings.systemPrompt || "";
  const replyLanguage = typeof body.replyLanguage === "string" ? body.replyLanguage.slice(0, 40).trim() : "";
  const languageRule = replyLanguage
    ? `\n\nThe user has pinned their reply language: answer ONLY in ${replyLanguage}, whatever language they write in. Keep code, commands and proper nouns as they are.`
    : "";
  const system = buildSystemPrompt(branding, customPrompt || null) + languageRule + searchContext;

  /* ── stream ───────────────────────────────────────────────────── */
  const abort = new AbortController();
  req.signal.addEventListener("abort", () => abort.abort(), { once: true });

  const conversationId = conversation.id;
  const conversationTitle = conversation.title;

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      let closed = false;
      const send = (event: string, data: unknown) => {
        if (closed) return;
        try {
          controller.enqueue(sse(event, data));
        } catch {
          closed = true;
        }
      };

      let answer = "";
      let usedModel: RuntimeModel | null = null;
      let lastError = "";

      const finish = async () => {
        if (closed) return;
        let assistantMessageId = "";
        if (answer.trim()) {
          const saved = await addMessage({
            conversationId,
            role: "assistant",
            content: answer,
            model: usedModel?.publicCode ?? "ash-basic",
          }).catch(() => null);
          assistantMessageId = saved?.id ?? "";

          // Organic learning: only clean, first-turn, text-only answers.
          if (
            isFirstMessage &&
            !images.length &&
            !searchContext &&
            !customPrompt &&
            usedModel &&
            usedModel.group === "full" &&
            lastUserText.trim()
          ) {
            remember({
              question: lastUserText.trim(),
              answer,
              providerId: usedModel.providerId,
              modelId: usedModel.modelId,
            }).catch(() => {});
          }
        }
        send("done", { assistantMessageId, content: answer, model: usedModel?.publicCode ?? "ash-basic" });
        closed = true;
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      };

      try {
        send("meta", {
          conversationId,
          userMessageId,
          model: requested?.publicCode ?? "ash-smart",
          title: conversationTitle,
          downgraded: false,
          trimmed: droppedTurns,
          agents: agents.used,
        });
        if (trimmedNote) send("notice", { message: trimmedNote });
        if (sources.length) {
          send("sources", { hits: sources.map((s) => ({ title: s.title, url: s.url, source: s.source })) });
        }

        bumpStat("messages", visitor.visitorId).catch(() => {});

        /* identity + offline shortcuts: always answerable */
        const identityKind = classifyIdentity(lastUserText);
        if (identityKind && (identityKind === "who" || identityKind === "creator" || identityKind === "country")) {
          const text = identityAnswer(identityKind, branding, detectScript(lastUserText));
          usedModel = (await runtimeModels()).find((m) => m.key === "demo:offline") ?? null;
          send("model", { model: usedModel?.publicCode ?? "ash-basic" });
          for (const chunk of text.match(/.{1,18}(\s|$)|.{1,18}/g) ?? [text]) {
            answer += chunk;
            send("delta", { text: chunk });
            await new Promise((r) => setTimeout(r, 10));
          }
          await finish();
          return;
        }

        /* an agent already has the complete answer (maths, memory, …) */
        if (agents.answer) {
          const fromMemory = agents.used.includes("memory");
          usedModel =
            (await runtimeModels()).find((m) => m.key === (fromMemory ? `${mode}:${mode === "smart" ? "auto" : "memory"}` : "demo:offline")) ??
            null;
          send("model", { model: usedModel?.publicCode ?? "ash-basic" });
          const text = agents.answer;
          for (const chunk of text.match(/[\s\S]{1,36}/g) ?? [text]) {
            if (abort.signal.aborted) break;
            answer += chunk;
            send("delta", { text: chunk });
            await new Promise((r) => setTimeout(r, 8));
          }
          if (mode === "brain" && !fromMemory && lastUserText.trim()) {
            enqueueQuestion(lastUserText.trim()).catch(() => {});
          }
          await finish();
          return;
        }

        /* build the fallback chain */
        const chain =
          mode === "demo"
            ? (await runtimeModels()).filter((m) => m.key === "demo:offline")
            : await buildChain(requested && requested.group === "full" ? requested : null, { needsVision });

        if (!chain.length) {
          send("error", { message: "No engine is configured yet. Open the Control Panel and paste one free key." });
          await finish();
          return;
        }

        const started = Date.now();
        const budget = needsVision ? TOTAL_BUDGET_MS_IMAGES : TOTAL_BUDGET_MS;
        let emitted = false;

        for (let i = 0; i < chain.length; i++) {
          const candidate = chain[i];
          const overBudget = Date.now() - started > budget;
          if (overBudget && candidate.group !== "offline") continue;
          if (abort.signal.aborted) break;

          const provider = await providerFor(candidate);
          const inner = new AbortController();
          const relay = () => inner.abort();
          abort.signal.addEventListener("abort", relay, { once: true });

          const iterator = provider.stream({
            model: candidate.modelId,
            messages: providerMessages,
            system,
            temperature,
            images: images.length ? images : undefined,
            vision: candidate.vision,
            signal: inner.signal,
          })[Symbol.asyncIterator]();

          let localEmitted = false;
          try {
            for (;;) {
              const limitMs = localEmitted ? BETWEEN_TOKEN_MS : needsVision ? FIRST_TOKEN_MS_IMAGES : FIRST_TOKEN_MS;
              const step = await nextWithTimeout(iterator, limitMs);
              if (step.kind === "timeout") {
                inner.abort();
                throw new ProviderError("The engine did not start answering in time.", 408);
              }
              if (step.value.done) break;
              const chunk = step.value.value;
              if (typeof chunk !== "string" || chunk === "") continue; // keep-alive only
              if (!localEmitted) {
                localEmitted = true;
                emitted = true;
                usedModel = candidate;
                send("model", { model: candidate.publicCode });
                if (requested && candidate.key !== requested.key) {
                  const noEnginesAtAll = !chain.some((m) => m.group === "full");
                  const delegating = requested.group === "offline"; // Ash Smart picking an engine is normal
                  let msg = "";
                  if (candidate.group === "offline") {
                    msg = noEnginesAtAll
                      ? `No engine is set up yet, so ${candidate.label} answered. Add one free key in the Control Panel to unlock full answers.`
                      : `All engines were busy — answered from ${branding.name}'s own memory instead.`;
                  } else if (!delegating) {
                    msg = `${requested.label} was busy, so ${candidate.label} answered instead.`;
                  }
                  if (msg) {
                    send("notice", { message: msg });
                    bumpStat("fallbacks").catch(() => {});
                  }
                }
              }
              answer += chunk;
              send("delta", { text: chunk });
              if (abort.signal.aborted) break;
            }

            if (localEmitted) break; // success — never swap engines mid-answer
            lastError = "That engine returned an empty answer.";
            await park(candidate.key, 500, lastError);
          } catch (err) {
            abort.signal.removeEventListener("abort", relay);
            if (abort.signal.aborted) break; // user pressed Stop: keep the partial text
            if (localEmitted) break; // text already started: keep what we have

            const status = err instanceof ProviderError ? err.status : isNetworkError(err) ? 0 : 500;
            lastError = scrubSecrets(err instanceof Error ? err.message : String(err));
            // Never stop the chain on one engine's complaint: several providers
            // answer 400 for an invalid key, so the next engine still deserves a go.
            await park(candidate.key, status, lastError).catch(() => {});
            continue;
          } finally {
            abort.signal.removeEventListener("abort", relay);
          }
        }

        if (!emitted && !abort.signal.aborted) {
          bumpStat("errors").catch(() => {});
          if (lastUserText.trim()) enqueueQuestion(lastUserText.trim()).catch(() => {});
          send("error", {
            message:
              lastError ||
              "Every engine is busy right now. Please try again in a moment, or pick a different engine from the header.",
          });
        }
        await finish();
      } catch (err) {
        bumpStat("errors").catch(() => {});
        send("error", { message: scrubSecrets(err instanceof Error ? err.message : "Something went wrong.") });
        await finish();
      }
    },
    cancel() {
      abort.abort();
    },
  });

  const res = new Response(stream, {
    headers: {
      "content-type": "text/event-stream; charset=utf-8",
      "cache-control": "no-cache, no-transform",
      connection: "keep-alive",
      "x-accel-buffering": "no",
    },
  });
  if (visitor.setCookie) res.headers.append("set-cookie", visitor.setCookie);
  return res;
}
