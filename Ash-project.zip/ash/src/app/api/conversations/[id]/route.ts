import { hydrateEnv } from "@/lib/settings";
import { resolveVisitor, withVisitorCookie } from "@/lib/auth/visitor";
import { deleteConversation, getConversation, listMessages, updateConversation } from "@/lib/db/repo";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(req: Request, ctx: Ctx) {
  await hydrateEnv();
  const { id } = await ctx.params;
  const visitor = resolveVisitor(req);
  const conversation = await getConversation(id, visitor.key);
  if (!conversation) return Response.json({ error: "Chat not found." }, { status: 404 });
  const messages = await listMessages(id);
  return withVisitorCookie(Response.json({ conversation, messages }), visitor);
}

export async function PATCH(req: Request, ctx: Ctx) {
  await hydrateEnv();
  const { id } = await ctx.params;
  const visitor = resolveVisitor(req);
  const existing = await getConversation(id, visitor.key);
  if (!existing) return Response.json({ error: "Chat not found." }, { status: 404 });

  const body = await req.json().catch(() => ({}) as any);
  const patch: { title?: string; pinned?: boolean; archived?: boolean; model?: string | null; systemPrompt?: string | null } = {};
  if (typeof body.title === "string") patch.title = body.title.trim().slice(0, 120) || "New chat";
  if (typeof body.pinned === "boolean") patch.pinned = body.pinned;
  if (typeof body.archived === "boolean") patch.archived = body.archived;
  if (typeof body.model === "string" || body.model === null) patch.model = body.model;
  if (typeof body.systemPrompt === "string" || body.systemPrompt === null) patch.systemPrompt = body.systemPrompt;
  await updateConversation(id, visitor.key, patch);
  const conversation = await getConversation(id, visitor.key);
  return withVisitorCookie(Response.json({ conversation }), visitor);
}

export async function DELETE(req: Request, ctx: Ctx) {
  await hydrateEnv();
  const { id } = await ctx.params;
  const visitor = resolveVisitor(req);
  await deleteConversation(id, visitor.key);
  return withVisitorCookie(Response.json({ ok: true }), visitor);
}
