import { hydrateEnv } from "@/lib/settings";
import { resolveVisitor, withVisitorCookie } from "@/lib/auth/visitor";
import { createConversation, deleteAllConversations, listConversations } from "@/lib/db/repo";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  await hydrateEnv();
  const visitor = resolveVisitor(req);
  const conversations = await listConversations(visitor.key);
  return withVisitorCookie(Response.json({ conversations }), visitor);
}

export async function POST(req: Request) {
  await hydrateEnv();
  const visitor = resolveVisitor(req);
  const body = await req.json().catch(() => ({}) as any);
  const conversation = await createConversation({
    title: typeof body.title === "string" && body.title.trim() ? body.title.trim().slice(0, 120) : "New chat",
    model: typeof body.model === "string" ? body.model : null,
    systemPrompt: typeof body.systemPrompt === "string" ? body.systemPrompt : null,
    ownerKey: visitor.key,
  });
  return withVisitorCookie(Response.json({ conversation }), visitor);
}

export async function DELETE(req: Request) {
  await hydrateEnv();
  const visitor = resolveVisitor(req);
  const removed = await deleteAllConversations(visitor.key);
  return withVisitorCookie(Response.json({ ok: true, removed }), visitor);
}
