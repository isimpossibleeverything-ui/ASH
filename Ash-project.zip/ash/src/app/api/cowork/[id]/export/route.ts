import { hydrateEnv } from "@/lib/settings";
import { resolveVisitor } from "@/lib/auth/visitor";
import * as store from "@/lib/cowork/store";
import { makeZip, type ZipEntry } from "@/lib/cowork/zip";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

function slug(text: string): string {
  return (
    text
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 50) || "task"
  );
}

function dataUrlBytes(dataUrl: string): Uint8Array | null {
  const m = dataUrl.match(/^data:[^;,]+(;base64)?,(.*)$/s);
  if (!m) return null;
  if (m[1]) return Uint8Array.from(Buffer.from(m[2], "base64"));
  return new TextEncoder().encode(decodeURIComponent(m[2]));
}

/** Everything the task produced, in one zip: files, the plan and the step log. */
export async function GET(req: Request, ctx: Ctx) {
  await hydrateEnv();
  const { id } = await ctx.params;
  const visitor = resolveVisitor(req);
  const session = await store.getSession(id, visitor.key);
  if (!session) return Response.json({ error: "That task does not exist." }, { status: 404 });

  const [steps, files] = await Promise.all([store.listSteps(id), store.listFiles(id)]);
  const encoder = new TextEncoder();
  const entries: ZipEntry[] = [];

  for (const meta of files) {
    const full = await store.readFile(id, meta.path);
    if (!full) continue;
    const bytes = full.kind === "image" && full.content.startsWith("data:") ? dataUrlBytes(full.content) : null;
    entries.push({
      name: full.path,
      data: bytes ?? encoder.encode(full.content),
      modified: new Date(full.updatedAt),
    });
  }

  const log = [
    `# ${session.title}`,
    "",
    "## Goal",
    "",
    session.goal,
    "",
    "## Plan",
    "",
    ...(session.plan.length ? session.plan.map((p) => `- [${p.status === "done" ? "x" : " "}] ${p.title}`) : ["(no plan was recorded)"]),
    "",
    "## What happened",
    "",
    ...steps.map((s) => {
      const head = `### ${s.seq}. ${s.title} — ${s.tool || "step"} (${s.status})`;
      const detail = s.output.trim() ? `\n\n\`\`\`\n${s.output.trim().slice(0, 4000)}\n\`\`\`` : "";
      return `${head}${detail}\n`;
    }),
    "## Summary",
    "",
    session.summary ?? "(not finished)",
    "",
  ].join("\n");

  entries.push({ name: "TASK-LOG.md", data: encoder.encode(log), modified: new Date(session.updatedAt) });

  const zip = makeZip(entries);
  return new Response(zip as unknown as BodyInit, {
    headers: {
      "content-type": "application/zip",
      "content-disposition": `attachment; filename="${slug(session.title)}.zip"`,
      "cache-control": "no-store",
    },
  });
}
