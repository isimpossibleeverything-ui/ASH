import { hydrateEnv } from "@/lib/settings";
import { resolveVisitor } from "@/lib/auth/visitor";
import * as store from "@/lib/cowork/store";
import { safePath } from "@/lib/cowork/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

const MIME: Record<string, string> = {
  md: "text/markdown; charset=utf-8",
  txt: "text/plain; charset=utf-8",
  csv: "text/csv; charset=utf-8",
  tsv: "text/tab-separated-values; charset=utf-8",
  json: "application/json; charset=utf-8",
  html: "text/html; charset=utf-8",
  css: "text/css; charset=utf-8",
  js: "text/javascript; charset=utf-8",
  ts: "text/plain; charset=utf-8",
  py: "text/x-python; charset=utf-8",
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  webp: "image/webp",
};

function dataUrlToBytes(dataUrl: string): { bytes: Uint8Array; mime: string } | null {
  const m = dataUrl.match(/^data:([^;,]+)(;base64)?,(.*)$/s);
  if (!m) return null;
  const mime = m[1] || "application/octet-stream";
  if (m[2]) return { bytes: Uint8Array.from(Buffer.from(m[3], "base64")), mime };
  return { bytes: new TextEncoder().encode(decodeURIComponent(m[3])), mime };
}

/** `?path=` reads one file; `?path=&download=1` sends it as an attachment. */
export async function GET(req: Request, ctx: Ctx) {
  await hydrateEnv();
  const { id } = await ctx.params;
  const visitor = resolveVisitor(req);
  const session = await store.getSession(id, visitor.key);
  if (!session) return Response.json({ error: "That task does not exist." }, { status: 404 });

  const url = new URL(req.url);
  const rawPath = url.searchParams.get("path");
  if (!rawPath) return Response.json({ files: await store.listFiles(id) });

  const path = safePath(rawPath);
  if (!path) return Response.json({ error: "That file name is not allowed." }, { status: 400 });
  const file = await store.readFile(id, path);
  if (!file) return Response.json({ error: "That file does not exist." }, { status: 404 });

  if (url.searchParams.get("download") !== "1") {
    return Response.json({ file });
  }

  const name = path.split("/").pop() || "file";
  const ext = name.toLowerCase().split(".").pop() ?? "";

  if (file.kind === "image" && file.content.startsWith("data:")) {
    const decoded = dataUrlToBytes(file.content);
    if (decoded) {
      return new Response(decoded.bytes as unknown as BodyInit, {
        headers: {
          "content-type": decoded.mime,
          "content-disposition": `attachment; filename="${name}"`,
          "cache-control": "no-store",
        },
      });
    }
  }

  return new Response(file.content, {
    headers: {
      "content-type": MIME[ext] ?? "text/plain; charset=utf-8",
      "content-disposition": `attachment; filename="${name}"`,
      "cache-control": "no-store",
    },
  });
}
