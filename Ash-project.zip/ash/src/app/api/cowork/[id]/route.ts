import { hydrateEnv } from "@/lib/settings";
import { resolveVisitor, withVisitorCookie } from "@/lib/auth/visitor";
import * as store from "@/lib/cowork/store";
import { stopRun, isRunning } from "@/lib/cowork/agent";
import { safePath } from "@/lib/cowork/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(req: Request, ctx: Ctx) {
  await hydrateEnv();
  const { id } = await ctx.params;
  const visitor = resolveVisitor(req);
  const session = await store.getSession(id, visitor.key);
  if (!session) return Response.json({ error: "That task does not exist." }, { status: 404 });
  const [steps, files] = await Promise.all([store.listSteps(id), store.listFiles(id)]);
  return withVisitorCookie(Response.json({ session, steps, files, running: isRunning(id) }), visitor);
}

export async function PATCH(req: Request, ctx: Ctx) {
  await hydrateEnv();
  const { id } = await ctx.params;
  const visitor = resolveVisitor(req);
  const session = await store.getSession(id, visitor.key);
  if (!session) return Response.json({ error: "That task does not exist." }, { status: 404 });

  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const action = typeof body.action === "string" ? body.action : "";

  switch (action) {
    case "pause": {
      const was = stopRun(id);
      await store.patchSession(id, { status: "paused" });
      return Response.json({ ok: true, wasRunning: was, session: await store.getSession(id, visitor.key) });
    }
    case "cancel": {
      stopRun(id);
      await store.patchSession(id, { status: "cancelled" });
      return Response.json({ ok: true, session: await store.getSession(id, visitor.key) });
    }
    case "approve":
    case "reject": {
      const stepId = typeof body.stepId === "string" ? body.stepId : "";
      const step = stepId ? await store.getStep(stepId) : null;
      if (!step || step.sessionId !== id) return Response.json({ error: "That step does not exist." }, { status: 404 });
      // the decision is recorded on the waiting step itself; the run picks it up on resume
      await store.setStepDecision(step.id, action === "approve" ? "approved" : "rejected");
      await store.updateStep(
        step.id,
        "awaiting",
        action === "approve" ? "Approved — carrying on." : "Refused — it will find another way.",
      );
      return Response.json({ ok: true });
    }
    case "rename": {
      const title = typeof body.title === "string" ? body.title.trim() : "";
      if (!title) return Response.json({ error: "Give it a name." }, { status: 400 });
      await store.patchSession(id, { title });
      return Response.json({ ok: true, session: await store.getSession(id, visitor.key) });
    }
    case "autoApprove": {
      await store.patchSession(id, { autoApprove: body.value === true });
      return Response.json({ ok: true, session: await store.getSession(id, visitor.key) });
    }
    case "writeFile": {
      const path = safePath(typeof body.path === "string" ? body.path : "");
      const content = typeof body.content === "string" ? body.content : "";
      if (!path) return Response.json({ error: "That file name is not allowed." }, { status: 400 });
      const existing = await store.readFile(id, path);
      const file = await store.writeFile({ sessionId: id, path, content, kind: existing?.kind ?? "text" });
      return Response.json({ ok: true, file });
    }
    case "deleteFile": {
      const path = safePath(typeof body.path === "string" ? body.path : "");
      if (!path) return Response.json({ error: "That file name is not allowed." }, { status: 400 });
      const gone = await store.deleteFile(id, path);
      return Response.json({ ok: gone });
    }
    default:
      return Response.json({ error: "Unknown action." }, { status: 400 });
  }
}

export async function DELETE(req: Request, ctx: Ctx) {
  await hydrateEnv();
  const { id } = await ctx.params;
  const visitor = resolveVisitor(req);
  stopRun(id);
  const gone = await store.deleteSession(id, visitor.key);
  if (!gone) return Response.json({ error: "That task does not exist." }, { status: 404 });
  return Response.json({ ok: true });
}
