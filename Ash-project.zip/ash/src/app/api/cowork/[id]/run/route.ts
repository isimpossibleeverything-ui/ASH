import { hydrateEnv, getSettings } from "@/lib/settings";
import { resolveVisitor } from "@/lib/auth/visitor";
import { clientIp, hit } from "@/lib/ratelimit";
import * as store from "@/lib/cowork/store";
import { runSession } from "@/lib/cowork/agent";
import type { CoworkEvent } from "@/lib/cowork/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 300;

type Ctx = { params: Promise<{ id: string }> };

export async function POST(req: Request, ctx: Ctx) {
  await hydrateEnv();
  const { id } = await ctx.params;
  const visitor = resolveVisitor(req);

  const settings = await getSettings();
  if (!settings.cowork.enabled) {
    return Response.json({ error: "Cowork is switched off in the Control Panel." }, { status: 403 });
  }

  const ip = clientIp(req);
  const limit = hit(`cowork-run:${ip}`, 20, 60_000, "Too many runs in one minute. Give it a moment.");
  if (!limit.ok) return Response.json({ error: limit.message, retryAfter: limit.retryAfter }, { status: 429 });

  const session = await store.getSession(id, visitor.key);
  if (!session) return Response.json({ error: "That task does not exist." }, { status: 404 });

  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const steer = typeof body.steer === "string" ? body.steer.slice(0, 1_000) : "";
  if (typeof body.goal === "string" && body.goal.trim() && body.goal.trim() !== session.goal) {
    await store.patchSession(id, { goal: body.goal.trim(), plan: [] });
  }
  if (body.restart === true) await store.patchSession(id, { plan: [], summary: null });

  const fresh = (await store.getSession(id, visitor.key)) ?? session;
  const encoder = new TextEncoder();
  const abort = new AbortController();
  req.signal.addEventListener("abort", () => abort.abort());

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      let open = true;
      const send = (event: CoworkEvent) => {
        if (!open) return;
        try {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(event)}\n\n`));
        } catch {
          open = false;
        }
      };

      const heartbeat = setInterval(() => {
        if (!open) return;
        try {
          controller.enqueue(encoder.encode(": keep-alive\n\n"));
        } catch {
          open = false;
        }
      }, 15_000);

      send({ type: "session", session: fresh });
      if (fresh.plan.length) send({ type: "plan", plan: fresh.plan });

      try {
        await runSession({ session: fresh, steer, emit: send, signal: abort.signal });
      } catch (err) {
        send({ type: "error", message: (err as Error)?.message || "The task stopped unexpectedly." });
      } finally {
        clearInterval(heartbeat);
        open = false;
        try {
          controller.close();
        } catch {
          /* already closed by the client leaving */
        }
      }
    },
  });

  return new Response(stream, {
    headers: {
      "content-type": "text/event-stream; charset=utf-8",
      "cache-control": "no-cache, no-transform",
      connection: "keep-alive",
      "x-accel-buffering": "no",
    },
  });
}
