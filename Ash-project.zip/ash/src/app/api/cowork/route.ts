import { hydrateEnv, getSettings } from "@/lib/settings";
import { resolveVisitor, withVisitorCookie } from "@/lib/auth/visitor";
import { clientIp, hit } from "@/lib/ratelimit";
import * as store from "@/lib/cowork/store";
import { LIMITS } from "@/lib/cowork/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  await hydrateEnv();
  const visitor = resolveVisitor(req);
  const settings = await getSettings();
  const sessions = await store.listSessions(visitor.key);
  return withVisitorCookie(Response.json({ sessions, enabled: settings.cowork.enabled }), visitor);
}

export async function POST(req: Request) {
  await hydrateEnv();
  const visitor = resolveVisitor(req);
  const settings = await getSettings();
  if (!settings.cowork.enabled) {
    return Response.json({ error: "Cowork is switched off in the Control Panel." }, { status: 403 });
  }

  const ip = clientIp(req);
  const limit = hit(`cowork:${ip}`, 12, 60_000, "That is a lot of new tasks in one minute. Give it a moment.");
  if (!limit.ok) return Response.json({ error: limit.message, retryAfter: limit.retryAfter }, { status: 429 });

  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const goal = typeof body.goal === "string" ? body.goal.trim() : "";
  if (!goal) return Response.json({ error: "Tell me what you want done first." }, { status: 400 });
  if (goal.length > LIMITS.maxGoalChars) {
    return Response.json({ error: `That task description is too long (limit ${LIMITS.maxGoalChars} characters).` }, { status: 400 });
  }

  const mine = await store.listSessions(visitor.key);
  if (mine.length >= 40) {
    return Response.json({ error: "You already have 40 tasks. Delete an old one first." }, { status: 400 });
  }

  const session = await store.createSession({
    ownerKey: visitor.key,
    goal,
    model: typeof body.model === "string" && body.model ? body.model : null,
    autoApprove: body.autoApprove === true ? true : settings.cowork.autoApprove,
  });
  return withVisitorCookie(Response.json({ session }), visitor);
}
