/**
 * One thought at a time, for the desktop agent.
 *
 * The desktop loop has to run in the app window, because only the window can
 * touch the real computer through Tauri. So the thinking happens here and the
 * doing happens there: the client sends what has happened so far, this returns
 * the single next action, and the client carries it out.
 */

import { hydrateEnv, getSettings } from "@/lib/settings";
import { resolveVisitor, withVisitorCookie } from "@/lib/auth/visitor";
import { clientIp, hit } from "@/lib/ratelimit";
import { complete } from "@/lib/cowork/agent";
import { buildChain, resolveModel, runtimeModels } from "@/lib/providers";
import { DEFAULT_BRANDING } from "@/lib/identity";
import type { ProviderMessage } from "@/lib/providers/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 120;

const MAX_TURNS = 40;
const MAX_CHARS = 60_000;

type Body = {
  messages?: { role?: string; content?: string }[];
  system?: string;
  model?: string | null;
};

function bad(message: string, status = 400) {
  return Response.json({ error: message }, { status });
}

export async function POST(req: Request) {
  await hydrateEnv();

  const visitor = resolveVisitor(req);

  const ip = clientIp(req);
  const limit = hit(
    `desktop:${ip}`,
    40,
    60_000,
    "That is a lot of steps very quickly. Give it a minute.",
  );
  if (!limit.ok) {
    return Response.json({ error: limit.message, retryAfter: limit.retryAfter }, { status: 429 });
  }

  let body: Body;
  try {
    body = (await req.json()) as Body;
  } catch {
    return bad("That request made no sense.");
  }

  const raw = Array.isArray(body.messages) ? body.messages : [];
  if (!raw.length) return bad("There was nothing to think about.");

  let used = 0;
  const messages: ProviderMessage[] = [];
  for (const m of raw.slice(-MAX_TURNS)) {
    const role = m.role === "assistant" ? "assistant" : "user";
    const content = String(m.content ?? "").slice(0, 20_000);
    if (!content.trim()) continue;
    used += content.length;
    if (used > MAX_CHARS) break;
    messages.push({ role, content });
  }
  if (!messages.length) return bad("There was nothing to think about.");

  const settings = await getSettings();
  if (settings.cowork?.enabled === false) {
    return bad("Cowork is switched off in the Control Panel.", 403);
  }

  const requested = body.model ? await resolveModel(body.model) : null;
  let chain = await buildChain(requested, { realEnginesOnly: true, allModels: true });
  if (!chain.length) {
    chain = (await runtimeModels()).filter((m) => m.configured && m.enabled);
  }
  if (!chain.length) {
    return bad("No engine is set up yet. Add a key in the Control Panel.", 503);
  }

  const name = settings.branding?.name || DEFAULT_BRANDING.name;
  const system = String(body.system ?? "").slice(0, 8_000) || `You are ${name}.`;

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 100_000);
  try {
    const got = await complete(chain, messages, system, controller.signal);
    if (!got.text.trim()) {
      return Response.json(
        { error: got.problem || "No engine could answer that." },
        { status: 503 },
      );
    }
    return withVisitorCookie(
      Response.json({
        text: got.text,
        model: got.model?.publicCode ?? null,
        label: got.model?.label ?? null,
      }),
      visitor,
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : "Something went wrong.";
    return Response.json({ error: message }, { status: 500 });
  } finally {
    clearTimeout(timer);
  }
}
