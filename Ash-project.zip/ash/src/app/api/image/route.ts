import { hydrateEnv, getSettings } from "@/lib/settings";
import { clientIp, hit } from "@/lib/ratelimit";
import { resolveVisitor, withVisitorCookie } from "@/lib/auth/visitor";
import { generateImage, MediaError } from "@/lib/images";
import { addMessage, createConversation, getConversation } from "@/lib/db/repo";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 300;

export async function POST(req: Request) {
  await hydrateEnv();
  const settings = await getSettings();
  if (!settings.limits.allowMedia) {
    return Response.json({ error: "Image creation is switched off right now." }, { status: 403 });
  }
  const ip = clientIp(req);
  const limit = hit(`image:${ip}`, 8, 60_000, "Image creation is limited to 8 per minute. Please wait a moment.");
  if (!limit.ok) return Response.json({ error: limit.message, retryAfter: limit.retryAfter }, { status: 429 });

  const visitor = resolveVisitor(req);
  const body = await req.json().catch(() => ({}) as any);
  const prompt = String(body.prompt ?? "").trim().slice(0, 1000);
  if (!prompt) return Response.json({ error: "Describe the image you want first." }, { status: 400 });

  try {
    const image = await generateImage(prompt, { signal: req.signal });
    let conversationId: string | null = typeof body.conversationId === "string" ? body.conversationId : null;

    if (body.save !== false) {
      let conversation = conversationId ? await getConversation(conversationId, visitor.key) : null;
      if (!conversation) {
        conversation = await createConversation({ title: prompt.slice(0, 48) || "Image", ownerKey: visitor.key });
      }
      conversationId = conversation.id;
      await addMessage({ conversationId, role: "user", content: `Create an image: ${prompt}` });
      await addMessage({
        conversationId,
        role: "assistant",
        content: `![${prompt.replace(/[[\]]/g, "")}](${image.dataUrl})`,
        model: "ash-image",
      });
    }
    return withVisitorCookie(Response.json({ dataUrl: image.dataUrl, conversationId }), visitor);
  } catch (err) {
    const detail = err instanceof MediaError ? err.detail : "";
    return Response.json(
      { error: (err as Error).message || "Could not create that image.", detail },
      { status: 502 },
    );
  }
}
