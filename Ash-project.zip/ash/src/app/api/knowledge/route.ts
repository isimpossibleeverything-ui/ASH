import { hydrateEnv, getSettings } from "@/lib/settings";
import { requireOwner } from "@/lib/auth/owner";
import { allKnowledge, clearKnowledge, knowledgeStats } from "@/lib/db/repo";
import { buildSystemPrompt } from "@/lib/identity";
import { toJsonl } from "@/lib/knowledge";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  await hydrateEnv();
  const guard = await requireOwner();
  if (guard) return guard;

  const url = new URL(req.url);
  const rows = await allKnowledge(8000);

  if (url.searchParams.get("export") === "jsonl") {
    const settings = await getSettings();
    const system = buildSystemPrompt(settings.branding, settings.systemPrompt || null);
    const body = toJsonl(rows, system);
    return new Response(body, {
      headers: {
        "content-type": "application/jsonl; charset=utf-8",
        "content-disposition": `attachment; filename="ash-knowledge-${new Date().toISOString().slice(0, 10)}.jsonl"`,
        "cache-control": "no-store",
      },
    });
  }

  const limit = Math.min(200, Math.max(1, Number(url.searchParams.get("limit") || 50)));
  return Response.json({
    ...(await knowledgeStats()),
    rows: rows.slice(0, limit).map((r) => ({
      id: r.id,
      question: r.question,
      answer: r.answer.slice(0, 400),
      topic: r.topic,
      hits: r.hits,
      createdAt: r.createdAt,
    })),
  });
}

export async function DELETE() {
  await hydrateEnv();
  const guard = await requireOwner();
  if (guard) return guard;
  await clearKnowledge();
  return Response.json({ ok: true });
}
