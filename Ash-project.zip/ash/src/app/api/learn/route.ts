import { hydrateEnv } from "@/lib/settings";
import { requireOwner } from "@/lib/auth/owner";
import { addQuestions, resumeIfEnabled, setSpeed, SPEEDS, startTrainer, stopTrainer, trainerStatus, type SpeedName } from "@/lib/knowledge/trainer";
import { recall } from "@/lib/knowledge";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function GET() {
  await hydrateEnv();
  const guard = await requireOwner();
  if (guard) return guard;
  await resumeIfEnabled();
  return Response.json(await trainerStatus());
}

export async function POST(req: Request) {
  await hydrateEnv();
  const guard = await requireOwner();
  if (guard) return guard;

  const body = await req.json().catch(() => ({}) as any);
  const action = String(body.action ?? "");

  if (action === "start") {
    const speed = String(body.speed ?? "") as SpeedName;
    await startTrainer(SPEEDS[speed] ?? undefined);
    return Response.json(await trainerStatus());
  }
  if (action === "speed") {
    const speed = String(body.speed ?? "normal") as SpeedName;
    await setSpeed(SPEEDS[speed] ?? 4);
    return Response.json(await trainerStatus());
  }
  if (action === "stop") {
    await stopTrainer();
    return Response.json(await trainerStatus());
  }
  if (action === "enqueue") {
    const added = await addQuestions(String(body.questions ?? ""));
    return Response.json({ ok: true, added, ...(await trainerStatus()) });
  }
  if (action === "test") {
    const question = String(body.question ?? "").trim();
    if (!question) return Response.json({ error: "Type a question to test." }, { status: 400 });
    const result = await recall(question);
    return Response.json(result);
  }
  return Response.json({ error: "Unknown action." }, { status: 400 });
}
