import { hydrateEnv, getSettings } from "@/lib/settings";
import { defaultModelId, publicModels } from "@/lib/providers";
import { capability } from "@/lib/images";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  await hydrateEnv();
  const models = await publicModels();
  const fallback = await defaultModelId();
  const settings = await getSettings();
  // Only {id,label,description,available,group} — no vendor names, ever.
  return Response.json({
    models,
    default: fallback,
    limits: {
      maxImages: settings.limits.maxImages,
      allowMedia: settings.limits.allowMedia,
      maxMessageChars: settings.limits.maxMessageChars,
    },
    media: settings.limits.allowMedia ? capability() : null,
  });
}
