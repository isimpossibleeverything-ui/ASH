import { cookies } from "next/headers";
import { hydrateEnv, getSettings } from "@/lib/settings";
import {
  createOwnerToken,
  getOwnerHash,
  isOwner,
  loginRateLimit,
  OWNER_COOKIE,
  ownerCookieOptions,
  setOwnerPassword,
  verifyPassword,
} from "@/lib/auth/owner";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  await hydrateEnv();
  const [hash, owner, settings] = await Promise.all([getOwnerHash(), isOwner(), getSettings()]);
  return Response.json({
    ownerExists: !!hash,
    unclaimed: !hash,
    isOwner: owner,
    branding: settings.branding,
    requireLogin: settings.limits.requireLogin,
  });
}

export async function POST(req: Request) {
  await hydrateEnv();
  const body = await req.json().catch(() => ({}) as any);
  const action = String(body.action ?? "");
  const jar = await cookies();

  if (action === "logout") {
    jar.set(OWNER_COOKIE, "", { ...ownerCookieOptions(0) });
    return Response.json({ ok: true });
  }

  if (action === "setup") {
    const existing = await getOwnerHash();
    if (existing) return Response.json({ error: "A password already exists. Sign in instead." }, { status: 400 });
    const password = String(body.password ?? "");
    if (password.length < 8) return Response.json({ error: "Use at least 8 characters." }, { status: 400 });
    await setOwnerPassword(password);
    jar.set(OWNER_COOKIE, await createOwnerToken(), ownerCookieOptions());
    return Response.json({ ok: true });
  }

  if (action === "login") {
    const limit = loginRateLimit(req);
    if (!limit.ok) return Response.json({ error: limit.message, retryAfter: limit.retryAfter }, { status: 429 });
    const hash = await getOwnerHash();
    if (!hash) return Response.json({ error: "No password has been created yet." }, { status: 400 });
    const password = String(body.password ?? "");
    if (!verifyPassword(password, hash)) return Response.json({ error: "That password is not right." }, { status: 401 });
    jar.set(OWNER_COOKIE, await createOwnerToken(), ownerCookieOptions());
    return Response.json({ ok: true });
  }

  if (action === "password") {
    if (!(await isOwner())) return Response.json({ error: "Owner access required." }, { status: 401 });
    const hash = await getOwnerHash(true);
    const current = String(body.current ?? "");
    const next = String(body.next ?? "");
    if (!hash || !verifyPassword(current, hash)) {
      return Response.json({ error: "Your current password is not right." }, { status: 401 });
    }
    if (next.length < 8) return Response.json({ error: "The new password needs at least 8 characters." }, { status: 400 });
    await setOwnerPassword(next);
    jar.set(OWNER_COOKIE, await createOwnerToken(), ownerCookieOptions());
    return Response.json({ ok: true, message: "Password changed. All old logins were signed out." });
  }

  return Response.json({ error: "Unknown action." }, { status: 400 });
}
