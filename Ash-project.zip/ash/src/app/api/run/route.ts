import { runProgram } from "@/lib/code/run";
import { clientIp, hit } from "@/lib/ratelimit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(req: Request) {
  const ip = clientIp(req);
  const limit = hit(`run:${ip}`, 20, 60_000, "That is a lot of runs in one minute. Please wait a few seconds.");
  if (!limit.ok) return Response.json({ error: limit.message, retryAfter: limit.retryAfter }, { status: 429 });

  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const code = typeof body.code === "string" ? body.code : "";
  const language = typeof body.language === "string" ? body.language : "";
  const stdin = typeof body.stdin === "string" ? body.stdin : "";

  const result = await runProgram({ code, language, stdin });
  if (!result.ok) return Response.json({ error: result.error }, { status: result.status ?? 502 });

  return Response.json({
    stdout: result.stdout,
    stderr: result.stderr,
    exitCode: result.exitCode,
    truncated: result.truncated,
    compiler: result.compiler,
  });
}
