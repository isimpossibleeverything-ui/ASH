import { hydrateEnv, getKeys, getSettings, maskKey, saveSettings, setKey, defaultSystemPromptTemplate } from "@/lib/settings";
import { requireOwner } from "@/lib/auth/owner";
import { catalogWithCustom, customKeyName, providerConfigured, providerFor, providerRanking, runtimeModels, trainingScores } from "@/lib/providers";
import { SEARCH_PROVIDERS } from "@/lib/providers/catalog";
import { clearCooldown, describeState, health } from "@/lib/providers/health";
import { readStats } from "@/lib/stats";
import { runSearchProvider } from "@/lib/search";
import { STT_PROVIDERS } from "@/lib/voice/stt";
import { TTS_PROVIDERS } from "@/lib/voice/tts";
import { scrubSecrets } from "@/lib/providers/sse";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 120;

export async function GET() {
  await hydrateEnv();
  const guard = await requireOwner();
  if (guard) return guard;

  const settings = await getSettings();
  const keys = await getKeys();
  const providers = catalogWithCustom(settings);
  const models = await runtimeModels();
  const entries = await health();
  const stats = await readStats();
  const training = await trainingScores();
  const ranking = await providerRanking(settings);

  const rows = providers
    .filter((p) => !["demo", "brain", "smart"].includes(p.id))
    .map((p) => {
      const prefs = settings.providers[p.id] ?? { enabled: p.defaultEnabled, models: p.models.map((m) => m.id) };
      const entry = entries.find((e) => e.id === p.id || e.id.startsWith(`${p.id}:`));
      return {
        id: p.id,
        vendor: p.vendor,
        publicName: p.publicName,
        note: p.note,
        signupUrl: p.signupUrl,
        paid: !!p.paid,
        custom: p.id.startsWith("custom-"),
        configured: providerConfigured(p),
        enabled: prefs.enabled !== false,
        keys: p.envKeys.concat(p.extraEnvKeys ?? []).map((name) => ({
          name,
          masked: maskKey(keys[name] || process.env[name]),
          present: !!(keys[name] || process.env[name] || "").trim(),
          fromEnv: !keys[name] && !!(process.env[name] || "").trim(),
        })),
        models: p.models.map((m) => {
          const rt = models.find((x) => x.key === `${p.id}:${m.id}`);
          return {
            id: m.id,
            label: m.label,
            description: m.description,
            vision: !!m.vision,
            exposed: prefs.models?.includes(m.id) ?? true,
            publicCode: rt?.publicCode ?? "",
          };
        }),
        trained: training[p.id] ?? 0,
        rank: ranking.indexOf(p.id) === -1 ? 999 : ranking.indexOf(p.id),
        status: entry ? describeState(entry) : providerConfigured(p) ? "Healthy" : "Key needed",
        statusKind: entry ? entry.state : providerConfigured(p) ? "healthy" : "unset",
        lastError: entry?.lastError ?? null,
      };
    });

  return Response.json({
    settings,
    providers: rows,
    searchProviders: SEARCH_PROVIDERS.map((sp) => ({
      ...sp,
      ...(settings.search.providers[sp.id] ?? { enabled: false, order: 99, url: "" }),
      hasKey: sp.needsKey ? !!(keys[searchKeyName(sp.id)] || process.env[searchKeyName(sp.id)] || "").trim() : true,
      masked: sp.needsKey ? maskKey(keys[searchKeyName(sp.id)] || process.env[searchKeyName(sp.id)]) : "",
      keyName: searchKeyName(sp.id),
    })),
    cooldowns: entries.map((e) => ({
      id: e.id,
      state: e.state,
      label: describeState(e),
      secondsLeft: Math.max(0, Math.ceil((e.until - Date.now()) / 1000)),
      lastError: e.lastError,
    })),
    stats,
    ranking,
    voiceProviders: {
      stt: STT_PROVIDERS.map((v) => ({
        id: v.id, label: v.label, note: v.note, requiresKey: v.requiresKey, configured: v.isConfigured(),
      })),
      tts: TTS_PROVIDERS.map((v) => ({
        id: v.id, label: v.label, note: v.note, requiresKey: v.requiresKey, configured: v.isConfigured(),
      })),
    },
    defaultSystemPrompt: defaultSystemPromptTemplate(),
  });
}

function searchKeyName(id: string): string {
  switch (id) {
    case "tavily":
      return "TAVILY_API_KEY";
    case "brave":
      return "BRAVE_API_KEY";
    case "serper":
      return "SERPER_API_KEY";
    case "searxng":
      return "SEARXNG_URL";
    default:
      return "";
  }
}

export async function POST(req: Request) {
  await hydrateEnv();
  const guard = await requireOwner();
  if (guard) return guard;

  const body = await req.json().catch(() => ({}) as any);
  const action = String(body.action ?? "save");

  if (action === "save") {
    const settings = await saveSettings(body.patch ?? {});
    return Response.json({ ok: true, settings });
  }

  if (action === "key") {
    const name = String(body.name ?? "").trim();
    if (!/^[A-Z0-9_]{3,64}$/.test(name)) return Response.json({ error: "That key name is not valid." }, { status: 400 });
    await setKey(name, String(body.value ?? "").trim());
    await clearCooldown();
    return Response.json({ ok: true, masked: maskKey(String(body.value ?? "").trim()) });
  }

  if (action === "reset-cooldowns") {
    await clearCooldown(body.id ? String(body.id) : undefined);
    return Response.json({ ok: true });
  }

  if (action === "test") {
    const providerId = String(body.providerId ?? "");
    const settings = await getSettings();
    const all = catalogWithCustom(settings);
    const p = all.find((x) => x.id === providerId);
    if (!p) return Response.json({ error: "Unknown engine." }, { status: 400 });
    const prefs = settings.providers[p.id];
    const modelId = String(body.modelId ?? "") || prefs?.models?.[0] || p.models[0]?.id;
    if (!modelId) return Response.json({ error: "This engine has no model selected." }, { status: 400 });

    const models = await runtimeModels();
    const rt = models.find((m) => m.key === `${p.id}:${modelId}`);
    if (!rt) return Response.json({ error: "Unknown model." }, { status: 400 });

    const started = Date.now();
    const controller = new AbortController();
    // free models can queue for a few seconds when busy, so allow headroom
    const timer = setTimeout(() => controller.abort(), 45_000);
    try {
      const provider = await providerFor(rt);
      let text = "";
      for await (const chunk of provider.stream({
        model: rt.modelId,
        messages: [{ role: "user", content: "Say OK" }],
        system: "Reply with the single word OK.",
        temperature: 0,
        signal: controller.signal,
      })) {
        text += chunk;
        if (text.trim().length > 0) break;
      }
      const ms = Date.now() - started;
      if (!text.trim()) return Response.json({ ok: false, error: "The engine answered with nothing." });
      await clearCooldown(p.id);
      return Response.json({ ok: true, ms, reply: text.trim().slice(0, 60) });
    } catch (err) {
      return Response.json({ ok: false, error: scrubSecrets((err as Error).message || "Test failed.") });
    } finally {
      clearTimeout(timer);
    }
  }

  if (action === "list-models") {
    const providerId = String(body.providerId ?? "");
    const settings = await getSettings();
    const p = catalogWithCustom(settings).find((x) => x.id === providerId);
    if (!p) return Response.json({ error: "Unknown engine." }, { status: 400 });
    const fallback = p.models.map((m) => m.id);
    if (!p.modelsEndpoint) return Response.json({ models: fallback, source: "catalog" });
    try {
      const headers: Record<string, string> = { accept: "application/json" };
      const key = (process.env[p.envKeys[0]] || "").trim();
      if (p.kind === "gemini") headers["x-goog-api-key"] = key;
      else if (key) headers.authorization = `Bearer ${key}`;
      const res = await fetch(p.modelsEndpoint, { headers, cache: "no-store", signal: AbortSignal.timeout(12_000) });
      if (!res.ok) return Response.json({ models: fallback, source: "catalog" });
      const data = (await res.json()) as any;
      const ids: string[] =
        p.kind === "gemini"
          ? (data?.models ?? []).map((m: any) => String(m.name || "").replace(/^models\//, ""))
          : (data?.data ?? data?.models ?? []).map((m: any) => String(m.id || m.name || ""));
      const clean = ids.filter(Boolean).slice(0, 400);
      return Response.json({ models: clean.length ? clean : fallback, source: clean.length ? "live" : "catalog" });
    } catch {
      return Response.json({ models: fallback, source: "catalog" });
    }
  }

  if (action === "custom-add") {
    const label = String(body.label ?? "").trim().slice(0, 40);
    const baseUrl = String(body.baseUrl ?? "").trim();
    const model = String(body.model ?? "").trim();
    const note = String(body.note ?? "").trim().slice(0, 80);
    const key = String(body.key ?? "").trim();
    if (!label || !baseUrl || !model) return Response.json({ error: "Name, base URL and model id are all needed." }, { status: 400 });
    if (!/^https?:\/\//.test(baseUrl)) return Response.json({ error: "The base URL must start with http:// or https://" }, { status: 400 });
    const id = `${label.toLowerCase().replace(/[^a-z0-9]+/g, "")}${Date.now().toString(36).slice(-4)}`.slice(0, 24);
    const settings = await getSettings();
    const customEngines = [...settings.customEngines, { id, label, baseUrl, model, note, enabled: true }];
    if (key) await setKey(customKeyName(id), key);
    const next = await saveSettings({
      customEngines,
      providers: { ...settings.providers, [`custom-${id}`]: { enabled: true, models: [model] } },
      fallbackOrder: [...settings.fallbackOrder, `custom-${id}`],
    });
    return Response.json({ ok: true, settings: next });
  }

  if (action === "custom-remove") {
    const id = String(body.id ?? "");
    const settings = await getSettings();
    const customEngines = settings.customEngines.filter((c) => c.id !== id);
    await setKey(customKeyName(id), "");
    const next = await saveSettings({
      customEngines,
      fallbackOrder: settings.fallbackOrder.filter((p) => p !== `custom-${id}`),
    });
    return Response.json({ ok: true, settings: next });
  }

  if (action === "test-search") {
    const id = String(body.id ?? "");
    const settings = await getSettings();
    const conf = settings.search.providers[id];
    const started = Date.now();
    try {
      let hits = await runSearchProvider(id, "latest technology news", 3, conf?.url);
      if (!hits.length) hits = await runSearchProvider(id, "artificial intelligence", 3, conf?.url);
      return Response.json({ ok: hits.length > 0, ms: Date.now() - started, count: hits.length, sample: hits[0]?.title ?? null });
    } catch (err) {
      return Response.json({ ok: false, error: scrubSecrets((err as Error).message || "Search failed.") });
    }
  }

  return Response.json({ error: "Unknown action." }, { status: 400 });
}
