import { statSync } from "node:fs";
import path from "node:path";
import { hydrateEnv } from "@/lib/settings";
import { requireOwner } from "@/lib/auth/owner";
import { countConversations, countMessages, driverLabel, knowledgeStats } from "@/lib/db/repo";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Storage is fully automatic. This endpoint only reports where data lives. */
export async function GET() {
  await hydrateEnv();
  const guard = await requireOwner();
  if (guard) return guard;

  const driver = await driverLabel();
  let fileSize: number | null = null;
  if (driver.startsWith("sqlite")) {
    try {
      fileSize = statSync(path.join(process.cwd(), "data", "app.db")).size;
    } catch {
      fileSize = null;
    }
  }
  const [conversations, messages, knowledge] = await Promise.all([countConversations(), countMessages(), knowledgeStats()]);
  return Response.json({ driver, fileSize, counts: { conversations, messages, knowledge: knowledge.total } });
}
