import { hydrateEnv, getSettings } from "@/lib/settings";
import { requireOwner } from "@/lib/auth/owner";
import { countConversations, countMessages, driverLabel, knowledgeStats } from "@/lib/db/repo";
import { runtimeModels } from "@/lib/providers";
import { readStats } from "@/lib/stats";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  await hydrateEnv();
  const guard = await requireOwner();
  if (guard) return guard;

  const [driver, conversations, messages, knowledge, models, settings, stats] = await Promise.all([
    driverLabel(),
    countConversations(),
    countMessages(),
    knowledgeStats(),
    runtimeModels(),
    getSettings(),
    readStats(),
  ]);

  return Response.json({
    version: "1.0.0",
    node: process.version,
    driver,
    counts: { conversations, messages, knowledge: knowledge.total },
    engines: models
      .filter((m) => m.group === "full" && m.configured && m.enabled)
      .map((m) => ({ publicCode: m.publicCode, label: m.label, vendor: m.vendor })),
    settingsSummary: {
      searchMode: settings.search.mode,
      requireLogin: settings.limits.requireLogin,
      allowMedia: settings.limits.allowMedia,
      learning: settings.learning.running,
    },
    today: stats,
  });
}
