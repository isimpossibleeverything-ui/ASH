import { hydrateEnv, getSettings } from "@/lib/settings";
import { clientIp, hit } from "@/lib/ratelimit";
import { resolveVisitor } from "@/lib/auth/visitor";
import { capability, generateFrames, MediaError } from "@/lib/images";
import { addMessage, createConversation, getConversation } from "@/lib/db/repo";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 300;

/** Clips are stored as a fenced ash-clip block so they survive a reload. */
function clipBlock(payload: { prompt: string; fps: number; mode: string; frames: string[] }): string {
  return ["```ash-clip", JSON.stringify(payload), "```"].join("\n");
}

const sse = (event: string, data: unknown) =>
  new TextEncoder().encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);

export async function POST(req: Request) {
  await hydrateEnv();
  const settings = await getSettings();
  if (!settings.limits.allowMedia) {
    return Response.json({ error: "Clip creation is switched off right now." }, { status: 403 });
  }
  const ip = clientIp(req);
  const limit = hit(`video:${ip}`, 3, 60_000, "Clips are limited to 3 per minute. Please wait a moment.");
  if (!limit.ok) return Response.json({ error: limit.message, retryAfter: limit.retryAfter }, { status: 429 });

  const visitor = resolveVisitor(req);
  const body = await req.json().catch(() => ({}) as any);
  const prompt = String(body.prompt ?? "").trim().slice(0, 1000);
  if (!prompt) return Response.json({ error: "Describe the clip you want first." }, { status: 400 });

  const cap = capability();
  const requested = cap.clipMode === "motion" ? 1 : Math.min(10, Math.max(2, Number(body.frames) || cap.suggestedFrames));
  const incomingId = typeof body.conversationId === "string" ? body.conversationId : null;

  const abort = new AbortController();
  req.signal.addEventListener("abort", () => abort.abort(), { once: true });

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      let closed = false;
      const send = (event: string, data: unknown) => {
        if (closed) return;
        try {
          controller.enqueue(sse(event, data));
        } catch {
          closed = true;
        }
      };
      const close = () => {
        if (closed) return;
        closed = true;
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      };

      send("start", {
        total: requested,
        keylessOnly: cap.keylessOnly,
        mode: cap.clipMode,
        waitMs: cap.waitMs,
        note:
          cap.clipMode === "motion"
            ? "No image key yet, so this is a one-frame motion clip. Add a free key in the Control Panel for full frame-by-frame clips."
            : "",
      });

      try {
        const clip = await generateFrames(prompt, requested, abort.signal, (p) => send("progress", p));

        let conversationId = incomingId;
        if (body.save !== false) {
          let conversation = conversationId ? await getConversation(conversationId, visitor.key) : null;
          if (!conversation) {
            conversation = await createConversation({ title: prompt.slice(0, 48) || "Clip", ownerKey: visitor.key });
          }
          conversationId = conversation.id;
          await addMessage({ conversationId, role: "user", content: `Create a short clip: ${prompt}` });
          await addMessage({
            conversationId,
            role: "assistant",
            content: clipBlock({ prompt, fps: clip.fps, mode: clip.mode, frames: clip.frames }),
            model: "ash-clip",
          });
        }

        send("done", {
          frames: clip.frames,
          fps: clip.fps,
          mode: clip.mode,
          conversationId,
          requested: clip.requested,
          partial: clip.frames.length < clip.requested,
        });
      } catch (err) {
        const media = err instanceof MediaError ? err : null;
        send("error", {
          message: (err as Error)?.message || "Could not create that clip.",
          detail: media?.detail ?? "",
          retryAfter: media?.retryAfter ?? 0,
        });
      } finally {
        close();
      }
    },
    cancel() {
      abort.abort();
    },
  });

  const res = new Response(stream, {
    headers: {
      "content-type": "text/event-stream; charset=utf-8",
      "cache-control": "no-cache, no-transform",
      "x-accel-buffering": "no",
    },
  });
  if (visitor.setCookie) res.headers.append("set-cookie", visitor.setCookie);
  return res;
}
