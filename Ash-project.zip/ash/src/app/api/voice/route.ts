import { hydrateEnv, getSettings } from "@/lib/settings";
import { configuredStt, STT_PROVIDERS } from "@/lib/voice/stt";
import { configuredTts, TTS_PROVIDERS } from "@/lib/voice/tts";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * What the browser needs to know about voice. Public on purpose: it carries
 * capability flags and public labels only — never keys or vendor endpoints.
 */
export async function GET() {
  await hydrateEnv();
  const settings = await getSettings();
  const stt = configuredStt();
  const tts = configuredTts();

  return Response.json({
    voice: settings.voice,
    server: {
      stt: stt.map((p) => ({ id: p.id, label: p.label })),
      tts: tts.map((p) => ({ id: p.id, label: p.label })),
    },
    // Browser engines always exist; the client fills in the detail.
    hasServerStt: stt.length > 0,
    hasServerTts: tts.length > 0,
    knownProviders: {
      stt: STT_PROVIDERS.map((p) => ({ id: p.id, label: p.label })),
      tts: TTS_PROVIDERS.map((p) => ({ id: p.id, label: p.label })),
    },
  });
}
