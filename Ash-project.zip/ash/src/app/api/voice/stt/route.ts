import { hydrateEnv, getSettings } from "@/lib/settings";
import { clientIp, hit } from "@/lib/ratelimit";
import { sttProvider, transcribeWithFallback } from "@/lib/voice/stt";
import { MAX_STT_BYTES } from "@/lib/voice/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 120;

export async function POST(req: Request) {
  await hydrateEnv();
  const settings = await getSettings();
  if (!settings.voice.enabled) {
    return Response.json({ error: "Voice is switched off." }, { status: 403 });
  }

  const limit = hit(`stt:${clientIp(req)}`, 40, 60_000, "Too many recordings in one minute. Please wait a moment.");
  if (!limit.ok) return Response.json({ error: limit.message, retryAfter: limit.retryAfter }, { status: 429 });

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return Response.json({ error: "That recording could not be read." }, { status: 400 });
  }

  const audio = form.get("audio");
  if (!(audio instanceof Blob) || audio.size === 0) {
    return Response.json({ error: "No recording was received." }, { status: 400 });
  }
  if (audio.size > MAX_STT_BYTES) {
    return Response.json({ error: "That recording is too long. Keep it under a minute or two." }, { status: 413 });
  }

  const wanted = String(form.get("provider") ?? settings.voice.sttProvider ?? "");
  if (wanted && wanted !== "browser" && !sttProvider(wanted)) {
    return Response.json({ error: "Unknown speech engine." }, { status: 400 });
  }
  const lang = String(form.get("lang") ?? settings.voice.voiceLang ?? "auto");

  try {
    const result = await transcribeWithFallback(wanted === "browser" ? undefined : wanted, {
      audio,
      lang,
      signal: req.signal,
    });
    return Response.json(result);
  } catch (err) {
    return Response.json({ error: (err as Error).message || "Could not understand that recording." }, { status: 502 });
  }
}
