import { hydrateEnv, getSettings } from "@/lib/settings";
import { clientIp, hit } from "@/lib/ratelimit";
import { synthesizeWithFallback, ttsProvider } from "@/lib/voice/tts";
import { MAX_TTS_CHARS, speakableText } from "@/lib/voice/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 120;

export async function POST(req: Request) {
  await hydrateEnv();
  const settings = await getSettings();
  if (!settings.voice.enabled) {
    return Response.json({ error: "Voice is switched off." }, { status: 403 });
  }

  const limit = hit(`tts:${clientIp(req)}`, 30, 60_000, "That is a lot of speech in one minute. Please wait a moment.");
  if (!limit.ok) return Response.json({ error: limit.message, retryAfter: limit.retryAfter }, { status: 429 });

  const body = await req.json().catch(() => ({}) as any);
  const raw = String(body.text ?? "");
  const text = speakableText(raw, MAX_TTS_CHARS);
  if (!text) return Response.json({ error: "There is nothing to read out." }, { status: 400 });

  const wanted = String(body.provider ?? settings.voice.ttsProvider ?? "");
  if (wanted && wanted !== "browser" && !ttsProvider(wanted)) {
    return Response.json({ error: "Unknown voice engine." }, { status: 400 });
  }

  try {
    const audio = await synthesizeWithFallback(wanted === "browser" ? undefined : wanted, {
      text,
      voice: typeof body.voice === "string" ? body.voice : settings.voice.ttsVoice,
      lang: typeof body.lang === "string" ? body.lang : settings.voice.voiceLang,
      rate: Number(body.rate) || settings.voice.rate,
      signal: req.signal,
    });
    return new Response(audio.body, {
      headers: {
        "content-type": audio.mimeType,
        "cache-control": "no-store",
        "x-voice-provider": audio.provider,
      },
    });
  } catch (err) {
    // The client falls back to the browser's own voice on a non-2xx.
    return Response.json({ error: (err as Error).message || "Could not read that out." }, { status: 502 });
  }
}
