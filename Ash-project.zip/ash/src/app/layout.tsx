import type { Metadata, Viewport } from "next";
import Script from "next/script";
import { PwaBoot } from "@/components/InstallApp";
import "./globals.css";

const APP_NAME = process.env.AI_NAME || "Ash";

export const metadata: Metadata = {
  title: `${APP_NAME} — AI chat`,
  description: `${APP_NAME} is a free AI chat app: streaming answers, saved history, markdown and code you can actually run.`,
  applicationName: APP_NAME,
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, title: APP_NAME, statusBarStyle: "default" },
  formatDetection: { telephone: false },
  icons: {
    icon: [
      {
        url:
          "data:image/svg+xml," +
          encodeURIComponent(
            `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="8" fill="#bd5d3a"/><text x="16" y="23" font-family="Georgia,serif" font-size="20" font-weight="700" fill="#fff" text-anchor="middle">A</text></svg>`,
          ),
      },
      { url: "/icons/favicon-32.png", sizes: "32x32", type: "image/png" },
      { url: "/icons/favicon-64.png", sizes: "64x64", type: "image/png" },
      { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [{ url: "/icons/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#faf9f5" },
    { media: "(prefers-color-scheme: dark)", color: "#1c1b19" },
  ],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* Real blocking script, served from /public — runs before paint and
            never enters the React tree, so there is no flash and no warning. */}
        <Script src="/theme.js" strategy="beforeInteractive" />
      </head>
      <body>
        <PwaBoot />
        {children}
      </body>
    </html>
  );
}
