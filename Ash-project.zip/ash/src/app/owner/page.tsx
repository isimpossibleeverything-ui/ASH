"use client";

import { useCallback, useEffect, useState } from "react";
import OwnerGate from "@/components/OwnerGate";
import ControlPanel from "@/components/ControlPanel";

export default function OwnerPage() {
  const [state, setState] = useState<{ loading: boolean; ownerExists: boolean; isOwner: boolean; unclaimed: boolean }>({
    loading: true,
    ownerExists: false,
    isOwner: false,
    unclaimed: false,
  });

  const refresh = useCallback(async () => {
    try {
      const data = await fetch("/api/owner").then((r) => r.json());
      setState({ loading: false, ownerExists: !!data.ownerExists, isOwner: !!data.isOwner, unclaimed: !!data.unclaimed });
    } catch {
      setState({ loading: false, ownerExists: false, isOwner: false, unclaimed: false });
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  if (state.loading) {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-paper">
        <p className="text-[13px] text-muted">Loading…</p>
      </div>
    );
  }

  if (!state.isOwner && !state.unclaimed) {
    return <OwnerGate ownerExists={state.ownerExists} onUnlocked={() => void refresh()} />;
  }

  return <ControlPanel unclaimed={state.unclaimed} onSignedOut={() => void refresh()} />;
}
