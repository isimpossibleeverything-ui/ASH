import ChatApp from "@/components/ChatApp";

export const dynamic = "force-dynamic";

export default function Home() {
  return <ChatApp />;
}
