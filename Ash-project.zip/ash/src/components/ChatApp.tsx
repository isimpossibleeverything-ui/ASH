"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import type { Conversation, PublicModel } from "@/lib/types";
import { DEFAULT_PREFS, loadPrefs, savePrefs, type Prefs } from "@/lib/prefs";
import { useVoiceSession } from "@/lib/useVoiceSession";
import VoiceOrb, { VoiceErrorBar } from "./VoiceOrb";
import type { ServerVoiceInfo } from "./VoiceSettings";
import { streamChat } from "@/lib/stream-client";
import Sidebar from "./Sidebar";
import Composer, { type Attachment, type ComposerMode } from "./Composer";
import MessageItem, { ErrorBlock, type UiMessage } from "./MessageItem";
import EmptyState from "./EmptyState";
import ModelPicker from "./ModelPicker";
import SettingsDialog from "./SettingsDialog";
import CodePreview, { type PreviewPayload } from "./CodePreview";
import LoginGate from "./LoginGate";
import Splash from "./Splash";
import { IconAlert, IconArrowDown, IconDownload, IconMic, IconPlay, IconPlus, IconSidebar, IconSpark, IconTerminal, IconX } from "./Icons";
import { isPreviewable } from "@/lib/code";
import CoworkPanel, { type CoworkHandle } from "./CoworkPanel";
import ComputerPanel from "./ComputerPanel";
import { useVoiceCommands } from "@/lib/useVoiceCommands";

interface OwnerState {
  ownerExists: boolean;
  isOwner: boolean;
  branding: { name: string; creator: string; country: string; city: string };
}

interface AccountState {
  required: boolean;
  available: boolean;
  signedIn: boolean;
  email: string | null;
}

const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

interface RunPayload {
  message?: string;
  regenerateFrom?: string;
  images?: { mimeType: string; data: string }[];
  previews?: string[];
  optimisticUser?: boolean;
}

type RetryAction = { type: "stream"; payload: RunPayload } | { type: "media"; kind: "image" | "video"; prompt: string };

function lastRunnableBlock(content: string): { code: string; language: string } | null {
  const matches = [...content.matchAll(/```([\w+#-]*)\n([\s\S]*?)```/g)];
  for (let i = matches.length - 1; i >= 0; i--) {
    const language = (matches[i][1] || "").toLowerCase();
    const code = matches[i][2] ?? "";
    if (isPreviewable(language, code)) return { code: code.replace(/\n$/, ""), language: language || "html" };
  }
  return null;
}

export default function ChatApp() {
  const router = useRouter();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<UiMessage[]>([]);
  const [models, setModels] = useState<PublicModel[]>([]);
  const [defaultModel, setDefaultModel] = useState("");
  const [prefs, setPrefs] = useState<Prefs>(() => ({ ...DEFAULT_PREFS, voice: { ...DEFAULT_PREFS.voice } }));
  const [serverVoice, setServerVoice] = useState<ServerVoiceInfo | null>(null);
  const [voicePanel, setVoicePanel] = useState(false);
  const [input, setInput] = useState("");
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [mode, setMode] = useState<ComposerMode>("chat");
  const [streaming, setStreaming] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [preview, setPreview] = useState<PreviewPayload | null>(null);
  const [owner, setOwner] = useState<OwnerState>({ ownerExists: true, isOwner: false, branding: { name: "Ash", creator: "", country: "", city: "" } });
  const [account, setAccount] = useState<AccountState>({ required: false, available: false, signedIn: false, email: null });
  const [stick, setStick] = useState(true);
  const [limits, setLimits] = useState({ maxImages: 4, allowMedia: true });
  const [media, setMedia] = useState<{ keylessOnly: boolean; suggestedFrames: number; clipMode?: "frames" | "motion" } | null>(null);

  const scrollRef = useRef<HTMLDivElement | null>(null);
  const bottomRef = useRef<HTMLDivElement | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const [retry, setRetry] = useState<RetryAction | null>(null);
  const coworkRef = useRef<CoworkHandle | null>(null);
  const headerRunnableRef = useRef<PreviewPayload | null>(null);
  const [heard, setHeard] = useState<string | null>(null);
  /** When on, every spoken sentence is read as a command, not dictation. */
  const [commandMode, setCommandMode] = useState(false);

  const appName = owner.branding.name || "Ash";
  const activeConversation = conversations.find((c) => c.id === activeId) ?? null;

  /* ───────────── bootstrap ───────────── */
  useEffect(() => {
    const p = loadPrefs();
    setPrefs(p);

    void (async () => {
      try {
        const [modelsRes, convRes, ownerRes, authRes, voiceRes] = await Promise.all([
          fetch("/api/models").then((r) => r.json()),
          fetch("/api/conversations").then((r) => r.json()),
          fetch("/api/owner").then((r) => r.json()),
          fetch("/api/auth").then((r) => r.json()),
          fetch("/api/voice").then((r) => r.json()).catch(() => null),
        ]);
        if (voiceRes?.server) setServerVoice(voiceRes.server);
        const list: PublicModel[] = modelsRes.models ?? [];
        setModels(list);
        setDefaultModel(modelsRes.default ?? "");
        setPrefs((prev) => {
          const chosen = list.find((m) => m.id === prev.model);
          const hasKeyedEngine = list.some((m) => m.group === "full");
          // Keep a deliberate choice, but never leave someone stuck on an offline
          // engine once a real key has been added.
          const keep = !!chosen && (chosen.group === "full" || !hasKeyedEngine);
          const next = keep ? prev : { ...prev, model: modelsRes.default ?? list[0]?.id ?? "" };
          savePrefs(next);
          return next;
        });
        setMedia(modelsRes.media ?? null);
        if (modelsRes.limits) {
          setLimits({
            maxImages: Number(modelsRes.limits.maxImages) || 4,
            allowMedia: modelsRes.limits.allowMedia !== false,
          });
        }
        setConversations(convRes.conversations ?? []);
        setOwner({
          ownerExists: !!ownerRes.ownerExists,
          isOwner: !!ownerRes.isOwner,
          branding: ownerRes.branding ?? { name: "Ash", creator: "", country: "", city: "" },
        });
        setAccount({
          required: !!authRes.required,
          available: !!authRes.available,
          signedIn: !!authRes.signedIn,
          email: authRes.email ?? null,
        });
      } catch {
        /* offline first paint is fine */
      }
    })();
  }, []);

  const updateVoice = useCallback((patch: Partial<Prefs["voice"]>) => {
    setPrefs((prev) => {
      const next = { ...prev, voice: { ...prev.voice, ...patch } };
      savePrefs(next);
      return next;
    });
  }, []);

  const updatePrefs = useCallback((patch: Partial<Prefs>) => {
    setPrefs((prev) => {
      const next = { ...prev, ...patch };
      savePrefs(next);
      return next;
    });
  }, []);

  /* ───────────── scrolling ───────────── */
  useEffect(() => {
    if (stick) bottomRef.current?.scrollIntoView({ block: "end" });
  }, [messages, stick]);

  const onScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    const distance = el.scrollHeight - el.scrollTop - el.clientHeight;
    setStick(distance < 90);
  };

  /* ───────────── keyboard shortcuts ───────────── */
  const newChat = useCallback(() => {
    abortRef.current?.abort();
    setActiveId(null);
    setMessages([]);
    setInput("");
    setAttachments([]);
    setError(null);
    setNotice(null);
    setMode("chat");
    setStick(true);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const meta = e.metaKey || e.ctrlKey;
      if (!meta) return;
      if (e.key.toLowerCase() === "b") {
        e.preventDefault();
        setSidebarOpen((o) => !o);
      } else if (e.key.toLowerCase() === "k") {
        e.preventDefault();
        newChat();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [newChat]);

  /* ───────────── conversations ───────────── */
  const refreshConversations = useCallback(async () => {
    try {
      const data = await fetch("/api/conversations").then((r) => r.json());
      setConversations(data.conversations ?? []);
    } catch {
      /* ignore */
    }
  }, []);

  const openConversation = useCallback(async (id: string) => {
    abortRef.current?.abort();
    setActiveId(id);
    setError(null);
    setNotice(null);
    setSidebarOpen(false);
    setStick(true);
    try {
      const data = await fetch(`/api/conversations/${id}`).then((r) => r.json());
      setMessages(
        (data.messages ?? [])
          .filter((m: any) => m.role !== "system")
          .map((m: any) => ({ id: m.id, role: m.role, content: m.content, model: m.model, createdAt: m.createdAt })),
      );
      if (data.conversation?.model) updatePrefs({ model: data.conversation.model });
    } catch {
      setError("That chat could not be opened.");
    }
  }, [updatePrefs]);

  const renameConversation = async (id: string, title: string) => {
    setConversations((prev) => prev.map((c) => (c.id === id ? { ...c, title } : c)));
    await fetch(`/api/conversations/${id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ title }),
    }).catch(() => {});
  };

  const toggleArchive = async (id: string, archived: boolean) => {
    setConversations((prev) => prev.map((c) => (c.id === id ? { ...c, archived } : c)));
    if (archived && id === activeId) newChat();
    await fetch(`/api/conversations/${id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ archived }),
    }).catch(() => {});
  };

  const togglePin = async (id: string, pinned: boolean) => {
    setConversations((prev) =>
      [...prev.map((c) => (c.id === id ? { ...c, pinned } : c))].sort(
        (a, b) => Number(b.pinned) - Number(a.pinned) || b.updatedAt - a.updatedAt,
      ),
    );
    await fetch(`/api/conversations/${id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ pinned }),
    }).catch(() => {});
  };

  const removeConversation = async (id: string) => {
    setConversations((prev) => prev.filter((c) => c.id !== id));
    if (id === activeId) newChat();
    await fetch(`/api/conversations/${id}`, { method: "DELETE" }).catch(() => {});
  };

  const deleteAll = async () => {
    await fetch("/api/conversations", { method: "DELETE" }).catch(() => {});
    setConversations([]);
    newChat();
  };

  /* ───────────── sending ───────────── */
  const runStream = useCallback(
    async (payload: RunPayload) => {
      setError(null);
      setRetry(null);
      setNotice(null);
      setStreaming(true);
      setStick(true);

      const controller = new AbortController();
      abortRef.current = controller;

      const assistantId = uid();
      const localUserId = uid();

      setMessages((prev) => {
        let next = [...prev];
        if (payload.regenerateFrom) {
          const idx = next.findIndex((m) => m.id === payload.regenerateFrom);
          if (idx >= 0) next = next.slice(0, idx);
        }
        if (payload.optimisticUser && payload.message !== undefined) {
          next.push({ id: localUserId, role: "user", content: payload.message, images: payload.previews });
        }
        next.push({ id: assistantId, role: "assistant", content: "", model: prefs.model });
        return next;
      });

      let conversationIdForRun = activeId ?? undefined;

      await streamChat(
        {
          conversationId: conversationIdForRun,
          message: payload.message,
          model: prefs.model || undefined,
          systemPrompt: prefs.systemPrompt || undefined,
          temperature: prefs.temperature,
          regenerateFrom: payload.regenerateFrom,
          images: payload.images,
          search: prefs.search === "on" ? true : prefs.search === "off" ? false : undefined,
          replyLanguage: prefs.replyLanguage && prefs.replyLanguage !== "auto" ? prefs.replyLanguage : undefined,
          useMemory: prefs.useMemory,
        },
        {
          onMeta: (meta) => {
            conversationIdForRun = meta.conversationId;
            if (!activeId) setActiveId(meta.conversationId);
            setMessages((prev) => prev.map((m) => (m.id === localUserId ? { ...m, id: meta.userMessageId || m.id } : m)));
          },
          onNotice: (n) => setNotice(n.message),
          onModel: (m) => setMessages((prev) => prev.map((x) => (x.id === assistantId ? { ...x, model: m.model } : x))),
          onSources: (s) => setMessages((prev) => prev.map((x) => (x.id === assistantId ? { ...x, sources: s.hits } : x))),
          onDelta: (d) =>
            setMessages((prev) => prev.map((x) => (x.id === assistantId ? { ...x, content: x.content + d.text } : x))),
          onError: (e) => {
            setError(e.message);
            setRetry({ type: "stream", payload });
          },
          onDone: (d) => {
            if (prefs.voice.autoSpeak && d.content?.trim()) speakRef.current(d.content);
            setMessages((prev) =>
              prev
                .map((x) => (x.id === assistantId ? { ...x, id: d.assistantMessageId || x.id, model: d.model || x.model } : x))
                .filter((x) => x.role !== "assistant" || x.content.trim().length > 0),
            );
            void refreshConversations();
          },
        },
        controller.signal,
      );

      if (abortRef.current === controller) {
        abortRef.current = null;
        setStreaming(false);
      }
    },
    [activeId, prefs, refreshConversations],
  );

  const createMedia = useCallback(
    async (kind: "image" | "video", prompt: string) => {
      setError(null);
      setRetry(null);
      setStreaming(true);
      const userId = uid();
      const assistantId = uid();
      setMessages((prev) => [
        ...prev,
        { id: userId, role: "user", content: prompt },
        { id: assistantId, role: "assistant", content: "" },
      ]);

      const patch = (fields: Partial<UiMessage>) =>
        setMessages((prev) => prev.map((m) => (m.id === assistantId ? { ...m, ...fields } : m)));

      const controller = new AbortController();
      abortRef.current = controller;

      try {
        if (kind === "image") {
          patch({ content: "_Painting your picture…_" });
          const res = await fetch("/api/image", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ prompt, conversationId: activeId ?? undefined }),
            signal: controller.signal,
          });
          const data = await res.json();
          if (!res.ok) throw new Error([data.error, data.detail].filter(Boolean).join(" — ") || "That did not work.");
          if (data.conversationId && !activeId) setActiveId(data.conversationId);
          patch({ content: `![${prompt}](${data.dataUrl})` });
        } else {
          // Clips stream their progress so nobody watches a dead spinner.
          const res = await fetch("/api/video", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ prompt, conversationId: activeId ?? undefined }),
            signal: controller.signal,
          });
          if (!res.ok || !res.body) {
            const data = await res.json().catch(() => ({}));
            throw new Error(data.error || "Could not start the clip.");
          }

          const reader = res.body.getReader();
          const decoder = new TextDecoder();
          let buffer = "";
          let failure: string | null = null;
          let note = "";

          for (;;) {
            const { done, value } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value, { stream: true });
            buffer = buffer.replace(/\r\n/g, "\n");
            let sep: number;
            while ((sep = buffer.indexOf("\n\n")) !== -1) {
              const block = buffer.slice(0, sep);
              buffer = buffer.slice(sep + 2);
              let event = "message";
              const payload: string[] = [];
              for (const line of block.split("\n")) {
                if (line.startsWith("event:")) event = line.slice(6).trim();
                else if (line.startsWith("data:")) payload.push(line.slice(5).replace(/^ /, ""));
              }
              let data: any = {};
              try {
                data = JSON.parse(payload.join("\n") || "{}");
              } catch {
                continue;
              }

              if (event === "start") {
                note = data.note || "";
                patch({
                  content:
                    (data.mode === "motion" ? "_Creating your motion clip…_" : `_Making a ${data.total}-frame clip…_`) +
                    (note ? `\n\n${note}` : ""),
                });
              } else if (event === "progress") {
                const waiting = data.waitMs > 1500 ? ` — next frame in ${Math.ceil(data.waitMs / 1000)}s` : "";
                patch({
                  content: `_Frame ${Math.min(data.done + 1, data.total)} of ${data.total}${waiting}_${note ? `\n\n${note}` : ""}`,
                });
              } else if (event === "done") {
                if (data.conversationId && !activeId) setActiveId(data.conversationId);
                patch({
                  frames: data.frames ?? [],
                  clipMode: data.mode ?? "frames",
                  clipPrompt: prompt,
                  content: data.partial ? `Clip made from ${data.frames.length} of ${data.requested} frames.` : "",
                });
              } else if (event === "error") {
                failure = [data.message, data.detail].filter(Boolean).join(" — ");
              }
            }
          }
          if (failure) throw new Error(failure);
        }
        void refreshConversations();
      } catch (err) {
        if ((err as Error)?.name === "AbortError") {
          setMessages((prev) => prev.filter((m) => m.id !== assistantId));
        } else {
          setMessages((prev) => prev.filter((m) => m.id !== assistantId));
          setError((err as Error).message);
          setRetry({ type: "media", kind, prompt });
        }
      } finally {
        if (abortRef.current === controller) {
          abortRef.current = null;
          setStreaming(false);
        }
        setMode("chat");
      }
    },
    [activeId, refreshConversations],
  );

  const sendText = useCallback(
    (text: string) => {
      const t = text.trim();
      if (!t) return;
      setMode("chat");
      void runStream({ message: t, optimisticUser: true });
    },
    [runStream],
  );

  const send = useCallback(() => {
    const text = input.trim();
    if (!text && !attachments.length) return;
    setInput("");
    const images = attachments.map((a) => ({ mimeType: a.mimeType, data: a.data }));
    const previews = attachments.map((a) => a.preview);
    setAttachments([]);

    if (mode === "image" || mode === "video") {
      void createMedia(mode, text);
      return;
    }
    void runStream({ message: text, images: images.length ? images : undefined, previews, optimisticUser: true });
  }, [input, attachments, mode, createMedia, runStream]);

  const stop = () => {
    abortRef.current?.abort();
    abortRef.current = null;
    setStreaming(false);
  };

  const regenerate = (assistantMessageId: string) => {
    void runStream({ regenerateFrom: assistantMessageId });
  };

  const editResend = (userMessageId: string, text: string) => {
    void runStream({ regenerateFrom: userMessageId, message: text, optimisticUser: true });
  };

  /* ───────────── voice ───────────── */
  const transcriptRef = useRef<(text: string) => void>(() => {});
  const voice = useVoiceSession({
    settings: prefs.voice,
    generating: streaming,
    onTranscript: (text) => transcriptRef.current(text),
  });

  const speakRef = useRef<(text: string) => void>(() => {});
  useEffect(() => {
    speakRef.current = voice.speak;
  }, [voice.speak]);

  const [spokenId, setSpokenId] = useState<string | null>(null);
  const speakMessage = useCallback(
    (id: string, text: string) => {
      if (spokenId === id && voice.speaking) {
        voice.stopSpeaking();
        setSpokenId(null);
        return;
      }
      setSpokenId(id);
      voice.speak(text);
    },
    [spokenId, voice],
  );
  useEffect(() => {
    if (!voice.speaking) setSpokenId(null);
  }, [voice.speaking]);

  /* ───────────── spoken control of the whole app ───────────── */
  const lastAssistant = useMemo(
    () => [...messages].reverse().find((m) => m.role === "assistant" && m.content.trim()) ?? null,
    [messages],
  );

  const { handleTranscript } = useVoiceCommands(
    {
      send: sendText,
      newChat,
      deleteChat: () => {
        if (activeId) void removeConversation(activeId);
      },
      renameChat: (title) => {
        if (activeId) void renameConversation(activeId, title);
      },
      openSettings: () => setSettingsOpen(true),
      openPanel: () => router.push("/owner"),
      close: () => {
        setSettingsOpen(false);
        setPreview(null);
        setVoicePanel(false);
        setSidebarOpen(false);
      },
      stopGenerating: () => {
        abortRef.current?.abort();
        abortRef.current = null;
        setStreaming(false);
      },
      regenerate: () => {
        if (lastAssistant) void runStream({ regenerateFrom: lastAssistant.id });
      },
      readLast: () => {
        if (lastAssistant) speakMessage(lastAssistant.id, lastAssistant.content);
      },
      stopReading: () => voice.stopSpeaking(),
      copyLast: () => {
        if (lastAssistant) void navigator.clipboard.writeText(lastAssistant.content).catch(() => {});
      },
      runCode: () => {
        if (headerRunnableRef.current) setPreview(headerRunnableRef.current);
      },
      scrollBottom: () => bottomRef.current?.scrollIntoView({ behavior: "smooth" }),
      setTheme: (theme) => {
        const root = document.documentElement;
        root.classList.remove("light", "dark");
        root.classList.add(theme);
        try {
          localStorage.setItem("ash:theme", theme);
        } catch {
          /* private mode — the class still applies for this visit */
        }
      },
      selectModel: (spoken) => {
        const want = spoken.toLowerCase().replace(/[^a-z0-9 ]/g, "").trim();
        if (!want) return false;
        const found =
          models.find((m) => m.label.toLowerCase() === want) ??
          models.find((m) => m.label.toLowerCase().replace(/[^a-z0-9 ]/g, "").includes(want)) ??
          models.find((m) => want.includes(m.label.toLowerCase().replace(/[^a-z0-9 ]/g, "")));
        if (!found) return false;
        updatePrefs({ model: found.id });
        return true;
      },
      setAppMode: (m) => updatePrefs({ appMode: m }),
      coworkNew: (goal) => void coworkRef.current?.newTask(goal),
      coworkRun: () => coworkRef.current?.run(),
      coworkPause: () => coworkRef.current?.pause(),
      coworkApprove: () => coworkRef.current?.approve(),
      coworkReject: () => coworkRef.current?.reject(),
      coworkExport: () => coworkRef.current?.exportZip(),
      makeImage: (prompt) => {
        updatePrefs({ appMode: "chat" });
        void createMedia("image", prompt);
      },
      makeClip: (prompt) => {
        updatePrefs({ appMode: "chat" });
        void createMedia("video", prompt);
      },
      webSearch: (query) => {
        updatePrefs({ appMode: "chat" });
        sendText(`Search the web and answer with sources: ${query}`);
      },
      say: (text) => {
        setHeard(text);
        window.setTimeout(() => setHeard((h) => (h === text ? null : h)), 3500);
        if (prefs.voice.autoSpeak && text) speakRef.current(text);
      },
    },
    {
      enabled: prefs.voice.commands !== false,
      commandMode,
      wakeWords: [appName, prefs.voice.wakeWord].filter(Boolean) as string[],
    },
  );

  useEffect(() => {
    transcriptRef.current = (text: string) => {
      const handled = handleTranscript(text);
      if (handled) return;
      if (prefs.appMode === "cowork") {
        if (coworkRef.current?.isBusy()) return;
        void coworkRef.current?.newTask(text);
        return;
      }
      sendText(text);
    };
  }, [handleTranscript, prefs.appMode, sendText]);

  /* ───────────── export ───────────── */
  const exportMarkdown = () => {
    const title = activeConversation?.title ?? "Chat";
    const lines = [`# ${title}`, "", `_Exported from ${appName} on ${new Date().toLocaleString()}_`, ""];
    for (const m of messages) {
      lines.push(m.role === "user" ? "## You" : `## ${appName}`, "", m.content, "");
    }
    const blob = new Blob([lines.join("\n")], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${title.replace(/[^\w\s-]/g, "").trim().replace(/\s+/g, "-").toLowerCase() || "chat"}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const headerRunnable = useMemo(() => {
    const last = [...messages].reverse().find((m) => m.role === "assistant" && m.content.trim());
    return last ? lastRunnableBlock(last.content) : null;
  }, [messages]);
  useEffect(() => {
    headerRunnableRef.current = headerRunnable;
  }, [headerRunnable]);

  const modelLabel = (id?: string | null) => models.find((m) => m.id === id)?.label ?? "";

  const runRetry = () => {
    const action = retry;
    if (!action) return;
    setRetry(null);
    if (action.type === "stream") void runStream(action.payload);
    else void createMedia(action.kind, action.prompt);
  };

  if (account.required && account.available && !account.signedIn) {
    return <LoginGate onSignedIn={(email) => setAccount((a) => ({ ...a, signedIn: true, email }))} />;
  }

  return (
    <>
      <Splash name={appName} />

      <div className="flex h-dvh overflow-hidden bg-paper">
        <Sidebar
          conversations={conversations}
          activeId={activeId}
          open={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
          onSelect={(id) => void openConversation(id)}
          onNew={newChat}
          onRename={(id, title) => void renameConversation(id, title)}
          onDelete={(id) => void removeConversation(id)}
          onTogglePin={(id, pinned) => void togglePin(id, pinned)}
          onToggleArchive={(id, archived) => void toggleArchive(id, archived)}
          onOpenSettings={() => setSettingsOpen(true)}
          appName={appName}
          ownerExists={owner.ownerExists}
          isOwner={owner.isOwner}
          account={{
            required: account.required,
            signedIn: account.signedIn,
            email: account.email,
            onSignOut: async () => {
              await fetch("/api/auth", {
                method: "POST",
                headers: { "content-type": "application/json" },
                body: JSON.stringify({ action: "signout" }),
              }).catch(() => {});
              setAccount((a) => ({ ...a, signedIn: false, email: null }));
            },
          }}
        />

        <div className="flex min-w-0 flex-1 flex-col">
          <header className="sticky top-0 z-20 flex items-center gap-2 border-b border-line bg-paper/85 px-3 py-2.5 backdrop-blur-md">
            <button
              type="button"
              onClick={() => setSidebarOpen((o) => !o)}
              aria-label="Toggle sidebar"
              title="Toggle sidebar (⌘B)"
              className="rounded-lg p-1.5 text-ink-2 transition hover:bg-surface-2 hover:text-ink"
            >
              <IconSidebar size={16} />
            </button>
            <button
              type="button"
              onClick={newChat}
              aria-label="New chat"
              className="rounded-lg p-1.5 text-ink-2 transition hover:bg-surface-2 hover:text-ink md:hidden"
            >
              <IconPlus size={16} />
            </button>

            <h1 className="min-w-0 flex-1 truncate font-serif text-[15px] font-semibold">
              {prefs.appMode === "cowork"
                ? "Cowork"
                : prefs.appMode === "computer"
                  ? "On my computer"
                  : (activeConversation?.title ?? "New chat")}
            </h1>

            <div role="tablist" aria-label="Mode" className="flex shrink-0 rounded-lg border border-line p-0.5">
              {(["chat", "cowork", "computer"] as const).map((m) => (
                <button
                  key={m}
                  type="button"
                  role="tab"
                  aria-selected={prefs.appMode === m}
                  onClick={() => updatePrefs({ appMode: m })}
                  title={
                    m === "chat"
                      ? "Ask questions"
                      : m === "cowork"
                        ? "Hand over a whole job"
                        : "Let Ash work on this computer"
                  }
                  className={`flex items-center gap-1 rounded-md px-2 py-1 text-[12px] font-medium transition ${
                    prefs.appMode === m ? "bg-accent text-accent-ink" : "text-ink-2 hover:text-ink"
                  }`}
                >
                  {m === "cowork" && <IconSpark size={12} />}
                  {m === "computer" && <IconTerminal size={12} />}
                  <span className={m === "computer" ? "hidden sm:inline" : ""}>
                    {m === "chat" ? "Chat" : m === "cowork" ? "Cowork" : "Computer"}
                  </span>
                </button>
              ))}
            </div>

            <ModelPicker models={models} value={prefs.model} defaultId={defaultModel} onChange={(id) => updatePrefs({ model: id })} />

            {!!messages.length && (
              <button
                type="button"
                onClick={exportMarkdown}
                aria-label="Export as Markdown"
                title="Export as Markdown"
                className="rounded-lg p-1.5 text-ink-2 transition hover:bg-surface-2 hover:text-ink"
              >
                <IconDownload size={16} />
              </button>
            )}

            {voice.canListen && (
              <button
                type="button"
                onClick={() => setVoicePanel((v) => !v)}
                aria-label="Voice mode"
                aria-pressed={voicePanel}
                title="Voice mode"
                className={`rounded-lg p-1.5 transition ${
                  voicePanel || voice.state !== "idle"
                    ? "bg-accent-soft text-accent"
                    : "text-ink-2 hover:bg-surface-2 hover:text-ink"
                }`}
              >
                <IconMic size={16} />
              </button>
            )}

            {headerRunnable && (
              <button
                type="button"
                onClick={() => setPreview(headerRunnable)}
                className="flex items-center gap-1.5 rounded-lg bg-accent-soft px-2.5 py-1.5 text-[12.5px] font-medium text-accent transition hover:opacity-90"
              >
                <IconPlay size={13} /> Run
              </button>
            )}
          </header>

          {voice.error && <VoiceErrorBar message={voice.error} onDismiss={voice.clearError} />}

          {notice && (
            <div className="flex items-center gap-2 border-b border-line bg-accent-soft px-4 py-2 text-[12.5px] text-ink-2">
              <span className="text-accent">
                <IconAlert size={14} />
              </span>
              <p className="flex-1">{notice}</p>
              <button type="button" onClick={() => setNotice(null)} aria-label="Dismiss notice" className="rounded p-1 text-muted transition hover:text-ink">
                <IconX size={13} />
              </button>
            </div>
          )}

          {heard && (
            <p className="border-b border-line bg-surface-2 px-4 py-1.5 text-[12px] text-ink-2">
              <span className="text-muted">Heard:</span> {heard}
            </p>
          )}

          <div className="flex min-h-0 flex-1">
            {prefs.appMode === "computer" ? (
              <ComputerPanel model={prefs.model} onNotice={setNotice} />
            ) : prefs.appMode === "cowork" ? (
              <div className="flex min-w-0 flex-1 flex-col">
                <CoworkPanel
                  handleRef={coworkRef}
                  model={prefs.model}
                  onNotice={setNotice}
                  onSpeak={(text) => {
                    if (prefs.voice.autoSpeak) speakRef.current(text);
                  }}
                />
                {voicePanel && (
                  <div className="border-t border-line bg-surface-2/60 px-4 py-3">
                    <div className="mx-auto flex max-w-3xl flex-col items-center gap-2">
                      <VoiceOrb
                        state={voice.state}
                        partial={voice.partial}
                        disabled={!voice.canListen}
                        pushToTalk={prefs.pushToTalk}
                        onToggle={voice.toggleListening}
                        onStopSpeaking={voice.stopSpeaking}
                        onHoldStart={voice.holdStart}
                        onHoldEnd={voice.holdEnd}
                      />
                      <p className="text-center text-[12px] text-muted">
                        Say a task to start it, or “continue”, “pause”, “approve”, “download the files”.
                      </p>
                      <button
                        type="button"
                        onClick={() => setCommandMode((c) => !c)}
                        aria-pressed={commandMode}
                        className={`rounded-lg border px-2.5 py-1 text-[12px] transition ${
                          commandMode ? "border-accent/40 bg-accent-soft text-accent" : "border-line text-ink-2 hover:border-accent/40"
                        }`}
                      >
                        Command mode
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
            <div className="flex min-w-0 flex-1 flex-col">
              <p aria-live="polite" aria-atomic="true" className="sr-only">
                {streaming ? "Ash is replying" : voice.state === "listening" ? "Listening" : ""}
              </p>
              <div
                ref={scrollRef}
                onScroll={onScroll}
                role="log"
                aria-label="Conversation"
                aria-busy={streaming}
                className="min-h-0 flex-1 overflow-y-auto scroll-thin"
              >
                {!messages.length ? (
                  <EmptyState
                    onPick={(prompt) => {
                      setInput(prompt);
                      setMode("chat");
                    }}
                  />
                ) : (
                  <div className="mx-auto max-w-3xl space-y-7 px-4 pb-6 pt-8">
                    {messages.map((m, i) => (
                      <MessageItem
                        key={m.id}
                        message={m}
                        streaming={streaming && i === messages.length - 1 && m.role === "assistant"}
                        modelLabel={m.role === "assistant" ? modelLabel(m.model) : ""}
                        onRegenerate={m.role === "assistant" && !streaming ? regenerate : undefined}
                        onEditResend={m.role === "user" && !streaming ? editResend : undefined}
                        onPreview={(code, language) => setPreview({ code, language })}
                        onSpeak={voice.canSpeak ? speakMessage : undefined}
                        speaking={voice.speaking && spokenId === m.id}
                      />
                    ))}
                    {error && (
                      <ErrorBlock
                        message={error}
                        onRetry={retry ? runRetry : undefined}
                        onDismiss={() => setError(null)}
                      />
                    )}
                    <div ref={bottomRef} />
                  </div>
                )}
                {!messages.length && error && (
                  <div className="mx-auto max-w-3xl px-4 pb-6">
                    <ErrorBlock message={error} onRetry={retry ? runRetry : undefined} onDismiss={() => setError(null)} />
                  </div>
                )}
              </div>

              {voicePanel && (
                <div className="border-t border-line bg-surface-2/60 px-4 py-4">
                  <div className="mx-auto flex max-w-3xl flex-col items-center gap-3">
                    <VoiceOrb
                      state={voice.state}
                      partial={voice.partial}
                      disabled={!voice.canListen}
                      pushToTalk={prefs.pushToTalk}
                      onToggle={voice.toggleListening}
                      onStopSpeaking={voice.stopSpeaking}
                      onHoldStart={voice.holdStart}
                      onHoldEnd={voice.holdEnd}
                    />
                    <div className="flex flex-wrap items-center justify-center gap-2 text-[12px]">
                      <button
                        type="button"
                        onClick={() => updateVoice({ autoSpeak: !prefs.voice.autoSpeak })}
                        className={`rounded-lg border px-2.5 py-1 transition ${
                          prefs.voice.autoSpeak ? "border-accent/40 bg-accent-soft text-accent" : "border-line text-ink-2 hover:border-accent/40"
                        }`}
                      >
                        Read answers aloud
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          const on = !prefs.voice.continuous;
                          updateVoice({ continuous: on, autoSpeak: on ? true : prefs.voice.autoSpeak });
                        }}
                        className={`rounded-lg border px-2.5 py-1 transition ${
                          prefs.voice.continuous ? "border-accent/40 bg-accent-soft text-accent" : "border-line text-ink-2 hover:border-accent/40"
                        }`}
                      >
                        Hands-free
                      </button>
                      <button
                        type="button"
                        onClick={() => updatePrefs({ pushToTalk: !prefs.pushToTalk })}
                        className={`rounded-lg border px-2.5 py-1 transition ${
                          prefs.pushToTalk ? "border-accent/40 bg-accent-soft text-accent" : "border-line text-ink-2 hover:border-accent/40"
                        }`}
                      >
                        Push to talk
                      </button>
                      <button
                        type="button"
                        onClick={() => setCommandMode((c) => !c)}
                        aria-pressed={commandMode}
                        title="Read every sentence as an app command instead of a message"
                        className={`rounded-lg border px-2.5 py-1 transition ${
                          commandMode ? "border-accent/40 bg-accent-soft text-accent" : "border-line text-ink-2 hover:border-accent/40"
                        }`}
                      >
                        Command mode
                      </button>
                      <button
                        type="button"
                        onClick={() => setSettingsOpen(true)}
                        className="rounded-lg border border-line px-2.5 py-1 text-ink-2 transition hover:border-accent/40"
                      >
                        Voice settings
                      </button>
                    </div>
                  </div>
                </div>
              )}

              <div className="relative">
                {!stick && !!messages.length && (
                  <button
                    type="button"
                    onClick={() => {
                      setStick(true);
                      bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
                    }}
                    aria-label="Scroll to latest"
                    className="absolute -top-11 left-1/2 z-10 flex h-9 w-9 -translate-x-1/2 items-center justify-center rounded-full border border-line bg-surface text-ink-2 shadow-[var(--shadow)] transition hover:border-accent/40 hover:text-ink"
                  >
                    <IconArrowDown size={16} />
                  </button>
                )}

                <Composer
                  value={input}
                  onChange={setInput}
                  attachments={attachments}
                  setAttachments={setAttachments}
                  mode={mode}
                  setMode={setMode}
                  searchOn={prefs.search === "on"}
                  onToggleSearch={() => updatePrefs({ search: prefs.search === "on" ? "auto" : "on" })}
                  streaming={streaming}
                  onSend={send}
                  onStop={stop}
                  maxImages={limits.maxImages}
                  allowMedia={limits.allowMedia}
                  media={media}
                  appName={appName}
                  voiceState={voice.state}
                  voiceAvailable={voice.canListen}
                  onToggleVoice={voice.toggleListening}
                  voicePartial={voice.partial}
                />
              </div>
            </div>
            )}

            {preview && <CodePreview payload={preview} onClose={() => setPreview(null)} />}
          </div>
        </div>
      </div>

      <SettingsDialog
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        models={models}
        prefs={prefs}
        onChange={updatePrefs}
        onVoiceChange={updateVoice}
        serverVoice={serverVoice}
        onDeleteAll={deleteAll}
      />
    </>
  );
}
