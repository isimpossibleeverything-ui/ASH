"use client";

import { useState, type ReactNode } from "react";
import { isPreviewable, isRunnable } from "@/lib/code";
import { IconCheck, IconCopy, IconPlay, IconTerminal, IconX } from "./Icons";

interface RunResult {
  stdout: string;
  stderr: string;
  exitCode: number;
  truncated?: boolean;
  error?: string;
}

export default function CodeBlock({
  code,
  language,
  children,
  onPreview,
}: {
  code: string;
  language: string;
  children: ReactNode;
  onPreview?: (code: string, language: string) => void;
}) {
  const [copied, setCopied] = useState(false);
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<RunResult | null>(null);

  const runnable = isRunnable(language);
  const previewable = isPreviewable(language, code);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* clipboard blocked */
    }
  };

  const run = async () => {
    setRunning(true);
    setResult(null);
    try {
      const res = await fetch("/api/run", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ code, language }),
      });
      const data = await res.json();
      setResult(res.ok ? data : { stdout: "", stderr: "", exitCode: 1, error: data.error || "Could not run that." });
    } catch {
      setResult({ stdout: "", stderr: "", exitCode: 1, error: "Could not reach the runner." });
    } finally {
      setRunning(false);
    }
  };

  return (
    <div className="my-3 overflow-hidden rounded-xl border border-line">
      <div className="flex items-center gap-2 border-b border-line bg-surface-2 px-3 py-1.5">
        <span className="font-mono text-[11px] uppercase tracking-wider text-muted">{language || "text"}</span>
        <div className="ml-auto flex items-center gap-1">
          {runnable && (
            <button
              type="button"
              onClick={run}
              disabled={running}
              className="flex items-center gap-1.5 rounded-lg px-2 py-1 text-[11.5px] text-ink-2 transition hover:bg-accent-soft hover:text-accent disabled:opacity-50"
            >
              <IconPlay size={12} /> {running ? "Running…" : "Run"}
            </button>
          )}
          {previewable && onPreview && (
            <button
              type="button"
              onClick={() => onPreview(code, language)}
              className="flex items-center gap-1.5 rounded-lg px-2 py-1 text-[11.5px] text-ink-2 transition hover:bg-accent-soft hover:text-accent"
            >
              <IconPlay size={12} /> Preview
            </button>
          )}
          <button
            type="button"
            onClick={copy}
            className="flex items-center gap-1.5 rounded-lg px-2 py-1 text-[11.5px] text-ink-2 transition hover:bg-accent-soft hover:text-accent"
          >
            {copied ? <IconCheck size={12} /> : <IconCopy size={12} />} {copied ? "Copied" : "Copy"}
          </button>
        </div>
      </div>

      <pre className="!rounded-none !border-0">{children}</pre>

      {result && (
        <div className="border-t border-line bg-surface-2">
          <div className="flex items-center gap-2 px-3 py-1.5 text-[11px] text-muted">
            <IconTerminal size={12} />
            <span className="font-mono uppercase tracking-wider">Console</span>
            {typeof result.exitCode === "number" && !result.error && (
              <span className={result.exitCode === 0 ? "text-muted" : "text-danger"}>exit {result.exitCode}</span>
            )}
            <button
              type="button"
              onClick={() => setResult(null)}
              aria-label="Hide console"
              className="ml-auto rounded p-1 transition hover:text-ink"
            >
              <IconX size={12} />
            </button>
          </div>
          <div className="max-h-64 overflow-auto px-3 pb-3 scroll-thin">
            {result.error && <p className="font-mono text-[12px] text-danger">{result.error}</p>}
            {result.stdout && <pre className="!m-0 !border-0 !bg-transparent !p-0 font-mono text-[12px] leading-relaxed">{result.stdout}</pre>}
            {result.stderr && (
              <pre className="!m-0 !border-0 !bg-transparent !p-0 font-mono text-[12px] leading-relaxed text-danger">{result.stderr}</pre>
            )}
            {!result.error && !result.stdout && !result.stderr && <p className="text-[12px] text-muted">No output.</p>}
            {result.truncated && <p className="mt-1 text-[11px] text-muted">Output was trimmed at 20 KB.</p>}
          </div>
        </div>
      )}
    </div>
  );
}
