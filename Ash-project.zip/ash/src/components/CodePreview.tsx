"use client";

import { useMemo } from "react";
import { buildPreviewDoc, SAMPLE_PREVIEW } from "@/lib/code";
import { IconCopy, IconDownload, IconX } from "./Icons";

export interface PreviewPayload {
  code: string;
  language: string;
}

export default function CodePreview({
  payload,
  onClose,
}: {
  payload: PreviewPayload | null;
  onClose: () => void;
}) {
  const doc = useMemo(() => (payload?.code ? buildPreviewDoc(payload.code, payload.language) : SAMPLE_PREVIEW), [payload]);

  if (!payload) return null;

  const extension =
    payload.language === "css" ? "css" : payload.language === "jsx" || payload.language === "tsx" ? "html" : "html";

  const download = () => {
    const blob = new Blob([doc], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `ash-preview.${extension}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <aside className="fixed inset-0 z-50 flex flex-col border-line bg-paper lg:static lg:z-auto lg:w-[46%] lg:min-w-[360px] lg:max-w-[760px] lg:border-l">
      <header className="flex items-center gap-2 border-b border-line bg-paper/85 px-4 py-3 backdrop-blur-md">
        <h2 className="flex-1 font-serif text-[15px] font-semibold">Code preview</h2>
        <button
          type="button"
          onClick={() => navigator.clipboard?.writeText(payload.code)}
          className="flex items-center gap-1.5 rounded-lg border border-line px-2.5 py-1.5 text-[12.5px] text-ink-2 transition hover:border-accent/40 hover:text-ink"
        >
          <IconCopy size={14} /> Copy code
        </button>
        <button
          type="button"
          onClick={download}
          className="flex items-center gap-1.5 rounded-lg border border-line px-2.5 py-1.5 text-[12.5px] text-ink-2 transition hover:border-accent/40 hover:text-ink"
        >
          <IconDownload size={14} /> Download
        </button>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close preview"
          className="rounded-lg border border-line p-1.5 text-ink-2 transition hover:border-accent/40 hover:text-ink"
        >
          <IconX size={14} />
        </button>
      </header>
      <iframe
        title="Code preview"
        sandbox="allow-scripts"
        srcDoc={doc}
        className="h-full w-full flex-1 bg-white"
      />
    </aside>
  );
}
