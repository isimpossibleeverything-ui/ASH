"use client";

import { useEffect, useRef, useState } from "react";
import { downscaleImage } from "@/lib/stream-client";
import { IconArrowUp, IconFilm, IconGlobe, IconImage, IconPlus, IconStop, IconX } from "./Icons";
import { VoiceMicButton } from "./VoiceOrb";
import type { VoiceState } from "@/lib/voice/client";

export type ComposerMode = "chat" | "image" | "video";

export interface Attachment {
  mimeType: string;
  data: string;
  preview: string;
  name: string;
}

interface Props {
  value: string;
  onChange: (value: string) => void;
  attachments: Attachment[];
  setAttachments: (next: Attachment[]) => void;
  mode: ComposerMode;
  setMode: (mode: ComposerMode) => void;
  searchOn: boolean;
  onToggleSearch: () => void;
  streaming: boolean;
  onSend: () => void;
  onStop: () => void;
  maxImages: number;
  allowMedia: boolean;
  media: { keylessOnly: boolean; suggestedFrames: number; clipMode?: "frames" | "motion" } | null;
  appName: string;
  voiceState: VoiceState;
  voiceAvailable: boolean;
  onToggleVoice: () => void;
  voicePartial: string;
}

const PLACEHOLDERS: Record<ComposerMode, string> = {
  chat: "Ask anything…  (Enter to send)",
  image: "Describe the image you want…  (Enter to create)",
  video: "Describe the clip you want…  (Enter to create)",
};

export default function Composer({
  value,
  onChange,
  attachments,
  setAttachments,
  mode,
  setMode,
  searchOn,
  onToggleSearch,
  streaming,
  onSend,
  onStop,
  maxImages,
  allowMedia,
  media,
  appName,
  voiceState,
  voiceAvailable,
  onToggleVoice,
  voicePartial,
}: Props) {
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);
  const addRef = useRef<HTMLDivElement | null>(null);
  const [addOpen, setAddOpen] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [composing, setComposing] = useState(false);

  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(208, el.scrollHeight)}px`;
  }, [value]);

  useEffect(() => {
    const onDown = (e: MouseEvent) => {
      if (addRef.current && !addRef.current.contains(e.target as Node)) setAddOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, []);

  const addFiles = async (files: FileList | File[]) => {
    const list = Array.from(files).filter((f) => f.type.startsWith("image/"));
    if (!list.length) return;
    const room = Math.max(0, maxImages - attachments.length);
    const next: Attachment[] = [];
    for (const file of list.slice(0, room)) {
      try {
        const shrunk = await downscaleImage(file);
        next.push({ ...shrunk, name: file.name });
      } catch {
        /* skip unreadable file */
      }
    }
    if (next.length) setAttachments([...attachments, ...next]);
  };

  const canSend = (value.trim().length > 0 || attachments.length > 0) && !streaming;

  return (
    <div className="px-4 pb-3 pt-1">
      <div className="mx-auto max-w-3xl">
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragging(true);
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragging(false);
            if (e.dataTransfer?.files?.length) void addFiles(e.dataTransfer.files);
          }}
          className={`rounded-2xl border bg-surface shadow-[var(--shadow)] transition ${
            dragging ? "border-accent" : "border-line"
          }`}
        >
          {!!attachments.length && (
            <div className="flex flex-wrap gap-2 px-3 pt-3">
              {attachments.map((a, i) => (
                <div key={i} className="relative">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={a.preview} alt={a.name} className="h-16 w-16 rounded-xl border border-line object-cover" />
                  <button
                    type="button"
                    onClick={() => setAttachments(attachments.filter((_, j) => j !== i))}
                    aria-label={`Remove ${a.name}`}
                    className="absolute -right-1.5 -top-1.5 rounded-full border border-line bg-surface p-0.5 text-muted shadow-[var(--shadow)] transition hover:text-danger"
                  >
                    <IconX size={11} />
                  </button>
                </div>
              ))}
            </div>
          )}

          <textarea
            ref={textareaRef}
            dir="auto"
            value={value}
            rows={1}
            placeholder={PLACEHOLDERS[mode]}
            onChange={(e) => onChange(e.target.value)}
            onCompositionStart={() => setComposing(true)}
            onCompositionEnd={() => setComposing(false)}
            onPaste={(e) => {
              const files = Array.from(e.clipboardData?.files ?? []);
              if (files.length) {
                e.preventDefault();
                void addFiles(files);
              }
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey && !composing) {
                e.preventDefault();
                if (canSend) onSend();
              }
            }}
            className="max-h-52 w-full resize-none bg-transparent px-4 py-3.5 text-[15px] leading-relaxed outline-none placeholder:text-muted scroll-thin"
          />

          <div className="flex items-center gap-1.5 px-2.5 pb-2.5">
            <div ref={addRef} className="relative">
              <button
                type="button"
                onClick={() => setAddOpen((o) => !o)}
                aria-label="Add"
                aria-expanded={addOpen}
                className="flex h-8 w-8 items-center justify-center rounded-lg border border-line text-ink-2 transition hover:border-accent/40 hover:text-ink"
              >
                <IconPlus size={15} />
              </button>
              {addOpen && (
                <div className="absolute bottom-10 left-0 z-30 w-64 overflow-hidden rounded-xl border border-line bg-surface py-1 shadow-[var(--shadow)]">
                  <button
                    type="button"
                    onClick={() => {
                      setAddOpen(false);
                      setMode("chat");
                      fileRef.current?.click();
                    }}
                    className="flex w-full items-start gap-2.5 px-3 py-2 text-left transition hover:bg-surface-2"
                  >
                    <span className="mt-0.5 text-accent">
                      <IconImage size={15} />
                    </span>
                    <span>
                      <span className="block text-[13px] font-medium">Upload an image</span>
                      <span className="block text-[11.5px] text-muted">Ask about a picture</span>
                    </span>
                  </button>
                  <button
                    type="button"
                    disabled={!allowMedia}
                    onClick={() => {
                      setAddOpen(false);
                      setMode(mode === "image" ? "chat" : "image");
                    }}
                    className="flex w-full items-start gap-2.5 px-3 py-2 text-left transition hover:bg-surface-2 disabled:opacity-50"
                  >
                    <span className="mt-0.5 text-accent">
                      <IconImage size={15} />
                    </span>
                    <span>
                      <span className="block text-[13px] font-medium">Create an image</span>
                      <span className="block text-[11.5px] text-muted">Describe it, {appName} draws it</span>
                    </span>
                  </button>
                  <button
                    type="button"
                    disabled={!allowMedia}
                    onClick={() => {
                      setAddOpen(false);
                      setMode(mode === "video" ? "chat" : "video");
                    }}
                    className="flex w-full items-start gap-2.5 px-3 py-2 text-left transition hover:bg-surface-2 disabled:opacity-50"
                  >
                    <span className="mt-0.5 text-accent">
                      <IconFilm size={15} />
                    </span>
                    <span>
                      <span className="block text-[13px] font-medium">Create a short clip</span>
                      <span className="block text-[11.5px] text-muted">
                        {media?.clipMode === "motion"
                          ? "One frame with camera motion · add a free key for multi-frame"
                          : "Free, no sound, a few seconds"}
                      </span>
                    </span>
                  </button>
                </div>
              )}
            </div>

            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              multiple
              hidden
              onChange={(e) => {
                if (e.target.files) void addFiles(e.target.files);
                e.target.value = "";
              }}
            />

            <button
              type="button"
              onClick={onToggleSearch}
              aria-pressed={searchOn}
              className={`flex h-8 items-center gap-1.5 rounded-lg border px-2.5 text-[12.5px] transition ${
                searchOn ? "border-accent/40 bg-accent-soft text-accent" : "border-line text-ink-2 hover:border-accent/40 hover:text-ink"
              }`}
            >
              <IconGlobe size={14} />
              <span className="hidden sm:inline">{searchOn ? "Web search on" : "Web search"}</span>
            </button>

            {mode !== "chat" && (
              <button
                type="button"
                onClick={() => setMode("chat")}
                className="flex h-8 items-center gap-1.5 rounded-lg border border-accent/40 bg-accent-soft px-2.5 text-[12.5px] text-accent transition hover:opacity-90"
              >
                {mode === "image" ? <IconImage size={14} /> : <IconFilm size={14} />}
                {mode === "image" ? "Image mode" : "Clip mode"}
                <IconX size={12} />
              </button>
            )}

            <div className="ml-auto flex items-center gap-1.5">
              {voiceAvailable && <VoiceMicButton state={voiceState} onToggle={onToggleVoice} />}

              {streaming ? (
                <button
                  type="button"
                  onClick={onStop}
                  aria-label="Stop"
                  className="flex h-9 w-9 items-center justify-center rounded-full bg-accent text-accent-ink transition hover:opacity-90"
                >
                  <IconStop size={15} />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={onSend}
                  disabled={!canSend}
                  aria-label="Send"
                  className="flex h-9 w-9 items-center justify-center rounded-full bg-accent text-accent-ink transition hover:opacity-90 disabled:opacity-35"
                >
                  <IconArrowUp size={16} />
                </button>
              )}
            </div>
          </div>
        </div>

        {voiceState === "listening" && (
          <p dir="auto" className="mt-2 text-center text-[12px] italic text-accent">
            {voicePartial || "Listening… speak now"}
          </p>
        )}
        <p className="mt-2 text-center text-[11px] text-muted">{appName} can make mistakes. Check important information.</p>
      </div>
    </div>
  );
}
