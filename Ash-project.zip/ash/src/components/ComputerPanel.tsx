"use client";

/**
 * "On my computer" — Ash working on the actual machine.
 *
 * In a browser tab this says so honestly and stops. In the Windows app it
 * asks for one folder, and from then on it can read, write, tidy, run
 * commands and open programs inside that folder — with a native confirmation
 * for anything it cannot take back.
 */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  desktopGrant,
  desktopList,
  desktopLog,
  desktopOpen,
  desktopRead,
  desktopRevoke,
  desktopStatus,
  isDesktop,
  onPermissionChange,
  prettyBytes,
  type DesktopEntry,
  type DesktopStatus,
  type LogEntry,
} from "@/lib/desktop";
import {
  MAX_DESKTOP_STEPS,
  desktopSystemPrompt,
  runDesktopTask,
  type DesktopEvent,
} from "@/lib/desktop/agent";
import {
  IconAlert,
  IconArrowUp,
  IconCheck,
  IconFile,
  IconFolder,
  IconGear,
  IconRefresh,
  IconShield,
  IconSpark,
  IconStop,
  IconTerminal,
  IconX,
} from "./Icons";

interface Props {
  model: string | null;
  onNotice: (text: string) => void;
}

type Line = DesktopEvent & { id: string; at: number };

const RELEASES = "https://github.com/";

export default function ComputerPanel({ model, onNotice }: Props) {
  const [status, setStatus] = useState<DesktopStatus | null>(null);
  const [busyGrant, setBusyGrant] = useState(false);

  const [cwd, setCwd] = useState("");
  const [entries, setEntries] = useState<DesktopEntry[]>([]);
  const [loadingFiles, setLoadingFiles] = useState(false);
  const [peek, setPeek] = useState<{ path: string; text: string } | null>(null);

  const [goal, setGoal] = useState("");
  const [lines, setLines] = useState<Line[]>([]);
  const [running, setRunning] = useState(false);
  const [showLog, setShowLog] = useState(false);
  const [audit, setAudit] = useState<LogEntry[]>([]);

  const abort = useRef<AbortController | null>(null);
  const tail = useRef<HTMLDivElement | null>(null);

  const inApp = useMemo(() => isDesktop(), []);
  const granted = Boolean(status?.granted && status.root);

  /* ── status ─────────────────────────────────────────────────── */

  const refreshStatus = useCallback(async () => {
    setStatus(await desktopStatus());
  }, []);

  useEffect(() => {
    void refreshStatus();
    let stop = () => {};
    void onPermissionChange(() => void refreshStatus()).then((fn) => {
      stop = fn;
    });
    return () => stop();
  }, [refreshStatus]);

  /* ── files ──────────────────────────────────────────────────── */

  const loadFiles = useCallback(
    async (where: string) => {
      if (!granted) return;
      setLoadingFiles(true);
      try {
        setEntries(await desktopList(where));
        setCwd(where);
      } catch (err) {
        onNotice(err instanceof Error ? err.message : "Could not open that folder.");
      } finally {
        setLoadingFiles(false);
      }
    },
    [granted, onNotice],
  );

  useEffect(() => {
    if (granted) void loadFiles("");
  }, [granted, loadFiles]);

  useEffect(() => {
    tail.current?.scrollIntoView({ block: "end" });
  }, [lines]);

  const grant = async () => {
    setBusyGrant(true);
    try {
      setStatus(await desktopGrant());
      setLines([]);
      setPeek(null);
    } catch (err) {
      onNotice(err instanceof Error ? err.message : "Nothing was granted.");
    } finally {
      setBusyGrant(false);
    }
  };

  const revoke = async () => {
    abort.current?.abort();
    try {
      setStatus(await desktopRevoke());
      setEntries([]);
      setPeek(null);
      setCwd("");
      onNotice("Ash can no longer reach your computer.");
    } catch {
      /* nothing worth saying */
    }
  };

  const openPeek = async (entry: DesktopEntry) => {
    if (entry.is_dir) {
      void loadFiles(entry.path);
      return;
    }
    try {
      const text = await desktopRead(entry.path);
      setPeek({ path: entry.path, text: text.slice(0, 20_000) });
    } catch {
      // not text, or too big — hand it to Windows instead
      try {
        await desktopOpen(entry.path);
      } catch (err) {
        onNotice(err instanceof Error ? err.message : "Could not open it.");
      }
    }
  };

  const upOne = () => {
    const parts = cwd.split("/").filter(Boolean);
    parts.pop();
    void loadFiles(parts.join("/"));
  };

  /* ── the job ────────────────────────────────────────────────── */

  const push = (e: DesktopEvent) =>
    setLines((prev) => [
      ...prev.slice(-199),
      { ...e, id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, at: Date.now() },
    ]);

  const start = async () => {
    const job = goal.trim();
    if (!job || running || !status?.root) return;

    const controller = new AbortController();
    abort.current = controller;
    setRunning(true);
    setLines([]);
    setGoal("");

    try {
      await runDesktopTask({
        goal: job,
        system: desktopSystemPrompt("Ash", status.root, status.os),
        model,
        signal: controller.signal,
        emit: (e) => {
          // the model only ever reports a thought while it waits — replace it
          setLines((prev) =>
            e.type === "thinking" && prev.at(-1)?.type === "thinking" ? prev.slice(0, -1) : prev,
          );
          push(e);
        },
      });
    } finally {
      setRunning(false);
      abort.current = null;
      if (granted) void loadFiles(cwd);
    }
  };

  const stop = () => {
    abort.current?.abort();
    setRunning(false);
  };

  const openAudit = async () => {
    setShowLog((v) => !v);
    if (!showLog) {
      try {
        setAudit(await desktopLog());
      } catch {
        setAudit([]);
      }
    }
  };

  /* ── browser: say so plainly ────────────────────────────────── */

  if (!inApp) {
    return (
      <div className="flex min-h-0 flex-1 items-start justify-center overflow-y-auto px-4 py-10 scroll-thin">
        <div className="w-full max-w-xl">
          <div className="rounded-2xl border border-line bg-surface p-6">
            <div className="mb-4 flex items-center gap-3">
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-accent-soft text-accent">
                <IconTerminal size={18} />
              </span>
              <div>
                <h2 className="font-serif text-[17px] font-semibold">Ash on your computer</h2>
                <p className="text-[12.5px] text-muted">Only in the Windows app</p>
              </div>
            </div>

            <p className="text-[14px] leading-relaxed text-ink-2">
              A web page is sealed off from the machine it is shown on — that is the browser doing its
              job, and Ash cannot talk its way around it. To let Ash tidy folders, run commands and open
              programs, it has to be installed as a proper Windows app.
            </p>

            <div className="mt-5 rounded-xl border border-line bg-surface-2 p-4">
              <p className="mb-2 text-[12.5px] font-semibold text-ink">In the desktop app Ash can</p>
              <ul className="space-y-1.5 text-[13px] text-ink-2">
                {[
                  "Sort, rename, read and write files in one folder you choose",
                  "Run commands — install things, run scripts, clean up",
                  "Open programs, files and links for you",
                ].map((t) => (
                  <li key={t} className="flex gap-2">
                    <IconCheck size={14} className="mt-0.5 shrink-0 text-ok" />
                    <span>{t}</span>
                  </li>
                ))}
              </ul>
            </div>

            <p className="mt-4 text-[12.5px] leading-relaxed text-muted">
              Everything else — chat, Cowork, images, voice — works right here in the browser, exactly
              as it does now.
            </p>

            <a
              href={RELEASES}
              target="_blank"
              rel="noreferrer"
              className="mt-5 inline-flex items-center gap-2 rounded-xl bg-accent px-4 py-2.5 text-[13.5px] font-medium text-accent-ink transition hover:opacity-90"
            >
              Where to get the Windows app
            </a>
          </div>
        </div>
      </div>
    );
  }

  /* ── in the app, not granted yet ────────────────────────────── */

  if (!granted) {
    return (
      <div className="flex min-h-0 flex-1 items-start justify-center overflow-y-auto px-4 py-10 scroll-thin">
        <div className="w-full max-w-xl">
          <div className="rounded-2xl border border-line bg-surface p-6">
            <div className="mb-4 flex items-center gap-3">
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-accent-soft text-accent">
                <IconShield size={18} />
              </span>
              <div>
                <h2 className="font-serif text-[17px] font-semibold">Ash is asking permission</h2>
                <p className="text-[12.5px] text-muted">Nothing is readable until you say yes</p>
              </div>
            </div>

            <p className="text-[14px] leading-relaxed text-ink-2">
              Pick one folder. That folder becomes the whole of Ash&apos;s world — it cannot see, read or
              change a single thing outside it, and it cannot widen that on its own.
            </p>

            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              <div className="rounded-xl border border-line bg-surface-2 p-4">
                <p className="mb-2 text-[12.5px] font-semibold text-ok">Ash will be able to</p>
                <ul className="space-y-1 text-[12.5px] text-ink-2">
                  <li>Read and write files in that folder</li>
                  <li>Make and tidy folders inside it</li>
                  <li>Run commands from it</li>
                  <li>Open files, apps and links</li>
                </ul>
              </div>
              <div className="rounded-xl border border-line bg-surface-2 p-4">
                <p className="mb-2 text-[12.5px] font-semibold text-danger">Ash will not</p>
                <ul className="space-y-1 text-[12.5px] text-ink-2">
                  <li>Touch anything outside the folder</li>
                  <li>Delete without asking you again</li>
                  <li>Keep the permission after you quit</li>
                  <li>Send your files anywhere</li>
                </ul>
              </div>
            </div>

            <button
              type="button"
              onClick={grant}
              disabled={busyGrant}
              className="mt-5 inline-flex items-center gap-2 rounded-xl bg-accent px-4 py-2.5 text-[13.5px] font-medium text-accent-ink transition hover:opacity-90 disabled:opacity-60"
            >
              <IconFolder size={15} />
              {busyGrant ? "Waiting for you to choose…" : "Let Ash use this computer"}
            </button>
            <p className="mt-2.5 text-[12px] text-muted">
              Windows will open its own folder picker. Ash cannot choose for you.
            </p>
          </div>
        </div>
      </div>
    );
  }

  /* ── granted: the working view ──────────────────────────────── */

  const crumbs = cwd.split("/").filter(Boolean);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      {/* where Ash is allowed */}
      <div className="flex shrink-0 flex-wrap items-center gap-2 border-b border-line bg-surface-2/60 px-4 py-2.5">
        <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-ok-soft text-ok">
          <IconShield size={13} />
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[12.5px] font-medium text-ink" title={status?.root ?? ""}>
            {status?.root}
          </p>
          <p className="text-[11px] text-muted">Ash can work in here, and nowhere else</p>
        </div>
        <button
          type="button"
          onClick={openAudit}
          aria-label="What Ash has done"
          title="What Ash has done"
          className="rounded-lg p-1.5 text-ink-2 transition hover:bg-surface hover:text-ink"
        >
          <IconGear size={15} />
        </button>
        <button
          type="button"
          onClick={grant}
          className="rounded-lg border border-line px-2.5 py-1 text-[12px] text-ink-2 transition hover:text-ink"
        >
          Change folder
        </button>
        <button
          type="button"
          onClick={revoke}
          className="rounded-lg border border-danger/40 px-2.5 py-1 text-[12px] text-danger transition hover:bg-danger-soft"
        >
          Stop sharing
        </button>
      </div>

      {showLog && (
        <div className="max-h-44 shrink-0 overflow-y-auto border-b border-line bg-surface px-4 py-3 scroll-thin">
          <p className="mb-2 text-[12px] font-semibold text-ink">Everything Ash has touched</p>
          {audit.length ? (
            <ul className="space-y-1">
              {audit.map((e, i) => (
                <li key={`${e.at}-${i}`} className="flex gap-2 text-[12px] text-ink-2">
                  <span className={e.ok ? "text-ok" : "text-danger"}>{e.ok ? "✓" : "✕"}</span>
                  <span className="shrink-0 text-muted">{new Date(e.at).toLocaleTimeString()}</span>
                  <span className="font-medium">{e.action}</span>
                  <span className="truncate">{e.detail}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-[12px] text-muted">Nothing yet.</p>
          )}
        </div>
      )}

      <div className="flex min-h-0 flex-1">
        {/* the folder */}
        <aside className="hidden w-64 shrink-0 flex-col border-r border-line bg-surface-2/40 lg:flex">
          <div className="flex items-center gap-1.5 border-b border-line px-3 py-2">
            <button
              type="button"
              onClick={upOne}
              disabled={!crumbs.length}
              aria-label="Up one folder"
              title="Up one folder"
              className="rounded-md p-1 text-ink-2 transition hover:bg-surface hover:text-ink disabled:opacity-30"
            >
              <IconArrowUp size={13} />
            </button>
            <p className="min-w-0 flex-1 truncate text-[12px] text-ink-2" title={cwd || "top folder"}>
              {cwd || "top folder"}
            </p>
            <button
              type="button"
              onClick={() => void loadFiles(cwd)}
              aria-label="Refresh this folder"
              title="Refresh this folder"
              className="rounded-md p-1 text-ink-2 transition hover:bg-surface hover:text-ink"
            >
              <IconRefresh size={13} />
            </button>
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto p-1.5 scroll-thin">
            {loadingFiles ? (
              <p className="px-2 py-3 text-[12px] text-muted">Looking…</p>
            ) : entries.length ? (
              entries.map((e) => (
                <button
                  key={e.path}
                  type="button"
                  onClick={() => void openPeek(e)}
                  className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-[12.5px] text-ink-2 transition hover:bg-surface hover:text-ink"
                >
                  {e.is_dir ? (
                    <IconFolder size={13} className="shrink-0 text-accent" />
                  ) : (
                    <IconFile size={13} className="shrink-0 text-muted" />
                  )}
                  <span className="min-w-0 flex-1 truncate">{e.name}</span>
                  {!e.is_dir && e.bytes > 0 && (
                    <span className="shrink-0 text-[10.5px] text-muted">{prettyBytes(e.bytes)}</span>
                  )}
                </button>
              ))
            ) : (
              <p className="px-2 py-3 text-[12px] text-muted">This folder is empty.</p>
            )}
          </div>
        </aside>

        {/* the work */}
        <div className="flex min-w-0 flex-1 flex-col">
          <div className="min-h-0 flex-1 overflow-y-auto px-4 py-4 scroll-thin">
            {peek ? (
              <div className="mb-4 rounded-xl border border-line bg-surface">
                <div className="flex items-center gap-2 border-b border-line px-3 py-2">
                  <IconFile size={13} className="shrink-0 text-muted" />
                  <p className="min-w-0 flex-1 truncate text-[12.5px] font-medium">{peek.path}</p>
                  <button
                    type="button"
                    onClick={() => setPeek(null)}
                    aria-label="Close the file"
                    title="Close the file"
                    className="rounded-md p-1 text-ink-2 transition hover:bg-surface-2 hover:text-ink"
                  >
                    <IconX size={13} />
                  </button>
                </div>
                <pre className="max-h-72 overflow-auto px-3 py-2.5 text-[12px] leading-relaxed text-ink-2 scroll-thin">
                  {peek.text}
                </pre>
              </div>
            ) : null}

            {lines.length ? (
              <ol className="space-y-2">
                {lines.map((l) => (
                  <li
                    key={l.id}
                    className={`flex gap-2.5 rounded-xl border px-3 py-2.5 text-[13px] ${
                      l.type === "error"
                        ? "border-danger/35 bg-danger-soft text-ink"
                        : l.type === "done"
                          ? "border-ok/35 bg-ok-soft text-ink"
                          : "border-line bg-surface text-ink-2"
                    }`}
                  >
                    <span className="mt-0.5 shrink-0">
                      {l.type === "error" ? (
                        <IconAlert size={14} className="text-danger" />
                      ) : l.type === "done" ? (
                        <IconCheck size={14} className="text-ok" />
                      ) : l.type === "result" ? (
                        l.ok ? (
                          <IconCheck size={14} className="text-ok" />
                        ) : (
                          <IconAlert size={14} className="text-warn" />
                        )
                      ) : l.type === "step" ? (
                        <IconSpark size={14} className="text-accent" />
                      ) : (
                        <IconTerminal size={14} className="text-muted" />
                      )}
                    </span>
                    <div className="min-w-0 flex-1">
                      {l.type === "step" && (
                        <p className="text-[11px] uppercase tracking-wide text-muted">
                          {l.tool?.replace(/_/g, " ")}
                        </p>
                      )}
                      <p className={`whitespace-pre-wrap break-words ${l.type === "step" ? "font-medium text-ink" : ""}`}>
                        {l.text}
                      </p>
                    </div>
                  </li>
                ))}
                <div ref={tail} />
              </ol>
            ) : (
              <div className="mx-auto max-w-md py-10 text-center">
                <span className="mx-auto mb-3 grid h-11 w-11 place-items-center rounded-xl bg-accent-soft text-accent">
                  <IconTerminal size={18} />
                </span>
                <h2 className="font-serif text-[16px] font-semibold">Tell Ash what to do here</h2>
                <p className="mt-1.5 text-[13px] leading-relaxed text-muted">
                  It works inside that one folder, up to {MAX_DESKTOP_STEPS} steps, and asks before it
                  deletes anything.
                </p>
                <div className="mt-4 space-y-1.5 text-left">
                  {[
                    "Sort every PDF in here into folders by year",
                    "Read the CSVs and write me a summary.md",
                    "Open Chrome on the GitHub releases page",
                  ].map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setGoal(s)}
                      className="block w-full rounded-lg border border-line bg-surface px-3 py-2 text-left text-[12.5px] text-ink-2 transition hover:border-accent/40 hover:text-ink"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* ask */}
          <div className="shrink-0 border-t border-line bg-surface-2/60 px-4 py-3">
            <div className="mx-auto flex max-w-3xl items-end gap-2">
              <textarea
                value={goal}
                onChange={(e) => setGoal(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    void start();
                  }
                }}
                rows={1}
                disabled={running}
                placeholder="What should Ash do in this folder?"
                aria-label="What should Ash do in this folder?"
                className="max-h-36 min-h-[42px] flex-1 resize-y rounded-xl border border-line bg-surface px-3.5 py-2.5 text-[14px] text-ink outline-none transition placeholder:text-muted focus:border-accent/50 disabled:opacity-60"
              />
              {running ? (
                <button
                  type="button"
                  onClick={stop}
                  aria-label="Stop"
                  title="Stop"
                  className="grid h-[42px] w-[42px] place-items-center rounded-xl bg-danger text-white transition hover:opacity-90"
                >
                  <IconStop size={15} />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => void start()}
                  disabled={!goal.trim()}
                  aria-label="Start"
                  title="Start"
                  className="grid h-[42px] w-[42px] place-items-center rounded-xl bg-accent text-accent-ink transition hover:opacity-90 disabled:opacity-40"
                >
                  <IconSpark size={15} />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
