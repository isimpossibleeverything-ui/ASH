"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  IconArchive,
  IconBolt,
  IconBrain,
  IconCheck,
  IconDownload,
  IconExternal,
  IconEye,
  IconEyeOff,
  IconGauge,
  IconGlobe,
  IconGrip,
  IconKey,
  IconLayers,
  IconLock,
  IconLogout,
  IconPaint,
  IconPlus,
  IconTrash,
  IconVolume,
  IconWand,
  IconX,
} from "./Icons";
import { COMMAND_HELP } from "@/lib/voice/commands";

/* ─────────────────────────── shared bits ─────────────────────────── */

function Card({
  step,
  title,
  subtitle,
  icon,
  children,
}: {
  step: number;
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-2xl border border-line bg-surface shadow-[var(--shadow)]">
      <header className="flex items-start gap-3 border-b border-line px-5 py-4">
        <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-accent-soft text-[12px] font-semibold text-accent">
          {step}
        </span>
        <div className="min-w-0 flex-1">
          <h2 className="font-serif text-[16px] font-semibold">{title}</h2>
          <p className="mt-0.5 text-[12.5px] leading-relaxed text-muted">{subtitle}</p>
        </div>
        <span className="mt-0.5 shrink-0 text-muted">{icon}</span>
      </header>
      <div className="px-5 py-4">{children}</div>
    </section>
  );
}

function Switch({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={`relative h-5 w-9 shrink-0 rounded-full border transition ${
        checked ? "border-accent/40 bg-accent" : "border-line bg-surface-2"
      }`}
    >
      <span
        className={`absolute top-0.5 h-3.5 w-3.5 rounded-full bg-white transition-all ${checked ? "left-[18px]" : "left-0.5"}`}
        style={{ background: checked ? "var(--accent-ink)" : "var(--muted)" }}
      />
    </button>
  );
}

function Dot({ kind }: { kind: string }) {
  const color =
    kind === "healthy" ? "#4d7c4f" : kind === "unset" ? "var(--line-2)" : kind === "badkey" ? "var(--danger)" : "#9a6b28";
  return <span className="inline-block h-2 w-2 shrink-0 rounded-full" style={{ background: color }} />;
}

function NumberField({
  label,
  hint,
  value,
  min = 0,
  onCommit,
}: {
  label: string;
  hint?: string;
  value: number;
  min?: number;
  onCommit: (v: number) => void;
}) {
  const [local, setLocal] = useState(String(value));
  useEffect(() => setLocal(String(value)), [value]);
  return (
    <label className="block">
      <span className="block text-[12.5px] font-medium">{label}</span>
      {hint && <span className="mt-0.5 block text-[11.5px] text-muted">{hint}</span>}
      <input
        type="number"
        min={min}
        value={local}
        onChange={(e) => setLocal(e.target.value)}
        onBlur={() => onCommit(Math.max(min, Number(local) || 0))}
        className="mt-1.5 w-full rounded-lg border border-line bg-surface-2 px-2.5 py-1.5 text-[13px] outline-none transition focus:border-accent/40"
      />
    </label>
  );
}

/* ─────────────────────────── types ─────────────────────────── */

interface ProviderRow {
  id: string;
  vendor: string;
  publicName: string;
  note: string;
  signupUrl: string;
  paid: boolean;
  custom: boolean;
  configured: boolean;
  enabled: boolean;
  keys: { name: string; masked: string; present: boolean; fromEnv: boolean }[];
  models: { id: string; label: string; description: string; vision: boolean; exposed: boolean; publicCode: string }[];
  status: string;
  statusKind: string;
  lastError: string | null;
  trained: number;
  rank: number;
}

interface SearchRow {
  id: string;
  label: string;
  note: string;
  needsKey: boolean;
  needsUrl: boolean;
  signupUrl?: string;
  enabled: boolean;
  order: number;
  url?: string;
  hasKey: boolean;
  masked: string;
  keyName: string;
}

interface PanelData {
  settings: any;
  providers: ProviderRow[];
  searchProviders: SearchRow[];
  cooldowns: { id: string; state: string; label: string; secondsLeft: number; lastError: string | null }[];
  stats: { messages: number; errors: number; fallbacks: number; visitors: number; day: string };
  ranking: string[];
  voiceProviders: {
    stt: { id: string; label: string; note: string; requiresKey: string | null; configured: boolean }[];
    tts: { id: string; label: string; note: string; requiresKey: string | null; configured: boolean }[];
  };
  defaultSystemPrompt: string;
}

/* ─────────────────────────── panel ─────────────────────────── */

export default function ControlPanel({ unclaimed, onSignedOut }: { unclaimed?: boolean; onSignedOut: () => void }) {
  const [data, setData] = useState<PanelData | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [learn, setLearn] = useState<any>(null);

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/settings");
      if (res.status === 401) {
        onSignedOut();
        return;
      }
      setData(await res.json());
    } catch {
      setToast("Could not load the panel.");
    }
  }, [onSignedOut]);

  const loadLearn = useCallback(async () => {
    try {
      const res = await fetch("/api/learn");
      if (res.ok) setLearn(await res.json());
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    void load();
    void loadLearn();
  }, [load, loadLearn]);

  useEffect(() => {
    const id = setInterval(() => void loadLearn(), learn?.running ? 2500 : 8000);
    return () => clearInterval(id);
  }, [loadLearn, learn?.running]);

  const flash = (message: string) => {
    setToast(message);
    setTimeout(() => setToast(null), 2600);
  };

  const post = useCallback(
    async (body: any) => {
      const res = await fetch("/api/settings", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(json.error || "That did not work.");
      return json;
    },
    [],
  );

  const save = useCallback(
    async (patch: any) => {
      try {
        await post({ action: "save", patch });
        await load();
      } catch (err) {
        flash((err as Error).message);
      }
    },
    [post, load],
  );

  if (!data) {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-paper">
        <p className="text-[13px] text-muted">Loading the Control Panel…</p>
      </div>
    );
  }

  const activeKeys = data.providers.filter((p) => p.configured && p.enabled).length;

  return (
    <div className="min-h-dvh bg-paper">
      <div className="mx-auto max-w-3xl px-4 py-8">
        <div className="mb-6 flex items-center gap-3">
          <Link href="/" className="text-[12.5px] text-muted transition hover:text-ink">
            ← Back to chat
          </Link>
          <div className="flex-1" />
          {!unclaimed && (
          <button
            type="button"
            onClick={async () => {
              await fetch("/api/owner", {
                method: "POST",
                headers: { "content-type": "application/json" },
                body: JSON.stringify({ action: "logout" }),
              });
              onSignedOut();
            }}
            className="flex items-center gap-1.5 rounded-lg border border-line px-2.5 py-1.5 text-[12.5px] text-ink-2 transition hover:border-accent/40 hover:text-ink"
          >
            <IconLogout size={14} /> Sign out
          </button>
          )}
        </div>

        <h1 className="font-serif text-[2rem] font-semibold tracking-tight">Control Panel</h1>
        <p className="mt-1.5 text-[13.5px] leading-relaxed text-muted">
          Everything that makes Ash work lives here: free engine keys, the order they fall back in, web access, limits,
          learning, branding and backups.
        </p>

        {unclaimed && (
          <div className="mt-5 flex items-start gap-3 rounded-xl border px-4 py-3" style={{ borderColor: "color-mix(in oklab, var(--accent) 45%, var(--line))", background: "var(--accent-soft)" }}>
            <span className="mt-0.5 text-accent">
              <IconLock size={16} />
            </span>
            <p className="text-[12.5px] leading-relaxed text-ink-2">
              <span className="font-semibold">No password on this panel yet.</span> Everything works, but anyone who
              reaches this URL can change these settings. Card 7 locks it whenever you feel like it.
            </p>
          </div>
        )}

        <div className="mt-7 space-y-5">
          <EnginesCard data={data} post={post} save={save} reload={load} flash={flash} activeKeys={activeKeys} />
          <FallbackCard data={data} post={post} save={save} reload={load} flash={flash} />
          <WebCard data={data} post={post} save={save} flash={flash} />
          <LimitsCard data={data} save={save} />
          <TrainingCard learn={learn} reload={loadLearn} flash={flash} />
          <BrandingCard data={data} save={save} />
          <PasswordCard flash={flash} unclaimed={unclaimed} onClaimed={onSignedOut} />
          <VoiceCard data={data} post={post} save={save} reload={load} flash={flash} />
          <CoworkCard data={data} save={save} />
          <BackupCard flash={flash} />
        </div>

        <p className="py-10 text-center text-[11.5px] text-muted">Ash · everything here is stored in your own database.</p>
      </div>

      {toast && (
        <div className="fixed bottom-5 left-1/2 z-50 -translate-x-1/2 rounded-xl border border-line bg-surface px-4 py-2.5 text-[13px] shadow-[var(--shadow)]">
          {toast}
        </div>
      )}
    </div>
  );
}

/* ─────────────────── 1. engines ─────────────────── */

function EnginesCard({
  data,
  post,
  save,
  reload,
  flash,
  activeKeys,
}: {
  data: PanelData;
  post: (b: any) => Promise<any>;
  save: (p: any) => Promise<void>;
  reload: () => Promise<void>;
  flash: (m: string) => void;
  activeKeys: number;
}) {
  const [expanded, setExpanded] = useState<string | null>(null);
  const [showKey, setShowKey] = useState<Record<string, boolean>>({});
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [testing, setTesting] = useState<string | null>(null);
  const [results, setResults] = useState<Record<string, { ok: boolean; text: string }>>({});
  const [liveModels, setLiveModels] = useState<Record<string, string[]>>({});
  const [adding, setAdding] = useState(false);
  const [custom, setCustom] = useState({ label: "", baseUrl: "", model: "", key: "", note: "" });

  const saveKey = async (name: string, value: string) => {
    try {
      await post({ action: "key", name, value });
      setDrafts((d) => ({ ...d, [name]: "" }));
      await reload();
      flash(value ? "Key saved." : "Key removed.");
    } catch (err) {
      flash((err as Error).message);
    }
  };

  const test = async (providerId: string) => {
    setTesting(providerId);
    setResults((r) => ({ ...r, [providerId]: { ok: false, text: "Testing…" } }));
    try {
      const res = await post({ action: "test", providerId });
      setResults((r) => ({
        ...r,
        [providerId]: res.ok ? { ok: true, text: `✓ ${res.ms} ms` } : { ok: false, text: res.error || "Failed" },
      }));
      await reload();
    } catch (err) {
      setResults((r) => ({ ...r, [providerId]: { ok: false, text: (err as Error).message } }));
    } finally {
      setTesting(null);
    }
  };

  const fetchModels = async (providerId: string) => {
    try {
      const res = await post({ action: "list-models", providerId });
      setLiveModels((m) => ({ ...m, [providerId]: res.models ?? [] }));
    } catch {
      /* keep catalog */
    }
  };

  const toggleModel = async (providerId: string, modelId: string, exposed: boolean) => {
    const current: string[] = data.settings.providers?.[providerId]?.models ?? [];
    const next = exposed ? [...new Set([...current, modelId])] : current.filter((m) => m !== modelId);
    await save({ providers: { [providerId]: { models: next } } });
  };

  return (
    <Card
      step={1}
      title={`Free engine keys (${activeKeys} active)`}
      subtitle="Every engine here has a free tier and asks for no credit card. Paste one key and Ash starts answering."
      icon={<IconKey size={18} />}
    >
      <div className="space-y-2.5">
        {data.providers.map((p) => (
          <div key={p.id} className="rounded-xl border border-line">
            <div className="flex flex-wrap items-center gap-2 px-3 py-2.5">
              <Dot kind={p.statusKind} />
              <div className="min-w-0 flex-1">
                <p className="truncate text-[13px] font-semibold">
                  {p.vendor} <span className="font-normal text-muted">· shown as {p.publicName}</span>
                  {p.paid && <span className="ml-1.5 rounded border border-line px-1 text-[10px] text-muted">paid, optional</span>}
                </p>
                <p className="truncate text-[11.5px] text-muted">{p.note}</p>
              </div>
              <span
                className={`rounded-full border px-2 py-0.5 text-[11px] ${
                  p.statusKind === "healthy" ? "border-line text-muted" : "border-accent/40 bg-accent-soft text-accent"
                }`}
              >
                {p.configured ? p.status : "Key needed"}
              </span>
              <Switch checked={p.enabled} onChange={(v) => void save({ providers: { [p.id]: { enabled: v } } })} label={`Enable ${p.publicName}`} />
            </div>

            <div className="space-y-2 border-t border-line px-3 py-2.5">
              {p.keys.map((k) => (
                <div key={k.name} className="flex flex-wrap items-center gap-1.5">
                  <span className="w-full font-mono text-[10.5px] uppercase tracking-wider text-muted sm:w-40 sm:shrink-0">{k.name}</span>
                  <div className="relative min-w-0 flex-1">
                    <input
                      type={showKey[k.name] ? "text" : "password"}
                      value={drafts[k.name] ?? ""}
                      onChange={(e) => setDrafts((d) => ({ ...d, [k.name]: e.target.value }))}
                      placeholder={k.present ? `Saved: ${k.masked}${k.fromEnv ? " (from .env)" : ""}` : "Paste the key here…"}
                      className="w-full rounded-lg border border-line bg-surface-2 px-2.5 py-1.5 pr-8 text-[12.5px] outline-none transition focus:border-accent/40"
                    />
                    <button
                      type="button"
                      onClick={() => setShowKey((s) => ({ ...s, [k.name]: !s[k.name] }))}
                      aria-label={showKey[k.name] ? "Hide" : "Show"}
                      className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded p-1 text-muted transition hover:text-ink"
                    >
                      {showKey[k.name] ? <IconEyeOff size={13} /> : <IconEye size={13} />}
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={() => void saveKey(k.name, (drafts[k.name] ?? "").trim())}
                    disabled={!(drafts[k.name] ?? "").trim()}
                    className="rounded-lg border border-line px-2.5 py-1.5 text-[12px] text-ink-2 transition hover:border-accent/40 hover:text-ink disabled:opacity-40"
                  >
                    Save
                  </button>
                  {k.present && (
                    <button
                      type="button"
                      onClick={() => void saveKey(k.name, "")}
                      aria-label="Remove key"
                      title="Remove key"
                      className="rounded-lg border border-line p-1.5 text-muted transition hover:border-danger/40 hover:text-danger"
                    >
                      <IconTrash size={13} />
                    </button>
                  )}
                </div>
              ))}

              <div className="flex flex-wrap items-center gap-2 pt-0.5">
                {p.signupUrl && (
                  <a
                    href={p.signupUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 text-[12px] text-accent transition hover:opacity-80"
                  >
                    Get free key <IconExternal size={11} />
                  </a>
                )}
                <button
                  type="button"
                  onClick={() => void test(p.id)}
                  disabled={testing === p.id || !p.configured}
                  className="rounded-lg border border-line px-2.5 py-1 text-[12px] text-ink-2 transition hover:border-accent/40 hover:text-ink disabled:opacity-40"
                >
                  {testing === p.id ? "Testing…" : "Test"}
                </button>
                {results[p.id] && (
                  <span className={`text-[12px] ${results[p.id].ok ? "text-[#4d7c4f]" : "text-danger"}`}>{results[p.id].text}</span>
                )}
                <button
                  type="button"
                  onClick={() => {
                    const next = expanded === p.id ? null : p.id;
                    setExpanded(next);
                    if (next) void fetchModels(p.id);
                  }}
                  className="ml-auto text-[12px] text-muted transition hover:text-ink"
                >
                  {expanded === p.id ? "Hide models" : `Models (${p.models.filter((m) => m.exposed).length}/${p.models.length})`}
                </button>
                {p.custom && (
                  <button
                    type="button"
                    onClick={async () => {
                      try {
                        await post({ action: "custom-remove", id: p.id.replace("custom-", "") });
                        await reload();
                        flash("Custom engine removed.");
                      } catch (err) {
                        flash((err as Error).message);
                      }
                    }}
                    className="rounded-lg border border-line p-1.5 text-muted transition hover:border-danger/40 hover:text-danger"
                    aria-label="Remove custom engine"
                  >
                    <IconX size={13} />
                  </button>
                )}
              </div>

              {p.lastError && <p className="text-[11.5px] text-danger">{p.lastError}</p>}

              {expanded === p.id && (
                <div className="mt-1 space-y-1 rounded-lg border border-line bg-surface-2 p-2">
                  {p.models.map((m) => (
                    <label key={m.id} className="flex cursor-pointer items-start gap-2 rounded-md px-1.5 py-1 transition hover:bg-surface">
                      <input
                        type="checkbox"
                        checked={m.exposed}
                        onChange={(e) => void toggleModel(p.id, m.id, e.target.checked)}
                        className="mt-1 accent-[var(--accent)]"
                      />
                      <span className="min-w-0 flex-1">
                        <span className="block text-[12.5px] font-medium">
                          {m.label} <span className="font-normal text-muted">· {m.publicCode}</span>
                        </span>
                        <span className="block truncate font-mono text-[11px] text-muted">{m.id}</span>
                      </span>
                      {m.vision && <span className="rounded border border-line px-1 text-[10px] text-muted">sees images</span>}
                    </label>
                  ))}
                  {!!liveModels[p.id]?.length && (
                    <details className="mt-1.5 px-1.5">
                      <summary className="cursor-pointer text-[11.5px] text-muted">
                        {liveModels[p.id].length} models reported by this engine
                      </summary>
                      <div className="mt-1 max-h-40 overflow-y-auto font-mono text-[11px] leading-relaxed text-muted scroll-thin">
                        {liveModels[p.id].slice(0, 200).map((id) => (
                          <p key={id} className="truncate">
                            {id}
                          </p>
                        ))}
                      </div>
                      <p className="mt-1 text-[11px] text-muted">
                        Add any of these with the custom engine box below, or edit <span className="font-mono">src/lib/providers/catalog.ts</span>.
                      </p>
                    </details>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 rounded-xl border border-dashed border-line p-3">
        {!adding ? (
          <button
            type="button"
            onClick={() => setAdding(true)}
            className="flex items-center gap-1.5 text-[12.5px] text-accent transition hover:opacity-80"
          >
            <IconPlus size={14} /> Add a custom OpenAI-compatible engine
          </button>
        ) : (
          <div className="space-y-2">
            <p className="text-[12.5px] font-medium">New engine</p>
            {[
              { key: "label", placeholder: "Public name, e.g. Ash Nova" },
              { key: "baseUrl", placeholder: "Base URL, e.g. https://api.example.com/v1" },
              { key: "model", placeholder: "Model id, e.g. llama-3.3-70b" },
              { key: "key", placeholder: "API key (leave empty for a local server)" },
              { key: "note", placeholder: "One-line note (optional)" },
            ].map((f) => (
              <input
                key={f.key}
                value={(custom as any)[f.key]}
                onChange={(e) => setCustom((c) => ({ ...c, [f.key]: e.target.value }))}
                placeholder={f.placeholder}
                className="w-full rounded-lg border border-line bg-surface-2 px-2.5 py-1.5 text-[12.5px] outline-none transition focus:border-accent/40"
              />
            ))}
            <div className="flex gap-2">
              <button
                type="button"
                onClick={async () => {
                  try {
                    await post({ action: "custom-add", ...custom });
                    setCustom({ label: "", baseUrl: "", model: "", key: "", note: "" });
                    setAdding(false);
                    await reload();
                    flash("Custom engine added.");
                  } catch (err) {
                    flash((err as Error).message);
                  }
                }}
                className="rounded-lg bg-accent px-3 py-1.5 text-[12.5px] text-accent-ink transition hover:opacity-90"
              >
                Add engine
              </button>
              <button
                type="button"
                onClick={() => setAdding(false)}
                className="rounded-lg border border-line px-3 py-1.5 text-[12.5px] text-ink-2 transition hover:border-accent/40"
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>

      <p className="mt-3 text-[11.5px] leading-relaxed text-muted">
        Keys are stored in your database and merged into the server environment on every request, so this also works on
        read-only hosts. They are never sent back to the browser — only a masked preview.
      </p>
    </Card>
  );
}

/* ─────────────────── 2. fallback & health ─────────────────── */

function FallbackCard({
  data,
  post,
  save,
  reload,
  flash,
}: {
  data: PanelData;
  post: (b: any) => Promise<any>;
  save: (p: any) => Promise<void>;
  reload: () => Promise<void>;
  flash: (m: string) => void;
}) {
  const manual: string[] = data.settings.fallbackOrder ?? [];
  // what the server will actually do: leader first, then best trained
  const effective: string[] = data.ranking?.length ? data.ranking : manual;
  const dragIndex = useRef<number | null>(null);

  const move = (from: number, to: number) => {
    if (from === to || from < 0 || to < 0) return;
    const next = [...manual];
    const [item] = next.splice(from, 1);
    next.splice(to, 0, item);
    void save({ fallbackOrder: next });
  };

  return (
    <Card
      step={2}
      title="Which engine leads, and what takes over"
      subtitle="One engine answers first. When it runs out of quota, Ash hands over to the engine that has trained it the most."
      icon={<IconLayers size={18} />}
    >
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="block">
          <span className="block text-[12.5px] font-medium">Engine that opens first</span>
          <span className="mt-0.5 block text-[11.5px] text-muted">Every visitor starts here.</span>
          <select
            value={data.settings.primaryProvider ?? "gemini"}
            onChange={(e) => void save({ primaryProvider: e.target.value })}
            className="mt-1.5 w-full rounded-lg border border-line bg-surface-2 px-2.5 py-1.5 text-[13px] outline-none transition focus:border-accent/40"
          >
            {data.providers
              .filter((p) => !p.paid)
              .map((p) => (
                <option key={p.id} value={p.id}>
                  {p.publicName} · {p.vendor}
                  {p.configured ? "" : " (no key yet)"}
                </option>
              ))}
          </select>
        </label>

        <label className="flex items-start gap-2.5 sm:pt-6">
          <Switch
            checked={data.settings.preferTrainedFallback !== false}
            onChange={(v) => void save({ preferTrainedFallback: v })}
            label="Hand over to the best-trained engine"
          />
          <span>
            <span className="block text-[12.5px] font-medium">Hand over to the best-trained engine</span>
            <span className="block text-[11.5px] text-muted">
              Off: Ash just walks down the list below instead.
            </span>
          </span>
        </label>
      </div>

      <p className="mt-4 text-[12.5px] font-medium">Hand-over order right now</p>
      <p className="mt-0.5 text-[11.5px] text-muted">
        Drag to set your own preference — it is the tie-breaker when two engines are trained the same.
      </p>
      <ul className="mt-2 space-y-1.5">
        {effective.map((id, i) => {
          const p = data.providers.find((x) => x.id === id);
          if (!p) return null;
          const isPrimary = id === (data.settings.primaryProvider ?? "gemini");
          return (
            <li
              key={id}
              draggable
              onDragStart={() => (dragIndex.current = manual.indexOf(id))}
              onDragOver={(e) => e.preventDefault()}
              onDrop={() => {
                if (dragIndex.current !== null) move(dragIndex.current, manual.indexOf(id));
                dragIndex.current = null;
              }}
              className={`flex items-center gap-2 rounded-lg border px-2.5 py-2 ${
                isPrimary ? "border-accent/40 bg-accent-soft/40" : "border-line"
              } ${p.enabled && p.configured ? "" : "opacity-50"}`}
            >
              <span className="cursor-grab text-muted">
                <IconGrip size={14} />
              </span>
              <span className="w-5 text-[11.5px] text-muted">{i + 1}</span>
              <span className="min-w-0 flex-1 truncate text-[13px]">
                {p.publicName} <span className="text-muted">· {p.vendor}</span>
                {isPrimary && <span className="ml-1.5 text-[10.5px] uppercase tracking-wide text-accent">leads</span>}
              </span>
              <span className="shrink-0 text-[11.5px] text-muted" title="Answers this engine has taught Ash">
                {p.trained} trained
              </span>
              <Dot kind={p.statusKind} />
            </li>
          );
        })}
      </ul>

      <div className="mt-4 overflow-hidden rounded-xl border border-line">
        <div className="grid grid-cols-[1fr_auto_auto] gap-2 border-b border-line bg-surface-2 px-3 py-1.5 text-[10.5px] uppercase tracking-[.09em] text-muted">
          <span>Engine</span>
          <span>State</span>
          <span>Seconds</span>
        </div>
        {!data.cooldowns.length && <p className="px-3 py-3 text-[12.5px] text-muted">Everything is healthy. Nothing is cooling down.</p>}
        {data.cooldowns.map((c) => (
          <div key={c.id} className="grid grid-cols-[1fr_auto_auto] gap-2 border-b border-line px-3 py-2 text-[12.5px] last:border-0">
            <span className="min-w-0">
              <span className="block truncate font-mono text-[11.5px]">{c.id}</span>
              {c.lastError && <span className="block truncate text-[11px] text-muted">{c.lastError}</span>}
            </span>
            <span className="text-muted">{c.label}</span>
            <span className="text-muted">{c.secondsLeft}s</span>
          </div>
        ))}
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-3">
        <button
          type="button"
          onClick={async () => {
            try {
              await post({ action: "reset-cooldowns" });
              await reload();
              flash("Cooldowns cleared.");
            } catch (err) {
              flash((err as Error).message);
            }
          }}
          className="rounded-lg border border-line px-2.5 py-1.5 text-[12.5px] text-ink-2 transition hover:border-accent/40 hover:text-ink"
        >
          Reset cooldowns
        </button>
        <label className="flex items-center gap-2 text-[12.5px]">
          <Switch
            checked={data.settings.allowMemoryFallback !== false}
            onChange={(v) => void save({ allowMemoryFallback: v })}
            label="Allow answering from memory when every engine fails"
          />
          Allow answering from memory when every engine fails
        </label>
      </div>
    </Card>
  );
}

/* ─────────────────── 3. web access ─────────────────── */

function WebCard({
  data,
  post,
  save,
  flash,
}: {
  data: PanelData;
  post: (b: any) => Promise<any>;
  save: (p: any) => Promise<void>;
  flash: (m: string) => void;
}) {
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [results, setResults] = useState<Record<string, string>>({});

  return (
    <Card
      step={3}
      title="Tools & web access"
      subtitle="Capabilities Ash may use. Only the ones a question actually needs are run."
      icon={<IconGlobe size={18} />}
    >
      <div className="mb-5 space-y-2">
        {[
          { id: "math", label: "Calculator", hint: "Answers a plain sum instantly without spending an engine call." },
          { id: "memory", label: "Memory", hint: "Checks what Ash already learned before calling an engine." },
          { id: "search", label: "Web search", hint: "Fetches live results and keeps the links as citations." },
        ].map((a) => (
          <label key={a.id} className="flex items-start gap-2.5">
            <Switch
              checked={data.settings.agents?.[a.id]?.enabled !== false}
              onChange={(v) => void save({ agents: { [a.id]: { enabled: v } } })}
              label={a.label}
            />
            <span>
              <span className="block text-[12.5px] font-medium">{a.label}</span>
              <span className="block text-[11.5px] text-muted">{a.hint}</span>
            </span>
          </label>
        ))}
      </div>
      <div className="mb-4 border-t border-line pt-4" />
      <div className="flex flex-wrap items-center gap-4">
        <label className="flex items-center gap-2 text-[12.5px]">
          Search mode
          <select
            value={data.settings.search?.mode ?? "auto"}
            onChange={(e) => void save({ search: { mode: e.target.value } })}
            className="rounded-lg border border-line bg-surface-2 px-2 py-1.5 text-[12.5px] outline-none transition focus:border-accent/40"
          >
            <option value="auto">Auto</option>
            <option value="always">Always</option>
            <option value="never">Never</option>
          </select>
        </label>
        <label className="flex items-center gap-2 text-[12.5px]">
          Max results
          <input
            type="number"
            min={3}
            max={8}
            value={data.settings.search?.maxResults ?? 5}
            onChange={(e) => void save({ search: { maxResults: Math.min(8, Math.max(3, Number(e.target.value) || 5)) } })}
            className="w-16 rounded-lg border border-line bg-surface-2 px-2 py-1.5 text-[12.5px] outline-none transition focus:border-accent/40"
          />
        </label>
        <label className="flex items-center gap-2 text-[12.5px]">
          <Switch
            checked={data.settings.search?.readPages !== false}
            onChange={(v) => void save({ search: { readPages: v } })}
            label="Read the best page"
          />
          Read the best page (max 8 KB, never private addresses)
        </label>
      </div>

      <div className="mt-4 space-y-2">
        {data.searchProviders
          .slice()
          .sort((a, b) => a.order - b.order)
          .map((sp) => (
            <div key={sp.id} className="rounded-xl border border-line px-3 py-2.5">
              <div className="flex flex-wrap items-center gap-2">
                <Switch
                  checked={sp.enabled}
                  onChange={(v) => void save({ search: { providers: { [sp.id]: { enabled: v } } } })}
                  label={`Enable ${sp.label}`}
                />
                <div className="min-w-0 flex-1">
                  <p className="text-[13px] font-semibold">{sp.label}</p>
                  <p className="truncate text-[11.5px] text-muted">{sp.note}</p>
                </div>
                <input
                  type="number"
                  value={sp.order}
                  min={0}
                  max={20}
                  onChange={(e) => void save({ search: { providers: { [sp.id]: { order: Number(e.target.value) || 0 } } } })}
                  className="w-14 rounded-lg border border-line bg-surface-2 px-2 py-1 text-[12px] outline-none transition focus:border-accent/40"
                  aria-label={`${sp.label} order`}
                />
                <button
                  type="button"
                  onClick={async () => {
                    setResults((r) => ({ ...r, [sp.id]: "Testing…" }));
                    try {
                      const res = await post({ action: "test-search", id: sp.id });
                      setResults((r) => ({
                        ...r,
                        [sp.id]: res.ok ? `✓ ${res.count} results · ${res.ms} ms` : res.error || "No results",
                      }));
                    } catch (err) {
                      setResults((r) => ({ ...r, [sp.id]: (err as Error).message }));
                    }
                  }}
                  className="rounded-lg border border-line px-2.5 py-1 text-[12px] text-ink-2 transition hover:border-accent/40 hover:text-ink"
                >
                  Test
                </button>
                {results[sp.id] && <span className="text-[11.5px] text-muted">{results[sp.id]}</span>}
              </div>

              {(sp.needsKey || sp.needsUrl) && (
                <div className="mt-2 flex flex-wrap items-center gap-1.5">
                  <input
                    value={drafts[sp.id] ?? ""}
                    onChange={(e) => setDrafts((d) => ({ ...d, [sp.id]: e.target.value }))}
                    placeholder={
                      sp.needsUrl
                        ? sp.url
                          ? `Saved: ${sp.url}`
                          : "https://searx.example.org"
                        : sp.hasKey
                          ? `Saved: ${sp.masked}`
                          : "Paste the free key here…"
                    }
                    className="min-w-0 flex-1 rounded-lg border border-line bg-surface-2 px-2.5 py-1.5 text-[12.5px] outline-none transition focus:border-accent/40"
                  />
                  <button
                    type="button"
                    onClick={async () => {
                      const value = (drafts[sp.id] ?? "").trim();
                      try {
                        if (sp.needsUrl) await save({ search: { providers: { [sp.id]: { url: value } } } });
                        else await post({ action: "key", name: sp.keyName, value });
                        setDrafts((d) => ({ ...d, [sp.id]: "" }));
                        flash("Saved.");
                      } catch (err) {
                        flash((err as Error).message);
                      }
                    }}
                    className="rounded-lg border border-line px-2.5 py-1.5 text-[12px] text-ink-2 transition hover:border-accent/40 hover:text-ink"
                  >
                    Save
                  </button>
                  {sp.signupUrl && (
                    <a
                      href={sp.signupUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 text-[12px] text-accent transition hover:opacity-80"
                    >
                      Get free key <IconExternal size={11} />
                    </a>
                  )}
                </div>
              )}
            </div>
          ))}
      </div>
    </Card>
  );
}

/* ─────────────────── 4. limits ─────────────────── */

function LimitsCard({ data, save }: { data: PanelData; save: (p: any) => Promise<void> }) {
  const l = data.settings.limits ?? {};
  return (
    <Card
      step={4}
      title="Chat limits & access"
      subtitle="The app is free for everyone, so these keep it from being drained by one visitor."
      icon={<IconGauge size={18} />}
    >
      <div className="grid gap-3 sm:grid-cols-2">
        <NumberField
          label="Messages per visitor per hour"
          hint="0 means unlimited"
          value={l.perVisitorHour ?? 60}
          onCommit={(v) => void save({ limits: { perVisitorHour: v } })}
        />
        <NumberField
          label="Messages per IP per minute"
          value={l.perIpMinute ?? 12}
          onCommit={(v) => void save({ limits: { perIpMinute: v } })}
        />
        <NumberField
          label="Max message length"
          hint="characters"
          value={l.maxMessageChars ?? 8000}
          min={200}
          onCommit={(v) => void save({ limits: { maxMessageChars: v } })}
        />
        <NumberField
          label="Context budget"
          hint="tokens of history sent to the model"
          value={l.contextTokens ?? 12000}
          min={2000}
          onCommit={(v) => void save({ limits: { contextTokens: v } })}
        />
        <NumberField
          label="Max images per message"
          value={l.maxImages ?? 4}
          onCommit={(v) => void save({ limits: { maxImages: v } })}
        />
      </div>

      <div className="mt-4 space-y-2.5">
        {[
          { key: "requireLogin", label: "Require login", hint: "Visitors must sign in with email before chatting." },
          { key: "allowMedia", label: "Allow image & clip generation", hint: "Turn off to disable the create buttons." },
          { key: "ownerCanViewChats", label: "Allow owner to view chats", hint: "Off by default — visitors' chats stay private." },
        ].map((row) => (
          <label key={row.key} className="flex items-start gap-2.5">
            <Switch
              checked={!!l[row.key]}
              onChange={(v) => void save({ limits: { [row.key]: v } })}
              label={row.label}
            />
            <span>
              <span className="block text-[12.5px] font-medium">{row.label}</span>
              <span className="block text-[11.5px] text-muted">{row.hint}</span>
            </span>
          </label>
        ))}
      </div>

      <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
        {[
          { label: "Messages", value: data.stats.messages },
          { label: "Visitors", value: data.stats.visitors },
          { label: "Errors", value: data.stats.errors },
          { label: "Fallbacks", value: data.stats.fallbacks },
        ].map((s) => (
          <div key={s.label} className="rounded-xl border border-line bg-surface-2 px-3 py-2.5">
            <p className="font-serif text-[20px] font-semibold">{s.value}</p>
            <p className="text-[11.5px] text-muted">{s.label} today</p>
          </div>
        ))}
      </div>
    </Card>
  );
}

/* ─────────────────── 5. training ─────────────────── */

function TrainingCard({ learn, reload, flash }: { learn: any; reload: () => Promise<void>; flash: (m: string) => void }) {
  const [speed, setSpeed] = useState<"gentle" | "normal" | "fast" | "turbo">("normal");
  useEffect(() => {
    const s = learn?.speed;
    if (s === "gentle" || s === "normal" || s === "fast" || s === "turbo") setSpeed(s);
  }, [learn?.speed]);
  const [questions, setQuestions] = useState("");
  const [probe, setProbe] = useState("");
  const [probeResult, setProbeResult] = useState<any>(null);
  const [confirmClear, setConfirmClear] = useState(false);

  const post = async (body: any) => {
    const res = await fetch("/api/learn", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(json.error || "That did not work.");
    return json;
  };

  return (
    <Card
      step={5}
      title="Training / Learning"
      subtitle="Ash remembers good answers from the free engines so it can reply instantly — and offline. This is a memory, not a fine-tune."
      icon={<IconBrain size={18} />}
    >
      <div className="flex flex-wrap items-center gap-3">
        <label className="flex items-center gap-2 text-[12.5px] font-medium">
          <Switch
            checked={!!learn?.running}
            onChange={async (v) => {
              try {
                await post({ action: v ? "start" : "stop", speed });
                await reload();
              } catch (err) {
                flash((err as Error).message);
              }
            }}
            label="Learning"
          />
          {learn?.running
            ? `Running · ${learn.workers ?? 0} of ${learn.desiredWorkers ?? 0} workers awake`
            : "Learning is stopped"}
        </label>

        <div className="ml-auto flex items-center gap-1 rounded-lg border border-line p-0.5">
          {(["gentle", "normal", "fast", "turbo"] as const).map((s) => (
            <button
              key={s}
              type="button"
              onClick={async () => {
                setSpeed(s);
                try {
                  await post({ action: "speed", speed: s });
                  await reload();
                } catch (err) {
                  flash((err as Error).message);
                }
              }}
              className={`rounded-md px-2 py-1 text-[11.5px] capitalize transition ${
                speed === s ? "bg-accent text-accent-ink" : "text-muted hover:text-ink"
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>
      <p className="mt-1.5 text-[11.5px] text-muted">
        Speed is the ceiling (gentle 2 · normal 4 · fast 8 · turbo 12). Free keys cap requests per minute, so Ash
        measures what actually gets through and quietly settles on that many workers — pick Turbo and let it find
        the limit by itself.
      </p>
      {learn?.lastError && <p className="mt-1.5 text-[11.5px] text-danger">{learn.lastError}</p>}

      <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
        {[
          { label: "Total saved", value: learn?.total ?? 0 },
          { label: "Saved / min", value: learn?.ratePerMin ?? 0 },
          { label: "Asked this run", value: learn?.asked ?? 0 },
          { label: "Rate-limited", value: learn?.rateLimited ?? 0 },
        ].map((s) => (
          <div key={s.label} className="rounded-xl border border-line bg-surface-2 px-3 py-2.5">
            <p className="font-serif text-[20px] font-semibold">{s.value}</p>
            <p className="text-[11.5px] text-muted">{s.label}</p>
          </div>
        ))}
      </div>

      {!!learn?.recent?.length && (
        <div className="mt-3 overflow-hidden rounded-xl border border-line">
          <p className="border-b border-line bg-surface-2 px-3 py-1.5 text-[10.5px] uppercase tracking-[.09em] text-muted">
            Live activity
          </p>
          <div className="max-h-44 overflow-y-auto scroll-thin">
            {learn.recent.map((r: any, i: number) => (
              <div key={i} className="flex items-center gap-2 border-b border-line px-3 py-1.5 text-[11.5px] last:border-0">
                <span
                  className="h-1.5 w-1.5 shrink-0 rounded-full"
                  style={{ background: r.outcome === "saved" ? "#4d7c4f" : r.outcome === "rejected" ? "#9a6b28" : "var(--danger)" }}
                />
                <span dir="auto" className="min-w-0 flex-1 truncate">{r.question}</span>
                <span className="shrink-0 text-muted">{r.reason ? r.reason.slice(0, 28) : r.outcome}</span>
                <span className="shrink-0 text-muted">{(r.ms / 1000).toFixed(1)}s</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="mt-4">
        <p className="text-[12.5px] font-medium">Your own questions</p>
        <p className="mt-0.5 text-[11.5px] text-muted">One per line. They go to the front of the queue.</p>
        <textarea
          dir="auto"
          value={questions}
          onChange={(e) => setQuestions(e.target.value)}
          rows={3}
          placeholder={"What is zakat and how is it calculated?\nPython mein list comprehension kya hai?"}
          className="mt-1.5 w-full resize-y rounded-xl border border-line bg-surface-2 px-3 py-2 text-[12.5px] leading-relaxed outline-none transition focus:border-accent/40"
        />
        <button
          type="button"
          onClick={async () => {
            try {
              const res = await post({ action: "enqueue", questions });
              setQuestions("");
              await reload();
              flash(`${res.added} question${res.added === 1 ? "" : "s"} queued.`);
            } catch (err) {
              flash((err as Error).message);
            }
          }}
          disabled={!questions.trim()}
          className="mt-2 rounded-lg border border-line px-2.5 py-1.5 text-[12.5px] text-ink-2 transition hover:border-accent/40 hover:text-ink disabled:opacity-40"
        >
          Add to queue
        </button>
      </div>

      <div className="mt-4 border-t border-line pt-4">
        <p className="text-[12.5px] font-medium">Test the memory</p>
        <p className="mt-0.5 text-[11.5px] text-muted">Answers only from what Ash has saved — no engine is called.</p>
        <div className="mt-1.5 flex gap-2">
          <input
            dir="auto"
            value={probe}
            onChange={(e) => setProbe(e.target.value)}
            placeholder="Ask something Ash should already know…"
            className="min-w-0 flex-1 rounded-lg border border-line bg-surface-2 px-2.5 py-1.5 text-[12.5px] outline-none transition focus:border-accent/40"
          />
          <button
            type="button"
            onClick={async () => {
              try {
                setProbeResult(await post({ action: "test", question: probe }));
              } catch (err) {
                flash((err as Error).message);
              }
            }}
            disabled={!probe.trim()}
            className="rounded-lg border border-line px-2.5 py-1.5 text-[12.5px] text-ink-2 transition hover:border-accent/40 hover:text-ink disabled:opacity-40"
          >
            Ask memory
          </button>
        </div>
        {probeResult && (
          <div className="mt-2 rounded-xl border border-line bg-surface-2 p-3">
            <p className="text-[11.5px] uppercase tracking-wider text-muted">
              {probeResult.kind} · confidence {probeResult.confidence}
            </p>
            <p dir="auto" className="mt-1 whitespace-pre-wrap text-[12.5px] leading-relaxed">
              {probeResult.answer ?? "Nothing saved for that yet."}
            </p>
          </div>
        )}
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-line pt-4">
        <a
          href="/api/knowledge?export=jsonl"
          className="flex items-center gap-1.5 rounded-lg border border-line px-2.5 py-1.5 text-[12.5px] text-ink-2 transition hover:border-accent/40 hover:text-ink"
        >
          <IconDownload size={14} /> Download dataset (JSONL)
        </a>
        {confirmClear ? (
          <>
            <button
              type="button"
              onClick={async () => {
                await fetch("/api/knowledge", { method: "DELETE" });
                setConfirmClear(false);
                await reload();
                flash("Knowledge cleared.");
              }}
              className="rounded-lg bg-danger px-2.5 py-1.5 text-[12.5px] text-white transition hover:opacity-90"
            >
              Yes, erase everything
            </button>
            <button
              type="button"
              onClick={() => setConfirmClear(false)}
              className="rounded-lg border border-line px-2.5 py-1.5 text-[12.5px] text-ink-2 transition hover:border-accent/40"
            >
              Cancel
            </button>
          </>
        ) : (
          <button type="button" onClick={() => setConfirmClear(true)} className="text-[12.5px] font-medium text-danger transition hover:opacity-80">
            Clear knowledge
          </button>
        )}
      </div>
    </Card>
  );
}

/* ─────────────────── 6. branding ─────────────────── */

function BrandingCard({ data, save }: { data: PanelData; save: (p: any) => Promise<void> }) {
  const b = data.settings.branding ?? {};
  const [local, setLocal] = useState({ ...b, systemPrompt: data.settings.systemPrompt ?? "" });
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setLocal({ ...data.settings.branding, systemPrompt: data.settings.systemPrompt ?? "" });
  }, [data.settings.branding, data.settings.systemPrompt]);

  return (
    <Card step={6} title="Branding" subtitle="Who Ash says it is. These values also feed the offline identity answers." icon={<IconPaint size={18} />}>
      <div className="grid gap-3 sm:grid-cols-2">
        {[
          { key: "name", label: "AI name" },
          { key: "creator", label: "Creator" },
          { key: "country", label: "Country" },
          { key: "city", label: "City" },
        ].map((f) => (
          <label key={f.key} className="block">
            <span className="block text-[12.5px] font-medium">{f.label}</span>
            <input
              value={(local as any)[f.key] ?? ""}
              onChange={(e) => setLocal((s: any) => ({ ...s, [f.key]: e.target.value }))}
              className="mt-1 w-full rounded-lg border border-line bg-surface-2 px-2.5 py-1.5 text-[13px] outline-none transition focus:border-accent/40"
            />
          </label>
        ))}
      </div>

      <div className="mt-4">
        <div className="flex items-center justify-between">
          <span className="text-[12.5px] font-medium">Default system prompt</span>
          <button
            type="button"
            onClick={() => setLocal((s: any) => ({ ...s, systemPrompt: "" }))}
            className="text-[11.5px] text-accent transition hover:opacity-80"
          >
            Reset to default
          </button>
        </div>
        <textarea
          value={local.systemPrompt}
          onChange={(e) => setLocal((s: any) => ({ ...s, systemPrompt: e.target.value }))}
          rows={6}
          placeholder={data.defaultSystemPrompt.slice(0, 160) + "…"}
          className="mt-1.5 w-full resize-y rounded-xl border border-line bg-surface-2 px-3 py-2 font-mono text-[11.5px] leading-relaxed outline-none transition focus:border-accent/40"
        />
        <p className="mt-1 text-[11.5px] text-muted">
          Leave empty to use Ash&apos;s built-in prompt. Use {"{AI_NAME}"}, {"{AI_CREATOR}"}, {"{AI_COUNTRY}"} and {"{AI_CITY}"} as placeholders.
        </p>
      </div>

      <button
        type="button"
        onClick={async () => {
          const { systemPrompt, ...branding } = local as any;
          await save({ branding, systemPrompt });
          setSaved(true);
          setTimeout(() => setSaved(false), 1800);
        }}
        className="mt-3 flex items-center gap-1.5 rounded-lg bg-accent px-3 py-1.5 text-[12.5px] text-accent-ink transition hover:opacity-90"
      >
        {saved ? <IconCheck size={14} /> : null} {saved ? "Saved" : "Save branding"}
      </button>
    </Card>
  );
}

/* ─────────────────── 7. password ─────────────────── */

function PasswordCard({
  flash,
  unclaimed,
  onClaimed,
}: {
  flash: (m: string) => void;
  unclaimed?: boolean;
  onClaimed?: () => void;
}) {
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [repeat, setRepeat] = useState("");
  const [show, setShow] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  return (
    <Card
      step={7}
      title={unclaimed ? "Lock this panel" : "Your password"}
      subtitle={
        unclaimed
          ? "Optional, and you can do it any time. Until then the panel stays open to anyone with the link."
          : "The only key to this panel. Change it whenever you like."
      }
      icon={<IconLock size={18} />}
    >
      <div className="grid gap-3 sm:grid-cols-3">
        {[
          ...(unclaimed ? [] : [{ label: "Current password", value: current, set: setCurrent }]),
          { label: unclaimed ? "Password" : "New password", value: next, set: setNext },
          { label: "Repeat password", value: repeat, set: setRepeat },
        ].map((f) => (
          <label key={f.label} className="block">
            <span className="block text-[12.5px] font-medium">{f.label}</span>
            <input
              type={show ? "text" : "password"}
              value={f.value}
              onChange={(e) => f.set(e.target.value)}
              className="mt-1 w-full rounded-lg border border-line bg-surface-2 px-2.5 py-1.5 text-[13px] outline-none transition focus:border-accent/40"
            />
          </label>
        ))}
      </div>

      <label className="mt-2.5 flex items-center gap-2 text-[12px] text-muted">
        <input type="checkbox" checked={show} onChange={(e) => setShow(e.target.checked)} className="accent-[var(--accent)]" />
        Show passwords
      </label>

      {error && <p className="mt-2 rounded-lg border border-danger/35 bg-danger/8 px-3 py-2 text-[12.5px] text-danger">{error}</p>}
      {message && <p className="mt-2 rounded-lg border border-line bg-surface-2 px-3 py-2 text-[12.5px]">{message}</p>}

      <button
        type="button"
        onClick={async () => {
          setError(null);
          setMessage(null);
          if (next !== repeat) {
            setError("The two passwords do not match.");
            return;
          }
          try {
            const res = await fetch("/api/owner", {
              method: "POST",
              headers: { "content-type": "application/json" },
              body: JSON.stringify(unclaimed ? { action: "setup", password: next } : { action: "password", current, next }),
            });
            const json = await res.json();
            if (!res.ok) setError(json.error || "That did not work.");
            else {
              setMessage(json.message || (unclaimed ? "Panel locked. Keep this password safe." : "Password changed."));
              setCurrent("");
              setNext("");
              setRepeat("");
              flash(unclaimed ? "Panel locked." : "Password changed.");
              onClaimed?.();
            }
          } catch {
            setError("Could not reach the server.");
          }
        }}
        disabled={(!unclaimed && !current) || next.length < 8}
        className="mt-3 rounded-lg bg-accent px-3 py-1.5 text-[12.5px] text-accent-ink transition hover:opacity-90 disabled:opacity-40"
      >
        {unclaimed ? "Set password" : "Change password"}
      </button>
    </Card>
  );
}

/* ─────────────────── 8. voice ─────────────────── */

function VoiceCard({
  data,
  post,
  save,
  reload,
  flash,
}: {
  data: PanelData;
  post: (b: any) => Promise<any>;
  save: (p: any) => Promise<void>;
  reload: () => Promise<void>;
  flash: (m: string) => void;
}) {
  const v = data.settings.voice ?? {};
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const vp = data.voiceProviders ?? { stt: [], tts: [] };

  const keyRow = (name: string) => (
    <div className="mt-2 flex flex-wrap items-center gap-1.5">
      <span className="w-full font-mono text-[10.5px] uppercase tracking-wider text-muted sm:w-40 sm:shrink-0">{name}</span>
      <input
        type="password"
        value={drafts[name] ?? ""}
        onChange={(e) => setDrafts((d) => ({ ...d, [name]: e.target.value }))}
        placeholder="Paste the key here…"
        className="min-w-0 flex-1 rounded-lg border border-line bg-surface-2 px-2.5 py-1.5 text-[12.5px] outline-none transition focus:border-accent/40"
      />
      <button
        type="button"
        disabled={!(drafts[name] ?? "").trim()}
        onClick={async () => {
          try {
            await post({ action: "key", name, value: (drafts[name] ?? "").trim() });
            setDrafts((d) => ({ ...d, [name]: "" }));
            await reload();
            flash("Key saved.");
          } catch (err) {
            flash((err as Error).message);
          }
        }}
        className="rounded-lg border border-line px-2.5 py-1.5 text-[12px] text-ink-2 transition hover:border-accent/40 hover:text-ink disabled:opacity-40"
      >
        Save
      </button>
    </div>
  );

  return (
    <Card
      step={8}
      title="Voice"
      subtitle="Talking and listening work with no key at all using the visitor's own device. These are the upgrades."
      icon={<IconVolume size={18} />}
    >
      <label className="flex items-start gap-2.5">
        <Switch checked={v.enabled !== false} onChange={(x) => void save({ voice: { enabled: x } })} label="Voice enabled" />
        <span>
          <span className="block text-[12.5px] font-medium">Voice enabled</span>
          <span className="block text-[11.5px] text-muted">Turn off to hide the microphone and read-aloud buttons.</span>
        </span>
      </label>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <label className="block">
          <span className="block text-[12.5px] font-medium">Default listening engine</span>
          <select
            value={v.sttProvider ?? "browser"}
            onChange={(e) => void save({ voice: { sttProvider: e.target.value } })}
            className="mt-1.5 w-full rounded-lg border border-line bg-surface-2 px-2.5 py-1.5 text-[13px] outline-none transition focus:border-accent/40"
          >
            <option value="browser">The visitor&apos;s own device (free)</option>
            {vp.stt.map((o) => (
              <option key={o.id} value={o.id} disabled={!o.configured}>
                {o.label}
                {o.configured ? "" : " — needs a key"}
              </option>
            ))}
          </select>
        </label>
        <label className="block">
          <span className="block text-[12.5px] font-medium">Default speaking engine</span>
          <select
            value={v.ttsProvider ?? "browser"}
            onChange={(e) => void save({ voice: { ttsProvider: e.target.value } })}
            className="mt-1.5 w-full rounded-lg border border-line bg-surface-2 px-2.5 py-1.5 text-[13px] outline-none transition focus:border-accent/40"
          >
            <option value="browser">The visitor&apos;s own device (free)</option>
            {vp.tts.map((o) => (
              <option key={o.id} value={o.id} disabled={!o.configured}>
                {o.label}
                {o.configured ? "" : " — needs a key"}
              </option>
            ))}
          </select>
        </label>
      </div>

      <div className="mt-4 space-y-2">
        {[...vp.stt, ...vp.tts].map((o) => (
          <div key={o.id} className="flex items-center gap-2 rounded-lg border border-line px-3 py-2">
            <Dot kind={o.configured ? "healthy" : "unset"} />
            <span className="min-w-0 flex-1">
              <span className="block truncate text-[12.5px] font-medium">{o.label}</span>
              <span className="block truncate text-[11.5px] text-muted">{o.note}</span>
            </span>
            <span className="shrink-0 text-[11px] text-muted">{o.configured ? "ready" : o.requiresKey || "needs setup"}</span>
          </div>
        ))}
      </div>

      {keyRow("ELEVENLABS_API_KEY")}
      <p className="mt-2 text-[11.5px] leading-relaxed text-muted">
        Fast Whisper reuses your <span className="font-mono">GROQ_API_KEY</span> and Open Voice reuses{" "}
        <span className="font-mono">HF_TOKEN</span> from card 1 — nothing extra to paste. Set{" "}
        <span className="font-mono">OPENAI_BASE_URL</span> to point at a Whisper or Kokoro server you run yourself.
      </p>
    </Card>
  );
}


/* ─────────────────── 9. cowork ─────────────────── */

function CoworkCard({ data, save }: { data: PanelData; save: (p: any) => Promise<void> }) {
  const cowork = data.settings.cowork ?? { enabled: true, autoApprove: false, maxSteps: 24 };
  const voice = data.settings.voice ?? {};

  return (
    <Card
      step={9}
      title="Cowork & spoken control"
      subtitle="Cowork takes a whole job instead of a question: it plans, uses tools, and hands back real files. Below that, the rules for driving the app by voice."
      icon={<IconWand size={18} />}
    >
      <div className="space-y-3">
        <label className="flex items-start gap-3">
          <Switch checked={cowork.enabled !== false} onChange={(v) => void save({ cowork: { enabled: v } })} label="Cowork mode" />
          <span className="min-w-0 flex-1">
            <span className="block text-[13px] font-medium">Cowork mode</span>
            <span className="block text-[11.5px] text-muted">
              Adds the Chat / Cowork switch at the top of the app. Turning it off hides the whole mode.
            </span>
          </span>
        </label>

        <label className="flex items-start gap-3">
          <Switch
            checked={cowork.autoApprove === true}
            onChange={(v) => void save({ cowork: { autoApprove: v } })}
            label="Let it delete files without asking"
          />
          <span className="min-w-0 flex-1">
            <span className="block text-[13px] font-medium">Let it delete files without asking</span>
            <span className="block text-[11.5px] text-muted">
              Off by default. While it is off, Ash stops and waits for your yes before deleting anything it made.
            </span>
          </span>
        </label>

        <div className="max-w-xs">
          <NumberField
            label="Steps per run"
            hint="How many tool steps one run may take before it stops and reports back. 24 is a sensible ceiling."
            value={Number(cowork.maxSteps ?? 24)}
            min={4}
            onCommit={(v) => void save({ cowork: { maxSteps: Math.min(60, Math.max(4, v)) } })}
          />
        </div>

        <hr className="border-line" />

        <label className="flex items-start gap-3">
          <Switch
            checked={voice.commands !== false}
            onChange={(v) => void save({ voice: { commands: v } })}
            label="Spoken commands"
          />
          <span className="min-w-0 flex-1">
            <span className="block text-[13px] font-medium">Spoken commands</span>
            <span className="block text-[11.5px] text-muted">
              Lets speech drive the app itself — new chat, read it out, dark mode, cowork, approve, stop. Say the assistant&apos;s
              name first, or switch Command mode on in the voice panel. &ldquo;Stop&rdquo; and &ldquo;ruk jao&rdquo; always work.
            </span>
          </span>
        </label>

        <label className="block max-w-xs">
          <span className="block text-[12.5px] font-medium">Extra wake word</span>
          <span className="mt-0.5 block text-[11.5px] text-muted">Optional. A second word that marks a sentence as a command.</span>
          <input
            defaultValue={voice.wakeWord ?? ""}
            onBlur={(e) => void save({ voice: { wakeWord: e.target.value.trim().slice(0, 24) } })}
            placeholder="e.g. computer"
            className="mt-1.5 w-full rounded-lg border border-line bg-surface-2 px-2.5 py-1.5 text-[13px] outline-none transition focus:border-accent/40"
          />
        </label>

        <div className="rounded-lg border border-line bg-surface-2 px-3 py-2.5">
          <p className="mb-1.5 text-[11.5px] font-semibold uppercase tracking-wide text-muted">What people can say</p>
          <div className="grid gap-x-6 gap-y-1 sm:grid-cols-2">
            {COMMAND_HELP.map((g) => (
              <div key={g.group}>
                <p className="text-[11.5px] font-medium text-ink-2">{g.group}</p>
                <ul className="mb-1.5">
                  {g.items.map((i) => (
                    <li key={i} className="text-[11.5px] text-muted">
                      {i}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Card>
  );
}

/* ─────────────────── 10. backup ─────────────────── */

function BackupCard({ flash }: { flash: (m: string) => void }) {
  const fileRef = useRef<HTMLInputElement | null>(null);
  const [busy, setBusy] = useState(false);

  return (
    <Card step={10} title="Backup" subtitle="Download everything (chats and settings, never the keys) or put it back." icon={<IconArchive size={18} />}>
      <div className="flex flex-wrap items-center gap-2">
        <a
          href="/api/backup"
          className="flex items-center gap-1.5 rounded-lg border border-line px-3 py-1.5 text-[12.5px] text-ink-2 transition hover:border-accent/40 hover:text-ink"
        >
          <IconDownload size={14} /> Download backup
        </a>
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          disabled={busy}
          className="flex items-center gap-1.5 rounded-lg border border-line px-3 py-1.5 text-[12.5px] text-ink-2 transition hover:border-accent/40 hover:text-ink disabled:opacity-50"
        >
          <IconBolt size={14} /> {busy ? "Restoring…" : "Restore from file"}
        </button>
        <input
          ref={fileRef}
          type="file"
          accept="application/json,.json"
          hidden
          onChange={async (e) => {
            const file = e.target.files?.[0];
            e.target.value = "";
            if (!file) return;
            setBusy(true);
            try {
              const text = await file.text();
              const res = await fetch("/api/backup", {
                method: "POST",
                headers: { "content-type": "application/json" },
                body: text,
              });
              const json = await res.json();
              if (!res.ok) throw new Error(json.error || "Restore failed.");
              flash(`Restored ${json.restoredChats} chats and ${json.restoredMessages} messages.`);
            } catch (err) {
              flash((err as Error).message);
            } finally {
              setBusy(false);
            }
          }}
        />
      </div>
      <p className="mt-2 text-[11.5px] text-muted">API keys are never included in a backup file.</p>
    </Card>
  );
}
