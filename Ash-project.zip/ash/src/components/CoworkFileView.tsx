"use client";

import { useEffect, useMemo, useState } from "react";
import Markdown from "./Markdown";
import { IconCheck, IconCopy, IconDownload, IconPencil, IconTrash, IconX } from "./Icons";
import type { CoworkFile } from "@/lib/cowork/types";

function humanBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

function CsvTable({ text }: { text: string }) {
  const rows = useMemo(() => {
    const out: string[][] = [];
    let row: string[] = [];
    let cell = "";
    let quoted = false;
    for (let i = 0; i < text.length && out.length < 200; i++) {
      const ch = text[i];
      if (quoted) {
        if (ch === '"' && text[i + 1] === '"') {
          cell += '"';
          i++;
        } else if (ch === '"') quoted = false;
        else cell += ch;
      } else if (ch === '"') quoted = true;
      else if (ch === ",") {
        row.push(cell);
        cell = "";
      } else if (ch === "\n") {
        row.push(cell);
        out.push(row);
        row = [];
        cell = "";
      } else if (ch !== "\r") cell += ch;
    }
    if (cell || row.length) {
      row.push(cell);
      out.push(row);
    }
    return out.filter((r) => r.some((c) => c.trim()));
  }, [text]);

  if (!rows.length) return <pre className="whitespace-pre-wrap text-[12.5px]">{text}</pre>;
  const [head, ...body] = rows;
  return (
    <div className="overflow-x-auto scroll-thin">
      <table className="w-full border-collapse text-[12.5px]">
        <thead>
          <tr>
            {head.map((h, i) => (
              <th key={i} className="border border-line bg-surface-2 px-2 py-1.5 text-left font-semibold">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {body.map((r, i) => (
            <tr key={i}>
              {head.map((_, j) => (
                <td key={j} className="border border-line px-2 py-1.5 align-top">
                  {r[j] ?? ""}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function CoworkFileView({
  sessionId,
  file,
  onClose,
  onSaved,
  onDeleted,
}: {
  sessionId: string;
  file: CoworkFile;
  onClose: () => void;
  onSaved: (file: CoworkFile) => void;
  onDeleted: (path: string) => void;
}) {
  const [content, setContent] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const [editing, setEditing] = useState(false);
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    setContent(null);
    setEditing(false);
    setError(null);
    (async () => {
      try {
        const res = await fetch(`/api/cowork/${sessionId}/files?path=${encodeURIComponent(file.path)}`, { cache: "no-store" });
        const data = await res.json();
        if (!alive) return;
        if (!res.ok) throw new Error(data?.error || "Could not open that file.");
        setContent(String(data.file?.content ?? ""));
      } catch (err) {
        if (alive) setError((err as Error).message);
      }
    })();
    return () => {
      alive = false;
    };
  }, [sessionId, file.path, file.updatedAt]);

  const ext = file.path.toLowerCase().split(".").pop() ?? "";
  const isImage = file.kind === "image";
  const isMarkdown = ext === "md" || ext === "markdown";
  const isCsv = ext === "csv";

  const save = async () => {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/cowork/${sessionId}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: "writeFile", path: file.path, content: draft }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || "Could not save that.");
      setContent(draft);
      setEditing(false);
      onSaved(data.file as CoworkFile);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    setBusy(true);
    try {
      await fetch(`/api/cowork/${sessionId}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: "deleteFile", path: file.path }),
      });
      onDeleted(file.path);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex items-center gap-1.5 border-b border-line px-3 py-2">
        <p className="min-w-0 flex-1 truncate text-[13px] font-medium" title={file.path}>
          {file.path}
        </p>
        <span className="shrink-0 text-[11px] text-muted">{humanBytes(file.bytes)}</span>

        {!isImage && content !== null && !editing && (
          <button
            type="button"
            onClick={() => {
              setDraft(content);
              setEditing(true);
            }}
            title="Edit this file"
            aria-label="Edit this file"
            className="rounded p-1.5 text-ink-2 transition hover:bg-surface-2 hover:text-ink"
          >
            <IconPencil size={14} />
          </button>
        )}
        {!isImage && content !== null && (
          <button
            type="button"
            onClick={async () => {
              await navigator.clipboard.writeText(content).catch(() => {});
              setCopied(true);
              setTimeout(() => setCopied(false), 1400);
            }}
            title="Copy the contents"
            aria-label="Copy the contents"
            className="rounded p-1.5 text-ink-2 transition hover:bg-surface-2 hover:text-ink"
          >
            {copied ? <IconCheck size={14} /> : <IconCopy size={14} />}
          </button>
        )}
        <a
          href={`/api/cowork/${sessionId}/files?path=${encodeURIComponent(file.path)}&download=1`}
          download
          title="Download this file"
          aria-label="Download this file"
          className="rounded p-1.5 text-ink-2 transition hover:bg-surface-2 hover:text-ink"
        >
          <IconDownload size={14} />
        </a>
        <button
          type="button"
          onClick={() => void remove()}
          disabled={busy}
          title="Delete this file"
          aria-label="Delete this file"
          className="rounded p-1.5 text-ink-2 transition hover:bg-surface-2 hover:text-danger disabled:opacity-50"
        >
          <IconTrash size={14} />
        </button>
        <button
          type="button"
          onClick={onClose}
          title="Close"
          aria-label="Close the file"
          className="rounded p-1.5 text-ink-2 transition hover:bg-surface-2 hover:text-ink"
        >
          <IconX size={14} />
        </button>
      </div>

      {error && <p className="border-b border-line bg-danger-soft px-3 py-2 text-[12.5px] text-danger">{error}</p>}

      <div className="min-h-0 flex-1 overflow-auto scroll-thin p-3">
        {content === null && !error && <p className="text-[12.5px] text-muted">Opening…</p>}

        {content !== null && editing && (
          <div className="flex h-full min-h-0 flex-col gap-2">
            <textarea
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              spellCheck={false}
              aria-label={`Contents of ${file.path}`}
              className="min-h-0 flex-1 resize-none rounded-lg border border-line bg-surface px-3 py-2 font-mono text-[12.5px] leading-relaxed outline-none focus:border-accent scroll-thin"
            />
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => void save()}
                disabled={busy}
                className="rounded-lg bg-accent px-3 py-1.5 text-[12.5px] font-medium text-accent-ink transition hover:opacity-90 disabled:opacity-50"
              >
                {busy ? "Saving…" : "Save"}
              </button>
              <button
                type="button"
                onClick={() => setEditing(false)}
                className="rounded-lg border border-line px-3 py-1.5 text-[12.5px] transition hover:bg-surface-2"
              >
                Cancel
              </button>
            </div>
          </div>
        )}

        {content !== null && !editing && (
          <>
            {isImage ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={content} alt={file.path} className="mx-auto max-w-full rounded-lg border border-line" />
            ) : isMarkdown ? (
              <div>
                <Markdown content={content} />
              </div>
            ) : isCsv ? (
              <CsvTable text={content} />
            ) : (
              <pre className="whitespace-pre-wrap break-words font-mono text-[12.5px] leading-relaxed">{content}</pre>
            )}
          </>
        )}
      </div>
    </div>
  );
}
