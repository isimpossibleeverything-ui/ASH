"use client";

import { useCallback, useEffect, useRef, useState, type RefObject } from "react";
import type { CoworkEvent, CoworkFile, CoworkSession, CoworkStep, PlanItem, SessionStatus } from "@/lib/cowork/types";
import CoworkFileView from "./CoworkFileView";
import {
  IconAlert,
  IconArchive,
  IconArrowUp,
  IconCheck,
  IconChecklist,
  IconDownload,
  IconFile,
  IconFolder,
  IconPause,
  IconPlay,
  IconPlus,
  IconSpark,
  IconTrash,
  IconX,
} from "./Icons";

export interface CoworkHandle {
  newTask: (goal: string) => Promise<void>;
  run: () => void;
  pause: () => void;
  approve: () => void;
  reject: () => void;
  exportZip: () => void;
  isBusy: () => boolean;
}

const STATUS_LABEL: Record<SessionStatus, string> = {
  idle: "Ready",
  planning: "Making a plan",
  running: "Working",
  paused: "Paused",
  awaiting: "Waiting for you",
  done: "Finished",
  failed: "Stopped",
  cancelled: "Cancelled",
};

const STATUS_TONE: Record<SessionStatus, string> = {
  idle: "bg-surface-2 text-ink-2",
  planning: "bg-accent-soft text-accent",
  running: "bg-accent-soft text-accent",
  paused: "bg-surface-2 text-ink-2",
  awaiting: "bg-warn-soft text-warn",
  done: "bg-ok-soft text-ok",
  failed: "bg-danger-soft text-danger",
  cancelled: "bg-surface-2 text-muted",
};

function humanBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

const EXAMPLES = [
  "Research the top 5 free AI image tools and write a comparison in compare.md",
  "Pakistan ke 5 bare shehron ki aabadi ka CSV banao aur ek chhota summary likho",
  "Write a Python script that checks a list of URLs, run it, and save the output",
];

export default function CoworkPanel({
  handleRef,
  model,
  onNotice,
  onSpeak,
}: {
  handleRef: RefObject<CoworkHandle | null>;
  model: string;
  onNotice: (text: string) => void;
  onSpeak?: (text: string) => void;
}) {
  const [sessions, setSessions] = useState<CoworkSession[]>([]);
  const [active, setActive] = useState<CoworkSession | null>(null);
  const [steps, setSteps] = useState<CoworkStep[]>([]);
  const [files, setFiles] = useState<CoworkFile[]>([]);
  const [openFile, setOpenFile] = useState<CoworkFile | null>(null);
  const [goal, setGoal] = useState("");
  const [steer, setSteer] = useState("");
  const [busy, setBusy] = useState(false);
  const [thinking, setThinking] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [listOpen, setListOpen] = useState(false);
  const [enabled, setEnabled] = useState(true);

  const abortRef = useRef<AbortController | null>(null);
  const feedRef = useRef<HTMLDivElement | null>(null);
  const activeRef = useRef<CoworkSession | null>(null);
  useEffect(() => {
    activeRef.current = active;
  }, [active]);

  /* ── loading ─────────────────────────────────────────────────── */

  const loadSessions = useCallback(async () => {
    try {
      const res = await fetch("/api/cowork", { cache: "no-store" });
      const data = await res.json();
      if (!res.ok) return;
      setSessions(Array.isArray(data.sessions) ? data.sessions : []);
      setEnabled(data.enabled !== false);
    } catch {
      /* offline — the panel still works once the network returns */
    }
  }, []);

  const openSession = useCallback(async (id: string) => {
    setError(null);
    setOpenFile(null);
    try {
      const res = await fetch(`/api/cowork/${id}`, { cache: "no-store" });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || "Could not open that task.");
      setActive(data.session as CoworkSession);
      setSteps(Array.isArray(data.steps) ? data.steps : []);
      setFiles(Array.isArray(data.files) ? data.files : []);
      setListOpen(false);
    } catch (err) {
      setError((err as Error).message);
    }
  }, []);

  useEffect(() => {
    void loadSessions();
  }, [loadSessions]);

  useEffect(() => {
    if (!feedRef.current) return;
    feedRef.current.scrollTop = feedRef.current.scrollHeight;
  }, [steps, thinking]);

  /* ── the live run ────────────────────────────────────────────── */

  const applyEvent = useCallback(
    (event: CoworkEvent) => {
      switch (event.type) {
        case "session":
          setActive(event.session);
          break;
        case "plan":
          setActive((s) => (s ? { ...s, plan: event.plan } : s));
          break;
        case "status":
          setActive((s) => (s ? { ...s, status: event.status } : s));
          break;
        case "step":
          setThinking("");
          setSteps((prev) => (prev.some((s) => s.id === event.step.id) ? prev : [...prev, event.step]));
          break;
        case "step-update":
          setSteps((prev) => prev.map((s) => (s.id === event.id ? { ...s, status: event.status, output: event.output } : s)));
          break;
        case "thinking":
          setThinking(event.text);
          break;
        case "file":
          setFiles((prev) => {
            const rest = prev.filter((f) => f.path !== event.file.path);
            return [...rest, event.file].sort((a, b) => a.path.localeCompare(b.path));
          });
          break;
        case "file-removed":
          setFiles((prev) => prev.filter((f) => f.path !== event.path));
          setOpenFile((f) => (f?.path === event.path ? null : f));
          break;
        case "notice":
          onNotice(event.text);
          break;
        case "approval":
          setActive((s) => (s ? { ...s, status: "awaiting" } : s));
          onNotice("Ash needs your go-ahead before it deletes anything.");
          break;
        case "done":
          setThinking("");
          setActive((s) => (s ? { ...s, summary: event.summary } : s));
          onSpeak?.(event.summary);
          break;
        case "error":
          setThinking("");
          setError(event.message);
          break;
      }
    },
    [onNotice, onSpeak],
  );

  const startRun = useCallback(
    async (sessionId: string, extra?: { steer?: string; restart?: boolean; goal?: string }) => {
      if (abortRef.current) return;
      const controller = new AbortController();
      abortRef.current = controller;
      setBusy(true);
      setError(null);
      try {
        const res = await fetch(`/api/cowork/${sessionId}/run`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify(extra ?? {}),
          signal: controller.signal,
        });
        if (!res.ok || !res.body) {
          const data = await res.json().catch(() => ({}));
          throw new Error(data?.error || "Could not start that task.");
        }
        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        for (;;) {
          const { value, done } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const parts = buffer.split("\n\n");
          buffer = parts.pop() ?? "";
          for (const part of parts) {
            const line = part.split("\n").find((l) => l.startsWith("data:"));
            if (!line) continue;
            try {
              applyEvent(JSON.parse(line.slice(5).trim()) as CoworkEvent);
            } catch {
              /* a partial frame — the next chunk completes it */
            }
          }
        }
      } catch (err) {
        if ((err as Error).name !== "AbortError") setError((err as Error).message);
      } finally {
        abortRef.current = null;
        setBusy(false);
        setThinking("");
        void loadSessions();
        const id = activeRef.current?.id;
        if (id) {
          const res = await fetch(`/api/cowork/${id}`, { cache: "no-store" }).catch(() => null);
          const data = await res?.json().catch(() => null);
          if (data?.session) {
            setActive(data.session as CoworkSession);
            setSteps(Array.isArray(data.steps) ? data.steps : []);
            setFiles(Array.isArray(data.files) ? data.files : []);
          }
        }
      }
    },
    [applyEvent, loadSessions],
  );

  const createTask = useCallback(
    async (text: string) => {
      const trimmed = text.trim();
      if (!trimmed) return;
      setError(null);
      try {
        const res = await fetch("/api/cowork", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ goal: trimmed, model: model || undefined }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data?.error || "Could not create that task.");
        const session = data.session as CoworkSession;
        setActive(session);
        setSteps([]);
        setFiles([]);
        setOpenFile(null);
        setGoal("");
        setListOpen(false);
        await loadSessions();
        void startRun(session.id);
      } catch (err) {
        setError((err as Error).message);
      }
    },
    [loadSessions, model, startRun],
  );

  const patch = useCallback(
    async (body: Record<string, unknown>) => {
      const id = activeRef.current?.id;
      if (!id) return null;
      const res = await fetch(`/api/cowork/${id}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await res.json().catch(() => ({}));
      if (data?.session) setActive(data.session as CoworkSession);
      return data;
    },
    [],
  );

  const pause = useCallback(() => {
    abortRef.current?.abort();
    void patch({ action: "pause" });
  }, [patch]);

  const awaitingStep = steps.find((s) => s.status === "awaiting");

  const decide = useCallback(
    async (decision: "approve" | "reject") => {
      const step = steps.find((s) => s.status === "awaiting");
      const id = activeRef.current?.id;
      if (!step || !id) return;
      await patch({ action: decision, stepId: step.id });
      setSteps((prev) => prev.map((s) => (s.id === step.id ? { ...s, output: decision === "approve" ? "Approved — carrying on." : "Refused." } : s)));
      void startRun(id);
    },
    [patch, startRun, steps],
  );

  const removeTask = useCallback(
    async (id: string) => {
      if (abortRef.current && activeRef.current?.id === id) abortRef.current.abort();
      await fetch(`/api/cowork/${id}`, { method: "DELETE" }).catch(() => {});
      if (activeRef.current?.id === id) {
        setActive(null);
        setSteps([]);
        setFiles([]);
        setOpenFile(null);
      }
      await loadSessions();
    },
    [loadSessions],
  );

  const exportZip = useCallback(() => {
    const id = activeRef.current?.id;
    if (!id) return;
    // an anchor click keeps the page where it is and still triggers the download
    const a = document.createElement("a");
    a.href = `/api/cowork/${id}/export`;
    a.download = "";
    document.body.appendChild(a);
    a.click();
    a.remove();
  }, []);

  /* ── the voice/keyboard control surface ──────────────────────── */

  useEffect(() => {
    handleRef.current = {
      newTask: (g: string) => createTask(g),
      run: () => {
        const id = activeRef.current?.id;
        if (id && !abortRef.current) void startRun(id);
      },
      pause,
      approve: () => void decide("approve"),
      reject: () => void decide("reject"),
      exportZip,
      isBusy: () => !!abortRef.current,
    };
    return () => {
      handleRef.current = null;
    };
  }, [createTask, decide, exportZip, handleRef, pause, startRun]);

  useEffect(() => () => abortRef.current?.abort(), []);

  /* ── render ──────────────────────────────────────────────────── */

  const plan: PlanItem[] = active?.plan ?? [];
  const status = active?.status ?? "idle";

  return (
    <div className="flex min-h-0 flex-1">
      {/* task list */}
      <aside
        className={`${
          listOpen ? "absolute inset-y-0 left-0 z-30 w-64 shadow-xl" : "hidden"
        } flex-col border-r border-line bg-surface md:relative md:z-auto md:flex md:w-56 md:shadow-none`}
      >
        <div className="flex items-center gap-1.5 border-b border-line px-3 py-2">
          <p className="flex-1 text-[12px] font-semibold uppercase tracking-wide text-muted">Tasks</p>
          <button
            type="button"
            onClick={() => {
              setActive(null);
              setSteps([]);
              setFiles([]);
              setOpenFile(null);
              setListOpen(false);
            }}
            title="New task"
            aria-label="New task"
            className="rounded p-1 text-ink-2 transition hover:bg-surface-2 hover:text-ink"
          >
            <IconPlus size={14} />
          </button>
          <button
            type="button"
            onClick={() => setListOpen(false)}
            aria-label="Close the task list"
            className="rounded p-1 text-ink-2 transition hover:bg-surface-2 md:hidden"
          >
            <IconX size={14} />
          </button>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto scroll-thin p-1.5">
          {!sessions.length && <p className="px-2 py-3 text-[12.5px] text-muted">No tasks yet.</p>}
          {sessions.map((s) => (
            <div
              key={s.id}
              className={`group flex items-center gap-1 rounded-lg px-2 py-1.5 transition ${
                active?.id === s.id ? "bg-accent-soft" : "hover:bg-surface-2"
              }`}
            >
              <button
                type="button"
                onClick={() => void openSession(s.id)}
                className="min-w-0 flex-1 text-left"
                title={s.goal}
              >
                <span className={`block truncate text-[13px] ${active?.id === s.id ? "font-medium text-accent" : ""}`}>{s.title}</span>
                <span className="block truncate text-[11px] text-muted">{STATUS_LABEL[s.status]}</span>
              </button>
              <button
                type="button"
                onClick={() => void removeTask(s.id)}
                aria-label={`Delete ${s.title}`}
                title="Delete this task"
                className="rounded p-1 text-muted opacity-0 transition hover:text-danger group-hover:opacity-100"
              >
                <IconTrash size={13} />
              </button>
            </div>
          ))}
        </div>
      </aside>

      {/* the work itself */}
      <div className="flex min-w-0 flex-1 flex-col">
        {!enabled && (
          <p className="border-b border-line bg-warn-soft px-4 py-2 text-[12.5px] text-warn">
            Cowork is switched off in the Control Panel. Turn it back on in card 10.
          </p>
        )}

        {!active ? (
          <div className="flex min-h-0 flex-1 flex-col items-center justify-center overflow-y-auto scroll-thin px-5 py-8 scroll-thin">
            <div className="w-full max-w-xl">
              <div className="mb-5 flex items-center gap-2.5">
                <span className="grid h-9 w-9 place-items-center rounded-xl bg-accent-soft text-accent">
                  <IconSpark size={18} />
                </span>
                <div>
                  <h2 className="font-serif text-[19px] font-semibold">Cowork</h2>
                  <p className="text-[12.5px] text-muted">Hand over a job, not a question. Ash plans it, does it, and gives you the files.</p>
                </div>
              </div>

              <label htmlFor="cowork-goal" className="sr-only">
                What should Ash do?
              </label>
              <textarea
                id="cowork-goal"
                value={goal}
                onChange={(e) => setGoal(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) void createTask(goal);
                }}
                rows={4}
                placeholder="e.g. Research free AI image tools and write a comparison in compare.md"
                className="w-full resize-none rounded-xl border border-line bg-surface px-3.5 py-3 text-[14px] leading-relaxed outline-none transition focus:border-accent placeholder:text-muted scroll-thin"
              />
              <div className="mt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => void createTask(goal)}
                  disabled={!goal.trim() || !enabled}
                  className="flex items-center gap-1.5 rounded-lg bg-accent px-3.5 py-2 text-[13px] font-medium text-accent-ink transition hover:opacity-90 disabled:opacity-40"
                >
                  <IconArrowUp size={14} /> Start working
                </button>
                <span className="text-[11.5px] text-muted">⌘↵ also starts it</span>
              </div>

              <p className="mt-6 mb-2 text-[11.5px] font-semibold uppercase tracking-wide text-muted">Try one of these</p>
              <div className="flex flex-col gap-1.5">
                {EXAMPLES.map((e) => (
                  <button
                    key={e}
                    type="button"
                    onClick={() => setGoal(e)}
                    className="rounded-lg border border-line px-3 py-2 text-left text-[12.5px] text-ink-2 transition hover:border-accent hover:text-ink"
                  >
                    {e}
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <>
            <div className="flex items-center gap-2 border-b border-line px-3 py-2">
              <button
                type="button"
                onClick={() => setListOpen(true)}
                aria-label="Show the task list"
                className="rounded p-1.5 text-ink-2 transition hover:bg-surface-2 md:hidden"
              >
                <IconFolder size={15} />
              </button>
              <h2 className="min-w-0 flex-1 truncate text-[14px] font-medium" title={active.goal}>
                {active.title}
              </h2>
              <span className={`shrink-0 rounded-full px-2 py-0.5 text-[11px] font-medium ${STATUS_TONE[status]}`}>
                {busy && status === "running" ? "Working…" : STATUS_LABEL[status]}
              </span>

              {busy ? (
                <button
                  type="button"
                  onClick={pause}
                  title="Pause"
                  aria-label="Pause the task"
                  className="rounded-lg p-1.5 text-ink-2 transition hover:bg-surface-2 hover:text-ink"
                >
                  <IconPause size={15} />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => void startRun(active.id)}
                  title={status === "done" ? "Run it again" : "Continue"}
                  aria-label={status === "done" ? "Run it again" : "Continue the task"}
                  className="rounded-lg p-1.5 text-ink-2 transition hover:bg-surface-2 hover:text-ink"
                >
                  <IconPlay size={15} />
                </button>
              )}
              {!!files.length && (
                <button
                  type="button"
                  onClick={exportZip}
                  title="Download everything as a zip"
                  aria-label="Download everything as a zip"
                  className="rounded-lg p-1.5 text-ink-2 transition hover:bg-surface-2 hover:text-ink"
                >
                  <IconArchive size={15} />
                </button>
              )}
            </div>

            {error && (
              <div className="flex items-center gap-2 border-b border-line bg-danger-soft px-4 py-2 text-[12.5px] text-danger">
                <IconAlert size={14} />
                <p className="flex-1">{error}</p>
                <button type="button" onClick={() => setError(null)} aria-label="Dismiss" className="rounded p-1">
                  <IconX size={13} />
                </button>
              </div>
            )}

            {awaitingStep && (
              <div className="border-b border-line bg-warn-soft px-4 py-3">
                <p className="text-[13px] font-medium text-warn">
                  Ash wants to {awaitingStep.tool.replace(/_/g, " ")}
                  {awaitingStep.args.path ? ` — ${awaitingStep.args.path}` : ""}. May it?
                </p>
                <div className="mt-2 flex gap-2">
                  <button
                    type="button"
                    onClick={() => void decide("approve")}
                    className="flex items-center gap-1.5 rounded-lg bg-accent px-3 py-1.5 text-[12.5px] font-medium text-accent-ink transition hover:opacity-90"
                  >
                    <IconCheck size={13} /> Allow
                  </button>
                  <button
                    type="button"
                    onClick={() => void decide("reject")}
                    className="rounded-lg border border-line bg-surface px-3 py-1.5 text-[12.5px] transition hover:bg-surface-2"
                  >
                    No, find another way
                  </button>
                </div>
              </div>
            )}

            <div className="flex min-h-0 flex-1">
              {/* plan + step feed */}
              <div ref={feedRef} className="min-h-0 flex-1 overflow-y-auto scroll-thin px-4 py-3" role="log" aria-label="What Ash is doing" aria-busy={busy}>
                <p className="mb-3 rounded-lg border border-line bg-surface px-3 py-2 text-[12.5px] leading-relaxed text-ink-2">{active.goal}</p>

                {!!plan.length && (
                  <section className="mb-4">
                    <p className="mb-1.5 flex items-center gap-1.5 text-[11.5px] font-semibold uppercase tracking-wide text-muted">
                      <IconChecklist size={13} /> Plan
                    </p>
                    <ul className="flex flex-col gap-1">
                      {plan.map((p) => (
                        <li key={p.id} className="flex items-start gap-2 text-[13px]">
                          <span
                            className={`mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full border text-[9px] ${
                              p.status === "done"
                                ? "border-ok bg-ok text-accent-ink"
                                : p.status === "active"
                                  ? "border-accent text-accent"
                                  : p.status === "skipped"
                                    ? "border-line text-muted"
                                    : "border-line text-transparent"
                            }`}
                          >
                            {p.status === "done" ? "✓" : p.status === "skipped" ? "–" : "•"}
                          </span>
                          <span className={p.status === "done" ? "text-muted line-through" : p.status === "active" ? "font-medium" : ""}>{p.title}</span>
                        </li>
                      ))}
                    </ul>
                  </section>
                )}

                <p className="mb-1.5 text-[11.5px] font-semibold uppercase tracking-wide text-muted">Steps</p>
                <ol className="flex flex-col gap-2">
                  {steps.map((s) => (
                    <li key={s.id} className="rounded-lg border border-line bg-surface px-3 py-2">
                      <div className="flex items-center gap-2">
                        <span
                          className={`grid h-5 w-5 shrink-0 place-items-center rounded-md text-[10px] font-semibold ${
                            s.status === "ok"
                              ? "bg-ok-soft text-ok"
                              : s.status === "error"
                                ? "bg-danger-soft text-danger"
                                : s.status === "awaiting"
                                  ? "bg-warn-soft text-warn"
                                  : s.status === "skipped"
                                    ? "bg-surface-2 text-muted"
                                    : "bg-accent-soft text-accent"
                          }`}
                        >
                          {s.seq}
                        </span>
                        <span className="min-w-0 flex-1 truncate text-[13px] font-medium">{s.title}</span>
                        <code className="shrink-0 rounded bg-surface-2 px-1.5 py-0.5 text-[10.5px] text-muted">{s.tool}</code>
                      </div>
                      {!!s.output.trim() && (
                        <pre className="mt-1.5 max-h-44 overflow-auto whitespace-pre-wrap break-words rounded bg-surface-2 px-2 py-1.5 font-mono text-[11.5px] leading-relaxed text-ink-2 scroll-thin">
                          {s.output.trim()}
                        </pre>
                      )}
                    </li>
                  ))}
                  {!steps.length && !thinking && <li className="text-[12.5px] text-muted">Nothing has run yet. Press play to start.</li>}
                  {!!thinking && (
                    <li className="flex items-center gap-2 px-1 text-[12.5px] text-muted">
                      <span className="inline-flex gap-1">
                        <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-accent" />
                        <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-accent [animation-delay:150ms]" />
                        <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-accent [animation-delay:300ms]" />
                      </span>
                      {thinking}
                    </li>
                  )}
                </ol>

                {!!active.summary && (
                  <div className="mt-4 rounded-lg border border-line bg-ok-soft px-3 py-2.5">
                    <p className="mb-1 text-[11.5px] font-semibold uppercase tracking-wide text-ok">Result</p>
                    <p className="whitespace-pre-wrap text-[13px] leading-relaxed">{active.summary}</p>
                  </div>
                )}

                <div className="mt-4 flex gap-2">
                  <label htmlFor="cowork-steer" className="sr-only">
                    Tell Ash something while it works
                  </label>
                  <input
                    id="cowork-steer"
                    value={steer}
                    onChange={(e) => setSteer(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key !== "Enter" || !steer.trim()) return;
                      const text = steer.trim();
                      setSteer("");
                      if (abortRef.current) {
                        abortRef.current.abort();
                        setTimeout(() => void startRun(active.id, { steer: text }), 350);
                      } else {
                        void startRun(active.id, { steer: text });
                      }
                    }}
                    placeholder="Change of plan? Type it here and press Enter…"
                    className="flex-1 rounded-lg border border-line bg-surface px-3 py-2 text-[13px] outline-none transition focus:border-accent placeholder:text-muted"
                  />
                </div>
              </div>

              {/* files */}
              <aside className="hidden w-72 shrink-0 flex-col border-l border-line lg:flex">
                {openFile ? (
                  <CoworkFileView
                    sessionId={active.id}
                    file={openFile}
                    onClose={() => setOpenFile(null)}
                    onSaved={(f) => setFiles((prev) => prev.map((x) => (x.path === f.path ? f : x)))}
                    onDeleted={(p) => {
                      setFiles((prev) => prev.filter((x) => x.path !== p));
                      setOpenFile(null);
                    }}
                  />
                ) : (
                  <>
                    <div className="flex items-center gap-1.5 border-b border-line px-3 py-2">
                      <IconFolder size={14} />
                      <p className="flex-1 text-[12px] font-semibold uppercase tracking-wide text-muted">Files</p>
                      {!!files.length && (
                        <button
                          type="button"
                          onClick={exportZip}
                          title="Download all as a zip"
                          aria-label="Download all as a zip"
                          className="rounded p-1 text-ink-2 transition hover:bg-surface-2 hover:text-ink"
                        >
                          <IconDownload size={13} />
                        </button>
                      )}
                    </div>
                    <div className="min-h-0 flex-1 overflow-y-auto scroll-thin p-1.5">
                      {!files.length && <p className="px-2 py-3 text-[12.5px] text-muted">Nothing yet. Files appear here as Ash makes them.</p>}
                      {files.map((f) => (
                        <button
                          key={f.path}
                          type="button"
                          onClick={() => setOpenFile(f)}
                          className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left transition hover:bg-surface-2"
                        >
                          <IconFile size={14} />
                          <span className="min-w-0 flex-1 truncate text-[12.5px]">{f.path}</span>
                          <span className="shrink-0 text-[10.5px] text-muted">{humanBytes(f.bytes)}</span>
                        </button>
                      ))}
                    </div>
                  </>
                )}
              </aside>
            </div>

            {/* files on narrow screens */}
            {!!files.length && (
              <div className="flex gap-1.5 overflow-x-auto border-t border-line px-3 py-2 scroll-thin lg:hidden">
                {files.map((f) => (
                  <button
                    key={f.path}
                    type="button"
                    onClick={() => setOpenFile(f)}
                    className="flex shrink-0 items-center gap-1.5 rounded-lg border border-line px-2.5 py-1.5 text-[12px] transition hover:bg-surface-2"
                  >
                    <IconFile size={12} /> {f.path}
                  </button>
                ))}
              </div>
            )}

            {openFile && (
              <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/40 p-4 lg:hidden" role="dialog" aria-label={openFile.path}>
                <div className="flex h-[80vh] w-full max-w-lg flex-col overflow-hidden rounded-xl border border-line bg-paper">
                  <CoworkFileView
                    sessionId={active.id}
                    file={openFile}
                    onClose={() => setOpenFile(null)}
                    onSaved={(f) => setFiles((prev) => prev.map((x) => (x.path === f.path ? f : x)))}
                    onDeleted={(p) => {
                      setFiles((prev) => prev.filter((x) => x.path !== p));
                      setOpenFile(null);
                    }}
                  />
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
