"use client";

import { IconSpark } from "./Icons";

const SUGGESTIONS = [
  { title: "Explain a hard idea", prompt: "Explain how vector embeddings work, using an analogy a designer would get." },
  { title: "Write some code", prompt: "Write a TypeScript debounce hook for React with cancel and flush, fully typed." },
  { title: "Plan something", prompt: "Draft a 4-week plan to ship a SaaS MVP solo. Give me weekly milestones." },
  { title: "Improve my writing", prompt: "Rewrite this to be tighter and warmer, then explain each change:" },
];

export default function EmptyState({ onPick }: { onPick: (prompt: string) => void }) {
  return (
    <div className="mx-auto flex max-w-3xl flex-col items-center px-4 py-10 text-center">
      <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-line bg-surface text-accent shadow-[var(--shadow)]">
        <IconSpark size={22} />
      </div>
      <h1 className="mt-5 font-serif text-[2rem] font-semibold tracking-tight sm:text-[2.35rem]">What should we dig into?</h1>
      <p className="mt-2 max-w-xl text-[14px] leading-relaxed text-muted">
        Streaming answers, saved history, markdown and code — pick a starting point or just type below.
      </p>

      <div className="mt-8 grid w-full grid-cols-1 gap-2.5 text-left sm:grid-cols-2">
        {SUGGESTIONS.map((s) => (
          <button
            key={s.title}
            type="button"
            onClick={() => onPick(s.prompt)}
            className="rounded-xl border border-line bg-surface p-3.5 transition hover:-translate-y-px hover:border-accent/40 hover:shadow-[var(--shadow)]"
          >
            <p className="text-[13.5px] font-semibold">{s.title}</p>
            <p className="mt-1 line-clamp-2 text-[12.5px] leading-relaxed text-muted">{s.prompt}</p>
          </button>
        ))}
      </div>
    </div>
  );
}
