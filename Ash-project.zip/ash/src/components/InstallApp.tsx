"use client";

import { useEffect, useState } from "react";
import { canInstall, initPwa, isStandalone, needsManualInstall, onInstallChange, platform, promptInstall } from "@/lib/pwa";

/** Mounted once in the root layout: registers the worker, listens for the prompt. */
export function PwaBoot() {
  useEffect(() => {
    initPwa();
  }, []);
  return null;
}

/** The row shown in Settings. Never a dead button — if there is no prompt to
 *  fire, it shows the actual steps for that device instead. */
export default function InstallApp() {
  const [, bump] = useState(0);
  const [mounted, setMounted] = useState(false);
  const [busy, setBusy] = useState(false);
  const [said, setSaid] = useState<string | null>(null);

  useEffect(() => {
    setMounted(true);
    return onInstallChange(() => bump((n) => n + 1));
  }, []);

  if (!mounted) return null;

  if (isStandalone()) {
    return (
      <p className="rounded-lg border border-line bg-ok-soft px-3 py-2 text-[12.5px] text-ok">
        Ash is installed — you are using it as an app right now.
      </p>
    );
  }

  const where = platform();

  if (canInstall()) {
    return (
      <div className="flex flex-col gap-1.5">
        <button
          type="button"
          disabled={busy}
          onClick={async () => {
            setBusy(true);
            const outcome = await promptInstall();
            setBusy(false);
            setSaid(
              outcome === "installed"
                ? "Installed. Look for Ash with your other apps."
                : outcome === "dismissed"
                  ? "No problem — you can install it later from here."
                  : "Your browser did not offer an install this time.",
            );
          }}
          className="rounded-lg bg-accent px-3.5 py-2 text-[13px] font-medium text-accent-ink transition hover:opacity-90 disabled:opacity-50"
        >
          {busy ? "Installing…" : "Install Ash as an app"}
        </button>
        <p className="text-[12px] text-muted">
          {where === "desktop"
            ? "It gets its own window and its own icon, with no browser bars."
            : "It gets its own icon on your home screen and opens full screen."}
        </p>
        {said && <p className="text-[12px] text-ink-2">{said}</p>}
      </div>
    );
  }

  if (needsManualInstall()) {
    return (
      <div className="rounded-lg border border-line px-3 py-2.5 text-[12.5px] text-ink-2">
        <p className="mb-1 font-medium text-ink">Add Ash to your home screen</p>
        <ol className="list-decimal space-y-0.5 pl-4 text-muted">
          <li>Tap the Share button at the bottom of Safari.</li>
          <li>Scroll down and tap <span className="text-ink">Add to Home Screen</span>.</li>
          <li>Tap <span className="text-ink">Add</span>. Ash then opens full screen like any other app.</li>
        </ol>
      </div>
    );
  }

  return (
    <p className="rounded-lg border border-line px-3 py-2.5 text-[12.5px] text-muted">
      {where === "desktop"
        ? "To install: open the menu in Chrome or Edge and choose “Install Ash”, or use the install icon in the address bar."
        : "To install: open your browser menu and choose “Install app” or “Add to Home screen”."}{" "}
      Installing needs the site to be served over HTTPS.
    </p>
  );
}
