"use client";

import { useState } from "react";
import { IconLock } from "./Icons";

export default function LoginGate({ onSignedIn }: { onSignedIn: (email: string) => void }) {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/auth", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: mode === "login" ? "login" : "signup", email, password }),
      });
      const data = await res.json();
      if (!res.ok) setError(data.error || "Could not sign you in.");
      else onSignedIn(data.email || email);
    } catch {
      setError("Could not reach the server.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex min-h-dvh items-center justify-center bg-paper px-4">
      <form onSubmit={submit} className="w-full max-w-sm rounded-2xl border border-line bg-surface p-6 shadow-[var(--shadow)]">
        <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-accent text-accent-ink">
          <IconLock size={18} />
        </div>
        <h1 className="mt-4 font-serif text-[22px] font-semibold">{mode === "login" ? "Sign in" : "Create an account"}</h1>
        <p className="mt-1 text-[13px] text-muted">This chat is set to members only right now.</p>

        <label className="mt-5 block text-[12.5px] font-medium">Email</label>
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="mt-1 w-full rounded-xl border border-line bg-surface-2 px-3 py-2 text-[14px] outline-none transition focus:border-accent/40"
          placeholder="you@example.com"
        />

        <label className="mt-3 block text-[12.5px] font-medium">Password</label>
        <input
          type="password"
          required
          minLength={6}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="mt-1 w-full rounded-xl border border-line bg-surface-2 px-3 py-2 text-[14px] outline-none transition focus:border-accent/40"
          placeholder="At least 6 characters"
        />

        {error && <p className="mt-3 rounded-xl border border-danger/35 bg-danger/8 px-3 py-2 text-[12.5px] text-danger">{error}</p>}

        <button
          type="submit"
          disabled={busy}
          className="mt-4 w-full rounded-xl bg-accent px-3 py-2.5 text-[14px] font-medium text-accent-ink transition hover:opacity-90 disabled:opacity-60"
        >
          {busy ? "Please wait…" : mode === "login" ? "Sign in" : "Create account"}
        </button>

        <button
          type="button"
          onClick={() => setMode(mode === "login" ? "signup" : "login")}
          className="mt-3 w-full text-[12.5px] text-muted transition hover:text-ink"
        >
          {mode === "login" ? "No account yet? Create one" : "Already have an account? Sign in"}
        </button>
      </form>
    </div>
  );
}
