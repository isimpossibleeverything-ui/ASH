"use client";

import { memo } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeHighlight from "rehype-highlight";
import CodeBlock from "./CodeBlock";
import VideoClip from "./VideoClip";

function nodeText(node: any): string {
  if (!node) return "";
  if (node.type === "text") return String(node.value ?? "");
  if (Array.isArray(node.children)) return node.children.map(nodeText).join("");
  return "";
}

function Markdown({
  content,
  onPreview,
}: {
  content: string;
  onPreview?: (code: string, language: string) => void;
}) {
  return (
    <ReactMarkdown
      remarkPlugins={[remarkGfm]}
      rehypePlugins={[[rehypeHighlight, { detect: true, ignoreMissing: true }]]}
      components={{
        pre({ node, children }) {
          const codeEl = (node as any)?.children?.find((c: any) => c.tagName === "code");
          const classes: string[] = Array.isArray(codeEl?.properties?.className)
            ? codeEl.properties.className.map(String)
            : [];
          const language = (classes.find((c) => c.startsWith("language-")) ?? "").replace("language-", "");
          const code = nodeText(codeEl).replace(/\n$/, "");

          // Clips are persisted as a fenced ash-clip block so they survive a reload.
          if (language === "ash-clip") {
            try {
              const clip = JSON.parse(code) as { frames?: string[]; fps?: number; prompt?: string; mode?: "frames" | "motion" };
              if (Array.isArray(clip.frames) && clip.frames.length) {
                return <VideoClip frames={clip.frames} fps={clip.fps ?? 2} prompt={clip.prompt} mode={clip.mode ?? "frames"} />;
              }
            } catch {
              /* fall through and show it as code */
            }
          }

          return (
            <CodeBlock code={code} language={language} onPreview={onPreview}>
              {children}
            </CodeBlock>
          );
        },
        table({ children }) {
          return (
            <div className="table-wrap">
              <table>{children}</table>
            </div>
          );
        },
        a({ href, children }) {
          return (
            <a href={href} target="_blank" rel="noopener noreferrer nofollow">
              {children}
            </a>
          );
        },
        img({ src, alt }) {
          // eslint-disable-next-line @next/next/no-img-element
          return <img src={typeof src === "string" ? src : ""} alt={alt || ""} loading="lazy" />;
        },
      }}
    >
      {content}
    </ReactMarkdown>
  );
}

export default memo(Markdown);
