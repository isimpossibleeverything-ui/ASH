"use client";

import { useEffect, useRef, useState } from "react";
import Markdown from "./Markdown";
import VideoClip from "./VideoClip";
import { IconCheck, IconCopy, IconLink, IconPencil, IconRefresh, IconStop, IconVolume, IconX } from "./Icons";

export interface UiMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  model?: string | null;
  images?: string[];
  frames?: string[];
  clipMode?: "frames" | "motion";
  clipPrompt?: string;
  createdAt?: number;
  sources?: { title: string; url: string; source?: string }[];
}

interface Props {
  message: UiMessage;
  streaming?: boolean;
  modelLabel?: string;
  onRegenerate?: (id: string) => void;
  onEditResend?: (id: string, text: string) => void;
  onPreview?: (code: string, language: string) => void;
  onSpeak?: (id: string, text: string) => void;
  speaking?: boolean;
}

function CopyButton({ text, label = "Copy" }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(text);
          setCopied(true);
          setTimeout(() => setCopied(false), 1500);
        } catch {
          /* clipboard blocked */
        }
      }}
      className="flex items-center gap-1.5 rounded-lg px-1.5 py-1 text-[11.5px] text-muted transition hover:bg-surface-2 hover:text-ink"
      title={label}
    >
      {copied ? <IconCheck size={13} /> : <IconCopy size={13} />}
      <span>{copied ? "Copied" : label}</span>
    </button>
  );
}

export default function MessageItem({ message, streaming, modelLabel, onRegenerate, onEditResend, onPreview, onSpeak, speaking }: Props) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(message.content);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  useEffect(() => {
    if (editing && textareaRef.current) {
      const el = textareaRef.current;
      el.focus();
      el.setSelectionRange(el.value.length, el.value.length);
      el.style.height = "auto";
      el.style.height = `${Math.min(240, el.scrollHeight)}px`;
    }
  }, [editing]);

  if (message.role === "user") {
    const clean = message.content.replace(/\n\n_\[\d+ images? attached\]_$/, "");
    return (
      <div className="group flex flex-col items-end gap-1.5">
        {!!message.images?.length && (
          <div className="flex max-w-[85%] flex-wrap justify-end gap-2">
            {message.images.map((src, i) => (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                key={i}
                src={src}
                alt={`Attachment ${i + 1}`}
                className="h-24 w-24 rounded-xl border border-line object-cover"
              />
            ))}
          </div>
        )}

        {editing ? (
          <div className="w-full max-w-[85%] rounded-2xl border border-accent/40 bg-surface p-2">
            <textarea
              ref={textareaRef}
              dir="auto"
              value={draft}
              onChange={(e) => {
                setDraft(e.target.value);
                e.target.style.height = "auto";
                e.target.style.height = `${Math.min(240, e.target.scrollHeight)}px`;
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  if (draft.trim()) {
                    setEditing(false);
                    onEditResend?.(message.id, draft.trim());
                  }
                } else if (e.key === "Escape") {
                  e.preventDefault();
                  setDraft(message.content);
                  setEditing(false);
                }
              }}
              className="w-full resize-none bg-transparent px-2 py-1 text-[14.5px] leading-relaxed outline-none"
              rows={1}
            />
            <div className="flex items-center justify-end gap-1 px-1 pt-1 text-[11px] text-muted">
              <span className="mr-auto">Enter to resend · Esc to cancel</span>
              <button
                type="button"
                onClick={() => {
                  setDraft(message.content);
                  setEditing(false);
                }}
                className="rounded-lg px-2 py-1 transition hover:bg-surface-2 hover:text-ink"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  if (!draft.trim()) return;
                  setEditing(false);
                  onEditResend?.(message.id, draft.trim());
                }}
                className="rounded-lg bg-accent px-2.5 py-1 text-accent-ink transition hover:opacity-90"
              >
                Resend
              </button>
            </div>
          </div>
        ) : (
          <div
            dir="auto"
            className="max-w-[85%] whitespace-pre-wrap rounded-2xl border border-line bg-surface-2 px-4 py-2.5 text-[14.8px] leading-relaxed"
          >
            {clean}
          </div>
        )}

        {!editing && (
          <div className="flex items-center gap-0.5 opacity-0 transition group-focus-within:opacity-100 group-hover:opacity-100">
            <CopyButton text={clean} />
            {onEditResend && (
              <button
                type="button"
                onClick={() => {
                  setDraft(clean);
                  setEditing(true);
                }}
                className="flex items-center gap-1.5 rounded-lg px-1.5 py-1 text-[11.5px] text-muted transition hover:bg-surface-2 hover:text-ink"
              >
                <IconPencil size={13} /> Edit
              </button>
            )}
          </div>
        )}
      </div>
    );
  }

  const empty = !message.content.trim();

  return (
    <div className="group">
      {!!message.sources?.length && (
        <div className="mb-2 flex flex-wrap items-center gap-1.5 text-[11.5px]">
          <span className="flex items-center gap-1 rounded-full border border-line bg-surface-2 px-2 py-0.5 text-muted">
            <IconLink size={11} /> Searched the web
          </span>
          {message.sources.slice(0, 4).map((s, i) => (
            <a
              key={i}
              href={s.url}
              target="_blank"
              rel="noopener noreferrer nofollow"
              className="max-w-[220px] truncate rounded-full border border-line px-2 py-0.5 text-muted transition hover:border-accent/40 hover:text-accent"
              title={s.title}
            >
              {s.title || new URL(s.url).hostname}
            </a>
          ))}
        </div>
      )}

      {!!message.frames?.length && (
        <VideoClip frames={message.frames} mode={message.clipMode ?? "frames"} prompt={message.clipPrompt} />
      )}

      {empty && streaming ? (
        <div className="flex items-center gap-1 py-1" aria-label="Thinking">
          <span className="dot h-1.5 w-1.5 rounded-full bg-muted" />
          <span className="dot h-1.5 w-1.5 rounded-full bg-muted" />
          <span className="dot h-1.5 w-1.5 rounded-full bg-muted" />
        </div>
      ) : (
        <div dir="auto" className={`prose-chat ${streaming ? "caret" : ""}`}>
          <Markdown content={message.content} onPreview={onPreview} />
        </div>
      )}

      {!streaming && !empty && (
        <div className="mt-2 flex items-center gap-0.5 opacity-0 transition group-focus-within:opacity-100 group-hover:opacity-100">
          <CopyButton text={message.content} />
          {onSpeak && (
            <button
              type="button"
              onClick={() => onSpeak(message.id, message.content)}
              className={`flex items-center gap-1.5 rounded-lg px-1.5 py-1 text-[11.5px] transition hover:bg-surface-2 ${
                speaking ? "text-accent" : "text-muted hover:text-ink"
              }`}
              title={speaking ? "Stop reading" : "Read aloud"}
            >
              {speaking ? <IconStop size={13} /> : <IconVolume size={13} />}
              <span>{speaking ? "Stop" : "Read aloud"}</span>
            </button>
          )}
          {onRegenerate && (
            <button
              type="button"
              onClick={() => onRegenerate(message.id)}
              className="flex items-center gap-1.5 rounded-lg px-1.5 py-1 text-[11.5px] text-muted transition hover:bg-surface-2 hover:text-ink"
            >
              <IconRefresh size={13} /> Regenerate
            </button>
          )}
          {modelLabel && <span className="ml-1 text-[11px] text-muted">{modelLabel}</span>}
          {!!message.createdAt && (
            <time dateTime={new Date(message.createdAt).toISOString()} className="text-[11px] text-muted">
              {new Date(message.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
            </time>
          )}
        </div>
      )}
    </div>
  );
}

export function ErrorBlock({ message, onRetry, onDismiss }: { message: string; onRetry?: () => void; onDismiss: () => void }) {
  return (
    <div className="flex items-start gap-3 rounded-xl border border-danger/35 bg-danger/8 px-4 py-3">
      <span className="mt-0.5 text-danger">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
          <path d="M12 4.5 21 19.5H3L12 4.5Z" />
          <path d="M12 10v4M12 17h.01" />
        </svg>
      </span>
      <div className="flex-1">
        <p className="text-[13.5px] font-semibold text-danger">Request failed</p>
        <p className="mt-0.5 text-[13.5px] leading-relaxed text-ink-2">{message}</p>
        {onRetry && (
          <button
            type="button"
            onClick={onRetry}
            className="mt-2 rounded-lg border border-line bg-surface px-2.5 py-1 text-[12.5px] text-ink-2 transition hover:border-accent/40 hover:text-ink"
          >
            Retry
          </button>
        )}
      </div>
      <button type="button" onClick={onDismiss} aria-label="Dismiss error" className="rounded p-1 text-muted transition hover:text-ink">
        <IconX size={14} />
      </button>
    </div>
  );
}
