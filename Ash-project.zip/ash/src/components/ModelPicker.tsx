"use client";

import { useEffect, useRef, useState } from "react";
import type { PublicModel } from "@/lib/types";
import { IconCheck, IconChevron } from "./Icons";

function Group({
  title,
  items,
  value,
  defaultId,
  onPick,
}: {
  title: string;
  items: PublicModel[];
  value: string;
  defaultId?: string;
  onPick: (id: string) => void;
}) {
  if (!items.length) return null;
  return (
    <div className="py-1">
      <p className="px-3 py-1 text-[10.5px] uppercase tracking-[.09em] text-muted">{title}</p>
      {items.map((m) => (
        <button
          key={m.id}
          type="button"
          onClick={() => onPick(m.id)}
          className={`flex w-full items-start gap-2 px-3 py-2 text-left transition hover:bg-surface-2 ${
            m.id === value ? "bg-accent-soft/60" : ""
          }`}
        >
          <span className="mt-0.5 w-4 shrink-0 text-accent">{m.id === value && <IconCheck size={14} />}</span>
          <span className="min-w-0">
            <span className="block text-[13px] font-semibold">
              {m.label}
              {m.id === defaultId && (
                <span className="ml-1.5 rounded border border-line px-1 py-px text-[9.5px] font-normal uppercase tracking-wide text-muted">
                  opens first
                </span>
              )}
            </span>
            <span className="block text-[11.5px] leading-snug text-muted">{m.description}</span>
          </span>
        </button>
      ))}
    </div>
  );
}

export default function ModelPicker({
  models,
  value,
  defaultId,
  onChange,
}: {
  models: PublicModel[];
  value: string;
  defaultId?: string;
  onChange: (id: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const current = models.find((m) => m.id === value);
  const offline = models.filter((m) => m.group === "offline");
  const full = models.filter((m) => m.group === "full");

  const pick = (id: string) => {
    onChange(id);
    setOpen(false);
  };

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-haspopup="listbox"
        aria-expanded={open}
        className="flex max-w-[190px] items-center gap-1.5 rounded-lg border border-line bg-surface px-2.5 py-1.5 text-[12.5px] text-ink-2 transition hover:border-accent/40 hover:text-ink"
      >
        <span className="truncate">{current?.label ?? "Choose engine"}</span>
        <IconChevron size={13} className={`shrink-0 transition ${open ? "rotate-180" : ""}`} />
      </button>

      {open && (
        <div className="absolute right-0 z-30 mt-1.5 max-h-[70vh] w-72 overflow-y-auto rounded-xl border border-line bg-surface py-1 shadow-[var(--shadow)] scroll-thin">
          {!models.length && <p className="px-3 py-3 text-[12.5px] text-muted">No engine is set up yet.</p>}
          <Group title="Full power" items={full} value={value} defaultId={defaultId} onPick={pick} />
          {!!offline.length && !!full.length && <div className="my-1 border-t border-line" />}
          <Group title="Works offline" items={offline} value={value} defaultId={defaultId} onPick={pick} />
        </div>
      )}
    </div>
  );
}
