"use client";

import Link from "next/link";
import { useState } from "react";
import { IconEye, IconEyeOff, IconShield } from "./Icons";

export default function OwnerGate({ ownerExists, onUnlocked }: { ownerExists: boolean; onUnlocked: () => void }) {
  const [password, setPassword] = useState("");
  const [repeat, setRepeat] = useState("");
  const [show, setShow] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!ownerExists && password !== repeat) {
      setError("The two passwords do not match.");
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/owner", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: ownerExists ? "login" : "setup", password }),
      });
      const data = await res.json();
      if (!res.ok) setError(data.error || "That did not work.");
      else onUnlocked();
    } catch {
      setError("Could not reach the server.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex min-h-dvh items-center justify-center bg-paper px-4">
      <form onSubmit={submit} className="w-full max-w-sm rounded-2xl border border-line bg-surface p-6 shadow-[var(--shadow)]">
        <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-accent text-accent-ink">
          <IconShield size={18} />
        </div>
        <h1 className="mt-4 font-serif text-[22px] font-semibold">{ownerExists ? "Control Panel" : "Create your password"}</h1>
        <p className="mt-1 text-[13px] leading-relaxed text-muted">
          {ownerExists
            ? "Only you can open this. Enter your owner password."
            : "You are the first person here. Pick a password of at least 8 characters — it is the only way in."}
        </p>

        <label className="mt-5 block text-[12.5px] font-medium">Password</label>
        <div className="relative mt-1">
          <input
            type={show ? "text" : "password"}
            required
            minLength={8}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full rounded-xl border border-line bg-surface-2 px-3 py-2 pr-10 text-[14px] outline-none transition focus:border-accent/40"
            placeholder="At least 8 characters"
            autoFocus
          />
          <button
            type="button"
            onClick={() => setShow((s) => !s)}
            aria-label={show ? "Hide password" : "Show password"}
            className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-muted transition hover:text-ink"
          >
            {show ? <IconEyeOff size={15} /> : <IconEye size={15} />}
          </button>
        </div>

        {!ownerExists && (
          <>
            <label className="mt-3 block text-[12.5px] font-medium">Repeat password</label>
            <input
              type={show ? "text" : "password"}
              required
              minLength={8}
              value={repeat}
              onChange={(e) => setRepeat(e.target.value)}
              className="mt-1 w-full rounded-xl border border-line bg-surface-2 px-3 py-2 text-[14px] outline-none transition focus:border-accent/40"
              placeholder="Type it again"
            />
          </>
        )}

        {error && <p className="mt-3 rounded-xl border border-danger/35 bg-danger/8 px-3 py-2 text-[12.5px] text-danger">{error}</p>}

        <button
          type="submit"
          disabled={busy}
          className="mt-4 w-full rounded-xl bg-accent px-3 py-2.5 text-[14px] font-medium text-accent-ink transition hover:opacity-90 disabled:opacity-60"
        >
          {busy ? "Please wait…" : ownerExists ? "Unlock" : "Create password"}
        </button>

        <Link href="/" className="mt-3 block text-center text-[12.5px] text-muted transition hover:text-ink">
          ← Back to chat
        </Link>
      </form>
    </div>
  );
}
