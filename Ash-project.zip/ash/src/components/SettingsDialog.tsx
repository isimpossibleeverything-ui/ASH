"use client";

import { useEffect, useState } from "react";
import type { PublicModel } from "@/lib/types";
import { REPLY_LANGUAGES, type Prefs } from "@/lib/prefs";
import type { VoiceSettings as VS } from "@/lib/useVoiceSession";
import VoiceSettings, { type ServerVoiceInfo } from "./VoiceSettings";
import InstallApp from "./InstallApp";
import { IconCheck, IconX } from "./Icons";

export default function SettingsDialog({
  open,
  onClose,
  models,
  prefs,
  onChange,
  onVoiceChange,
  serverVoice,
  onDeleteAll,
}: {
  open: boolean;
  onClose: () => void;
  models: PublicModel[];
  prefs: Prefs;
  onChange: (patch: Partial<Prefs>) => void;
  onVoiceChange: (patch: Partial<VS>) => void;
  serverVoice: ServerVoiceInfo | null;
  onDeleteAll: () => Promise<void>;
}) {
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  useEffect(() => {
    if (!open) setConfirming(false);
  }, [open]);

  if (!open) return null;

  const temperatureLabel = prefs.temperature <= 0.35 ? "Precise" : prefs.temperature <= 0.85 ? "Balanced" : "Creative";

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4" role="dialog" aria-modal="true" aria-label="Settings">
      <div className="absolute inset-0 bg-black/25 backdrop-blur-[2px]" onClick={onClose} />
      <div className="relative z-10 max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-2xl border border-line bg-surface shadow-[var(--shadow)] scroll-thin">
        <header className="sticky top-0 flex items-center gap-2 border-b border-line bg-surface px-5 py-3.5">
          <h2 className="flex-1 font-serif text-[17px] font-semibold">Settings</h2>
          <button type="button" onClick={onClose} aria-label="Close settings" className="rounded-lg p-1.5 text-muted transition hover:bg-surface-2 hover:text-ink">
            <IconX size={15} />
          </button>
        </header>

        <div className="space-y-6 px-5 py-5">
          <section>
            <h3 className="text-[13px] font-semibold">Engines</h3>
            <p className="mt-0.5 text-[12px] text-muted">Which engine answers first. If it is busy, Ash quietly uses another one.</p>
            <div className="mt-3 overflow-hidden rounded-xl border border-line">
              {models.map((m, i) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => onChange({ model: m.id })}
                  className={`flex w-full items-start gap-2.5 px-3 py-2.5 text-left transition ${i ? "border-t border-line" : ""} ${
                    prefs.model === m.id ? "bg-accent-soft/60" : "hover:bg-surface-2"
                  }`}
                >
                  <span className="mt-0.5 w-4 shrink-0 text-accent">{prefs.model === m.id && <IconCheck size={14} />}</span>
                  <span className="min-w-0">
                    <span className="block text-[13px] font-semibold">{m.label}</span>
                    <span className="block text-[11.5px] leading-snug text-muted">{m.description}</span>
                  </span>
                </button>
              ))}
              {!models.length && <p className="px-3 py-3 text-[12.5px] text-muted">No engine is set up yet.</p>}
            </div>
          </section>

          <section>
            <h3 className="text-[13px] font-semibold">Reply language</h3>
            <p className="mt-0.5 text-[12px] text-muted">
              Ash normally answers in whatever language you wrote in. Pin one here if you prefer.
            </p>
            <select
              value={prefs.replyLanguage}
              onChange={(e) => onChange({ replyLanguage: e.target.value })}
              className="mt-2 w-full rounded-xl border border-line bg-surface-2 px-3 py-2 text-[13px] outline-none transition focus:border-accent/40"
            >
              {REPLY_LANGUAGES.map((l) => (
                <option key={l.code} value={l.code}>
                  {l.label}
                </option>
              ))}
            </select>
          </section>

          <section>
            <h3 className="text-[13px] font-semibold">Memory</h3>
            <p className="mt-0.5 text-[12px] text-muted">
              Ash can answer instantly from things it has already learned. Turn this off to always ask a live engine.
            </p>
            <label className="mt-2 flex items-center gap-2.5 rounded-xl border border-line px-3 py-2.5">
              <input
                type="checkbox"
                checked={prefs.useMemory}
                onChange={(e) => onChange({ useMemory: e.target.checked })}
                className="h-4 w-4 accent-[var(--accent)]"
              />
              <span className="text-[13px]">Answer from memory when Ash already knows something</span>
            </label>
          </section>

          <section>
            <h3 className="text-[13px] font-semibold">Voice</h3>
            <p className="mt-0.5 text-[12px] text-muted">
              Listening and speaking both work with no key at all, using this device&apos;s own speech engine.
            </p>
            <div className="mt-2 rounded-xl border border-line px-3">
              <VoiceSettings
                value={prefs.voice}
                onChange={onVoiceChange}
                pushToTalk={prefs.pushToTalk}
                onPushToTalk={(v) => onChange({ pushToTalk: v })}
                server={serverVoice}
              />
            </div>
          </section>

          <section>
            <h3 className="text-[13px] font-semibold">System prompt</h3>
            <p className="mt-0.5 text-[12px] text-muted">Applies to new chats. Leave it empty to use Ash&apos;s own prompt.</p>
            <textarea
              dir="auto"
              value={prefs.systemPrompt}
              onChange={(e) => onChange({ systemPrompt: e.target.value })}
              placeholder="You are a thoughtful, precise assistant…"
              rows={4}
              className="mt-2 w-full resize-y rounded-xl border border-line bg-surface-2 px-3 py-2 text-[13px] leading-relaxed outline-none transition focus:border-accent/40"
            />
          </section>

          <section>
            <div className="flex items-baseline justify-between">
              <h3 className="text-[13px] font-semibold">Temperature</h3>
              <span className="text-[12px] text-muted">
                {temperatureLabel} · {prefs.temperature.toFixed(1)}
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={1.2}
              step={0.1}
              value={prefs.temperature}
              onChange={(e) => onChange({ temperature: Number(e.target.value) })}
              className="mt-3 w-full accent-[var(--accent)]"
            />
            <div className="mt-1 flex justify-between text-[11px] text-muted">
              <span>Precise</span>
              <span>Balanced</span>
              <span>Creative</span>
            </div>
          </section>

          <section className="border-t border-line pt-5">
            <h3 className="text-[13px] font-semibold">Install as an app</h3>
            <p className="mt-0.5 mb-2 text-[12px] text-muted">
              Put Ash on your phone&apos;s home screen or your computer&apos;s desktop. It opens in its own window, with no
              browser bars, and keeps working on a bad connection.
            </p>
            <InstallApp />
          </section>

          <section className="border-t border-line pt-5">
            <h3 className="text-[13px] font-semibold">Your chats</h3>
            <p className="mt-0.5 text-[12px] text-muted">This only removes the chats saved in this browser. Nobody else is affected.</p>
            {confirming ? (
              <div className="mt-2 flex items-center gap-2">
                <button
                  type="button"
                  disabled={busy}
                  onClick={async () => {
                    setBusy(true);
                    try {
                      await onDeleteAll();
                      setConfirming(false);
                      onClose();
                    } finally {
                      setBusy(false);
                    }
                  }}
                  className="rounded-lg bg-danger px-3 py-1.5 text-[12.5px] text-white transition hover:opacity-90 disabled:opacity-60"
                >
                  {busy ? "Deleting…" : "Yes, delete everything"}
                </button>
                <button
                  type="button"
                  onClick={() => setConfirming(false)}
                  className="rounded-lg border border-line px-3 py-1.5 text-[12.5px] text-ink-2 transition hover:border-accent/40"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirming(true)}
                className="mt-2 text-[12.5px] font-medium text-danger transition hover:opacity-80"
              >
                Delete all conversations
              </button>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}
