"use client";

import Link from "next/link";
import { useMemo, useRef, useState } from "react";
import type { Conversation } from "@/lib/types";
import ThemeToggle from "./ThemeToggle";
import { IconArchive, IconGear, IconLogout, IconPin, IconPlus, IconSearch, IconShield, IconTrash, IconUser, IconX } from "./Icons";

interface Props {
  conversations: Conversation[];
  activeId: string | null;
  open: boolean;
  onClose: () => void;
  onSelect: (id: string) => void;
  onNew: () => void;
  onRename: (id: string, title: string) => void;
  onDelete: (id: string) => void;
  onTogglePin: (id: string, pinned: boolean) => void;
  onToggleArchive: (id: string, archived: boolean) => void;
  onOpenSettings: () => void;
  appName: string;
  ownerExists: boolean;
  isOwner: boolean;
  account: { required: boolean; signedIn: boolean; email: string | null; onSignOut: () => void };
}

function groupOf(c: Conversation): string {
  if (c.archived) return "Archived";
  if (c.pinned) return "Pinned";
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const yesterday = today - 86_400_000;
  const week = today - 7 * 86_400_000;
  if (c.updatedAt >= today) return "Today";
  if (c.updatedAt >= yesterday) return "Yesterday";
  if (c.updatedAt >= week) return "Previous 7 days";
  return "Older";
}

const ORDER = ["Pinned", "Today", "Yesterday", "Previous 7 days", "Older", "Archived"];

export default function Sidebar({
  conversations,
  activeId,
  open,
  onClose,
  onSelect,
  onNew,
  onRename,
  onDelete,
  onTogglePin,
  onToggleArchive,
  onOpenSettings,
  appName,
  ownerExists,
  isOwner,
  account,
}: Props) {
  const [query, setQuery] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const inputRef = useRef<HTMLInputElement | null>(null);

  const groups = useMemo(() => {
    const filtered = query.trim()
      ? conversations.filter((c) => c.title.toLowerCase().includes(query.trim().toLowerCase()))
      : conversations;
    const map = new Map<string, Conversation[]>();
    for (const c of filtered) {
      const g = groupOf(c);
      map.set(g, [...(map.get(g) ?? []), c]);
    }
    return ORDER.filter((g) => map.has(g)).map((g) => ({ label: g, items: map.get(g) ?? [] }));
  }, [conversations, query]);

  const startRename = (c: Conversation) => {
    setEditingId(c.id);
    setDraft(c.title);
    setTimeout(() => inputRef.current?.select(), 0);
  };

  const commit = () => {
    if (editingId && draft.trim()) onRename(editingId, draft.trim());
    setEditingId(null);
  };

  return (
    <>
      {open && <div className="fixed inset-0 z-30 bg-black/25 backdrop-blur-[2px] md:hidden" onClick={onClose} aria-hidden="true" />}

      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-72 flex-col border-r border-line bg-paper-2 transition-transform md:static md:translate-x-0 ${
          open ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex items-center gap-2 px-3 pt-3.5">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-accent text-[14px] font-bold text-accent-ink">A</div>
          <span className="flex-1 font-serif text-[15px] font-semibold">{appName}</span>
          <button type="button" onClick={onClose} aria-label="Close sidebar" className="rounded-lg p-1.5 text-muted transition hover:text-ink md:hidden">
            <IconX size={15} />
          </button>
        </div>

        <div className="px-3 pt-3">
          <button
            type="button"
            onClick={onNew}
            className="flex w-full items-center gap-2 rounded-xl border border-line bg-surface px-3 py-2.5 text-[13.5px] font-medium shadow-[var(--shadow)] transition hover:border-accent/40"
          >
            <span className="text-accent">
              <IconPlus size={15} />
            </span>
            <span className="flex-1 text-left">New chat</span>
            <kbd className="kbd">⌘K</kbd>
          </button>
        </div>

        <div className="px-3 pt-2.5">
          <div className="relative">
            <span className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-muted">
              <IconSearch size={14} />
            </span>
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search chats"
              aria-label="Search chats"
              className="w-full rounded-lg border border-transparent bg-surface-2 py-2 pl-8 pr-2.5 text-[14px] outline-none transition focus:border-accent/40"
            />
          </div>
        </div>

        <nav className="mt-2 min-h-0 flex-1 overflow-y-auto px-2 pb-2 scroll-thin">
          {!groups.length && (
            <p className="px-3 py-10 text-center text-[12.5px] leading-relaxed text-muted">
              {query ? "Nothing matches that." : "No chats yet.\nStart one — it saves itself."}
            </p>
          )}

          {groups.map((group) => (
            <div key={group.label} className="mb-2">
              <p className="px-2.5 py-1.5 text-[10.5px] uppercase tracking-[.09em] text-muted">{group.label}</p>
              {group.items.map((c) => (
                <div
                  key={c.id}
                  className={`group relative flex items-center rounded-lg border transition ${
                    c.id === activeId ? "border-line bg-surface-2" : "border-transparent hover:bg-surface-2/70"
                  }`}
                >
                  {editingId === c.id ? (
                    <input
                      ref={inputRef}
                      value={draft}
                      onChange={(e) => setDraft(e.target.value)}
                      onBlur={commit}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") commit();
                        if (e.key === "Escape") setEditingId(null);
                      }}
                      className="w-full rounded-lg border border-accent bg-surface px-2.5 py-2 text-[13.5px] outline-none"
                    />
                  ) : (
                    <>
                      <button
                        type="button"
                        onClick={() => onSelect(c.id)}
                        onDoubleClick={() => startRename(c)}
                        className="flex min-w-0 flex-1 items-center gap-1.5 px-2.5 py-2 text-left"
                        title={c.title}
                      >
                        {c.pinned && (
                          <span className="shrink-0 text-accent">
                            <IconPin size={11} />
                          </span>
                        )}
                        <span className="truncate text-[13.5px]">{c.title}</span>
                      </button>
                      <span className="absolute right-1 flex items-center gap-0.5 bg-gradient-to-l from-surface-2 via-surface-2 to-transparent pl-4 opacity-0 transition group-focus-within:opacity-100 group-hover:opacity-100">
                        <button
                          type="button"
                          onClick={() => onTogglePin(c.id, !c.pinned)}
                          aria-label={c.pinned ? "Unpin chat" : "Pin chat"}
                          title={c.pinned ? "Unpin" : "Pin"}
                          className={`rounded-md p-1.5 transition hover:text-accent ${c.pinned ? "text-accent" : "text-muted"}`}
                        >
                          <IconPin size={13} />
                        </button>
                        <button
                          type="button"
                          onClick={() => onToggleArchive(c.id, !c.archived)}
                          aria-label={c.archived ? "Unarchive chat" : "Archive chat"}
                          title={c.archived ? "Unarchive" : "Archive"}
                          className={`rounded-md p-1.5 transition hover:text-accent ${c.archived ? "text-accent" : "text-muted"}`}
                        >
                          <IconArchive size={13} />
                        </button>
                        <button
                          type="button"
                          onClick={() => onDelete(c.id)}
                          aria-label="Delete chat"
                          title="Delete"
                          className="rounded-md p-1.5 text-muted transition hover:text-danger"
                        >
                          <IconTrash size={13} />
                        </button>
                      </span>
                    </>
                  )}
                </div>
              ))}
            </div>
          ))}
        </nav>

        {!isOwner && !ownerExists && (
          <div className="border-t border-line px-3 py-2.5">
            <Link
              href="/owner"
              className="flex items-center gap-2 rounded-lg bg-accent-soft px-2.5 py-2 text-[12.5px] font-medium text-accent transition hover:opacity-90"
            >
              <IconShield size={14} /> Set up owner
            </Link>
          </div>
        )}

        {isOwner && (
          <div className="border-t border-line px-3 py-2.5">
            <Link
              href="/owner"
              className="flex items-center gap-2 rounded-lg px-2.5 py-2 text-[12.5px] text-ink-2 transition hover:bg-surface-2 hover:text-ink"
            >
              <IconShield size={14} /> Control Panel
            </Link>
          </div>
        )}

        {account.required && account.signedIn && (
          <div className="flex items-center gap-2 border-t border-line px-3 py-2.5">
            <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-accent-soft text-[12px] font-semibold text-accent">
              {(account.email ?? "?").charAt(0).toUpperCase() || <IconUser size={13} />}
            </div>
            <span className="min-w-0 flex-1 truncate text-[12.5px] text-ink-2">{account.email}</span>
            <button
              type="button"
              onClick={account.onSignOut}
              aria-label="Sign out"
              title="Sign out"
              className="rounded-md p-1.5 text-muted transition hover:text-ink"
            >
              <IconLogout size={14} />
            </button>
          </div>
        )}

        <div className="flex items-center gap-2 border-t border-line px-3 py-2.5">
          <button
            type="button"
            onClick={onOpenSettings}
            className="flex flex-1 items-center gap-2 rounded-lg border border-line px-2.5 py-1.5 text-[13px] text-ink-2 transition hover:border-accent/40 hover:text-ink"
          >
            <IconGear size={15} /> Settings
          </button>
          <ThemeToggle compact />
        </div>
      </aside>
    </>
  );
}
