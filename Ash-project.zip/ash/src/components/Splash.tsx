"use client";

import { useCallback, useEffect, useRef, useState } from "react";

/* ─────────────────────────── timeline (ms) ───────────────────────────
   0      ─ dust fades in, already on screen
   260    ─ assembly starts, staggered left → right
   2000   ─ every particle has landed
   2000+  ─ the web of connecting lines fades in
   4150   ─ the whole overlay cross-fades into the app
   4910   ─ unmounted
   ------------------------------------------------------------------ */
const ENTER = 320;
const ASSEMBLE_AT = 260;
const STAGGER = 560;
const TRAVEL = 1180;
const SETTLED = ASSEMBLE_AT + STAGGER + TRAVEL;
const WIRE = 460;
const HOLD_UNTIL = 4150;
const EXIT = 760;
const SKIP_EXIT = 260;
const TOTAL = HOLD_UNTIL + EXIT;

const MAX_PAIRS = 900;
const RELAYOUT_TRAVEL = 420;

interface Particle {
  sx: number;
  sy: number;
  tx: number;
  ty: number;
  /** perpendicular bow so the path curves instead of sliding in a straight line */
  nx: number;
  ny: number;
  bow: number;
  /** absolute ms (from animation start) when this particle begins moving */
  t0: number;
  travel: number;
  r: number;
  accent: boolean;
  phase: number;
  x: number;
  y: number;
}

const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);
const easeOutCubic = (t: number) => 1 - (1 - t) * (1 - t) * (1 - t);

export default function Splash({ name = "Ash" }: { name?: string }) {
  const [mounted, setMounted] = useState(false);
  const [exitMs, setExitMs] = useState<number | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const rafRef = useRef(0);
  const exitTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const exiting = useRef(false);

  const beginExit = useCallback((ms: number) => {
    if (exiting.current) return;
    exiting.current = true;
    setExitMs(ms);
    exitTimer.current = setTimeout(() => setMounted(false), ms + 40);
  }, []);

  /* ── should it play at all? ── */
  useEffect(() => {
    if (typeof window === "undefined") return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    // ?splash or #splash replays it on demand — handy after a deploy.
    const forced = window.location.search.includes("splash") || window.location.hash === "#splash";
    if (!forced) {
      try {
        if (window.sessionStorage.getItem("ash:splash") === "1") return;
        window.sessionStorage.setItem("ash:splash", "1");
      } catch {
        /* private mode: play it, once per page load */
      }
    }
    setMounted(true);
  }, []);

  /* ── the animation ── */
  useEffect(() => {
    if (!mounted) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d", { alpha: true });
    if (!ctx) return;

    const word = (name || "Ash").trim().slice(0, 14) || "Ash";
    const styles = getComputedStyle(document.documentElement);
    const ink = styles.getPropertyValue("--ink").trim() || "#23221f";
    const accent = styles.getPropertyValue("--accent").trim() || "#bd5d3a";

    let particles: Particle[] = [];
    let pairs: Int32Array = new Int32Array(0);
    let width = 0;
    let height = 0;
    let dpr = 1;
    let startedAt = 0;
    let disposed = false;

    /* sample the word, build particles and the neighbour web */
    const build = (firstRun: boolean, elapsed: number) => {
      width = canvas.clientWidth || window.innerWidth;
      height = canvas.clientHeight || window.innerHeight;
      dpr = Math.min(2, window.devicePixelRatio || 1);

      canvas.width = Math.round(width * dpr);
      canvas.height = Math.round(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      const off = document.createElement("canvas");
      off.width = canvas.width;
      off.height = canvas.height;
      const octx = off.getContext("2d", { willReadFrequently: true });
      if (!octx) return false;
      octx.scale(dpr, dpr);

      const serif = `"Iowan Old Style","Palatino Linotype",Palatino,"Book Antiqua",Georgia,ui-serif,serif`;
      let fontSize = Math.round(Math.max(88, Math.min(width * 0.34, height * 0.3, 264)));
      octx.font = `600 ${fontSize}px ${serif}`;
      const fit = (octx.measureText(word).width || fontSize) / (width * 0.8);
      if (fit > 1) fontSize = Math.max(56, Math.round(fontSize / fit));

      octx.font = `600 ${fontSize}px ${serif}`;
      octx.textAlign = "center";
      octx.textBaseline = "middle";
      octx.fillStyle = "#000";
      const cx = width / 2;
      const cy = height / 2;
      octx.fillText(word, cx, cy);

      // read back only the glyph box, not the whole viewport
      const m = octx.measureText(word);
      const padL = Number.isFinite(m.actualBoundingBoxLeft) ? m.actualBoundingBoxLeft : m.width / 2;
      const padR = Number.isFinite(m.actualBoundingBoxRight) ? m.actualBoundingBoxRight : m.width / 2;
      const padA = Number.isFinite(m.actualBoundingBoxAscent) ? m.actualBoundingBoxAscent : fontSize * 0.75;
      const padD = Number.isFinite(m.actualBoundingBoxDescent) ? m.actualBoundingBoxDescent : fontSize * 0.3;
      const bx = Math.max(0, Math.floor(cx - padL - 6));
      const by = Math.max(0, Math.floor(cy - padA - 6));
      const bw = Math.min(width - bx, Math.ceil(padL + padR + 12));
      const bh = Math.min(height - by, Math.ceil(padA + padD + 12));
      if (bw <= 0 || bh <= 0) return false;

      const img = octx.getImageData(
        Math.round(bx * dpr),
        Math.round(by * dpr),
        Math.round(bw * dpr),
        Math.round(bh * dpr),
      );
      const iw = img.width;
      const ih = img.height;
      const data = img.data;

      // adaptive spacing keeps the particle count (and the frame time) in budget
      const budget = width < 640 ? 900 : 1500;
      let gap = Math.max(4, Math.round(fontSize / 34));
      let points: { x: number; y: number }[] = [];
      for (let attempt = 0; attempt < 7; attempt++) {
        points = [];
        const stepPx = Math.round(gap * dpr);
        for (let y = 0; y < ih; y += stepPx) {
          for (let x = 0; x < iw; x += stepPx) {
            if (data[(y * iw + x) * 4 + 3] > 128) {
              points.push({ x: bx + x / dpr, y: by + y / dpr });
            }
          }
        }
        if (points.length <= budget) break;
        gap += 1;
      }
      if (!points.length) return false;

      const previous = particles;
      const tau = Math.PI * 2;

      particles = points.map((p, i) => {
        const old = firstRun ? undefined : previous[i];
        // Seed on screen as scattered dust so there is something to watch from frame one.
        const sx = old ? old.x : (Math.random() * 1.18 - 0.09) * width;
        const sy = old ? old.y : (Math.random() * 1.18 - 0.09) * height;
        const dx = p.x - sx;
        const dy = p.y - sy;
        const len = Math.hypot(dx, dy) || 1;
        // left-to-right stagger: the word writes itself
        const lane = width > 1 ? clamp01(p.x / width) : 0;
        return {
          sx,
          sy,
          tx: p.x,
          ty: p.y,
          nx: -dy / len,
          ny: dx / len,
          bow: (Math.random() * 2 - 1) * Math.min(80, len * 0.2),
          t0: firstRun ? ASSEMBLE_AT + lane * STAGGER * 0.75 + Math.random() * STAGGER * 0.25 : elapsed,
          travel: firstRun ? TRAVEL * (0.86 + Math.random() * 0.28) : RELAYOUT_TRAVEL,
          r: 0.78 + Math.random() * 0.85,
          accent: Math.random() < 0.12,
          phase: Math.random() * tau,
          x: sx,
          y: sy,
        };
      });

      /* neighbour web, computed once from the final positions */
      const cell = Math.max(8, gap * 1.6);
      const grid = new Map<number, number[]>();
      const cols = Math.ceil(width / cell) + 2;
      const keyOf = (x: number, y: number) => ((y / cell) | 0) * cols + ((x / cell) | 0);
      particles.forEach((p, i) => {
        const k = keyOf(p.tx, p.ty);
        const bucket = grid.get(k);
        if (bucket) bucket.push(i);
        else grid.set(k, [i]);
      });

      const maxD2 = (gap * 1.5) * (gap * 1.5);
      const degree = new Uint8Array(particles.length);
      const flat: number[] = [];
      outer: for (let i = 0; i < particles.length; i++) {
        if (degree[i] >= 2) continue;
        const a = particles[i];
        const gx = (a.tx / cell) | 0;
        const gy = (a.ty / cell) | 0;
        for (let oy = -1; oy <= 1; oy++) {
          for (let ox = -1; ox <= 1; ox++) {
            const bucket = grid.get((gy + oy) * cols + (gx + ox));
            if (!bucket) continue;
            for (const j of bucket) {
              if (j <= i || degree[j] >= 2 || degree[i] >= 2) continue;
              const b = particles[j];
              const dx = a.tx - b.tx;
              const dy = a.ty - b.ty;
              if (dx * dx + dy * dy > maxD2) continue;
              flat.push(i, j);
              degree[i]++;
              degree[j]++;
              if (flat.length >= MAX_PAIRS * 2) break outer;
            }
          }
        }
      }
      pairs = Int32Array.from(flat);
      return true;
    };

    const draw = (now: number) => {
      if (disposed) return;
      const elapsed = now - startedAt;

      // The overlay has already faded out by now; just stop burning frames.
      if (elapsed >= TOTAL) return;
      if (elapsed >= HOLD_UNTIL) beginExit(EXIT);

      ctx.clearRect(0, 0, width, height);
      const enter = clamp01(elapsed / ENTER);

      /* positions: pure time-based easing, so it is identical at 60 Hz and 120 Hz */
      for (const p of particles) {
        const t = clamp01((elapsed - p.t0) / p.travel);
        if (t >= 1) {
          // barely-there drift so the settled word breathes instead of freezing
          p.x = p.tx + Math.sin(now * 0.0013 + p.phase) * 0.35;
          p.y = p.ty + Math.cos(now * 0.0011 + p.phase) * 0.35;
        } else {
          const e = easeOutCubic(t);
          const arc = Math.sin(Math.PI * e) * p.bow;
          p.x = p.sx + (p.tx - p.sx) * e + p.nx * arc;
          p.y = p.sy + (p.ty - p.sy) * e + p.ny * arc;
        }
      }

      /* the web — one path, one stroke call */
      if (pairs.length && elapsed > SETTLED - 120) {
        const wire = clamp01((elapsed - (SETTLED - 120)) / WIRE);
        ctx.globalAlpha = wire * (0.26 + 0.05 * Math.sin(elapsed * 0.0016));
        ctx.strokeStyle = accent;
        ctx.lineWidth = 0.6;
        ctx.beginPath();
        for (let i = 0; i < pairs.length; i += 2) {
          const a = particles[pairs[i]];
          const b = particles[pairs[i + 1]];
          if (!a || !b) continue;
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(b.x, b.y);
        }
        ctx.stroke();
      }

      /* particles — one path per colour, two fill calls total */
      const tau = Math.PI * 2;
      ctx.globalAlpha = enter;
      ctx.fillStyle = ink;
      ctx.beginPath();
      for (const p of particles) {
        if (p.accent) continue;
        ctx.moveTo(p.x + p.r, p.y);
        ctx.arc(p.x, p.y, p.r, 0, tau);
      }
      ctx.fill();

      ctx.fillStyle = accent;
      ctx.beginPath();
      for (const p of particles) {
        if (!p.accent) continue;
        ctx.moveTo(p.x + p.r, p.y);
        ctx.arc(p.x, p.y, p.r, 0, tau);
      }
      ctx.fill();

      ctx.globalAlpha = 1;
      rafRef.current = requestAnimationFrame(draw);
    };

    let resizeTimer: ReturnType<typeof setTimeout> | null = null;
    const onResize = () => {
      if (resizeTimer) clearTimeout(resizeTimer);
      resizeTimer = setTimeout(() => {
        if (disposed) return;
        const w = canvas.clientWidth || window.innerWidth;
        const h = canvas.clientHeight || window.innerHeight;
        if (Math.abs(w - width) < 40 && Math.abs(h - height) < 40) return;
        build(false, performance.now() - startedAt);
      }, 160);
    };

    const skip = () => beginExit(SKIP_EXIT);

    const launch = () => {
      if (disposed) return;
      if (!build(true, 0)) {
        beginExit(SKIP_EXIT);
        return;
      }
      startedAt = performance.now();
      rafRef.current = requestAnimationFrame(draw);
      window.addEventListener("resize", onResize);
      window.addEventListener("keydown", skip);
      window.addEventListener("pointerdown", skip);
    };

    // Let the serif load first, but never wait long for it.
    const fonts = (document as Document & { fonts?: FontFaceSet }).fonts;
    if (fonts?.ready) {
      Promise.race([fonts.ready, new Promise((r) => setTimeout(r, 200))]).then(launch, launch);
    } else {
      launch();
    }

    return () => {
      disposed = true;
      cancelAnimationFrame(rafRef.current);
      if (resizeTimer) clearTimeout(resizeTimer);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("keydown", skip);
      window.removeEventListener("pointerdown", skip);
    };
  }, [mounted, name, beginExit]);

  useEffect(
    () => () => {
      if (exitTimer.current) clearTimeout(exitTimer.current);
    },
    [],
  );

  if (!mounted) return null;

  return (
    <div
      className="fixed inset-0 z-[90] bg-paper"
      role="presentation"
      aria-hidden="true"
      style={{
        opacity: exitMs === null ? 1 : 0,
        transition: `opacity ${exitMs ?? EXIT}ms cubic-bezier(.4,0,.2,1)`,
        pointerEvents: exitMs === null ? "auto" : "none",
      }}
    >
      <canvas ref={canvasRef} className="block h-full w-full" />
      <p
        className="pointer-events-none absolute inset-x-0 bottom-10 text-center text-[11px] tracking-wide text-muted"
        style={{ animation: "ash-fade-in .7s ease 1.5s both" }}
      >
        Click anywhere to skip
      </p>
    </div>
  );
}
