"use client";

import { useEffect, useState } from "react";
import { IconMoon, IconSun } from "./Icons";

export default function ThemeToggle({ compact = false }: { compact?: boolean }) {
  const [dark, setDark] = useState(false);

  useEffect(() => {
    const el = document.documentElement;
    // explicit class wins, otherwise fall back to what the device asked for
    const explicit = el.classList.contains("dark") ? true : el.classList.contains("light") ? false : null;
    setDark(explicit ?? window.matchMedia("(prefers-color-scheme: dark)").matches);
  }, []);

  const toggle = () => {
    const next = !dark;
    setDark(next);
    const el = document.documentElement;
    el.classList.toggle("dark", next);
    el.classList.toggle("light", !next);
    try {
      localStorage.setItem("theme", next ? "dark" : "light");
    } catch {
      /* private mode */
    }
  };

  return (
    <button
      type="button"
      onClick={toggle}
      title={dark ? "Switch to light" : "Switch to dark"}
      aria-label={dark ? "Switch to light theme" : "Switch to dark theme"}
      className={`flex items-center gap-2 rounded-lg border border-line px-2.5 py-1.5 text-[13px] text-ink-2 transition hover:border-accent/40 hover:text-ink ${
        compact ? "" : "w-full justify-center"
      }`}
    >
      {dark ? <IconMoon size={15} /> : <IconSun size={15} />}
      {!compact && <span>{dark ? "Dark" : "Light"}</span>}
    </button>
  );
}
