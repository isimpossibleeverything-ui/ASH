"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { IconDownload, IconPause, IconPlay } from "./Icons";

export type ClipMode = "frames" | "motion";

const MOTION_LOOP_MS = 6000;
const easeInOutSine = (t: number) => -(Math.cos(Math.PI * t) - 1) / 2;

/**
 * A short silent clip.
 *  • "frames" — a real frame-by-frame slideshow (needs a free image key).
 *  • "motion" — one generated still with a genuine slow push-in and drift,
 *    which is what the keyless image tier can deliver without a long wait.
 * Both modes record to a downloadable WebM from the same canvas.
 */
export default function VideoClip({
  frames,
  fps = 2,
  prompt,
  mode = "frames",
}: {
  frames: string[];
  fps?: number;
  prompt?: string;
  mode?: ClipMode;
}) {
  const effectiveMode: ClipMode = mode === "motion" || frames.length === 1 ? "motion" : "frames";
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(true);
  const [busy, setBusy] = useState(false);
  const [ready, setReady] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const imagesRef = useRef<HTMLImageElement[]>([]);
  const rafRef = useRef(0);
  const playingRef = useRef(true);

  useEffect(() => {
    playingRef.current = playing;
  }, [playing]);

  /* decode every frame once */
  useEffect(() => {
    let cancelled = false;
    Promise.all(
      frames.map(
        (src) =>
          new Promise<HTMLImageElement>((resolve, reject) => {
            const img = new Image();
            img.onload = () => resolve(img);
            img.onerror = reject;
            img.src = src;
          }),
      ),
    )
      .then((imgs) => {
        if (cancelled) return;
        imagesRef.current = imgs;
        const canvas = canvasRef.current;
        if (canvas && imgs[0]) {
          canvas.width = imgs[0].naturalWidth || 1024;
          canvas.height = imgs[0].naturalHeight || 576;
        }
        setReady(true);
      })
      .catch(() => setReady(false));
    return () => {
      cancelled = true;
    };
  }, [frames]);

  /** One painted frame. `t` is 0‒1 through the loop. */
  const paint = useCallback(
    (t: number) => {
      const canvas = canvasRef.current;
      const imgs = imagesRef.current;
      if (!canvas || !imgs.length) return;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      const W = canvas.width;
      const H = canvas.height;

      if (effectiveMode === "motion") {
        const img = imgs[0];
        // ping-pong so the loop never jumps
        const p = easeInOutSine(t < 0.5 ? t * 2 : (1 - t) * 2);
        const zoom = 1 + 0.16 * p;
        const sw = W / zoom;
        const sh = H / zoom;
        const sx = (W - sw) * (0.5 + 0.22 * (p - 0.5));
        const sy = (H - sh) * (0.5 - 0.16 * (p - 0.5));
        ctx.drawImage(img, sx, sy, sw, sh, 0, 0, W, H);
      } else {
        const i = Math.min(imgs.length - 1, Math.floor(t * imgs.length));
        ctx.drawImage(imgs[i], 0, 0, W, H);
        if (i !== index) setIndex(i);
      }
    },
    [effectiveMode, index],
  );

  /* live playback */
  useEffect(() => {
    if (!ready) return;
    const loopMs = effectiveMode === "motion" ? MOTION_LOOP_MS : Math.max(600, (frames.length * 1000) / Math.max(1, fps));
    let startedAt = performance.now();
    let pausedAt: number | null = null;

    const tick = (now: number) => {
      if (!playingRef.current) {
        if (pausedAt === null) pausedAt = now;
      } else if (pausedAt !== null) {
        startedAt += now - pausedAt;
        pausedAt = null;
      }
      const t = (((now - startedAt) % loopMs) + loopMs) % loopMs;
      paint(t / loopMs);
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [ready, effectiveMode, frames.length, fps, paint]);

  const downloadWebm = async () => {
    const canvas = canvasRef.current;
    if (!canvas || busy || !ready) return;
    if (typeof MediaRecorder === "undefined") return;
    setBusy(true);
    const wasPlaying = playingRef.current;
    playingRef.current = false;
    cancelAnimationFrame(rafRef.current);

    try {
      const stream = canvas.captureStream(30);
      const mime = MediaRecorder.isTypeSupported("video/webm;codecs=vp9") ? "video/webm;codecs=vp9" : "video/webm";
      const recorder = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 4_000_000 });
      const chunks: BlobPart[] = [];
      recorder.ondataavailable = (e) => e.data.size && chunks.push(e.data);
      const stopped = new Promise<void>((resolve) => {
        recorder.onstop = () => resolve();
      });

      recorder.start();
      const loopMs = effectiveMode === "motion" ? MOTION_LOOP_MS : Math.max(600, (frames.length * 1000) / Math.max(1, fps));
      const total = effectiveMode === "motion" ? loopMs : loopMs * 2;
      const began = performance.now();
      await new Promise<void>((resolve) => {
        const render = (now: number) => {
          const elapsed = now - began;
          if (elapsed >= total) return resolve();
          paint((elapsed % loopMs) / loopMs);
          requestAnimationFrame(render);
        };
        requestAnimationFrame(render);
      });
      recorder.stop();
      await stopped;

      const blob = new Blob(chunks, { type: "video/webm" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${(prompt || "ash-clip").replace(/[^\w\s-]/g, "").trim().slice(0, 40).replace(/\s+/g, "-").toLowerCase() || "ash-clip"}.webm`;
      a.click();
      URL.revokeObjectURL(url);
    } finally {
      playingRef.current = wasPlaying;
      setBusy(false);
      setReady((r) => r); // nudge the playback effect back to life
      rafRef.current = requestAnimationFrame(function resume(now) {
        paint(((now / (effectiveMode === "motion" ? MOTION_LOOP_MS : 1000)) % 1 + 1) % 1);
        rafRef.current = requestAnimationFrame(resume);
      });
    }
  };

  if (!frames.length) return null;

  return (
    <figure className="my-2 overflow-hidden rounded-xl border border-line bg-surface">
      <canvas ref={canvasRef} className="block w-full bg-paper-2" aria-label={prompt || "Generated clip"} />
      <figcaption className="flex flex-wrap items-center gap-2 border-t border-line px-3 py-2 text-[11.5px] text-muted">
        <button
          type="button"
          onClick={() => setPlaying((p) => !p)}
          className="flex items-center gap-1.5 rounded-lg border border-line px-2 py-1 text-ink-2 transition hover:border-accent/40 hover:text-ink"
        >
          {playing ? <IconPause size={13} /> : <IconPlay size={13} />}
          {playing ? "Pause" : "Play"}
        </button>
        <button
          type="button"
          onClick={downloadWebm}
          disabled={busy || !ready}
          className="flex items-center gap-1.5 rounded-lg border border-line px-2 py-1 text-ink-2 transition hover:border-accent/40 hover:text-ink disabled:opacity-50"
        >
          <IconDownload size={13} /> {busy ? "Recording…" : "Save WebM"}
        </button>
        <span className="ml-auto">
          {effectiveMode === "motion"
            ? "Silent motion clip · one generated frame, real camera move"
            : `Silent clip · ${frames.length} frames · ${index + 1}/${frames.length}`}
        </span>
      </figcaption>
    </figure>
  );
}
