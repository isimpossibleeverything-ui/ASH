"use client";

import type { VoiceState } from "@/lib/voice/client";
import { IconMic, IconStop, IconX } from "./Icons";

const LABEL: Record<VoiceState, string> = {
  idle: "Tap to speak",
  listening: "Listening…",
  thinking: "Thinking…",
  speaking: "Speaking…",
};

/** The big microphone. Its ring tells you exactly what Ash is doing. */
export default function VoiceOrb({
  state,
  partial,
  disabled,
  onToggle,
  onStopSpeaking,
  onHoldStart,
  onHoldEnd,
  pushToTalk,
}: {
  state: VoiceState;
  partial?: string;
  disabled?: boolean;
  onToggle: () => void;
  onStopSpeaking: () => void;
  onHoldStart: () => void;
  onHoldEnd: () => void;
  pushToTalk: boolean;
}) {
  const listening = state === "listening";
  const speaking = state === "speaking";
  const thinking = state === "thinking";

  const hold = pushToTalk
    ? {
        onPointerDown: (e: React.PointerEvent) => {
          e.preventDefault();
          onHoldStart();
        },
        onPointerUp: (e: React.PointerEvent) => {
          e.preventDefault();
          onHoldEnd();
        },
        onPointerLeave: () => onHoldEnd(),
      }
    : { onClick: onToggle };

  return (
    <div className="flex flex-col items-center gap-2">
      <div className="relative">
        {listening && <span className="voice-ring pointer-events-none absolute inset-0 rounded-full" aria-hidden="true" />}
        <button
          type="button"
          disabled={disabled}
          aria-label={pushToTalk ? "Hold to speak" : listening ? "Stop listening" : "Start speaking"}
          aria-pressed={listening}
          {...hold}
          className={`relative flex h-14 w-14 items-center justify-center rounded-full border transition disabled:opacity-40 ${
            listening
              ? "border-accent bg-accent text-accent-ink"
              : speaking
                ? "breathe border-accent/40 bg-accent-soft text-accent"
                : "border-line bg-surface text-ink-2 hover:border-accent/40 hover:text-accent"
          }`}
          style={{ boxShadow: listening ? "0 0 0 6px color-mix(in oklab, var(--accent) 14%, transparent)" : undefined }}
        >
          {speaking ? (
            <span className="wave flex items-end gap-[3px]" aria-hidden="true">
              <span /> <span /> <span /> <span /> <span />
            </span>
          ) : thinking ? (
            <span className="flex items-center gap-1" aria-hidden="true">
              <span className="dot h-1.5 w-1.5 rounded-full bg-current" />
              <span className="dot h-1.5 w-1.5 rounded-full bg-current" />
              <span className="dot h-1.5 w-1.5 rounded-full bg-current" />
            </span>
          ) : (
            <IconMic size={22} />
          )}
        </button>

        {speaking && (
          <button
            type="button"
            onClick={onStopSpeaking}
            aria-label="Stop speaking"
            title="Stop speaking"
            className="absolute -right-1 -top-1 flex h-6 w-6 items-center justify-center rounded-full border border-line bg-surface text-muted shadow-[var(--shadow)] transition hover:text-danger"
          >
            <IconStop size={11} />
          </button>
        )}
      </div>

      <p className="h-4 text-[11.5px] text-muted">{LABEL[state]}</p>

      {!!partial && (
        <p dir="auto" className="max-w-md rounded-lg bg-surface-2 px-3 py-1.5 text-center text-[12.5px] italic text-ink-2">
          {partial}
        </p>
      )}
    </div>
  );
}

/** Compact mic for the composer toolbar. */
export function VoiceMicButton({
  state,
  disabled,
  onToggle,
}: {
  state: VoiceState;
  disabled?: boolean;
  onToggle: () => void;
}) {
  const listening = state === "listening";
  const speaking = state === "speaking";
  return (
    <button
      type="button"
      onClick={onToggle}
      disabled={disabled}
      aria-label={listening ? "Stop listening" : "Speak"}
      aria-pressed={listening}
      className={`relative flex h-8 w-8 items-center justify-center rounded-lg border transition disabled:opacity-40 ${
        listening
          ? "border-accent bg-accent text-accent-ink"
          : speaking
            ? "border-accent/40 bg-accent-soft text-accent"
            : "border-line text-ink-2 hover:border-accent/40 hover:text-ink"
      }`}
    >
      {listening && <span className="voice-ring pointer-events-none absolute inset-0 rounded-lg opacity-60" aria-hidden="true" />}
      <IconMic size={15} />
    </button>
  );
}

export function VoiceErrorBar({ message, onDismiss }: { message: string; onDismiss: () => void }) {
  return (
    <div className="flex items-center gap-2 border-b border-line bg-danger/8 px-4 py-2 text-[12.5px] text-ink-2">
      <span className="text-danger">
        <IconMic size={14} />
      </span>
      <p className="flex-1">{message}</p>
      <button type="button" onClick={onDismiss} aria-label="Dismiss" className="rounded p-1 text-muted transition hover:text-ink">
        <IconX size={13} />
      </button>
    </div>
  );
}
