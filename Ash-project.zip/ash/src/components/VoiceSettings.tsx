"use client";

import { useEffect, useState } from "react";
import { browserVoices, hasBrowserStt, hasBrowserTts, hasRecorder } from "@/lib/voice/client";
import type { VoiceSettings as VS } from "@/lib/useVoiceSession";
import { SPEECH_LANGUAGES } from "@/lib/prefs";

export interface ServerVoiceInfo {
  stt: { id: string; label: string }[];
  tts: { id: string; label: string }[];
}

function Row({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <label className="flex items-start justify-between gap-4 py-2">
      <span className="min-w-0">
        <span className="block text-[12.5px] font-medium">{label}</span>
        {hint && <span className="mt-0.5 block text-[11.5px] leading-snug text-muted">{hint}</span>}
      </span>
      <span className="shrink-0">{children}</span>
    </label>
  );
}

const select =
  "rounded-lg border border-line bg-surface-2 px-2 py-1.5 text-[12.5px] outline-none transition focus:border-accent/40 max-w-[190px]";

export default function VoiceSettings({
  value,
  onChange,
  pushToTalk,
  onPushToTalk,
  server,
}: {
  value: VS;
  onChange: (patch: Partial<VS>) => void;
  pushToTalk: boolean;
  onPushToTalk: (v: boolean) => void;
  server: ServerVoiceInfo | null;
}) {
  const [voices, setVoices] = useState<{ id: string; label: string; lang: string }[]>([]);
  const [device, setDevice] = useState({ stt: false, recorder: false, tts: false });

  useEffect(() => {
    setDevice({ stt: hasBrowserStt(), recorder: hasRecorder(), tts: hasBrowserTts() });
    const load = () => setVoices(browserVoices());
    load();
    const t = setTimeout(load, 600);
    return () => clearTimeout(t);
  }, []);

  const sttOptions = [
    ...(device.stt || device.recorder
      ? [{ id: "browser", label: device.stt ? "This device (free, instant)" : "This device (record & send)" }]
      : []),
    ...(server?.stt ?? []),
  ];
  const ttsOptions = [
    ...(device.tts ? [{ id: "browser", label: "This device (free, instant)" }] : []),
    ...(server?.tts ?? []),
  ];

  const matching = voices.filter((v) => {
    if (value.voiceLang === "auto") return true;
    return v.lang.toLowerCase().startsWith(value.voiceLang.split("-")[0].toLowerCase());
  });
  const voiceList = matching.length ? matching : voices;

  return (
    <div className="divide-y divide-line">
      <Row label="Listening engine" hint="What turns your speech into text.">
        <select value={value.sttProvider} onChange={(e) => onChange({ sttProvider: e.target.value })} className={select}>
          {sttOptions.length ? (
            sttOptions.map((o) => (
              <option key={o.id} value={o.id}>
                {o.label}
              </option>
            ))
          ) : (
            <option value="browser">Not available here</option>
          )}
        </select>
      </Row>

      <Row label="Speaking engine" hint="What reads answers out loud.">
        <select value={value.ttsProvider} onChange={(e) => onChange({ ttsProvider: e.target.value })} className={select}>
          {ttsOptions.length ? (
            ttsOptions.map((o) => (
              <option key={o.id} value={o.id}>
                {o.label}
              </option>
            ))
          ) : (
            <option value="browser">Not available here</option>
          )}
        </select>
      </Row>

      <Row label="Voice language" hint="Used for both listening and speaking.">
        <select value={value.voiceLang} onChange={(e) => onChange({ voiceLang: e.target.value, ttsVoice: "" })} className={select}>
          {SPEECH_LANGUAGES.map((l) => (
            <option key={l.code} value={l.code}>
              {l.label}
            </option>
          ))}
        </select>
      </Row>

      {value.ttsProvider === "browser" && (
        <Row label="Voice" hint={voiceList.length ? `${voiceList.length} available on this device` : "Loading device voices…"}>
          <select value={value.ttsVoice} onChange={(e) => onChange({ ttsVoice: e.target.value })} className={select}>
            <option value="">Best match</option>
            {voiceList.map((v) => (
              <option key={v.id} value={v.id}>
                {v.label} · {v.lang}
              </option>
            ))}
          </select>
        </Row>
      )}

      <Row label="Speaking speed" hint={`${value.rate.toFixed(1)}×`}>
        <input
          type="range"
          min={0.6}
          max={1.6}
          step={0.1}
          value={value.rate}
          onChange={(e) => onChange({ rate: Number(e.target.value) })}
          className="w-36 accent-[var(--accent)]"
        />
      </Row>

      <Row label="Volume" hint={`${Math.round(value.volume * 100)}%`}>
        <input
          type="range"
          min={0}
          max={1}
          step={0.05}
          value={value.volume}
          onChange={(e) => onChange({ volume: Number(e.target.value) })}
          className="w-36 accent-[var(--accent)]"
        />
      </Row>

      <Row label="Read answers aloud" hint="Speak every reply as soon as it finishes.">
        <input
          type="checkbox"
          checked={value.autoSpeak}
          onChange={(e) => onChange({ autoSpeak: e.target.checked })}
          className="h-4 w-4 accent-[var(--accent)]"
        />
      </Row>

      <Row label="Hands-free conversation" hint="After Ash finishes speaking, the microphone reopens by itself.">
        <input
          type="checkbox"
          checked={value.continuous}
          onChange={(e) => onChange({ continuous: e.target.checked, autoSpeak: e.target.checked ? true : value.autoSpeak })}
          className="h-4 w-4 accent-[var(--accent)]"
        />
      </Row>

      <Row label="Push to talk" hint="Hold the microphone button instead of tapping it.">
        <input
          type="checkbox"
          checked={pushToTalk}
          onChange={(e) => onPushToTalk(e.target.checked)}
          className="h-4 w-4 accent-[var(--accent)]"
        />
      </Row>
    </div>
  );
}
