/**
 * Runs once when the server process starts.
 * If learning was switched on, it picks up again by itself — nobody has to
 * open the Control Panel to restart it after a deploy or a crash.
 */
export async function register() {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;
  if (process.env.NEXT_PHASE === "phase-production-build") return;

  try {
    const { hydrateEnv } = await import("@/lib/settings");
    await hydrateEnv();
    const { resumeIfEnabled } = await import("@/lib/knowledge/trainer");
    await resumeIfEnabled();
  } catch {
    // never let background setup stop the server from serving
  }
}
