import type { SearchHit } from "@/lib/types";
import type { Settings } from "@/lib/settings";
import { buildSearchContext, shouldAutoSearch, webSearch } from "@/lib/search";
import { recall } from "@/lib/knowledge";
import { tryArithmetic } from "@/lib/providers/demo";
import { detectScript, unknownAnswer } from "@/lib/identity";

/**
 * Capabilities Ash can bring to a question.
 *
 * The point of this layer is restraint: a question only pays for the agents it
 * actually needs. The orchestrator asks each one "should you run?", runs the
 * few that say yes in priority order, and stops the moment one of them has a
 * complete answer.
 */

export interface AgentContext {
  question: string;
  /** Engine family the visitor picked: "smart", "brain", "demo" or a real provider. */
  mode: string;
  hasImages: boolean;
  /** true = user forced search on, false = forced off, undefined = decide. */
  searchChoice?: boolean;
  /** Visitor-level opt-out, independent of the owner setting. */
  useMemory?: boolean;
  settings: Settings;
  signal?: AbortSignal;
}

export interface AgentResult {
  /** Structured grounding appended to the system prompt. */
  context?: string;
  /** Citations the UI can show. Never invented. */
  sources?: SearchHit[];
  /** A complete answer — no model call needed. */
  answer?: string;
  /** Shown to the user as a small status line. */
  note?: string;
}

export interface Agent {
  id: string;
  label: string;
  description: string;
  /** Lower runs first. */
  priority: number;
  defaultEnabled: boolean;
  shouldRun(ctx: AgentContext): boolean;
  run(ctx: AgentContext): Promise<AgentResult | null>;
}

/* ─────────────────────────── the agents ─────────────────────────── */

const mathAgent: Agent = {
  id: "math",
  label: "Calculator",
  description: "Answers a plain arithmetic expression instantly, without spending an engine call.",
  priority: 10,
  defaultEnabled: true,
  shouldRun: (ctx) => !ctx.hasImages && ctx.question.length <= 120,
  async run(ctx) {
    const result = tryArithmetic(ctx.question);
    return result ? { answer: result } : null;
  },
};

const memoryAgent: Agent = {
  id: "memory",
  label: "Memory",
  description: "Looks the question up in what Ash has already learned before calling an engine.",
  priority: 20,
  defaultEnabled: true,
  shouldRun: (ctx) => ctx.useMemory !== false && (ctx.mode === "smart" || ctx.mode === "brain") && !ctx.hasImages,
  async run(ctx) {
    const hit = await recall(ctx.question).catch(() => null);
    if (hit?.answer && (hit.kind === "exact" || hit.kind === "similar")) {
      return { answer: hit.answer, note: hit.kind === "similar" ? "Answered from memory" : undefined };
    }
    // Memory-only mode has nowhere else to go, so be honest and stop here.
    if (ctx.mode === "brain") return { answer: unknownAnswer(detectScript(ctx.question)) };
    return null;
  },
};

const searchAgent: Agent = {
  id: "search",
  label: "Web search",
  description: "Fetches live results when the question needs current facts, and keeps the links as citations.",
  priority: 30,
  defaultEnabled: true,
  shouldRun(ctx) {
    if (ctx.settings.search.mode === "never" || ctx.searchChoice === false) return false;
    if (!ctx.question.trim()) return false;
    if (ctx.searchChoice === true || ctx.settings.search.mode === "always") return true;
    return shouldAutoSearch(ctx.question);
  },
  async run(ctx) {
    const outcome = await webSearch(ctx.question).catch(() => null);
    if (!outcome?.hits.length) return null;
    return {
      context: buildSearchContext(outcome.hits, outcome.pageText),
      sources: outcome.hits,
      note: "Searched the web",
    };
  },
};

export const AGENTS: Agent[] = [mathAgent, memoryAgent, searchAgent];

export function agentById(id: string): Agent | undefined {
  return AGENTS.find((a) => a.id === id);
}

export function agentEnabled(settings: Settings, agent: Agent): boolean {
  return settings.agents?.[agent.id]?.enabled ?? agent.defaultEnabled;
}

export interface OrchestrationResult {
  answer?: string;
  context: string;
  sources: SearchHit[];
  used: string[];
  notes: string[];
}

/** Central controller. Runs the few agents that apply, in priority order. */
export async function orchestrate(ctx: AgentContext): Promise<OrchestrationResult> {
  const out: OrchestrationResult = { context: "", sources: [], used: [], notes: [] };

  const candidates = AGENTS.filter((a) => agentEnabled(ctx.settings, a)).sort((a, b) => a.priority - b.priority);

  for (const agent of candidates) {
    let applies = false;
    try {
      applies = agent.shouldRun(ctx);
    } catch {
      applies = false;
    }
    if (!applies) continue;

    let result: AgentResult | null = null;
    try {
      result = await agent.run(ctx);
    } catch {
      // A broken tool must never break the answer.
      continue;
    }
    if (!result) continue;

    out.used.push(agent.id);
    if (result.note) out.notes.push(result.note);
    if (result.context) out.context += result.context;
    if (result.sources?.length) out.sources.push(...result.sources);
    if (result.answer) {
      out.answer = result.answer;
      break; // complete answer: stop, do not run the rest
    }
  }
  return out;
}
