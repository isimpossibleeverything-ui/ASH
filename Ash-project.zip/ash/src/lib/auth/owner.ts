import { createHmac, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import { getSetting, setSetting } from "@/lib/db/repo";
import { hit, clientIp } from "@/lib/ratelimit";

const HASH_KEY = "owner_password_hash";
const SECRET_KEY = "owner_auth_secret";
export const OWNER_COOKIE = "ash_owner";
const THIRTY_DAYS = 30 * 24 * 60 * 60;

let hashCache: { value: string | null; at: number } | null = null;
let secretCache: string | null = null;
const HASH_TTL = 10 * 60 * 1000; // 10 min, so DB read quotas never lock the owner out

export function hashPassword(password: string): string {
  const salt = randomBytes(16);
  const dk = scryptSync(password, salt, 64);
  return `scrypt:${salt.toString("hex")}:${dk.toString("hex")}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [scheme, saltHex, hashHex] = stored.split(":");
    if (scheme !== "scrypt" || !saltHex || !hashHex) return false;
    const dk = scryptSync(password, Buffer.from(saltHex, "hex"), 64);
    const expected = Buffer.from(hashHex, "hex");
    if (expected.length !== dk.length) return false;
    return timingSafeEqual(dk, expected);
  } catch {
    return false;
  }
}

export async function getOwnerHash(force = false): Promise<string | null> {
  if (!force && hashCache && Date.now() - hashCache.at < HASH_TTL) return hashCache.value;
  let value: string | null = null;
  try {
    value = await getSetting(HASH_KEY);
  } catch {
    value = hashCache?.value ?? null;
  }
  hashCache = { value, at: Date.now() };
  return value;
}

export async function setOwnerPassword(password: string): Promise<void> {
  const h = hashPassword(password);
  await setSetting(HASH_KEY, h);
  hashCache = { value: h, at: Date.now() };
  // rotate the signing secret so every old login is signed out
  secretCache = randomBytes(32).toString("hex");
  await setSetting(SECRET_KEY, secretCache);
}

async function getSecret(): Promise<string> {
  if (secretCache) return secretCache;
  let s = await getSetting(SECRET_KEY);
  if (!s) {
    s = randomBytes(32).toString("hex");
    await setSetting(SECRET_KEY, s);
  }
  secretCache = s;
  return s;
}

function b64url(input: string): string {
  return Buffer.from(input, "utf8").toString("base64url");
}

export async function createOwnerToken(): Promise<string> {
  const secret = await getSecret();
  const payload = b64url(JSON.stringify({ iat: Date.now(), exp: Date.now() + THIRTY_DAYS * 1000 }));
  const sig = createHmac("sha256", secret).update(payload).digest("base64url");
  return `${payload}.${sig}`;
}

export async function verifyOwnerToken(token: string | undefined | null): Promise<boolean> {
  if (!token || !token.includes(".")) return false;
  const [payload, sig] = token.split(".");
  if (!payload || !sig) return false;
  try {
    const secret = await getSecret();
    const expected = createHmac("sha256", secret).update(payload).digest("base64url");
    const a = Buffer.from(sig);
    const b = Buffer.from(expected);
    if (a.length !== b.length || !timingSafeEqual(a, b)) return false;
    const data = JSON.parse(Buffer.from(payload, "base64url").toString("utf8")) as { exp?: number };
    return typeof data.exp === "number" && data.exp > Date.now();
  } catch {
    return false;
  }
}

/**
 * Nobody has claimed this install yet. The Control Panel stays open so the
 * app is usable immediately; setting a password locks it to one person.
 */
export async function isUnclaimed(): Promise<boolean> {
  return !(await getOwnerHash());
}

export async function isOwner(): Promise<boolean> {
  if (await isUnclaimed()) return true;
  const jar = await cookies();
  return verifyOwnerToken(jar.get(OWNER_COOKIE)?.value);
}

export async function ownerExists(): Promise<boolean> {
  return !!(await getOwnerHash());
}

/** Use at the top of every owner-only API route. */
export async function requireOwner(): Promise<Response | null> {
  if (await isOwner()) return null;
  return Response.json({ error: "Owner access required." }, { status: 401 });
}

export function ownerCookieOptions(maxAge = THIRTY_DAYS) {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge,
  };
}

export function loginRateLimit(req: Request) {
  return hit(`owner-login:${clientIp(req)}`, 5, 60_000, "Too many attempts. Wait a minute and try again.");
}
