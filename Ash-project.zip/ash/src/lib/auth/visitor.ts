import { randomBytes } from "node:crypto";

export const VISITOR_COOKIE = "ash_vid";
const USER_COOKIE = "ash_uid";
const ONE_YEAR = 365 * 24 * 60 * 60;

function parseCookies(header: string | null): Record<string, string> {
  const out: Record<string, string> = {};
  if (!header) return out;
  for (const part of header.split(";")) {
    const i = part.indexOf("=");
    if (i < 0) continue;
    out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

export interface VisitorContext {
  /** The owner_key written on every conversation row. */
  key: string;
  visitorId: string;
  userId: string | null;
  /** Set-Cookie value to attach when the visitor is brand new. */
  setCookie?: string;
}

export function resolveVisitor(req: Request): VisitorContext {
  const jar = parseCookies(req.headers.get("cookie"));
  const userId = jar[USER_COOKIE] || null;
  let visitorId = jar[VISITOR_COOKIE];
  let setCookie: string | undefined;
  if (!visitorId || visitorId.length < 16) {
    visitorId = randomBytes(16).toString("hex");
    const secure = process.env.NODE_ENV === "production" ? "; Secure" : "";
    setCookie = `${VISITOR_COOKIE}=${visitorId}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${ONE_YEAR}${secure}`;
  }
  return { key: userId || visitorId, visitorId, userId, setCookie };
}

export function withVisitorCookie(res: Response, ctx: VisitorContext): Response {
  if (ctx.setCookie) res.headers.append("set-cookie", ctx.setCookie);
  return res;
}

export function userCookie(userId: string): string {
  const secure = process.env.NODE_ENV === "production" ? "; Secure" : "";
  return `${USER_COOKIE}=${encodeURIComponent(userId)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${ONE_YEAR}${secure}`;
}

export function clearUserCookie(): string {
  return `${USER_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`;
}
