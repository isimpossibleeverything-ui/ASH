/**
 * Languages that can actually run, mapped to the free Wandbox service.
 * `WANDBOX_LANGUAGES` maps a markdown fence tag to Wandbox's language name;
 * the server resolves the newest working compiler at runtime and falls back
 * to `WANDBOX_FALLBACK` if the service cannot be reached.
 */
export const WANDBOX_LANGUAGES: Record<string, string> = {
  python: "Python",
  python3: "Python",
  py: "Python",
  javascript: "JavaScript",
  js: "JavaScript",
  node: "JavaScript",
  typescript: "TypeScript",
  ts: "TypeScript",
  cpp: "C++",
  "c++": "C++",
  cc: "C++",
  c: "C",
  java: "Java",
  rust: "Rust",
  rs: "Rust",
  go: "Go",
  golang: "Go",
  php: "PHP",
  ruby: "Ruby",
  rb: "Ruby",
  csharp: "C#",
  "c#": "C#",
  cs: "C#",
  sql: "SQL",
  sqlite: "SQL",
  lua: "Lua",
  perl: "Perl",
  swift: "Swift",
  r: "R",
  haskell: "Haskell",
  hs: "Haskell",
  scala: "Scala",
  bash: "Bash script",
  sh: "Bash script",
  shell: "Bash script",
};

/** Used only when the live compiler list cannot be fetched. */
export const WANDBOX_FALLBACK: Record<string, string> = {
  Python: "cpython-3.14.0",
  JavaScript: "nodejs-20.17.0",
  TypeScript: "typescript-5.6.2",
  "C++": "gcc-13.2.0",
  C: "gcc-13.2.0-c",
  Java: "openjdk-jdk-22+36",
  Rust: "rust-1.82.0",
  Go: "go-1.23.2",
  PHP: "php-8.3.12",
  Ruby: "ruby-3.4.9",
  "C#": "mono-6.12.0.199",
  SQL: "sqlite-3.46.1",
  Lua: "lua-5.4.7",
  Perl: "perl-5.40.0",
  Swift: "swift-6.0.1",
  R: "r-4.4.1",
  Haskell: "ghc-9.10.1",
  Scala: "scala-3.5.1",
  "Bash script": "bash",
};

export const RUNNABLE_LANGUAGES = Object.keys(WANDBOX_LANGUAGES);

const PREVIEW_LANGUAGES = new Set(["html", "htm", "css", "jsx", "tsx", "react", "svg", "vue"]);

export function normaliseLang(lang: string | undefined | null): string {
  return (lang || "").trim().toLowerCase().replace(/^language-/, "");
}

export function isRunnable(lang: string | undefined | null): boolean {
  const l = normaliseLang(lang);
  if (!l) return false;
  if (isPreviewable(l)) return false;
  return !!WANDBOX_LANGUAGES[l];
}

export function isPreviewable(lang: string | undefined | null, code?: string): boolean {
  const l = normaliseLang(lang);
  if (PREVIEW_LANGUAGES.has(l)) return true;
  if ((l === "javascript" || l === "js") && code) {
    return /document\.|window\.|addEventListener|createRoot|ReactDOM/.test(code);
  }
  return false;
}

export function wandboxLanguage(lang: string): string | null {
  return WANDBOX_LANGUAGES[normaliseLang(lang)] ?? null;
}

const REACT_RUNTIME = `
<script src="https://cdnjs.cloudflare.com/ajax/libs/react/18.3.1/umd/react.production.min.js" crossorigin></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/react-dom/18.3.1/umd/react-dom.production.min.js" crossorigin></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/babel-standalone/7.24.7/babel.min.js" crossorigin></script>`;

const BASE_STYLE = `
<style>
  :root{color-scheme:light}
  *,*::before,*::after{box-sizing:border-box}
  body{margin:0;padding:20px;font-family:ui-sans-serif,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;color:#23221f;background:#faf9f5;line-height:1.6}
  h1,h2,h3{font-family:"Iowan Old Style","Palatino Linotype",Palatino,"Book Antiqua",Georgia,ui-serif,serif;letter-spacing:-.01em}
  button{font:inherit;padding:8px 14px;border-radius:10px;border:1px solid #e6e1d6;background:#fff;cursor:pointer}
  button:hover{border-color:#bd5d3a}
  pre,code{font-family:ui-monospace,"SF Mono",Menlo,Consolas,monospace}
</style>`;

export const SAMPLE_PREVIEW = `<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">${BASE_STYLE}</head>
<body>
  <h1>Code preview</h1>
  <p>Anything Ash writes in HTML, CSS, JavaScript or React renders here, live.</p>
  <button onclick="this.textContent='It works.'">Press me</button>
</body></html>`;

/** Builds one self-contained document for the sandboxed iframe. */
export function buildPreviewDoc(code: string, lang: string): string {
  const l = normaliseLang(lang);
  const trimmed = code.trim();

  if (l === "html" || l === "htm" || /^<!doctype html|^<html[\s>]/i.test(trimmed)) {
    if (/<head[\s>]/i.test(trimmed)) return trimmed.replace(/<head([^>]*)>/i, `<head$1>${BASE_STYLE}`);
    return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">${BASE_STYLE}</head><body>${trimmed}</body></html>`;
  }

  if (l === "css") {
    return `<!doctype html><html><head><meta charset="utf-8">${BASE_STYLE}<style>${trimmed}</style></head>
<body><h1>Heading</h1><p class="demo">A paragraph styled by the CSS above.</p><button class="demo">Button</button>
<div class="box card demo" style="margin-top:16px">A box with classes <code>box card demo</code>.</div></body></html>`;
  }

  if (l === "svg" || /^<svg[\s>]/i.test(trimmed)) {
    return `<!doctype html><html><head><meta charset="utf-8">${BASE_STYLE}</head><body style="display:grid;place-items:center;min-height:90vh">${trimmed}</body></html>`;
  }

  if (l === "jsx" || l === "tsx" || l === "react" || /export default function|ReactDOM|createRoot|from ['"]react['"]/.test(trimmed)) {
    const cleaned = trimmed
      .replace(/^\s*import[^\n]*from\s*['"][^'"]+['"];?\s*$/gm, "")
      .replace(/^\s*import\s+['"][^'"]+['"];?\s*$/gm, "")
      .replace(/export\s+default\s+function\s+([A-Za-z0-9_]+)/, "function $1")
      .replace(/export\s+default\s+/, "const __AshDefault = ")
      .replace(/^\s*export\s+(const|function|class)\s/gm, "$1 ");

    return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">${BASE_STYLE}${REACT_RUNTIME}</head>
<body><div id="root"></div>
<script type="text/babel" data-presets="env,react,typescript" data-type="module">
const { useState, useEffect, useRef, useMemo, useCallback, useReducer, Fragment } = React;
${cleaned}
(function mount(){
  const candidates = [typeof __AshDefault !== 'undefined' ? __AshDefault : null, typeof App !== 'undefined' ? App : null,
    typeof Main !== 'undefined' ? Main : null, typeof Page !== 'undefined' ? Page : null, typeof Component !== 'undefined' ? Component : null];
  const Root = candidates.find(c => typeof c === 'function');
  const el = document.getElementById('root');
  if (!Root) { el.innerHTML = '<p style="color:#b4443a">No React component was found to render. Name it <code>App</code> or export it as default.</p>'; return; }
  ReactDOM.createRoot(el).render(React.createElement(Root));
})();
</script></body></html>`;
  }

  // plain browser JavaScript
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">${BASE_STYLE}</head>
<body><div id="app"></div><script>
(function(){
  const log = [];
  const print = console.log.bind(console);
  console.log = function(...a){ log.push(a.map(String).join(' ')); print(...a); render(); };
  function render(){
    if(!log.length) return;
    let pre = document.getElementById('__ash_log');
    if(!pre){ pre = document.createElement('pre'); pre.id='__ash_log';
      pre.style.cssText='background:#f6f3ec;border:1px solid #e6e1d6;border-radius:12px;padding:12px;margin-top:16px;white-space:pre-wrap';
      document.body.appendChild(pre); }
    pre.textContent = log.join('\\n');
  }
  try { ${trimmed}
  } catch (e) { document.body.insertAdjacentHTML('beforeend','<pre style="color:#b4443a">'+String(e)+'</pre>'); }
})();
</script></body></html>`;
}
