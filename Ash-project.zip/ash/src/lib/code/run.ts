import { WANDBOX_FALLBACK, wandboxLanguage } from "./index";

/**
 * One shared program runner. The /api/run route and the Cowork agent both go
 * through this, so a compiler fix is never only half-applied.
 */

export const MAX_OUTPUT = 20_000;

export interface RunResult {
  ok: boolean;
  stdout: string;
  stderr: string;
  exitCode: number;
  truncated: boolean;
  compiler: string;
  error?: string;
  status?: number;
}

interface WandboxCompiler {
  name: string;
  language: string;
}

let compilerCache: { at: number; list: WandboxCompiler[] } | null = null;

/** The free list changes over time, so resolve the newest compiler live. */
export async function resolveCompiler(language: string): Promise<string | null> {
  const fallback = WANDBOX_FALLBACK[language] ?? null;
  try {
    if (!compilerCache || Date.now() - compilerCache.at > 60 * 60_000) {
      const res = await fetch("https://wandbox.org/api/list.json", { cache: "no-store", signal: AbortSignal.timeout(10_000) });
      if (!res.ok) return fallback;
      const list = (await res.json()) as WandboxCompiler[];
      if (Array.isArray(list) && list.length) compilerCache = { at: Date.now(), list };
    }
    const matches = (compilerCache?.list ?? [])
      .filter((c) => c.language === language)
      .map((c) => c.name)
      .filter((name) => !name.includes("head") && !name.startsWith("cpython-2"));
    return matches[0] ?? fallback;
  } catch {
    return fallback;
  }
}

export async function runProgram(input: { code: string; language: string; stdin?: string; timeoutMs?: number }): Promise<RunResult> {
  const fail = (error: string, status: number): RunResult => ({
    ok: false,
    stdout: "",
    stderr: "",
    exitCode: 1,
    truncated: false,
    compiler: "",
    error,
    status,
  });

  const code = input.code ?? "";
  if (!code.trim()) return fail("There is no code to run.", 400);
  if (code.length > 100_000) return fail("That program is too long to run here.", 400);

  const wandboxLang = wandboxLanguage(input.language);
  if (!wandboxLang) return fail(`${input.language || "This language"} cannot be run here.`, 400);

  const compiler = await resolveCompiler(wandboxLang);
  if (!compiler) return fail(`No free compiler is available for ${wandboxLang} right now.`, 503);

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), input.timeoutMs ?? 30_000);
  try {
    const res = await fetch("https://wandbox.org/api/compile.json", {
      method: "POST",
      cache: "no-store",
      signal: controller.signal,
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ code, compiler, stdin: (input.stdin ?? "").slice(0, 10_000), save: false }),
    });
    if (!res.ok) {
      const detail = (await res.text().catch(() => "")).slice(0, 160);
      return fail(`The free compiler service could not run that${detail ? ` (${detail})` : ""}.`, 502);
    }
    const data = (await res.json()) as Record<string, unknown>;
    const rawOut = String(data.program_output ?? "");
    return {
      ok: true,
      stdout: rawOut.slice(0, MAX_OUTPUT),
      stderr: String(data.program_error ?? data.compiler_error ?? "").slice(0, MAX_OUTPUT),
      exitCode: Number(data.status ?? 0),
      truncated: rawOut.length > MAX_OUTPUT,
      compiler,
    };
  } catch (err) {
    const aborted = (err as Error)?.name === "AbortError";
    return fail(
      aborted ? "The program took longer than 30 seconds and was stopped." : "Could not reach the free compiler service.",
      504,
    );
  } finally {
    clearTimeout(timer);
  }
}
