import { buildChain, providerFor, resolveModel, runtimeModels, type RuntimeModel } from "@/lib/providers";
import type { ProviderMessage } from "@/lib/providers/types";
import { isNetworkError, ProviderError, scrubSecrets } from "@/lib/providers/sse";
import { classifyFailure, coolingInfo, park } from "@/lib/providers/health";
import { getSettings } from "@/lib/settings";
import { DEFAULT_BRANDING } from "@/lib/identity";
import * as store from "./store";
import { executeTool, TOOL_HELP } from "./tools";
import {
  DESTRUCTIVE,
  LIMITS,
  TOOL_NAMES,
  type AgentAction,
  type CoworkEvent,
  type CoworkSession,
  type PlanItem,
  type ToolName,
} from "./types";

/* ── live run registry: lets a second request pause or cancel a run ──── */

const running = new Map<string, AbortController>();

export function isRunning(sessionId: string): boolean {
  return running.has(sessionId);
}

export function stopRun(sessionId: string): boolean {
  const c = running.get(sessionId);
  if (!c) return false;
  c.abort();
  running.delete(sessionId);
  return true;
}

/* ── protocol parsing ────────────────────────────────────────────────── */

const OPEN = "<<<ASH";
const CLOSE = "ASH>>>";

/**
 * The model answers in a tiny line protocol rather than JSON, because small
 * free models mangle JSON escaping the moment a file contains quotes or
 * newlines — and file contents are the whole point of this mode.
 */
export function parseAction(raw: string): AgentAction | null {
  let text = (raw || "").trim();
  if (!text) return null;

  // strip a stray markdown fence around the whole reply
  const fenced = text.match(/^```[a-zA-Z]*\n([\s\S]*?)\n?```$/);
  if (fenced) text = fenced[1].trim();

  const openIdx = text.indexOf(OPEN);
  const head = (openIdx >= 0 ? text.slice(0, openIdx) : text).split(/\r?\n/);

  let body = "";
  if (openIdx >= 0) {
    const after = text.slice(openIdx + OPEN.length).replace(/^\r?\n/, "");
    const closeIdx = after.lastIndexOf(CLOSE);
    body = (closeIdx >= 0 ? after.slice(0, closeIdx) : after).replace(/\r?\n$/, "");
  }

  const args: Record<string, string> = {};
  let step = "";
  let tool = "";
  for (const line of head) {
    const m = line.match(/^\s*([A-Za-z_]{2,12})\s*:\s*(.*)$/);
    if (!m) continue;
    const key = m[1].toLowerCase();
    const value = m[2].trim().replace(/^["'`]|["'`]$/g, "");
    if (key === "step") step = value;
    else if (key === "tool" || key === "action") tool = value.toLowerCase().replace(/[^a-z_]/g, "");
    else if (key === "thought") continue;
    else args[key] = value;
  }

  if (!tool) return null;
  if (!TOOL_NAMES.includes(tool as ToolName)) {
    const guess = TOOL_NAMES.find((t) => tool.includes(t) || t.includes(tool));
    if (!guess) return null;
    tool = guess;
  }

  /* Some engines put the header lines inside the body block. Lift any that
     are missing from the head rather than failing the whole action. */
  let cleanBody = body;
  if (!args.path && !args.query && !args.prompt) {
    const bodyLines = cleanBody.split(/\r?\n/);
    let lifted = 0;
    while (bodyLines.length) {
      const m = bodyLines[0].match(/^\s*(path|file|filename|lang|language|query|prompt|stdin)\s*:\s*(.+)$/i);
      if (!m) break;
      args[m[1].toLowerCase()] = m[2].trim().replace(/^["'`]|["'`]$/g, "");
      bodyLines.shift();
      if (++lifted > 4) break;
    }
    if (lifted) cleanBody = bodyLines.join("\n").replace(/^\n+/, "");
  }

  return {
    step: step || tool.replace(/_/g, " "),
    tool: tool as ToolName,
    args,
    body: cleanBody.slice(0, LIMITS.maxBodyChars),
  };
}

/* ── model access ────────────────────────────────────────────────────── */

interface Completion {
  text: string;
  model: RuntimeModel | null;
  /** Plain-language reason when nothing could answer. */
  problem?: string;
}

/**
 * Walks the normal fallback chain and returns one complete reply.
 * A failing engine is parked in provider_state exactly as the chat route does
 * it, so the very next step skips the dead one instead of hammering it.
 */
export async function complete(
  chain: RuntimeModel[],
  messages: ProviderMessage[],
  system: string,
  signal: AbortSignal,
  onEngine?: (m: RuntimeModel) => void,
  onTrying?: (m: RuntimeModel) => void,
): Promise<Completion> {
  const problems: string[] = [];

  for (const model of chain) {
    if (signal.aborted) break;
    const resting = await coolingInfo(model.key);
    if (resting) {
      // say WHY, otherwise the owner just sees "no engine was available"
      problems.push(
        `${model.label} is resting (${
          resting.state === "badkey"
            ? "its key was refused"
            : resting.state === "daily"
              ? "free allowance used up for today"
              : "it was busy a moment ago"
        })`,
      );
      continue;
    }
    // one engine must never be able to hold the whole task hostage
    const clock = new AbortController();
    const relay = () => clock.abort();
    signal.addEventListener("abort", relay, { once: true });
    const timer = setTimeout(() => clock.abort(), LIMITS.engineTimeoutMs);
    try {
      const provider = await providerFor(model);
      if (!provider.isConfigured()) continue;
      onTrying?.(model);
      let text = "";
      for await (const chunk of provider.stream({
        model: model.modelId,
        messages,
        system,
        temperature: 0.2,
        signal: clock.signal,
      })) {
        text += chunk;
        if (text.length > 200_000) break;
      }
      if (text.trim()) {
        // only now is it true that this engine is doing the work
        onEngine?.(model);
        return { text, model };
      }
      await park(model.key, 500, "The engine returned nothing.").catch(() => {});
      problems.push(`${model.label} returned nothing`);
    } catch (err) {
      if (signal.aborted) break;
      if (clock.signal.aborted) {
        await park(model.key, 408, "The engine did not answer in time.").catch(() => {});
        problems.push(`${model.label} did not answer in time`);
        continue;
      }
      const status = err instanceof ProviderError ? err.status : isNetworkError(err) ? 0 : 500;
      const raw = scrubSecrets(err instanceof Error ? err.message : String(err));
      await park(model.key, status, raw).catch(() => {});
      const { state } = classifyFailure(status, raw);
      problems.push(
        `${model.label} ${
          state === "badkey"
            ? "would not accept its key"
            : state === "daily"
              ? "has used up its free allowance for today"
              : "was busy"
        }`,
      );
    } finally {
      clearTimeout(timer);
      signal.removeEventListener("abort", relay);
    }
  }

  return { text: "", model: null, problem: problems.length ? problems.join("; ") : "no engine was available" };
}

export async function chainFor(session: CoworkSession, signal: AbortSignal): Promise<RuntimeModel[]> {
  void signal;
  const requested = session.model ? await resolveModel(session.model) : null;
  // allModels: a long job must be able to drop to a sibling model when the
  // leader is briefly overloaded, instead of giving up on the whole provider.
  const chain = await buildChain(requested, { realEnginesOnly: true, allModels: true });
  if (chain.length) return chain;
  // last resort so the mode never dead-ends on a blank screen
  return (await runtimeModels()).filter((m) => m.configured && m.enabled);
}

/* ── prompts ─────────────────────────────────────────────────────────── */

async function systemPrompt(): Promise<string> {
  const settings = await getSettings();
  const name = settings.branding.name || DEFAULT_BRANDING.name;
  return `You are ${name} working in Cowork mode. You are not chatting — you are doing the job yourself, like a capable colleague who was handed a task.

You work inside one private folder for this task. These are the only tools that exist:

${TOOL_HELP}

Reply with EXACTLY ONE action and nothing else, in this exact shape:

STEP: <short title, at most 8 words>
TOOL: <one tool name from the list>
PATH: <only when the tool takes a path>
LANG: <only for run_code>
QUERY: <only for web_search>
PROMPT: <only for make_image>
${OPEN}
<the body, only for tools that take one>
${CLOSE}

Hard rules:
- One action per reply. No greetings, no commentary outside the shape above.
- write_file, append_file, read_file and delete_file ALWAYS need a PATH: line above the body. Without it the action is thrown away.
- Never claim you wrote a file — actually call write_file.
- Never invent the contents of a file: call read_file first.
- Never invent facts, numbers, names, dates or links. If you need a real fact, call web_search.
- Keep files complete and genuinely useful. A report means real prose, not an outline of what you would write.
- Work in the same language the goal is written in.
- Do the fewest steps that finish the job properly, then call finish with a short summary of what you made.
- If the goal is impossible with these tools, call finish and say plainly what you could not do.`;
}

async function planSystemPrompt(): Promise<string> {
  const settings = await getSettings();
  const name = settings.branding.name || DEFAULT_BRANDING.name;
  return `You are ${name}, planning a piece of work before starting it. Answer with a plain list of steps and absolutely nothing else — no tool names, no code, no markers, no explanation.`;
}

function planPrompt(goal: string): ProviderMessage[] {
  return [
    {
      role: "user",
      content: `Here is the task:

${goal}

Write the plan you will follow, as 2 to 6 short steps. One step per line, each starting with "- ". No numbering, no explanation, no preamble, nothing after the list. Write the steps in the same language as the task.`,
    },
  ];
}

/** Protocol fragments an engine may leak into a plan. They are never steps. */
const PROTOCOL_LINE = /^(step|tool|action|path|lang|language|query|prompt|thought|body|stdin)\s*:/i;

function parsePlan(text: string): PlanItem[] {
  const lines = text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l && l !== OPEN && l !== CLOSE && !l.startsWith("```") && !PROTOCOL_LINE.test(l))
    .map((l) => l.replace(/^\s*(?:[-*•]|\d+[.)])\s*/, "").trim())
    .filter((l) => l.length > 3 && l.length < 200 && !/^(plan|steps?|here(?:'s| is)?\b)/i.test(l));

  const seen = new Set<string>();
  const unique = lines.filter((l) => {
    const k = l.toLowerCase();
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });
  return unique.slice(0, 6).map((title, i) => ({ id: `p${i + 1}`, title, status: "pending" as const }));
}

/* ── the loop ────────────────────────────────────────────────────────── */

export interface RunOptions {
  session: CoworkSession;
  /** Extra instruction typed or spoken by the human mid-run. */
  steer?: string;
  emit: (event: CoworkEvent) => void;
  signal: AbortSignal;
}

export async function runSession({ session, steer, emit, signal }: RunOptions): Promise<void> {
  const sessionId = session.id;
  if (running.has(sessionId)) {
    emit({ type: "notice", text: "This task is already running." });
    return;
  }

  const controller = new AbortController();
  running.set(sessionId, controller);
  const onOuterAbort = () => controller.abort();
  signal.addEventListener("abort", onOuterAbort);

  const stopped = () => controller.signal.aborted;

  try {
    const settings = await getSettings();
    const maxSteps = Math.min(60, Math.max(4, Number(settings.cowork?.maxSteps) || LIMITS.maxSteps));
    const system = await systemPrompt();
    const chain = await chainFor(session, controller.signal);
    if (!chain.length) {
      emit({ type: "error", message: "No engine is set up yet, so there is nothing to work with. Add a key in the Control Panel." });
      await store.patchSession(sessionId, { status: "failed" });
      emit({ type: "status", status: "failed" });
      return;
    }

    let announced = "";
    const announce = (m: RuntimeModel) => {
      if (m.publicCode === announced) return;
      announced = m.publicCode;
      emit({ type: "notice", text: `Working with ${m.label}.` });
    };
    // Saying "Working with X" before X has produced a single character is a
    // small lie that reads as a freeze when X is down. Report attempts
    // separately, and only claim an engine once it has actually answered.
    const trying = (m: RuntimeModel) => {
      if (m.publicCode === announced) return;
      emit({ type: "thinking", text: `Asking ${m.label}…` });
    };

    /* 1 — a plan, if there isn't one yet */
    let plan = session.plan;
    if (!plan.length) {
      await store.patchSession(sessionId, { status: "planning" });
      emit({ type: "status", status: "planning" });
      const got = await complete(chain, planPrompt(session.goal), await planSystemPrompt(), controller.signal, announce, trying);
      if (!got.text.trim()) {
        const why = got.problem ?? "no engine was available";
        const message = `I could not start: ${why}. Add or refresh a key in the Control Panel, then press play.`;
        await store.patchSession(sessionId, { status: "failed", summary: message });
        emit({ type: "error", message });
        emit({ type: "status", status: "failed" });
        return;
      }
      plan = parsePlan(got.text);
      if (!plan.length) plan = [{ id: "p1", title: session.goal.slice(0, 120), status: "pending" }];
      await store.patchSession(sessionId, { plan });
      emit({ type: "plan", plan });
    }

    if (stopped()) return;

    await store.patchSession(sessionId, { status: "running" });
    emit({ type: "status", status: "running" });

    /* 2 — rebuild the agent's memory from what already happened */
    const history: ProviderMessage[] = [{ role: "user", content: `TASK:\n${session.goal}\n\nPLAN:\n${plan.map((p) => `- ${p.title}`).join("\n")}` }];
    const pastRaw = await store.listSteps(sessionId);

    /* A step still marked "running" belongs to a run that was killed. Leaving
       it like that lets the engine believe work happened that never did, so
       reconcile it to the truth before replaying any history. */
    for (const s of pastRaw) {
      if (s.status !== "running") continue;
      const honest = "This step did not finish — the run was interrupted.";
      await store.updateStep(s.id, "error", honest);
      s.status = "error";
      s.output = honest;
      emit({ type: "step-update", id: s.id, status: "error", output: honest });
    }
    const past = pastRaw;

    for (const s of past.slice(-LIMITS.memoryWindow)) {
      if (!s.tool) continue;
      history.push({ role: "assistant", content: `STEP: ${s.title}\nTOOL: ${s.tool}` });
      history.push({ role: "user", content: `OBSERVATION: ${s.output || (s.status === "ok" ? "ok" : s.status)}` });
    }
    if (steer?.trim()) {
      history.push({ role: "user", content: `NEW INSTRUCTION FROM THE HUMAN: ${steer.trim()}\nTake this into account from now on.` });
    }

    /* 3 — resume anything the human was asked to approve */
    const pending = past.find((s) => s.status === "awaiting");
    let resumed: AgentAction | null = null;
    /** True for exactly one iteration: the human already said yes to it. */
    let preApproved = false;
    if (pending) {
      const decision = pending.args.decision ?? "";
      if (decision === "approved") {
        resumed = { step: pending.title, tool: pending.tool as ToolName, args: pending.args, body: pending.args.body ?? "" };
        preApproved = true;
        await store.updateStep(pending.id, "running", "Approved by you.");
        emit({ type: "step-update", id: pending.id, status: "running", output: "Approved by you." });
      } else {
        await store.updateStep(pending.id, "skipped", "You refused this step.");
        emit({ type: "step-update", id: pending.id, status: "skipped", output: "You refused this step." });
        history.push({ role: "user", content: `OBSERVATION: the human refused ${pending.tool}. Do not try it again; find another way or finish.` });
      }
    }

    /* 4 — plan → act → observe, until finished */
    let planCursor = plan.findIndex((p) => p.status !== "done");
    if (planCursor < 0) planCursor = 0;
    let budget = maxSteps - past.filter((s) => s.status === "ok" || s.status === "error").length;
    let strikes = 0;
    let finishedSummary: string | null = null;

    while (budget-- > 0 && !stopped()) {
      // a pause or cancel may have arrived from another request while we worked
      const live = await store.sessionStatus(sessionId).catch(() => null);
      if (live === "paused" || live === "cancelled") {
        emit({ type: "notice", text: live === "paused" ? "Paused." : "Cancelled." });
        emit({ type: "status", status: live });
        return;
      }

      let action = resumed;
      resumed = null;
      const alreadyApproved = preApproved;
      preApproved = false;

      if (!action) {
        emit({ type: "thinking", text: "Deciding the next step…" });
        const reply = await complete(chain, history, system, controller.signal, announce, trying);
        if (stopped()) break;

        if (!reply.text.trim()) {
          /* every engine is down — say so once and stop, rather than
             burning the whole step budget on a wall. */
          if (++strikes >= 2) {
            const why = reply.problem ?? "no engine was available";
            const message = `I had to stop: ${why}. Nothing was lost — press play once an engine is working again.`;
            await store.patchSession(sessionId, { status: "failed", summary: message });
            emit({ type: "error", message });
            emit({ type: "status", status: "failed" });
            return;
          }
          emit({ type: "notice", text: `${reply.problem ?? "An engine was busy"}. Trying once more…` });
          await new Promise((r) => setTimeout(r, 1_500));
          continue;
        }

        action = parseAction(reply.text);
        if (!action) {
          if (++strikes >= 4) {
            const message = "The engine kept replying with prose instead of an action, so I stopped. Try a simpler goal, or a different engine.";
            await store.patchSession(sessionId, { status: "failed", summary: message });
            emit({ type: "error", message });
            emit({ type: "status", status: "failed" });
            return;
          }
          history.push({ role: "assistant", content: reply.text.slice(0, 500) });
          history.push({
            role: "user",
            content: `OBSERVATION: that was not a valid action. Reply with ONLY the STEP/TOOL block described in your instructions.`,
          });
          continue;
        }
        strikes = 0;
        history.push({ role: "assistant", content: `STEP: ${action.step}\nTOOL: ${action.tool}` });
      }

      /* approval gate for anything destructive */
      const needsApproval = DESTRUCTIVE.includes(action.tool) && !session.autoApprove && !alreadyApproved;
      const seq = await store.nextSeq(sessionId);

      if (needsApproval) {
        const step = await store.addStep({
          sessionId,
          seq,
          title: action.step,
          tool: action.tool,
          args: { ...action.args, body: action.body.slice(0, 4_000) },
          status: "awaiting",
          output: "Waiting for you to approve this.",
        });
        emit({ type: "step", step });
        emit({ type: "approval", stepId: step.id, tool: action.tool, args: action.args });
        await store.patchSession(sessionId, { status: "awaiting" });
        emit({ type: "status", status: "awaiting" });
        return;
      }

      const step = alreadyApproved && pending
        ? pending
        : await store.addStep({
            sessionId,
            seq,
            title: action.step,
            tool: action.tool,
            args: action.args,
            status: "running",
          });
      if (!alreadyApproved) emit({ type: "step", step });

      const outcome = await executeTool(
        { sessionId, signal: controller.signal, onNotice: (t) => emit({ type: "notice", text: t }) },
        action,
      );

      const shown = outcome.detail?.trim() || outcome.observation;
      await store.updateStep(step.id, outcome.ok ? "ok" : "error", shown);
      emit({ type: "step-update", id: step.id, status: outcome.ok ? "ok" : "error", output: shown });

      if (outcome.file) {
        if (action.tool === "delete_file") emit({ type: "file-removed", path: outcome.file.path });
        else {
          const files = await store.listFiles(sessionId);
          const f = files.find((x) => x.path === outcome.file?.path);
          if (f) emit({ type: "file", file: f });
        }
      }

      history.push({ role: "user", content: `OBSERVATION: ${outcome.observation}` });
      while (history.length > 2 * LIMITS.memoryWindow + 2) history.splice(1, 2);

      /* tick the plan along when a real piece of work lands */
      if (outcome.ok && action.tool !== "note" && action.tool !== "list_files" && planCursor < plan.length) {
        plan = plan.map((p, i) => (i === planCursor ? { ...p, status: "done" as const } : i === planCursor + 1 ? { ...p, status: "active" as const } : p));
        planCursor += 1;
        await store.patchSession(sessionId, { plan });
        emit({ type: "plan", plan });
      }

      if (outcome.finished) {
        const given = outcome.detail?.trim() ?? "";
        // some engines call finish with an empty body; never echo the step title back
        const weak = given.length < 15 || given.toLowerCase() === action.step.toLowerCase();
        if (weak) {
          const made = await store.listFiles(sessionId);
          finishedSummary = made.length
            ? `Done. I made ${made.length} file${made.length === 1 ? "" : "s"}: ${made.map((f) => f.path).join(", ")}.`
            : "Done — though nothing was saved to a file.";
        } else {
          finishedSummary = given;
        }
        break;
      }
    }

    if (stopped()) {
      await store.patchSession(sessionId, { status: "paused" });
      emit({ type: "status", status: "paused" });
      return;
    }

    const files = await store.listFiles(sessionId);
    const summary =
      finishedSummary ??
      (files.length
        ? `Stopped after ${maxSteps} steps. ${files.length} file${files.length === 1 ? "" : "s"} were produced — you can carry on from here.`
        : `Stopped after ${maxSteps} steps without finishing. Try a smaller, more specific goal.`);

    plan = plan.map((p) => (p.status === "pending" || p.status === "active" ? { ...p, status: finishedSummary ? ("done" as const) : ("skipped" as const) } : p));
    await store.patchSession(sessionId, { status: finishedSummary ? "done" : "failed", summary, plan });
    emit({ type: "plan", plan });
    emit({ type: "done", summary });
    emit({ type: "status", status: finishedSummary ? "done" : "failed" });
  } catch (err) {
    const message = (err as Error)?.message || "Something went wrong while working.";
    await store.patchSession(sessionId, { status: "failed", summary: message }).catch(() => {});
    emit({ type: "error", message });
    emit({ type: "status", status: "failed" });
  } finally {
    signal.removeEventListener("abort", onOuterAbort);
    running.delete(sessionId);
  }
}
