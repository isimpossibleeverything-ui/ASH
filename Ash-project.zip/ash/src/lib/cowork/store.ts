import { randomUUID } from "node:crypto";
import { all, one, run, sql } from "@/lib/db";
import type {
  CoworkFile,
  CoworkFileFull,
  CoworkSession,
  CoworkStep,
  PlanItem,
  SessionStatus,
  StepStatus,
  ToolName,
} from "./types";
import { LIMITS } from "./types";

const n = (v: unknown): number => (typeof v === "number" ? v : Number(v ?? 0));
const s = (v: unknown): string => (v == null ? "" : String(v));
const sn = (v: unknown): string | null => (v == null ? null : String(v));

const newId = (): string => randomUUID();

function parsePlan(raw: unknown): PlanItem[] {
  try {
    const v = JSON.parse(s(raw) || "[]");
    if (!Array.isArray(v)) return [];
    return v
      .filter((x): x is PlanItem => !!x && typeof x === "object" && typeof (x as PlanItem).title === "string")
      .map((x) => ({ id: s(x.id) || newId(), title: s(x.title).slice(0, 160), status: x.status ?? "pending" }));
  } catch {
    return [];
  }
}

function toSession(r: Record<string, unknown>): CoworkSession {
  return {
    id: s(r.id),
    title: s(r.title),
    goal: s(r.goal),
    status: (s(r.status) || "idle") as SessionStatus,
    plan: parsePlan(r.plan),
    summary: sn(r.summary),
    model: sn(r.model),
    autoApprove: n(r.auto_approve) === 1,
    createdAt: n(r.created_at),
    updatedAt: n(r.updated_at),
  };
}

function toStep(r: Record<string, unknown>): CoworkStep {
  let args: Record<string, string> = {};
  try {
    const parsed: unknown = JSON.parse(s(r.args) || "{}");
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      args = Object.fromEntries(Object.entries(parsed as Record<string, unknown>).map(([k, v]) => [k, s(v)]));
    }
  } catch {
    args = {};
  }
  return {
    id: s(r.id),
    sessionId: s(r.session_id),
    seq: n(r.seq),
    title: s(r.title),
    tool: (s(r.tool) || "") as ToolName | "",
    args,
    output: s(r.output),
    status: (s(r.status) || "running") as StepStatus,
    createdAt: n(r.created_at),
  };
}

function toFile(r: Record<string, unknown>): CoworkFile {
  return {
    id: s(r.id),
    sessionId: s(r.session_id),
    path: s(r.path),
    kind: (s(r.kind) || "text") as CoworkFile["kind"],
    bytes: n(r.bytes),
    updatedAt: n(r.updated_at),
  };
}

/* ───────────────────────────── sessions ───────────────────────────── */

export async function listSessions(ownerKey: string): Promise<CoworkSession[]> {
  const rows = await all(
    sql`SELECT * FROM cowork_sessions WHERE owner_key = ${ownerKey} ORDER BY updated_at DESC LIMIT 100`,
  );
  return rows.map(toSession);
}

export async function createSession(input: {
  ownerKey: string;
  goal: string;
  title?: string;
  model?: string | null;
  autoApprove?: boolean;
}): Promise<CoworkSession> {
  const now = Date.now();
  const id = newId();
  const goal = input.goal.slice(0, LIMITS.maxGoalChars);
  const title = (input.title || titleFromGoal(goal)).slice(0, 120);
  await run(
    sql`INSERT INTO cowork_sessions (id, owner_key, title, goal, status, plan, summary, model, auto_approve, created_at, updated_at)
        VALUES (${id}, ${input.ownerKey}, ${title}, ${goal}, 'idle', '[]', NULL, ${input.model ?? null}, ${
          input.autoApprove ? 1 : 0
        }, ${now}, ${now})`,
  );
  return {
    id,
    title,
    goal,
    status: "idle",
    plan: [],
    summary: null,
    model: input.model ?? null,
    autoApprove: !!input.autoApprove,
    createdAt: now,
    updatedAt: now,
  };
}

export function titleFromGoal(goal: string): string {
  const first = goal.trim().split(/\r?\n/)[0] ?? "";
  const clean = first.replace(/^[-*\d.)\s]+/, "").trim();
  if (!clean) return "New task";
  return clean.length > 60 ? `${clean.slice(0, 57).trimEnd()}…` : clean;
}

export async function getSession(id: string, ownerKey: string): Promise<CoworkSession | null> {
  const row = await one(sql`SELECT * FROM cowork_sessions WHERE id = ${id} AND owner_key = ${ownerKey}`);
  return row ? toSession(row) : null;
}

/** Status only, without an owner check — for the running loop, which already owns it. */
export async function sessionStatus(id: string): Promise<SessionStatus | null> {
  const row = await one(sql`SELECT status FROM cowork_sessions WHERE id = ${id}`);
  const v = row ? s(row.status) : "";
  return v ? (v as SessionStatus) : null;
}

export async function patchSession(
  id: string,
  patch: Partial<Pick<CoworkSession, "title" | "goal" | "status" | "plan" | "summary" | "model" | "autoApprove">>,
): Promise<void> {
  const now = Date.now();
  if (patch.title !== undefined) await run(sql`UPDATE cowork_sessions SET title = ${patch.title.slice(0, 120)} WHERE id = ${id}`);
  if (patch.goal !== undefined)
    await run(sql`UPDATE cowork_sessions SET goal = ${patch.goal.slice(0, LIMITS.maxGoalChars)} WHERE id = ${id}`);
  if (patch.status !== undefined) await run(sql`UPDATE cowork_sessions SET status = ${patch.status} WHERE id = ${id}`);
  if (patch.plan !== undefined) await run(sql`UPDATE cowork_sessions SET plan = ${JSON.stringify(patch.plan)} WHERE id = ${id}`);
  if (patch.summary !== undefined) await run(sql`UPDATE cowork_sessions SET summary = ${patch.summary} WHERE id = ${id}`);
  if (patch.model !== undefined) await run(sql`UPDATE cowork_sessions SET model = ${patch.model} WHERE id = ${id}`);
  if (patch.autoApprove !== undefined)
    await run(sql`UPDATE cowork_sessions SET auto_approve = ${patch.autoApprove ? 1 : 0} WHERE id = ${id}`);
  await run(sql`UPDATE cowork_sessions SET updated_at = ${now} WHERE id = ${id}`);
}

export async function deleteSession(id: string, ownerKey: string): Promise<boolean> {
  const existing = await getSession(id, ownerKey);
  if (!existing) return false;
  // explicit child deletes: ON DELETE CASCADE needs a pragma that not every driver honours
  await run(sql`DELETE FROM cowork_files WHERE session_id = ${id}`);
  await run(sql`DELETE FROM cowork_steps WHERE session_id = ${id}`);
  await run(sql`DELETE FROM cowork_sessions WHERE id = ${id}`);
  return true;
}

export async function countSessions(): Promise<number> {
  const row = await one<{ c: number }>(sql`SELECT COUNT(*) AS c FROM cowork_sessions`);
  return n(row?.c);
}

/* ───────────────────────────── steps ───────────────────────────── */

export async function listSteps(sessionId: string): Promise<CoworkStep[]> {
  const rows = await all(sql`SELECT * FROM cowork_steps WHERE session_id = ${sessionId} ORDER BY seq ASC LIMIT 400`);
  return rows.map(toStep);
}

export async function nextSeq(sessionId: string): Promise<number> {
  const row = await one<{ m: number }>(sql`SELECT COALESCE(MAX(seq), 0) AS m FROM cowork_steps WHERE session_id = ${sessionId}`);
  return n(row?.m) + 1;
}

export async function addStep(input: {
  sessionId: string;
  seq: number;
  title: string;
  tool: ToolName | "";
  args: Record<string, string>;
  status?: StepStatus;
  output?: string;
}): Promise<CoworkStep> {
  const now = Date.now();
  const id = newId();
  const args = JSON.stringify(input.args ?? {}).slice(0, 8_000);
  const status = input.status ?? "running";
  const output = (input.output ?? "").slice(0, LIMITS.maxObservationChars);
  await run(
    sql`INSERT INTO cowork_steps (id, session_id, seq, title, tool, args, output, status, created_at)
        VALUES (${id}, ${input.sessionId}, ${input.seq}, ${input.title.slice(0, 160)}, ${input.tool}, ${args}, ${output}, ${status}, ${now})`,
  );
  return {
    id,
    sessionId: input.sessionId,
    seq: input.seq,
    title: input.title.slice(0, 160),
    tool: input.tool,
    args: input.args ?? {},
    output,
    status,
    createdAt: now,
  };
}

export async function updateStep(id: string, status: StepStatus, output: string): Promise<void> {
  await run(sql`UPDATE cowork_steps SET status = ${status}, output = ${output.slice(0, LIMITS.maxObservationChars)} WHERE id = ${id}`);
}

/** Records the human's approve/reject answer on the step that is waiting. */
export async function setStepDecision(id: string, decision: "approved" | "rejected"): Promise<void> {
  const step = await getStep(id);
  if (!step) return;
  const args = JSON.stringify({ ...step.args, decision }).slice(0, 8_000);
  await run(sql`UPDATE cowork_steps SET args = ${args} WHERE id = ${id}`);
}

export async function getStep(id: string): Promise<CoworkStep | null> {
  const row = await one(sql`SELECT * FROM cowork_steps WHERE id = ${id}`);
  return row ? toStep(row) : null;
}

/* ───────────────────────────── files ───────────────────────────── */

export async function listFiles(sessionId: string): Promise<CoworkFile[]> {
  const rows = await all(
    sql`SELECT id, session_id, path, kind, bytes, updated_at FROM cowork_files WHERE session_id = ${sessionId} ORDER BY path ASC LIMIT 200`,
  );
  return rows.map(toFile);
}

export async function readFile(sessionId: string, path: string): Promise<CoworkFileFull | null> {
  const row = await one(sql`SELECT * FROM cowork_files WHERE session_id = ${sessionId} AND path = ${path}`);
  if (!row) return null;
  return { ...toFile(row), content: s(row.content) };
}

export async function writeFile(input: {
  sessionId: string;
  path: string;
  content: string;
  kind: CoworkFile["kind"];
}): Promise<CoworkFile> {
  const now = Date.now();
  const bytes = Buffer.byteLength(input.content, "utf8");
  const existing = await one<{ id: string }>(
    sql`SELECT id FROM cowork_files WHERE session_id = ${input.sessionId} AND path = ${input.path}`,
  );
  if (existing?.id) {
    await run(
      sql`UPDATE cowork_files SET content = ${input.content}, kind = ${input.kind}, bytes = ${bytes}, updated_at = ${now} WHERE id = ${existing.id}`,
    );
    return { id: s(existing.id), sessionId: input.sessionId, path: input.path, kind: input.kind, bytes, updatedAt: now };
  }
  const id = newId();
  await run(
    sql`INSERT INTO cowork_files (id, session_id, path, kind, content, bytes, updated_at)
        VALUES (${id}, ${input.sessionId}, ${input.path}, ${input.kind}, ${input.content}, ${bytes}, ${now})`,
  );
  return { id, sessionId: input.sessionId, path: input.path, kind: input.kind, bytes, updatedAt: now };
}

export async function deleteFile(sessionId: string, path: string): Promise<boolean> {
  const existing = await one<{ id: string }>(
    sql`SELECT id FROM cowork_files WHERE session_id = ${sessionId} AND path = ${path}`,
  );
  if (!existing?.id) return false;
  await run(sql`DELETE FROM cowork_files WHERE id = ${existing.id}`);
  return true;
}

export async function countFiles(sessionId: string): Promise<number> {
  const row = await one<{ c: number }>(sql`SELECT COUNT(*) AS c FROM cowork_files WHERE session_id = ${sessionId}`);
  return n(row?.c);
}
