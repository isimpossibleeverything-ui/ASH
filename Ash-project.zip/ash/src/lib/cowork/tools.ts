import { runProgram } from "@/lib/code/run";
import { buildSearchContext, webSearch } from "@/lib/search";
import { generateImage } from "@/lib/images";
import { isRunnable, normaliseLang, RUNNABLE_LANGUAGES } from "@/lib/code";
import * as store from "./store";
import { fileKindFor, humanBytes, LIMITS, safePath, type AgentAction, type ToolOutcome } from "./types";

/**
 * The real tools. Every one of these does actual work — there is no mock
 * branch anywhere in this file. If a tool cannot do the job it says so in
 * plain words and the agent loop carries on.
 */

export interface ToolContext {
  sessionId: string;
  signal: AbortSignal;
  /** Called when a tool wants to tell the human something straight away. */
  onNotice?: (text: string) => void;
}

const clip = (text: string, max: number = LIMITS.maxObservationChars): string =>
  text.length <= max ? text : `${text.slice(0, max)}\n… (${text.length - max} more characters)`;

/** Engines name the path key half a dozen ways; accept all of them. */
function rawPath(action: AgentAction): string {
  return (action.args.path ?? action.args.file ?? action.args.filename ?? action.args.name ?? action.args.to ?? "").trim();
}

/** One precise message per failure, so the engine can actually self-correct. */
function pathProblem(action: AgentAction): string | null {
  const raw = rawPath(action);
  if (!raw) {
    return 'error — you left out the "PATH:" line. Repeat the same action with PATH: <filename> on its own line, directly under TOOL:.';
  }
  if (!safePath(raw)) {
    return `error — "${raw.slice(0, 60)}" is not a usable file name. Use a plain name like report.md or data.csv: letters, numbers, spaces, dots and dashes only, no leading slash and no "..".`;
  }
  return null;
}

async function fileListLine(sessionId: string): Promise<string> {
  const files = await store.listFiles(sessionId);
  if (!files.length) return "FILES: (the folder is empty)";
  return `FILES: ${files.map((f) => `${f.path} (${humanBytes(f.bytes)})`).join(", ")}`;
}

/* ── individual tools ───────────────────────────────────────────────── */

async function toolWrite(ctx: ToolContext, action: AgentAction, append: boolean): Promise<ToolOutcome> {
  const problem = pathProblem(action);
  if (problem) return { ok: false, observation: problem };
  const path = safePath(rawPath(action)) as string;

  const count = await store.countFiles(ctx.sessionId);
  const existing = await store.readFile(ctx.sessionId, path);
  if (!existing && count >= LIMITS.maxFiles) {
    return { ok: false, observation: `error — this task already has ${LIMITS.maxFiles} files. Reuse one instead.` };
  }

  let content = action.body ?? "";
  if (append && existing) content = `${existing.content}${existing.content.endsWith("\n") ? "" : "\n"}${content}`;
  if (content.length > LIMITS.maxFileChars) {
    return { ok: false, observation: `error — that file would be ${content.length} characters, the limit is ${LIMITS.maxFileChars}.` };
  }
  if (!content.trim() && !append) {
    return { ok: false, observation: "error — refused to write an empty file. Put the real content in the body." };
  }

  const file = await store.writeFile({ sessionId: ctx.sessionId, path, content, kind: fileKindFor(path) });
  return {
    ok: true,
    observation: `ok — ${append ? "appended to" : "wrote"} ${path} (${humanBytes(file.bytes)}). ${await fileListLine(ctx.sessionId)}`,
    detail: content.slice(0, 2_000),
    file: { path: file.path, kind: file.kind, bytes: file.bytes },
  };
}

async function toolRead(ctx: ToolContext, action: AgentAction): Promise<ToolOutcome> {
  const problem = pathProblem(action);
  if (problem) return { ok: false, observation: problem };
  const path = safePath(rawPath(action)) as string;
  const file = await store.readFile(ctx.sessionId, path);
  if (!file) return { ok: false, observation: `error — ${path} does not exist. ${await fileListLine(ctx.sessionId)}` };
  if (file.kind === "image") {
    return { ok: true, observation: `ok — ${path} is an image (${humanBytes(file.bytes)}); its contents cannot be read as text.` };
  }
  return { ok: true, observation: `ok — ${path}:\n${clip(file.content)}`, detail: file.content.slice(0, 4_000) };
}

async function toolList(ctx: ToolContext): Promise<ToolOutcome> {
  const line = await fileListLine(ctx.sessionId);
  return { ok: true, observation: `ok — ${line}`, detail: line };
}

async function toolDelete(ctx: ToolContext, action: AgentAction): Promise<ToolOutcome> {
  const problem = pathProblem(action);
  if (problem) return { ok: false, observation: problem };
  const path = safePath(rawPath(action)) as string;
  const gone = await store.deleteFile(ctx.sessionId, path);
  return gone
    ? { ok: true, observation: `ok — deleted ${path}. ${await fileListLine(ctx.sessionId)}`, file: { path, kind: "text", bytes: 0 } }
    : { ok: false, observation: `error — ${path} does not exist.` };
}

async function toolRun(ctx: ToolContext, action: AgentAction): Promise<ToolOutcome> {
  const lang = normaliseLang(action.args.lang || action.args.language || "python");
  if (!isRunnable(lang)) {
    return { ok: false, observation: `error — ${lang} cannot be run here. Available: ${RUNNABLE_LANGUAGES.slice(0, 12).join(", ")}.` };
  }
  const code = action.body ?? "";
  if (!code.trim()) return { ok: false, observation: "error — there was no program in the body." };

  const result = await runProgram({ code, language: lang, stdin: action.args.stdin ?? "", timeoutMs: 30_000 });
  if (!result.ok) return { ok: false, observation: `error — ${result.error}` };

  const out = [result.stdout.trim(), result.stderr.trim() ? `stderr: ${result.stderr.trim()}` : ""].filter(Boolean).join("\n");
  const body = out || "(the program produced no output)";
  return {
    ok: result.exitCode === 0,
    observation: `${result.exitCode === 0 ? "ok" : `exit ${result.exitCode}`} — ${clip(body)}`,
    detail: body.slice(0, 4_000),
  };
}

async function toolSearch(ctx: ToolContext, action: AgentAction): Promise<ToolOutcome> {
  const query = (action.args.query || action.body || "").trim().slice(0, 300);
  if (!query) return { ok: false, observation: "error — no search query was given." };
  try {
    const outcome = await webSearch(query);
    if (!outcome.hits.length) return { ok: false, observation: `no results — the free search engines returned nothing for "${query}".` };
    const context = buildSearchContext(outcome.hits, outcome.pageText);
    const links = outcome.hits.slice(0, 6).map((h, i) => `[${i + 1}] ${h.title} — ${h.url}`).join("\n");
    return {
      ok: true,
      observation: `ok — ${outcome.hits.length} results for "${query}":\n${clip(context, 2_600)}`,
      detail: links,
    };
  } catch (err) {
    return { ok: false, observation: `error — search failed: ${(err as Error).message}` };
  }
}

async function toolImage(ctx: ToolContext, action: AgentAction): Promise<ToolOutcome> {
  const prompt = (action.args.prompt || action.body || "").trim().slice(0, 500);
  if (!prompt) return { ok: false, observation: "error — no image description was given." };
  let path = safePath(rawPath(action) || "image.jpg");
  if (!path) return { ok: false, observation: `error — "${rawPath(action).slice(0, 60)}" is not a usable file name. Use something like picture.jpg.` };
  if (!/\.(jpe?g|png|webp)$/i.test(path)) path = `${path}.jpg`;

  try {
    const image = await generateImage(prompt, { signal: ctx.signal, waitForSlot: true });
    if (image.dataUrl.length > LIMITS.maxImageBytes) {
      return { ok: false, observation: "error — the generated picture was too large to keep." };
    }
    const file = await store.writeFile({ sessionId: ctx.sessionId, path, content: image.dataUrl, kind: "image" });
    return {
      ok: true,
      observation: `ok — created the picture ${path} (${humanBytes(file.bytes)}).`,
      file: { path: file.path, kind: "image", bytes: file.bytes },
    };
  } catch (err) {
    return { ok: false, observation: `error — could not make the picture: ${(err as Error).message}` };
  }
}

/* ── dispatcher ─────────────────────────────────────────────────────── */

export async function executeTool(ctx: ToolContext, action: AgentAction): Promise<ToolOutcome> {
  switch (action.tool) {
    case "write_file":
      return toolWrite(ctx, action, false);
    case "append_file":
      return toolWrite(ctx, action, true);
    case "read_file":
      return toolRead(ctx, action);
    case "list_files":
      return toolList(ctx);
    case "delete_file":
      return toolDelete(ctx, action);
    case "run_code":
      return toolRun(ctx, action);
    case "web_search":
      return toolSearch(ctx, action);
    case "make_image":
      return toolImage(ctx, action);
    case "note": {
      const text = (action.body || action.step || "").trim().slice(0, 600);
      ctx.onNotice?.(text);
      return { ok: true, observation: "ok — the human has been told.", detail: text };
    }
    case "finish": {
      const summary = (action.body || action.step || "").trim();
      return { ok: true, observation: "ok — task finished.", detail: summary, finished: true };
    }
    default:
      return { ok: false, observation: `error — there is no tool called "${String(action.tool)}".` };
  }
}

/** One-line descriptions used in the agent's own instructions. */
export const TOOL_HELP = `write_file   PATH: <name>    body = the complete file contents (replaces whatever was there)
append_file  PATH: <name>    body = text added to the end of that file
read_file    PATH: <name>    (no body)
list_files                   (no body)
delete_file  PATH: <name>    (no body — the human must approve this one)
run_code     LANG: <${RUNNABLE_LANGUAGES.slice(0, 8).join("|")}>   body = one complete runnable program
web_search   QUERY: <one line>   (no body)
make_image   PATH: <name.jpg>  PROMPT: <one line>   (no body)
note                         body = a short progress line for the human
finish                       body = the final summary for the human`;
