/**
 * Cowork — the agentic workspace mode.
 *
 * Chat answers a question. Cowork takes a GOAL, writes a plan, then works
 * through it on its own with real tools, producing real files the human can
 * open, edit, download and reject. The human can watch every step, steer it
 * mid-flight, pause it, or approve/refuse a destructive action.
 */

export type SessionStatus =
  | "idle"
  | "planning"
  | "running"
  | "paused"
  | "awaiting"
  | "done"
  | "failed"
  | "cancelled";

export type StepStatus = "running" | "ok" | "error" | "skipped" | "awaiting";

export type ToolName =
  | "write_file"
  | "append_file"
  | "read_file"
  | "list_files"
  | "delete_file"
  | "run_code"
  | "web_search"
  | "make_image"
  | "note"
  | "finish";

export const TOOL_NAMES: ToolName[] = [
  "write_file",
  "append_file",
  "read_file",
  "list_files",
  "delete_file",
  "run_code",
  "web_search",
  "make_image",
  "note",
  "finish",
];

/** Tools that change or destroy something the human may care about. */
export const DESTRUCTIVE: ToolName[] = ["delete_file"];

export interface PlanItem {
  id: string;
  title: string;
  status: "pending" | "active" | "done" | "skipped";
}

export interface CoworkSession {
  id: string;
  title: string;
  goal: string;
  status: SessionStatus;
  plan: PlanItem[];
  summary: string | null;
  model: string | null;
  autoApprove: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface CoworkStep {
  id: string;
  sessionId: string;
  seq: number;
  title: string;
  tool: ToolName | "";
  args: Record<string, string>;
  output: string;
  status: StepStatus;
  createdAt: number;
}

export interface CoworkFile {
  id: string;
  sessionId: string;
  path: string;
  kind: "text" | "image" | "data";
  bytes: number;
  updatedAt: number;
}

export interface CoworkFileFull extends CoworkFile {
  content: string;
}

/** One parsed action from the model. */
export interface AgentAction {
  step: string;
  tool: ToolName;
  args: Record<string, string>;
  body: string;
}

export interface ToolOutcome {
  ok: boolean;
  /** Short line fed back to the model as the observation. */
  observation: string;
  /** Longer text shown to the human in the step card. */
  detail?: string;
  /** A file was created or changed. */
  file?: { path: string; kind: CoworkFile["kind"]; bytes: number };
  /** The run should stop here. */
  finished?: boolean;
}

/* ── limits ─────────────────────────────────────────────────────────── */

export const LIMITS = {
  maxSteps: 24,
  maxFiles: 60,
  maxFileChars: 400_000,
  maxImageBytes: 2_500_000,
  maxObservationChars: 4_000,
  maxBodyChars: 120_000,
  maxGoalChars: 4_000,
  /** How many past steps are replayed to the model each turn. */
  memoryWindow: 8,
  /** One engine attempt. Past this it is parked and the next one is tried,
      so a hanging provider can never freeze a task. */
  engineTimeoutMs: 75_000,
} as const;

/* ── the wire protocol between the agent loop and the browser ───────── */

export type CoworkEvent =
  | { type: "session"; session: CoworkSession }
  | { type: "plan"; plan: PlanItem[] }
  | { type: "step"; step: CoworkStep }
  | { type: "step-update"; id: string; status: StepStatus; output: string }
  | { type: "thinking"; text: string }
  | { type: "file"; file: CoworkFile }
  | { type: "file-removed"; path: string }
  | { type: "notice"; text: string }
  | { type: "approval"; stepId: string; tool: ToolName; args: Record<string, string> }
  | { type: "status"; status: SessionStatus }
  | { type: "done"; summary: string }
  | { type: "error"; message: string };

export function fileKindFor(path: string): CoworkFile["kind"] {
  const ext = path.toLowerCase().split(".").pop() ?? "";
  if (["png", "jpg", "jpeg", "webp", "gif"].includes(ext)) return "image";
  if (["csv", "tsv", "json", "xml", "yml", "yaml"].includes(ext)) return "data";
  return "text";
}

/**
 * Keeps every path inside the session's own folder. No absolute paths, no
 * "..", no hidden files, no silly lengths.
 */
export function safePath(raw: string): string | null {
  let p = (raw || "").trim().replace(/^["'`]|["'`]$/g, "");
  if (!p) return null;
  p = p.replace(/\\/g, "/");
  // reject absolutes BEFORE any stripping, or "/etc/passwd" quietly becomes "etc/passwd"
  if (p.startsWith("/") || /^[a-zA-Z]:/.test(p) || p.startsWith("~")) return null;
  p = p.replace(/^\.\//, "");
  const parts = p.split("/").filter(Boolean);
  if (!parts.length || parts.length > 4) return null;
  for (const part of parts) {
    if (part === "." || part === ".." || part.startsWith(".")) return null;
    if (part.length > 80) return null;
    if (!/^[a-zA-Z0-9][a-zA-Z0-9 _.\-()]*$/.test(part)) return null;
  }
  const joined = parts.join("/");
  return joined.length <= 180 ? joined : null;
}

export function humanBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}
