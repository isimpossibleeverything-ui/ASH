import { sql, type SQL } from "drizzle-orm";
import { mkdirSync } from "node:fs";
import path from "node:path";

export type Dialect = "sqlite" | "postgres";

interface Executor {
  dialect: Dialect;
  all<T = Record<string, unknown>>(query: SQL): Promise<T[]>;
  run(query: SQL): Promise<void>;
  raw(statement: string): Promise<void>;
  driverLabel: string;
}

let executorPromise: Promise<Executor> | null = null;
let schemaReady = false;

function dbUrl(): string {
  const raw = (process.env.DATABASE_URL || "").trim();
  if (raw) return raw;
  // The desktop app installs into Program Files, which is read-only, and
  // Next's standalone server chdir()s into its own folder — so the data
  // directory has to be passed in rather than guessed from cwd.
  const base = (process.env.ASH_DATA_DIR || "").trim() || process.cwd();
  const dir = path.join(base, "data");
  try {
    mkdirSync(dir, { recursive: true });
  } catch {
    /* read-only fs: fall through, libsql will complain clearly */
  }
  return `file:${path.join(dir, "app.db")}`;
}

async function createExecutor(): Promise<Executor> {
  const url = dbUrl();

  if (url.startsWith("postgres://") || url.startsWith("postgresql://")) {
    const [{ drizzle }, postgresMod] = await Promise.all([
      import("drizzle-orm/postgres-js"),
      import("postgres"),
    ]);
    const postgres = postgresMod.default;
    const client = postgres(url, { max: 4, prepare: false, onnotice: () => {} });
    const db = drizzle(client);
    return {
      dialect: "postgres",
      driverLabel: "postgres",
      async all<T>(query: SQL) {
        const rows = await db.execute(query);
        return rows as unknown as T[];
      },
      async run(query: SQL) {
        await db.execute(query);
      },
      async raw(statement: string) {
        await client.unsafe(statement);
      },
    };
  }

  const [{ drizzle }, { createClient }] = await Promise.all([
    import("drizzle-orm/libsql"),
    import("@libsql/client"),
  ]);
  const isTurso = url.startsWith("libsql://");
  const client = createClient({
    url,
    authToken: isTurso ? process.env.DATABASE_AUTH_TOKEN : undefined,
  });
  const db = drizzle(client);
  return {
    dialect: "sqlite",
    driverLabel: isTurso ? "turso (libsql)" : "sqlite (libsql file)",
    async all<T>(query: SQL) {
      const rows = await db.all(query);
      return rows as unknown as T[];
    },
    async run(query: SQL) {
      await db.run(query);
    },
    async raw(statement: string) {
      await client.execute(statement);
    },
  };
}

export async function getExecutor(): Promise<Executor> {
  if (!executorPromise) executorPromise = createExecutor();
  return executorPromise;
}

export async function driverLabel(): Promise<string> {
  return (await getExecutor()).driverLabel;
}

const SQLITE_DDL = [
  `CREATE TABLE IF NOT EXISTS conversations (
     id TEXT PRIMARY KEY,
     title TEXT NOT NULL DEFAULT 'New chat',
     model TEXT,
     system_prompt TEXT,
     pinned INTEGER NOT NULL DEFAULT 0,
     created_at INTEGER NOT NULL,
     updated_at INTEGER NOT NULL,
     owner_key TEXT NOT NULL DEFAULT '',
     archived INTEGER NOT NULL DEFAULT 0
   )`,
  `CREATE INDEX IF NOT EXISTS idx_conversations_updated ON conversations(updated_at)`,
  `CREATE INDEX IF NOT EXISTS idx_conversations_owner ON conversations(owner_key, updated_at)`,
  `CREATE TABLE IF NOT EXISTS messages (
     id TEXT PRIMARY KEY,
     conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
     role TEXT NOT NULL,
     content TEXT NOT NULL,
     model TEXT,
     created_at INTEGER NOT NULL
   )`,
  `CREATE INDEX IF NOT EXISTS idx_messages_conv ON messages(conversation_id, created_at)`,
  `CREATE TABLE IF NOT EXISTS knowledge (
     id TEXT PRIMARY KEY,
     question TEXT NOT NULL,
     question_norm TEXT NOT NULL UNIQUE,
     answer TEXT NOT NULL,
     topic TEXT,
     provider TEXT,
     model TEXT,
     quality INTEGER NOT NULL DEFAULT 0,
     hits INTEGER NOT NULL DEFAULT 0,
     created_at INTEGER NOT NULL
   )`,
  `CREATE TABLE IF NOT EXISTS harvest_queue (
     id TEXT PRIMARY KEY,
     question TEXT NOT NULL,
     topic TEXT,
     status TEXT NOT NULL DEFAULT 'pending',
     attempts INTEGER NOT NULL DEFAULT 0,
     created_at INTEGER NOT NULL
   )`,
  `CREATE TABLE IF NOT EXISTS provider_state (
     id TEXT PRIMARY KEY,
     state TEXT NOT NULL,
     until INTEGER NOT NULL DEFAULT 0,
     last_error TEXT
   )`,
  `CREATE TABLE IF NOT EXISTS app_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS cowork_sessions (
     id TEXT PRIMARY KEY,
     owner_key TEXT NOT NULL DEFAULT '',
     title TEXT NOT NULL DEFAULT 'New task',
     goal TEXT NOT NULL DEFAULT '',
     status TEXT NOT NULL DEFAULT 'idle',
     plan TEXT NOT NULL DEFAULT '[]',
     summary TEXT,
     model TEXT,
     auto_approve INTEGER NOT NULL DEFAULT 0,
     created_at INTEGER NOT NULL,
     updated_at INTEGER NOT NULL
   )`,
  `CREATE INDEX IF NOT EXISTS idx_cowork_owner ON cowork_sessions(owner_key, updated_at)`,
  `CREATE TABLE IF NOT EXISTS cowork_steps (
     id TEXT PRIMARY KEY,
     session_id TEXT NOT NULL REFERENCES cowork_sessions(id) ON DELETE CASCADE,
     seq INTEGER NOT NULL,
     title TEXT NOT NULL DEFAULT '',
     tool TEXT NOT NULL DEFAULT '',
     args TEXT NOT NULL DEFAULT '{}',
     output TEXT NOT NULL DEFAULT '',
     status TEXT NOT NULL DEFAULT 'running',
     created_at INTEGER NOT NULL
   )`,
  `CREATE INDEX IF NOT EXISTS idx_cowork_steps ON cowork_steps(session_id, seq)`,
  `CREATE TABLE IF NOT EXISTS cowork_files (
     id TEXT PRIMARY KEY,
     session_id TEXT NOT NULL REFERENCES cowork_sessions(id) ON DELETE CASCADE,
     path TEXT NOT NULL,
     kind TEXT NOT NULL DEFAULT 'text',
     content TEXT NOT NULL DEFAULT '',
     bytes INTEGER NOT NULL DEFAULT 0,
     updated_at INTEGER NOT NULL
   )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS idx_cowork_files_path ON cowork_files(session_id, path)`,
];

const POSTGRES_DDL = [
  `CREATE TABLE IF NOT EXISTS conversations (
     id TEXT PRIMARY KEY,
     title TEXT NOT NULL DEFAULT 'New chat',
     model TEXT,
     system_prompt TEXT,
     pinned INTEGER NOT NULL DEFAULT 0,
     created_at BIGINT NOT NULL,
     updated_at BIGINT NOT NULL,
     owner_key TEXT NOT NULL DEFAULT '',
     archived INTEGER NOT NULL DEFAULT 0
   )`,
  `CREATE INDEX IF NOT EXISTS idx_conversations_updated ON conversations(updated_at)`,
  `CREATE INDEX IF NOT EXISTS idx_conversations_owner ON conversations(owner_key, updated_at)`,
  `CREATE TABLE IF NOT EXISTS messages (
     id TEXT PRIMARY KEY,
     conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
     role TEXT NOT NULL,
     content TEXT NOT NULL,
     model TEXT,
     created_at BIGINT NOT NULL
   )`,
  `CREATE INDEX IF NOT EXISTS idx_messages_conv ON messages(conversation_id, created_at)`,
  `CREATE TABLE IF NOT EXISTS knowledge (
     id TEXT PRIMARY KEY,
     question TEXT NOT NULL,
     question_norm TEXT NOT NULL UNIQUE,
     answer TEXT NOT NULL,
     topic TEXT,
     provider TEXT,
     model TEXT,
     quality INTEGER NOT NULL DEFAULT 0,
     hits INTEGER NOT NULL DEFAULT 0,
     created_at BIGINT NOT NULL
   )`,
  `CREATE TABLE IF NOT EXISTS harvest_queue (
     id TEXT PRIMARY KEY,
     question TEXT NOT NULL,
     topic TEXT,
     status TEXT NOT NULL DEFAULT 'pending',
     attempts INTEGER NOT NULL DEFAULT 0,
     created_at BIGINT NOT NULL
   )`,
  `CREATE TABLE IF NOT EXISTS provider_state (
     id TEXT PRIMARY KEY,
     state TEXT NOT NULL,
     until BIGINT NOT NULL DEFAULT 0,
     last_error TEXT
   )`,
  `CREATE TABLE IF NOT EXISTS app_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS cowork_sessions (
     id TEXT PRIMARY KEY,
     owner_key TEXT NOT NULL DEFAULT '',
     title TEXT NOT NULL DEFAULT 'New task',
     goal TEXT NOT NULL DEFAULT '',
     status TEXT NOT NULL DEFAULT 'idle',
     plan TEXT NOT NULL DEFAULT '[]',
     summary TEXT,
     model TEXT,
     auto_approve INTEGER NOT NULL DEFAULT 0,
     created_at BIGINT NOT NULL,
     updated_at BIGINT NOT NULL
   )`,
  `CREATE INDEX IF NOT EXISTS idx_cowork_owner ON cowork_sessions(owner_key, updated_at)`,
  `CREATE TABLE IF NOT EXISTS cowork_steps (
     id TEXT PRIMARY KEY,
     session_id TEXT NOT NULL REFERENCES cowork_sessions(id) ON DELETE CASCADE,
     seq INTEGER NOT NULL,
     title TEXT NOT NULL DEFAULT '',
     tool TEXT NOT NULL DEFAULT '',
     args TEXT NOT NULL DEFAULT '{}',
     output TEXT NOT NULL DEFAULT '',
     status TEXT NOT NULL DEFAULT 'running',
     created_at BIGINT NOT NULL
   )`,
  `CREATE INDEX IF NOT EXISTS idx_cowork_steps ON cowork_steps(session_id, seq)`,
  `CREATE TABLE IF NOT EXISTS cowork_files (
     id TEXT PRIMARY KEY,
     session_id TEXT NOT NULL REFERENCES cowork_sessions(id) ON DELETE CASCADE,
     path TEXT NOT NULL,
     kind TEXT NOT NULL DEFAULT 'text',
     content TEXT NOT NULL DEFAULT '',
     bytes BIGINT NOT NULL DEFAULT 0,
     updated_at BIGINT NOT NULL
   )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS idx_cowork_files_path ON cowork_files(session_id, path)`,
];

/** Columns added after v1. Additive only — existing rows keep their data. */
const MIGRATIONS: { table: string; column: string; ddl: string }[] = [
  { table: "conversations", column: "archived", ddl: "INTEGER NOT NULL DEFAULT 0" },
];

async function applyMigrations(ex: Executor): Promise<void> {
  for (const m of MIGRATIONS) {
    try {
      // cheapest portable existence probe: select it and see if it blows up
      await ex.all(sql.raw(`SELECT ${m.column} FROM ${m.table} LIMIT 1`));
    } catch {
      try {
        await ex.raw(`ALTER TABLE ${m.table} ADD COLUMN ${m.column} ${m.ddl}`);
      } catch {
        /* already there, or the dialect added it concurrently */
      }
    }
  }
}

/** Auto-creates every table on first request, then applies additive migrations. */
export async function ensureSchema(): Promise<void> {
  if (schemaReady) return;
  const ex = await getExecutor();
  const ddl = ex.dialect === "postgres" ? POSTGRES_DDL : SQLITE_DDL;
  for (const statement of ddl) await ex.raw(statement);
  if (ex.dialect === "sqlite") {
    await ex.raw("PRAGMA foreign_keys = ON");
  }
  await applyMigrations(ex);
  schemaReady = true;
}

export async function all<T = Record<string, unknown>>(query: SQL): Promise<T[]> {
  await ensureSchema();
  const ex = await getExecutor();
  return ex.all<T>(query);
}

export async function one<T = Record<string, unknown>>(query: SQL): Promise<T | null> {
  const rows = await all<T>(query);
  return rows.length ? rows[0] : null;
}

export async function run(query: SQL): Promise<void> {
  await ensureSchema();
  const ex = await getExecutor();
  await ex.run(query);
}

export { sql };
