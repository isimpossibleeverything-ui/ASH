import { randomUUID } from "node:crypto";
import { all, one, run, sql, driverLabel, getExecutor } from "./index";
import type { ChatMessage, Conversation, Role } from "@/lib/types";

const n = (v: unknown): number => (typeof v === "number" ? v : Number(v ?? 0));
const s = (v: unknown): string => (v == null ? "" : String(v));
const sn = (v: unknown): string | null => (v == null ? null : String(v));

export const newId = (): string => randomUUID();

/* ───────────────────────────── conversations ───────────────────────────── */

function toConversation(r: Record<string, unknown>): Conversation {
  return {
    id: s(r.id),
    title: s(r.title),
    model: sn(r.model),
    systemPrompt: sn(r.system_prompt),
    pinned: n(r.pinned) === 1,
    archived: n(r.archived) === 1,
    createdAt: n(r.created_at),
    updatedAt: n(r.updated_at),
  };
}

export async function listConversations(ownerKey: string): Promise<Conversation[]> {
  const rows = await all(
    sql`SELECT * FROM conversations WHERE owner_key = ${ownerKey} ORDER BY pinned DESC, updated_at DESC LIMIT 300`,
  );
  return rows.map(toConversation);
}

export async function listAllConversations(): Promise<Conversation[]> {
  const rows = await all(sql`SELECT * FROM conversations ORDER BY updated_at DESC LIMIT 500`);
  return rows.map(toConversation);
}

export async function createConversation(input: {
  title: string;
  model?: string | null;
  systemPrompt?: string | null;
  ownerKey: string;
}): Promise<Conversation> {
  const now = Date.now();
  const id = newId();
  await run(
    sql`INSERT INTO conversations (id, title, model, system_prompt, pinned, created_at, updated_at, owner_key)
        VALUES (${id}, ${input.title}, ${input.model ?? null}, ${input.systemPrompt ?? null}, 0, ${now}, ${now}, ${input.ownerKey})`,
  );
  return {
    id,
    title: input.title,
    model: input.model ?? null,
    systemPrompt: input.systemPrompt ?? null,
    pinned: false,
    archived: false,
    createdAt: now,
    updatedAt: now,
  };
}

export async function getConversation(id: string, ownerKey?: string): Promise<Conversation | null> {
  const row = ownerKey
    ? await one(sql`SELECT * FROM conversations WHERE id = ${id} AND owner_key = ${ownerKey}`)
    : await one(sql`SELECT * FROM conversations WHERE id = ${id}`);
  return row ? toConversation(row) : null;
}

export async function updateConversation(
  id: string,
  ownerKey: string,
  patch: { title?: string; pinned?: boolean; archived?: boolean; model?: string | null; systemPrompt?: string | null },
): Promise<void> {
  const now = Date.now();
  if (patch.title !== undefined)
    await run(sql`UPDATE conversations SET title = ${patch.title}, updated_at = ${now} WHERE id = ${id} AND owner_key = ${ownerKey}`);
  if (patch.pinned !== undefined)
    await run(sql`UPDATE conversations SET pinned = ${patch.pinned ? 1 : 0} WHERE id = ${id} AND owner_key = ${ownerKey}`);
  if (patch.archived !== undefined)
    await run(sql`UPDATE conversations SET archived = ${patch.archived ? 1 : 0} WHERE id = ${id} AND owner_key = ${ownerKey}`);
  if (patch.model !== undefined)
    await run(sql`UPDATE conversations SET model = ${patch.model} WHERE id = ${id} AND owner_key = ${ownerKey}`);
  if (patch.systemPrompt !== undefined)
    await run(sql`UPDATE conversations SET system_prompt = ${patch.systemPrompt} WHERE id = ${id} AND owner_key = ${ownerKey}`);
}

export async function touchConversation(id: string): Promise<void> {
  await run(sql`UPDATE conversations SET updated_at = ${Date.now()} WHERE id = ${id}`);
}

export async function deleteConversation(id: string, ownerKey: string): Promise<void> {
  await run(sql`DELETE FROM messages WHERE conversation_id = ${id}`);
  await run(sql`DELETE FROM conversations WHERE id = ${id} AND owner_key = ${ownerKey}`);
}

export async function deleteAllConversations(ownerKey: string): Promise<number> {
  const rows = await all<{ id: unknown }>(sql`SELECT id FROM conversations WHERE owner_key = ${ownerKey}`);
  for (const r of rows) {
    await run(sql`DELETE FROM messages WHERE conversation_id = ${s(r.id)}`);
  }
  await run(sql`DELETE FROM conversations WHERE owner_key = ${ownerKey}`);
  return rows.length;
}

/* ─────────────────────────────── messages ─────────────────────────────── */

function toMessage(r: Record<string, unknown>): ChatMessage {
  return {
    id: s(r.id),
    conversationId: s(r.conversation_id),
    role: s(r.role) as Role,
    content: s(r.content),
    model: sn(r.model),
    createdAt: n(r.created_at),
  };
}

export async function listMessages(conversationId: string, limit = 400): Promise<ChatMessage[]> {
  // rowid exists on SQLite only; Postgres orders by the id tiebreaker instead.
  const ex = await getExecutor();
  const rows =
    ex.dialect === "sqlite"
      ? await all(
          sql`SELECT * FROM messages WHERE conversation_id = ${conversationId} ORDER BY created_at ASC, rowid ASC LIMIT ${limit}`,
        )
      : await all(
          sql`SELECT * FROM messages WHERE conversation_id = ${conversationId} ORDER BY created_at ASC, id ASC LIMIT ${limit}`,
        );
  return rows.map(toMessage);
}

export async function addMessage(input: {
  conversationId: string;
  role: Role;
  content: string;
  model?: string | null;
  createdAt?: number;
}): Promise<ChatMessage> {
  const id = newId();
  const createdAt = input.createdAt ?? Date.now();
  await run(
    sql`INSERT INTO messages (id, conversation_id, role, content, model, created_at)
        VALUES (${id}, ${input.conversationId}, ${input.role}, ${input.content}, ${input.model ?? null}, ${createdAt})`,
  );
  await touchConversation(input.conversationId);
  return { id, conversationId: input.conversationId, role: input.role, content: input.content, model: input.model ?? null, createdAt };
}

export async function updateMessageContent(id: string, content: string, model?: string | null): Promise<void> {
  await run(sql`UPDATE messages SET content = ${content}, model = ${model ?? null} WHERE id = ${id}`);
}

/** Deletes the given message and everything created after it in that chat. */
export async function deleteFromMessage(conversationId: string, messageId: string): Promise<void> {
  const row = await one<{ created_at: unknown }>(
    sql`SELECT created_at FROM messages WHERE id = ${messageId} AND conversation_id = ${conversationId}`,
  );
  if (!row) return;
  const at = n(row.created_at);
  await run(sql`DELETE FROM messages WHERE conversation_id = ${conversationId} AND created_at >= ${at}`);
}

export async function countMessages(): Promise<number> {
  const row = await one<{ c: unknown }>(sql`SELECT COUNT(*) AS c FROM messages`);
  return n(row?.c);
}

export async function countConversations(): Promise<number> {
  const row = await one<{ c: unknown }>(sql`SELECT COUNT(*) AS c FROM conversations`);
  return n(row?.c);
}

/* ─────────────────────────────── settings ─────────────────────────────── */

export async function getSetting(key: string): Promise<string | null> {
  const row = await one<{ value: unknown }>(sql`SELECT value FROM app_settings WHERE key = ${key}`);
  return row ? s(row.value) : null;
}

export async function setSetting(key: string, value: string): Promise<void> {
  await run(
    sql`INSERT INTO app_settings (key, value) VALUES (${key}, ${value})
        ON CONFLICT (key) DO UPDATE SET value = ${value}`,
  );
}

export async function deleteSetting(key: string): Promise<void> {
  await run(sql`DELETE FROM app_settings WHERE key = ${key}`);
}

/* ─────────────────────────────── knowledge ─────────────────────────────── */

export interface KnowledgeRow {
  id: string;
  question: string;
  questionNorm: string;
  answer: string;
  topic: string | null;
  provider: string | null;
  model: string | null;
  quality: number;
  hits: number;
  createdAt: number;
}

function toKnowledge(r: Record<string, unknown>): KnowledgeRow {
  return {
    id: s(r.id),
    question: s(r.question),
    questionNorm: s(r.question_norm),
    answer: s(r.answer),
    topic: sn(r.topic),
    provider: sn(r.provider),
    model: sn(r.model),
    quality: n(r.quality),
    hits: n(r.hits),
    createdAt: n(r.created_at),
  };
}

export async function saveKnowledge(input: {
  question: string;
  questionNorm: string;
  answer: string;
  topic?: string | null;
  provider?: string | null;
  model?: string | null;
  quality?: number;
}): Promise<"inserted" | "updated" | "kept"> {
  const existing = await one(sql`SELECT * FROM knowledge WHERE question_norm = ${input.questionNorm}`);
  const now = Date.now();
  if (existing) {
    const prev = toKnowledge(existing);
    if (input.answer.length > prev.answer.length) {
      await run(
        sql`UPDATE knowledge SET answer = ${input.answer}, provider = ${input.provider ?? null}, model = ${input.model ?? null},
            quality = ${input.quality ?? 1}, topic = ${input.topic ?? prev.topic} WHERE id = ${prev.id}`,
      );
      return "updated";
    }
    return "kept";
  }
  await run(
    sql`INSERT INTO knowledge (id, question, question_norm, answer, topic, provider, model, quality, hits, created_at)
        VALUES (${newId()}, ${input.question}, ${input.questionNorm}, ${input.answer}, ${input.topic ?? null},
                ${input.provider ?? null}, ${input.model ?? null}, ${input.quality ?? 1}, 0, ${now})`,
  );
  return "inserted";
}

export async function findKnowledgeExact(questionNorm: string): Promise<KnowledgeRow | null> {
  const row = await one(sql`SELECT * FROM knowledge WHERE question_norm = ${questionNorm}`);
  return row ? toKnowledge(row) : null;
}

export async function allKnowledge(limit = 8000): Promise<KnowledgeRow[]> {
  const rows = await all(sql`SELECT * FROM knowledge ORDER BY created_at DESC LIMIT ${limit}`);
  return rows.map(toKnowledge);
}

export async function bumpKnowledgeHit(id: string): Promise<void> {
  await run(sql`UPDATE knowledge SET hits = hits + 1 WHERE id = ${id}`);
}

export async function knowledgeStats(): Promise<{ total: number; fromAi: number }> {
  const total = await one<{ c: unknown }>(sql`SELECT COUNT(*) AS c FROM knowledge`);
  const ai = await one<{ c: unknown }>(sql`SELECT COUNT(*) AS c FROM knowledge WHERE quality >= 1`);
  return { total: n(total?.c), fromAi: n(ai?.c) };
}

/** How many saved answers each engine contributed — Ash's "most trained" ranking. */
export async function knowledgeByProvider(): Promise<Record<string, number>> {
  const rows = await all<{ provider: unknown; c: unknown }>(
    sql`SELECT provider, COUNT(*) AS c FROM knowledge WHERE provider IS NOT NULL GROUP BY provider`,
  );
  const out: Record<string, number> = {};
  for (const r of rows) {
    const key = sn(r.provider);
    if (key) out[key] = n(r.c);
  }
  return out;
}

export async function clearKnowledge(): Promise<void> {
  await run(sql`DELETE FROM knowledge`);
  await run(sql`DELETE FROM harvest_queue`);
}

/* ───────────────────────────── harvest queue ───────────────────────────── */

export interface QueueRow {
  id: string;
  question: string;
  topic: string | null;
  status: string;
  attempts: number;
  createdAt: number;
}

export async function enqueueQuestion(question: string, topic?: string | null): Promise<void> {
  const norm = question.trim().toLowerCase();
  if (!norm) return;
  const dupe = await one(sql`SELECT id FROM harvest_queue WHERE question = ${question.trim()} AND status = 'pending'`);
  if (dupe) return;
  const known = await one(sql`SELECT id FROM knowledge WHERE question_norm = ${norm}`);
  if (known) return;
  await run(
    sql`INSERT INTO harvest_queue (id, question, topic, status, attempts, created_at)
        VALUES (${newId()}, ${question.trim()}, ${topic ?? null}, 'pending', 0, ${Date.now()})`,
  );
}

export async function nextQueued(): Promise<QueueRow | null> {
  const row = await one(sql`SELECT * FROM harvest_queue WHERE status = 'pending' ORDER BY created_at ASC LIMIT 1`);
  if (!row) return null;
  return {
    id: s(row.id),
    question: s(row.question),
    topic: sn(row.topic),
    status: s(row.status),
    attempts: n(row.attempts),
    createdAt: n(row.created_at),
  };
}

export async function setQueueStatus(id: string, status: string, attempts?: number): Promise<void> {
  if (attempts === undefined) await run(sql`UPDATE harvest_queue SET status = ${status} WHERE id = ${id}`);
  else await run(sql`UPDATE harvest_queue SET status = ${status}, attempts = ${attempts} WHERE id = ${id}`);
}

export async function queueCount(): Promise<number> {
  const row = await one<{ c: unknown }>(sql`SELECT COUNT(*) AS c FROM harvest_queue WHERE status = 'pending'`);
  return n(row?.c);
}

/* ──────────────────────────── provider health ──────────────────────────── */

export interface ProviderStateRow {
  id: string;
  state: string;
  until: number;
  lastError: string | null;
}

export async function listProviderState(): Promise<ProviderStateRow[]> {
  const rows = await all(sql`SELECT * FROM provider_state`);
  return rows.map((r) => ({ id: s(r.id), state: s(r.state), until: n(r.until), lastError: sn(r.last_error) }));
}

export async function setProviderState(id: string, state: string, until: number, lastError: string | null): Promise<void> {
  await run(
    sql`INSERT INTO provider_state (id, state, until, last_error) VALUES (${id}, ${state}, ${until}, ${lastError})
        ON CONFLICT (id) DO UPDATE SET state = ${state}, until = ${until}, last_error = ${lastError}`,
  );
}

export async function clearProviderState(id?: string): Promise<void> {
  if (id) await run(sql`DELETE FROM provider_state WHERE id = ${id}`);
  else await run(sql`DELETE FROM provider_state`);
}

export { driverLabel };
