import { sqliteTable, text, integer, index } from "drizzle-orm/sqlite-core";

/**
 * Canonical schema. The SQLite/libSQL/Turso driver uses these definitions
 * directly; the Postgres driver mirrors them with the same column names so one
 * repository implementation serves every backend.
 */
export const conversations = sqliteTable(
  "conversations",
  {
    id: text("id").primaryKey(),
    title: text("title").notNull().default("New chat"),
    model: text("model"),
    systemPrompt: text("system_prompt"),
    pinned: integer("pinned").notNull().default(0),
    createdAt: integer("created_at").notNull(),
    updatedAt: integer("updated_at").notNull(),
    ownerKey: text("owner_key").notNull().default(""),
  },
  (t) => [index("idx_conversations_updated").on(t.updatedAt)],
);

export const messages = sqliteTable(
  "messages",
  {
    id: text("id").primaryKey(),
    conversationId: text("conversation_id").notNull(),
    role: text("role").notNull(),
    content: text("content").notNull(),
    model: text("model"),
    createdAt: integer("created_at").notNull(),
  },
  (t) => [index("idx_messages_conv").on(t.conversationId, t.createdAt)],
);

export const knowledge = sqliteTable("knowledge", {
  id: text("id").primaryKey(),
  question: text("question").notNull(),
  questionNorm: text("question_norm").notNull().unique(),
  answer: text("answer").notNull(),
  topic: text("topic"),
  provider: text("provider"),
  model: text("model"),
  quality: integer("quality").notNull().default(0),
  hits: integer("hits").notNull().default(0),
  createdAt: integer("created_at").notNull(),
});

export const harvestQueue = sqliteTable("harvest_queue", {
  id: text("id").primaryKey(),
  question: text("question").notNull(),
  topic: text("topic"),
  status: text("status").notNull().default("pending"),
  attempts: integer("attempts").notNull().default(0),
  createdAt: integer("created_at").notNull(),
});

export const providerState = sqliteTable("provider_state", {
  id: text("id").primaryKey(),
  state: text("state").notNull(),
  until: integer("until").notNull().default(0),
  lastError: text("last_error"),
});

export const appSettings = sqliteTable("app_settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
});
