/**
 * The desktop agent loop.
 *
 * Cowork's loop lives on the server because its files live on the server.
 * This one has to live in the window, because only the window can reach the
 * real computer. So the shape is inverted: the thinking is fetched one step at
 * a time from /api/desktop/think, and every action is carried out right here.
 *
 * Same discipline as Cowork: one action per reply, an observation fed back,
 * a hard step ceiling, and a plain-language stop when something goes wrong.
 */

import {
  desktopDelete,
  desktopList,
  desktopMkdir,
  desktopOpen,
  desktopRead,
  desktopRun,
  desktopWrite,
  prettyBytes,
} from "./index";

export const DESKTOP_TOOLS = [
  "list_files",
  "read_file",
  "write_file",
  "make_folder",
  "delete_file",
  "run_command",
  "open_thing",
  "note",
  "finish",
] as const;

export type DesktopTool = (typeof DESKTOP_TOOLS)[number];

export interface DesktopAction {
  step: string;
  tool: DesktopTool;
  path?: string;
  target?: string;
  command?: string;
  body?: string;
}

export type DesktopEventType =
  | "step"
  | "result"
  | "thinking"
  | "notice"
  | "done"
  | "error";

export interface DesktopEvent {
  type: DesktopEventType;
  text: string;
  tool?: DesktopTool;
  ok?: boolean;
  engine?: string | null;
}

export const MAX_DESKTOP_STEPS = 20;
const MAX_OBSERVATION = 4_000;

const TOOL_HELP = `list_files   — see what is in a folder.   PATH: subfolder (leave empty for the top)
read_file    — read a text file.           PATH: notes/todo.txt
write_file   — create or overwrite a file. PATH: notes/todo.txt  then the contents in the body
make_folder  — create a folder.            PATH: invoices/2026
delete_file  — delete a file or folder.    PATH: old/junk.txt   (the person is asked first, every time)
run_command  — run one command line.       COMMAND: winget install --id Google.Chrome
open_thing   — open a file, folder, app or link. TARGET: report.pdf   or   https://example.com
note         — say something to the person without touching anything
finish       — the job is done; put the summary in the body`;

export function desktopSystemPrompt(name: string, root: string, os: string): string {
  return `You are ${name}, working directly on someone's ${os === "windows" ? "Windows PC" : "computer"}.

You have been given one folder to work in: ${root}
Everything you touch must be inside it. Paths are written relative to that folder.

These are the only tools that exist:

${TOOL_HELP}

Reply with EXACTLY ONE action and nothing else, in this exact shape:

STEP: <short title, at most 8 words>
TOOL: <one tool name from the list>
PATH: <only for file tools>
COMMAND: <only for run_command>
TARGET: <only for open_thing>
<<<ASH
<the file contents, the note, or the finishing summary — leave this out when the tool needs no body>
ASH>>>

Rules you do not break:
- One action per reply. Never two. Never a commentary.
- Look before you leap: list_files or read_file before you change something you have not seen.
- run_command is a real command line on a real machine. Prefer safe, reversible commands. Never try to work around the folder you were given.
- If the person asked for something you cannot do with these tools, use note to say so plainly, then finish.
- When the job is genuinely complete, use finish and summarise what changed in a sentence or two.
- Write to the person in the language they used.`;
}

/* ── parsing ───────────────────────────────────────────────────────── */

const HEADER = /^(STEP|TOOL|PATH|COMMAND|TARGET)\s*:\s*(.*)$/i;

export function parseDesktopAction(raw: string): DesktopAction | null {
  const text = raw.replace(/\r/g, "").trim();
  if (!text) return null;

  let body = "";
  const open = text.indexOf("<<<ASH");
  const close = text.lastIndexOf("ASH>>>");
  let head = text;
  if (open !== -1) {
    head = text.slice(0, open);
    body = text.slice(open + 6, close === -1 ? undefined : close);
    body = body.replace(/^\n/, "").replace(/\n$/, "");
  }

  const fields: Record<string, string> = {};
  for (const line of head.split("\n")) {
    const m = line.match(HEADER);
    if (m) fields[m[1].toUpperCase()] = m[2].trim();
  }

  // models sometimes slide a header into the top of the body — lift it back out
  if (!fields.TOOL && body) {
    const lines = body.split("\n");
    let moved = 0;
    while (lines.length && moved < 4) {
      const m = lines[0].match(HEADER);
      if (!m) break;
      fields[m[1].toUpperCase()] = m[2].trim();
      lines.shift();
      moved++;
    }
    if (moved) body = lines.join("\n");
  }

  const tool = (fields.TOOL || "").toLowerCase().replace(/[^a-z_]/g, "") as DesktopTool;
  if (!DESKTOP_TOOLS.includes(tool)) return null;

  return {
    step: (fields.STEP || tool.replace(/_/g, " ")).slice(0, 90),
    tool,
    path: fields.PATH || undefined,
    target: fields.TARGET || undefined,
    command: fields.COMMAND || undefined,
    body,
  };
}

/* ── doing ─────────────────────────────────────────────────────────── */

const clip = (s: string) =>
  s.length > MAX_OBSERVATION ? `${s.slice(0, MAX_OBSERVATION)}\n… (trimmed)` : s;

/** Carries out one action and returns what the model should be told about it. */
export async function performDesktopAction(
  action: DesktopAction,
): Promise<{ observation: string; ok: boolean; shown: string }> {
  try {
    switch (action.tool) {
      case "list_files": {
        const items = await desktopList(action.path ?? "");
        if (!items.length) return { observation: "That folder is empty.", ok: true, shown: "Empty folder." };
        const lines = items
          .map((i) => `${i.is_dir ? "[folder] " : ""}${i.path}${i.bytes ? ` (${prettyBytes(i.bytes)})` : ""}`)
          .join("\n");
        return { observation: clip(lines), ok: true, shown: `${items.length} item${items.length === 1 ? "" : "s"}.` };
      }
      case "read_file": {
        if (!action.path) throw new Error("No file was named.");
        const text = await desktopRead(action.path);
        return { observation: clip(text || "(the file is empty)"), ok: true, shown: `Read ${action.path}.` };
      }
      case "write_file": {
        if (!action.path) throw new Error("No file was named.");
        const where = await desktopWrite(action.path, action.body ?? "");
        return { observation: `Saved ${where}.`, ok: true, shown: `Saved ${where}.` };
      }
      case "make_folder": {
        if (!action.path) throw new Error("No folder was named.");
        const where = await desktopMkdir(action.path);
        return { observation: `Created the folder ${where}.`, ok: true, shown: `Created ${where}.` };
      }
      case "delete_file": {
        if (!action.path) throw new Error("No file was named.");
        const gone = await desktopDelete(action.path);
        return { observation: `Deleted ${gone}.`, ok: true, shown: `Deleted ${gone}.` };
      }
      case "run_command": {
        const line = action.command || action.body || "";
        if (!line.trim()) throw new Error("There was no command to run.");
        const r = await desktopRun(line);
        const parts = [
          `exit code ${r.code}${r.timed_out ? " (it ran out of time and was stopped)" : ""}`,
          r.stdout.trim() ? `output:\n${r.stdout.trim()}` : "",
          r.stderr.trim() ? `errors:\n${r.stderr.trim()}` : "",
        ].filter(Boolean);
        return {
          observation: clip(parts.join("\n\n")),
          ok: r.code === 0 && !r.timed_out,
          shown: `${line} — exit ${r.code}`,
        };
      }
      case "open_thing": {
        const what = action.target || action.path || action.body || "";
        if (!what.trim()) throw new Error("There was nothing to open.");
        const opened = await desktopOpen(what);
        return { observation: `Opened ${opened}.`, ok: true, shown: `Opened ${opened}.` };
      }
      case "note":
        return { observation: "Noted. Carry on.", ok: true, shown: action.body || action.step };
      case "finish":
        return { observation: "", ok: true, shown: action.body || "Done." };
    }
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return { observation: `That failed: ${message}`, ok: false, shown: message };
  }
}

/* ── the loop ──────────────────────────────────────────────────────── */

export interface DesktopRunOptions {
  goal: string;
  system: string;
  model?: string | null;
  signal: AbortSignal;
  emit: (event: DesktopEvent) => void;
  maxSteps?: number;
}

async function think(
  messages: { role: "user" | "assistant"; content: string }[],
  system: string,
  model: string | null | undefined,
  signal: AbortSignal,
): Promise<{ text: string; label: string | null }> {
  const res = await fetch("/api/desktop/think", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ messages, system, model }),
    signal,
  });
  const data = (await res.json().catch(() => ({}))) as {
    text?: string;
    label?: string | null;
    error?: string;
  };
  if (!res.ok) throw new Error(data.error || "Ash could not think that through.");
  return { text: data.text ?? "", label: data.label ?? null };
}

export async function runDesktopTask({
  goal,
  system,
  model,
  signal,
  emit,
  maxSteps = MAX_DESKTOP_STEPS,
}: DesktopRunOptions): Promise<void> {
  const history: { role: "user" | "assistant"; content: string }[] = [
    { role: "user", content: `The job: ${goal}\n\nTake the first action.` },
  ];

  let confused = 0;
  let announced = "";

  for (let step = 0; step < maxSteps; step++) {
    if (signal.aborted) {
      emit({ type: "notice", text: "Stopped." });
      return;
    }

    emit({ type: "thinking", text: step === 0 ? "Working out where to start…" : "Deciding the next step…" });

    let reply: { text: string; label: string | null };
    try {
      reply = await think(history, system, model, signal);
    } catch (err) {
      if (signal.aborted) return;
      emit({ type: "error", text: err instanceof Error ? err.message : "Something went wrong." });
      return;
    }

    if (reply.label && reply.label !== announced) {
      announced = reply.label;
      emit({ type: "notice", text: `Working with ${reply.label}.`, engine: reply.label });
    }

    const action = parseDesktopAction(reply.text);
    if (!action) {
      confused++;
      if (confused >= 3) {
        emit({ type: "error", text: "Ash kept replying with something that was not an action, so it stopped." });
        return;
      }
      history.push({ role: "assistant", content: reply.text.slice(0, 2_000) });
      history.push({
        role: "user",
        content: "That was not a single action in the required shape. Reply again with exactly one STEP/TOOL block.",
      });
      continue;
    }
    confused = 0;

    emit({ type: "step", text: action.step, tool: action.tool });

    if (action.tool === "finish") {
      emit({ type: "done", text: action.body?.trim() || "The job is done." });
      return;
    }

    const { observation, ok, shown } = await performDesktopAction(action);
    emit({ type: "result", text: shown, tool: action.tool, ok });

    history.push({ role: "assistant", content: reply.text.slice(0, 8_000) });
    history.push({
      role: "user",
      content: `OBSERVATION: ${observation || "(nothing to report)"}\n\nTake the next action, or finish if the job is complete.`,
    });
  }

  emit({
    type: "error",
    text: `That took more than ${maxSteps} steps, so Ash stopped to check in. Tell it what to do next.`,
  });
}
