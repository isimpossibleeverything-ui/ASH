/**
 * The bridge between the Ash page and the Windows app around it.
 *
 * In a normal browser tab every call here fails the same honest way: "this
 * only works in the desktop app". Inside the Tauri shell the same calls reach
 * real folders and real programs — but only after the person has picked a
 * folder, which is the moment permission is actually given.
 */

export type DesktopStatus = {
  available: boolean;
  granted: boolean;
  root: string | null;
  os: string;
  app_version: string;
  port: number;
};

export type DesktopEntry = {
  name: string;
  path: string;
  is_dir: boolean;
  bytes: number;
};

export type RunResult = {
  code: number;
  stdout: string;
  stderr: string;
  timed_out: boolean;
};

export type LogEntry = {
  at: number;
  action: string;
  detail: string;
  ok: boolean;
};

type TauriGlobal = {
  core?: { invoke?: (cmd: string, args?: Record<string, unknown>) => Promise<unknown> };
  event?: {
    listen?: (
      name: string,
      handler: (e: { payload: unknown }) => void,
    ) => Promise<() => void>;
  };
};

function bridge(): TauriGlobal | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as { __TAURI__?: TauriGlobal };
  return w.__TAURI__ ?? null;
}

/** True when the page is running inside the Ash desktop app. */
export function isDesktop(): boolean {
  return Boolean(bridge()?.core?.invoke);
}

export const DESKTOP_ONLY =
  "This only works in the Ash desktop app for Windows. In a browser tab Ash cannot reach your files or programs.";

async function call<T>(cmd: string, args?: Record<string, unknown>): Promise<T> {
  const invoke = bridge()?.core?.invoke;
  if (!invoke) throw new Error(DESKTOP_ONLY);
  return (await invoke(cmd, args)) as T;
}

/* ───────────────────────── permission ───────────────────────── */

const OFFLINE: DesktopStatus = {
  available: false,
  granted: false,
  root: null,
  os: "browser",
  app_version: "",
  port: 0,
};

export async function desktopStatus(): Promise<DesktopStatus> {
  if (!isDesktop()) return OFFLINE;
  try {
    return await call<DesktopStatus>("desktop_status");
  } catch {
    return OFFLINE;
  }
}

/** Opens the real Windows folder picker. Whatever is chosen becomes the fence. */
export function desktopGrant(): Promise<DesktopStatus> {
  return call<DesktopStatus>("desktop_grant");
}

export function desktopRevoke(): Promise<DesktopStatus> {
  return call<DesktopStatus>("desktop_revoke");
}

/** Fires whenever permission is given or taken away. */
export async function onPermissionChange(
  fn: (granted: boolean) => void,
): Promise<() => void> {
  const listen = bridge()?.event?.listen;
  if (!listen) return () => {};
  try {
    return await listen("desktop-permission", (e) => fn(Boolean(e.payload)));
  } catch {
    return () => {};
  }
}

/* ───────────────────────── the work ───────────────────────── */

export const desktopList = (path?: string) =>
  call<DesktopEntry[]>("desktop_list", { path: path ?? "" });

export const desktopRead = (path: string) => call<string>("desktop_read", { path });

export const desktopWrite = (path: string, contents: string) =>
  call<string>("desktop_write", { path, contents });

export const desktopMkdir = (path: string) => call<string>("desktop_mkdir", { path });

/** Always asks again in a native dialog, even while permission is live. */
export const desktopDelete = (path: string) => call<string>("desktop_delete", { path });

export const desktopRun = (line: string) => call<RunResult>("desktop_run", { line });

export const desktopOpen = (target: string) => call<string>("desktop_open", { target });

export const desktopLog = () => call<LogEntry[]>("desktop_log");

/** Human-sized file size for the file lists. */
export function prettyBytes(n: number): string {
  if (!n) return "";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${Math.round(n / 1024)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}
