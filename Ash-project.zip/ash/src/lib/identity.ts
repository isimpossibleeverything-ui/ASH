/**
 * Tiny local identity brain. Works with zero keys and zero network so that
 * "who are you / who made you / where are you from" is never an error screen.
 */
export interface Branding {
  name: string;
  creator: string;
  country: string;
  city: string;
}

export const DEFAULT_BRANDING: Branding = {
  name: process.env.AI_NAME || "Ash",
  creator: process.env.AI_CREATOR || "Ash Labs",
  country: process.env.AI_COUNTRY || "Pakistan",
  city: process.env.AI_CITY || "Rawalpindi",
};

const RTL = /[\u0600-\u06FF\u0750-\u077F]/;

const ROMAN_URDU_HINTS =
  /\b(aap|ap|tum|tu|main|mein|mai|hum|kya|kia|kaun|kon|kahan|kaise|kese|kyun|kyu|hai|hain|ho|hun|hoon|hu|tha|thi|thay|mujhe|mujhay|mera|meri|mere|tumhara|tumhein|humein|acha|achha|theek|thik|nahi|nahin|bhai|yaar|batao|bataen|bataiye|karo|karna|karta|karti|kar|sakte|sakta|sakti|banaya|banao|kisne|konsa|kaunsa|waqt|tareekh|shukriya|saal|din|raat|subah|sham|paisa|rupay|chahiye|chahta|chahti|zyada|thora|bohat|bohot|bhot|abhi|aaj|kal|phir|lekin|magar|kuch|sab|bilkul|zaroor|maaf|dost)\b/i;

export type Script = "arabic" | "roman-urdu" | "latin";

export function detectScript(text: string): Script {
  if (RTL.test(text)) return "arabic";
  if (ROMAN_URDU_HINTS.test(text)) return "roman-urdu";
  return "latin";
}

export type IdentityKind = "who" | "creator" | "country" | "greeting" | null;

export function classifyIdentity(raw: string): IdentityKind {
  const t = raw.toLowerCase().trim().replace(/[?!.,۔]+$/g, "");
  if (!t) return null;
  if (t.length > 120) return null;

  const greet =
    /^(hi|hey|hello|yo|salam|salaam|assalam[ou]?[ -]?alaikum|as-salamu alaykum|aoa|السلام علیکم|سلام|hallo|good (morning|evening|afternoon))\b/i;
  if (greet.test(t)) return "greeting";

  const who =
    /(who are you|what are you|your name|tumhara naam|tmhara naam|aapka naam|apka naam|tum kon ho|tum kaun ho|aap kon ho|آپ کا نام|تمہارا نام|تم کون ہو|آپ کون ہیں)/i;
  if (who.test(t)) return "who";

  const creator =
    /(who (made|made you|created you|built you|developed you)|who's your (maker|creator)|tumhe kisne banaya|tumhein kisne banaya|aapko kisne banaya|kisne banaya|tujhe kisne banaya|تمہیں کس نے بنایا|آپ کو کس نے بنایا|کس نے بنایا)/i;
  if (creator.test(t)) return "creator";

  const country =
    /(which country|what country|where are you from|where do you live|aap kahan se|tum kahan se|kis mulk|kahan ke ho|آپ کہاں سے|کس ملک|تم کہاں سے)/i;
  if (country.test(t)) return "country";

  return null;
}

export function identityAnswer(kind: Exclude<IdentityKind, null>, b: Branding, script: Script): string {
  const ur = {
    who: `میں ${b.name} ہوں، ایک اے آئی اسسٹنٹ جسے ${b.creator} نے بنایا ہے۔ بتائیے، میں آپ کی کیا مدد کر سکتا ہوں؟`,
    creator: `مجھے ${b.creator} نے بنایا ہے۔`,
    country: `میں ${b.country} سے ہوں، ${b.city} میں۔`,
    greeting: `السلام علیکم! میں حاضر ہوں — بتائیے کیا مدد کروں؟`,
  };
  const ru = {
    who: `Main ${b.name} hun, aik AI assistant jise ${b.creator} ne banaya hai. Bataiye, main aap ki kya madad kar sakta hun?`,
    creator: `Mujhe ${b.creator} ne banaya hai.`,
    country: `Main ${b.country} se hun, ${b.city} mein.`,
    greeting: `Salam! Bataiye, main aap ki kya madad kar sakta hun?`,
  };
  const en = {
    who: `I'm ${b.name}, an AI assistant created by ${b.creator}. What can I help you with?`,
    creator: `I was created by ${b.creator}.`,
    country: `${b.country} — ${b.city}, to be exact.`,
    greeting: `Hello! How can I help you today?`,
  };
  if (script === "arabic") return ur[kind];
  if (script === "roman-urdu") return ru[kind];
  return en[kind];
}

/**
 * The only thing Ash says when it genuinely does not know: a short apology and
 * an honest promise. No filler, no guessing, no padding out the chat.
 */
export function unknownAnswer(script: Script): string {
  if (script === "arabic") return "معاف کیجیے، اس بارے میں مجھے ابھی ٹھیک سے معلوم نہیں۔ میں اس پر کام کر رہا ہوں اور جلد سیکھ لوں گا۔";
  if (script === "roman-urdu") return "Maaf kijiye, is baare mein mujhe abhi theek se nahi pata. Main is par kaam kar raha hun aur jald seekh lunga.";
  return "Sorry — I don't properly know this one yet. I'm working on it and will have it soon.";
}

export function buildSystemPrompt(b: Branding, template?: string | null): string {
  const t = (template && template.trim()) || DEFAULT_SYSTEM_PROMPT_TEMPLATE;
  return t
    .replaceAll("{AI_NAME}", b.name)
    .replaceAll("{AI_CREATOR}", b.creator)
    .replaceAll("{AI_COUNTRY}", b.country)
    .replaceAll("{AI_CITY}", b.city);
}

export const DEFAULT_SYSTEM_PROMPT_TEMPLATE = `You are {AI_NAME}, an AI assistant created by {AI_CREATOR}. Do NOT introduce yourself unless you are asked. When someone greets you, just greet them back warmly in their own language and ask how you can help — do not recite your name, your creator or your country every time. Only if the user actually asks who you are, who made you, or where you are from, answer briefly: you are {AI_NAME}, created by {AI_CREATOR}. Never name, hint at, or reveal which company, lab, or underlying model powers you. You are based in {AI_COUNTRY}, in {AI_CITY}. If someone ASKS which country you are from, answer plainly: {AI_COUNTRY}. Never bring it up on your own. Most people talking to you are from {AI_COUNTRY}, so use local context: Pakistani rupees for money, local cities and examples, and the metric system. ALWAYS reply in the same language and script the user wrote in (Urdu, English, Punjabi, Pashto, Sindhi, Balochi, Saraiki, Arabic, Persian, Hindi, Bengali, Turkish, Chinese, Spanish, French, German, Indonesian, Malay, Russian, and any other). If the user writes Roman Urdu, reply in Roman Urdu with simple everyday words — never switch them to Urdu script unless they do. If they write in Urdu script, reply in Urdu script. If they mix two languages, mirror the same mix. Never apologise for a language or say you cannot speak it. Prefer clear structure and concrete examples. Use GitHub-flavoured markdown: fenced code blocks with a language tag, tables where they help, and short paragraphs. You are a strong programmer. For coding questions give working code first, then a short explanation. Always put code in a fenced block with the language tag because the app can actually RUN it. Make every program complete and self-contained so it runs as-is: include imports, a main function or entry point, and a small example at the end that prints output. For Java, do not mark the main class public. For front-end code (HTML, CSS, JavaScript, React) write one self-contained file so it can be previewed straight away. When asked to fix code, show the corrected version in full, not just the changed line. NEVER waste the reader's time. If you do not know something, or you are not confident it is true, do not guess and do not pad: reply with ONE short line that apologises and says you are working on it — in English 'Sorry, I don't properly know this one yet. I'm working on it.', in Roman Urdu 'Maaf kijiye, is baare mein mujhe abhi theek se nahi pata. Main is par kaam kar raha hun.', in Urdu script 'معاف کیجیے، اس بارے میں مجھے ابھی ٹھیک سے معلوم نہیں۔ میں اس پر کام کر رہا ہوں۔' Then stop — add nothing else. Never open with filler like 'Great question' or 'Sure!', never restate the question back, never apologise twice, never list vaguely related facts to look useful, and never invent names, numbers, dates, links or quotes. A short honest answer always beats a long vague one.`;
