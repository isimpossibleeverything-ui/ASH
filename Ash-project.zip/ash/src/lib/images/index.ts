/**
 * Free image + clip generation.
 *
 * The keyless source (no sign-up at all) allows roughly one image per minute
 * per IP and answers 402 in between, so every call goes through a pacer that
 * knows when the next slot opens. Any free key the owner adds removes that
 * limit, and frames are then generated in parallel.
 */

export interface ImageResult {
  dataUrl: string;
  source: string;
}

export class MediaError extends Error {
  detail: string;
  retryAfter: number;
  constructor(message: string, detail: string, retryAfter = 0) {
    super(message);
    this.name = "MediaError";
    this.detail = detail;
    this.retryAfter = retryAfter;
  }
}

/* Measured against the live service: a slot opens roughly once a minute.
   The gap self-tunes — every 402 widens it, every success relaxes it. */
const KEYLESS_BASE_MS = 62_000;
const KEYLESS_MAX_MS = 150_000;
let keylessCooldownMs = KEYLESS_BASE_MS;
const TIMEOUT = 90_000;
const MIN_BYTES = 2000;

let keylessNextAt = 0;

export function keylessWaitMs(): number {
  return Math.max(0, keylessNextAt - Date.now());
}

const sleep = (ms: number, signal?: AbortSignal) =>
  new Promise<void>((resolve, reject) => {
    if (ms <= 0) return resolve();
    const t = setTimeout(resolve, ms);
    signal?.addEventListener(
      "abort",
      () => {
        clearTimeout(t);
        reject(new Error("cancelled"));
      },
      { once: true },
    );
  });

async function timed<T>(fn: (signal: AbortSignal) => Promise<T>, outer?: AbortSignal, ms = TIMEOUT): Promise<T> {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), ms);
  const relay = () => controller.abort();
  outer?.addEventListener("abort", relay, { once: true });
  try {
    return await fn(controller.signal);
  } finally {
    clearTimeout(t);
    outer?.removeEventListener("abort", relay);
  }
}

function toDataUrl(buf: ArrayBuffer, mime = "image/jpeg"): string {
  return `data:${mime.split(";")[0]};base64,${Buffer.from(buf).toString("base64")}`;
}

export interface GenerateOptions {
  width?: number;
  height?: number;
  seed?: number;
  signal?: AbortSignal;
  /** Clips may wait for the keyless slot; a single image should not. */
  waitForSlot?: boolean;
}

/* ───────────────────────────── sources ───────────────────────────── */

async function pollinations(prompt: string, o: { width: number; height: number; seed: number }, signal?: AbortSignal) {
  return timed(async (s) => {
    const url =
      `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}` +
      `?width=${o.width}&height=${o.height}&nologo=true&seed=${o.seed}&model=flux&referrer=ash-chat`;
    // cache:"no-store" is essential — the framework fetch cache corrupts binary bodies.
    const res = await fetch(url, { signal: s, cache: "no-store", headers: { accept: "image/*" } });
    if (res.status === 402 || res.status === 429) {
      keylessCooldownMs = Math.min(KEYLESS_MAX_MS, Math.round(keylessCooldownMs * 1.25) + 5_000);
      keylessNextAt = Date.now() + keylessCooldownMs;
      throw new MediaError("rate limited", "keyless tier is cooling down", Math.ceil(keylessCooldownMs / 1000));
    }
    if (!res.ok) throw new Error(`free service returned ${res.status}`);
    const type = res.headers.get("content-type") || "image/jpeg";
    const buf = await res.arrayBuffer();
    if (!type.startsWith("image/")) throw new Error(`free service sent ${type}`);
    if (buf.byteLength < MIN_BYTES) throw new Error(`free service sent ${buf.byteLength} bytes`);
    keylessCooldownMs = Math.max(KEYLESS_BASE_MS, Math.round(keylessCooldownMs * 0.9));
    keylessNextAt = Date.now() + keylessCooldownMs;
    return { dataUrl: toDataUrl(buf, type), source: "free" } satisfies ImageResult;
  }, signal);
}

async function huggingface(prompt: string, signal?: AbortSignal) {
  const token = (process.env.HF_TOKEN || "").trim();
  if (!token) return null;
  return timed(async (s) => {
    const res = await fetch("https://router.huggingface.co/hf-inference/models/black-forest-labs/FLUX.1-schnell", {
      method: "POST",
      signal: s,
      cache: "no-store",
      headers: { authorization: `Bearer ${token}`, "content-type": "application/json", accept: "image/png" },
      body: JSON.stringify({ inputs: prompt }),
    });
    if (!res.ok) throw new Error(`hf returned ${res.status}`);
    const type = res.headers.get("content-type") || "";
    const buf = await res.arrayBuffer();
    if (!type.startsWith("image/")) throw new Error(`hf sent ${type}`);
    if (buf.byteLength < MIN_BYTES) throw new Error("hf sent an empty image");
    return { dataUrl: toDataUrl(buf, type), source: "hf" } satisfies ImageResult;
  }, signal);
}

async function together(prompt: string, o: { width: number; height: number }, signal?: AbortSignal) {
  const key = (process.env.TOGETHER_API_KEY || "").trim();
  if (!key) return null;
  return timed(async (s) => {
    const res = await fetch("https://api.together.xyz/v1/images/generations", {
      method: "POST",
      signal: s,
      cache: "no-store",
      headers: { authorization: `Bearer ${key}`, "content-type": "application/json" },
      body: JSON.stringify({
        model: "black-forest-labs/FLUX.1-schnell-Free",
        prompt,
        width: o.width,
        height: o.height,
        steps: 4,
        n: 1,
        response_format: "b64_json",
      }),
    });
    if (!res.ok) throw new Error(`together returned ${res.status}`);
    const data = (await res.json()) as any;
    const b64 = data?.data?.[0]?.b64_json;
    if (typeof b64 === "string" && b64.length > 1000) {
      return { dataUrl: `data:image/png;base64,${b64}`, source: "together" } satisfies ImageResult;
    }
    const url = data?.data?.[0]?.url;
    if (typeof url === "string") {
      const img = await fetch(url, { signal: s, cache: "no-store" });
      if (img.ok) {
        return {
          dataUrl: toDataUrl(await img.arrayBuffer(), img.headers.get("content-type") || "image/png"),
          source: "together",
        } satisfies ImageResult;
      }
    }
    throw new Error("together sent no image");
  }, signal);
}

async function geminiImage(prompt: string, signal?: AbortSignal) {
  const key = (process.env.GEMINI_API_KEY || "").trim();
  if (!key) return null;
  return timed(async (s) => {
    const res = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image:generateContent", {
      method: "POST",
      signal: s,
      cache: "no-store",
      headers: { "content-type": "application/json", "x-goog-api-key": key },
      body: JSON.stringify({ contents: [{ role: "user", parts: [{ text: prompt }] }] }),
    });
    if (!res.ok) throw new Error(`gemini image returned ${res.status}`);
    const data = (await res.json()) as any;
    for (const p of data?.candidates?.[0]?.content?.parts ?? []) {
      const inline = p?.inlineData ?? p?.inline_data;
      if (inline?.data) {
        return {
          dataUrl: `data:${inline.mimeType || inline.mime_type || "image/png"};base64,${inline.data}`,
          source: "gemini",
        } satisfies ImageResult;
      }
    }
    throw new Error("gemini sent no image");
  }, signal);
}

/** Which keyed sources the owner has unlocked. */
export function keyedSourceCount(): number {
  let n = 0;
  if ((process.env.HF_TOKEN || "").trim()) n++;
  if ((process.env.TOGETHER_API_KEY || "").trim()) n++;
  if ((process.env.GEMINI_API_KEY || "").trim()) n++;
  return n;
}

export type ClipMode = "frames" | "motion";

export interface MediaCapability {
  keyedSources: number;
  /** true when the only option is the once-a-minute keyless service */
  keylessOnly: boolean;
  waitMs: number;
  /** how many clip frames are realistic right now */
  suggestedFrames: number;
  /**
   * "frames" = a true frame-by-frame clip (needs a free key).
   * "motion" = one generated still with real camera movement, which is all the
   * once-a-minute keyless tier can deliver without a multi-minute wait.
   */
  clipMode: ClipMode;
}

export function capability(): MediaCapability {
  const keyed = keyedSourceCount();
  return {
    keyedSources: keyed,
    keylessOnly: keyed === 0,
    waitMs: keylessWaitMs(),
    suggestedFrames: keyed === 0 ? 1 : 6,
    clipMode: keyed === 0 ? "motion" : "frames",
  };
}

/* ───────────────────────────── one image ───────────────────────────── */

export async function generateImage(prompt: string, options: GenerateOptions = {}): Promise<ImageResult> {
  const width = options.width ?? 1024;
  const height = options.height ?? 1024;
  const seed = options.seed ?? Math.floor(Math.random() * 1_000_000);
  const keyed = keyedSourceCount();
  const reasons: string[] = [];

  // Keyed sources first — they are faster and have no per-minute gate.
  const keyedAttempts: Array<[string, () => Promise<ImageResult | null>]> = [
    ["hf", () => huggingface(prompt, options.signal)],
    ["together", () => together(prompt, { width, height }, options.signal)],
    ["gemini", () => geminiImage(prompt, options.signal)],
  ];
  for (const [id, attempt] of keyedAttempts) {
    if (options.signal?.aborted) break;
    try {
      const result = await attempt();
      if (result) return result;
    } catch (err) {
      reasons.push(`${id}: ${(err as Error)?.message || "failed"}`);
    }
  }

  // Keyless source, respecting its cooldown.
  const wait = keylessWaitMs();
  if (wait > 0) {
    if (!options.waitForSlot) {
      throw new MediaError(
        keyed > 0
          ? "Every image service is busy right now. Please try again shortly."
          : `The free image service allows one picture a minute. The next one is ready in ${Math.ceil(wait / 1000)}s.`,
        reasons.join(" · ") || "keyless tier cooling down",
        Math.ceil(wait / 1000),
      );
    }
    await sleep(wait, options.signal);
  }

  try {
    const result = await pollinations(prompt, { width, height, seed }, options.signal);
    if (result) return result;
  } catch (err) {
    const e = err as MediaError;
    reasons.push(`free: ${e?.message || "failed"}`);
    throw new MediaError(
      keyed > 0
        ? "Every image service is busy right now. Please try again shortly."
        : `The free image service is cooling down. Try again in about ${e?.retryAfter || 60}s, or add a free key in the Control Panel for instant images.`,
      reasons.join(" · "),
      e?.retryAfter || 60,
    );
  }

  throw new MediaError("Could not create that image right now.", reasons.join(" · ") || "no image source available");
}

/* ───────────────────────────── clips ───────────────────────────── */

export interface ClipProgress {
  done: number;
  total: number;
  /** ms until the next frame can start, when the keyless gate applies */
  waitMs: number;
}

export interface ClipResult {
  frames: string[];
  fps: number;
  mode: ClipMode;
  requested: number;
  failures: string[];
}

async function poolRun<T>(jobs: Array<() => Promise<T>>, size: number): Promise<PromiseSettledResult<T>[]> {
  const results: PromiseSettledResult<T>[] = new Array(jobs.length);
  let cursor = 0;
  await Promise.all(
    Array.from({ length: Math.min(size, jobs.length) }, async () => {
      for (;;) {
        const i = cursor++;
        if (i >= jobs.length) return;
        try {
          results[i] = { status: "fulfilled", value: await jobs[i]() };
        } catch (reason) {
          results[i] = { status: "rejected", reason };
        }
      }
    }),
  );
  return results;
}

/**
 * A short silent clip. Frames are 512px so six of them stay around 250 KB.
 * With a free key the frames run three at a time; keyless they are paced
 * one per slot and progress is reported so nobody stares at a dead spinner.
 */
export async function generateFrames(
  prompt: string,
  count: number,
  signal?: AbortSignal,
  onProgress?: (p: ClipProgress) => void,
): Promise<ClipResult> {
  const cap = capability();

  /* ── keyless: one still, animated with real camera motion in the browser ──
     A frame-by-frame clip would need one image per minute, so it would take
     several minutes and still risk the serverless timeout. One good frame plus
     a genuine slow push-in gives a watchable clip in a few seconds. */
  if (cap.clipMode === "motion") {
    onProgress?.({ done: 0, total: 1, waitMs: keylessWaitMs() });
    const still = await generateImage(`${prompt}, cinematic, rich depth, detailed, wide composition`, {
      width: 1024,
      height: 576,
      signal,
      waitForSlot: true,
    });
    onProgress?.({ done: 1, total: 1, waitMs: 0 });
    return { frames: [still.dataUrl], fps: 30, mode: "motion", requested: 1, failures: [] };
  }

  /* ── with a free key: a real multi-frame clip, three at a time ── */
  const total = Math.min(10, Math.max(2, count || cap.suggestedFrames));
  const baseSeed = Math.floor(Math.random() * 500_000);
  const style = "consistent character, consistent style and colour palette, cinematic still";
  const shot = (i: number) => `${prompt}, ${style}, frame ${i + 1} of ${total}`;
  const frames: string[] = [];
  const failures: string[] = [];
  let finished = 0;

  const jobs = Array.from({ length: total }, (_, i) => async () => {
    const r = await generateImage(shot(i), { width: 512, height: 512, seed: baseSeed + i * 11, signal, waitForSlot: true });
    onProgress?.({ done: ++finished, total, waitMs: 0 });
    return r;
  });

  const settled = await poolRun(jobs, 3);
  for (const r of settled) {
    if (r?.status === "fulfilled" && r.value) frames.push(r.value.dataUrl);
    else if (r?.status === "rejected") failures.push((r.reason as Error)?.message || "frame failed");
  }

  if (frames.length < 2) {
    throw new MediaError(
      "Could not create that clip right now. Please try again in a moment.",
      failures.slice(0, 3).join(" · ") || "no frames were produced",
    );
  }
  return { frames, fps: 2, mode: "frames", requested: total, failures };
}
