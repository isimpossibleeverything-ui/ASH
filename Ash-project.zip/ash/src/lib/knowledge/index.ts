import { allKnowledge, bumpKnowledgeHit, findKnowledgeExact, saveKnowledge, type KnowledgeRow } from "@/lib/db/repo";
import { invalidateTrainingScores } from "@/lib/providers";

const STOP = new Set([
  "the","a","an","is","are","was","were","of","to","in","on","for","and","or","what","who","how","why","when","where",
  "do","does","did","it","that","this","with","as","at","by","from","be","can","you","your","me","my","i","explain",
  "simply","please","tell","about","kya","hai","hain","ka","ki","ke","ko","se","mein","main","aur","ye","yeh","wo",
  "kaise","kyun","kon","kaun","batao","bataye","samjhayen","sakta","sakte","ho","hu","hun",
]);

export function normaliseQuestion(q: string): string {
  return q
    .toLowerCase()
    .replace(/[\u0640]/g, "")
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function terms(q: string): string[] {
  return normaliseQuestion(q)
    .split(" ")
    .filter((t) => t.length > 1 && !STOP.has(t));
}

function dice(a: Set<string>, b: Set<string>): number {
  if (!a.size || !b.size) return 0;
  let inter = 0;
  for (const t of a) if (b.has(t)) inter++;
  return (2 * inter) / (a.size + b.size);
}

/* ───────────────── cached search index ─────────────────
   Rebuilding this on every question made both chat recall and the training
   loop scan the whole table. It is now built once and reused until a write
   bumps the version. */

interface KnowledgeIndex {
  rows: KnowledgeRow[];
  tokens: string[][];
  sets: Set<string>[];
  df: Map<string, number>;
  avgdl: number;
  version: number;
  at: number;
}

let indexVersion = 0;
let cachedIndex: KnowledgeIndex | null = null;
let building: Promise<KnowledgeIndex> | null = null;

/** Call after anything writes to the knowledge table. */
export function invalidateKnowledgeIndex(): void {
  indexVersion++;
}

async function getIndex(): Promise<KnowledgeIndex> {
  if (cachedIndex && cachedIndex.version === indexVersion && Date.now() - cachedIndex.at < 120_000) return cachedIndex;
  if (building) return building;
  const version = indexVersion;
  building = (async () => {
    const rows = await allKnowledge(8000);
    const tokens = rows.map((r) => terms(r.question));
    const sets = tokens.map((t) => new Set(t));
    const df = new Map<string, number>();
    for (const set of sets) for (const t of set) df.set(t, (df.get(t) ?? 0) + 1);
    const avgdl = tokens.reduce((sum, t) => sum + t.length, 0) / (tokens.length || 1) || 1;
    const built: KnowledgeIndex = { rows, tokens, sets, df, avgdl, version, at: Date.now() };
    cachedIndex = built;
    building = null;
    return built;
  })();
  return building;
}

/** Classic BM25, scored against the prebuilt index. */
function bm25(queryTerms: string[], index: KnowledgeIndex): Float64Array {
  const k1 = 1.5;
  const b = 0.75;
  const N = index.rows.length || 1;
  const scores = new Float64Array(N);
  for (let d = 0; d < N; d++) {
    const docTokens = index.tokens[d];
    if (!docTokens.length) continue;
    let score = 0;
    for (const q of queryTerms) {
      let f = 0;
      for (const t of docTokens) if (t === q) f++;
      if (!f) continue;
      const n = index.df.get(q) ?? 0;
      const idf = Math.log(1 + (N - n + 0.5) / (n + 0.5));
      score += idf * ((f * (k1 + 1)) / (f + k1 * (1 - b + (b * docTokens.length) / index.avgdl)));
    }
    scores[d] = score;
  }
  return scores;
}

export type RecallKind = "exact" | "similar" | "unknown";

export interface Recall {
  kind: RecallKind;
  answer: string | null;
  confidence: number;
  question?: string;
  source?: string;
}

/** Wikipedia-style markup sometimes sneaks in. Make it readable markdown. */
export function cleanMarkup(text: string): string {
  return text
    .replace(/^======\s*(.+?)\s*======$/gm, "**$1**")
    .replace(/^=====\s*(.+?)\s*=====$/gm, "**$1**")
    .replace(/^====\s*(.+?)\s*====$/gm, "**$1**")
    .replace(/^===\s*(.+?)\s*===$/gm, "**$1**")
    .replace(/^==\s*(.+?)\s*==$/gm, "**$1**")
    .replace(/\[\[([^\]|]+)\|([^\]]+)\]\]/g, "$2")
    .replace(/\[\[([^\]]+)\]\]/g, "$1")
    .replace(/'''(.+?)'''/g, "**$1**")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

const SIMILAR_THRESHOLD = 0.72;

export async function recall(question: string): Promise<Recall> {
  const norm = normaliseQuestion(question);
  if (!norm) return { kind: "unknown", answer: null, confidence: 0 };

  const exact = await findKnowledgeExact(norm);
  if (exact && isTrusted(exact)) {
    bumpKnowledgeHit(exact.id).catch(() => {});
    return { kind: "exact", answer: cleanMarkup(exact.answer), confidence: 1, question: exact.question, source: exact.provider || undefined };
  }

  const qTerms = terms(question);
  if (!qTerms.length) return { kind: "unknown", answer: null, confidence: 0 };
  const index = await getIndex();
  if (!index.rows.length) return { kind: "unknown", answer: null, confidence: 0 };

  const qSet = new Set(qTerms);
  const scores = bm25(qTerms, index);
  const shortlist: number[] = [];
  for (let i = 0; i < scores.length; i++) if (scores[i] > 0) shortlist.push(i);
  shortlist.sort((a, b) => scores[b] - scores[a]);

  let best: { row: KnowledgeRow; score: number } | null = null;
  for (const i of shortlist.slice(0, 25)) {
    const row = index.rows[i];
    if (!row || !isTrusted(row)) continue;
    const dSet = index.sets[i];
    let covered = 0;
    for (const t of qSet) if (dSet.has(t)) covered++;
    const coverage = covered / qSet.size;
    const score = coverage * 0.65 + dice(qSet, dSet) * 0.35;
    if (!best || score > best.score) best = { row, score };
  }

  if (best && best.score >= SIMILAR_THRESHOLD) {
    bumpKnowledgeHit(best.row.id).catch(() => {});
    return {
      kind: "similar",
      answer: cleanMarkup(best.row.answer),
      confidence: Math.round(best.score * 100) / 100,
      question: best.row.question,
      source: best.row.provider || undefined,
    };
  }
  return { kind: "unknown", answer: null, confidence: best ? Math.round(best.score * 100) / 100 : 0 };
}

/** Only answers that came from a real AI engine are trusted for recall. */
function isTrusted(row: KnowledgeRow): boolean {
  const p = (row.provider || "").toLowerCase();
  if (!p) return false;
  if (p === "demo" || p === "brain" || p === "smart" || p === "web") return false;
  return row.quality >= 1;
}

export interface GateResult {
  ok: boolean;
  reason?: string;
}

/** Quality gates. Nothing gets saved unless it passes every one of them. */
export function passesQualityGates(question: string, answer: string, providerId: string): GateResult {
  const a = (answer || "").trim();
  if (a.length < 200) return { ok: false, reason: "Too short (under 200 characters)." };
  const p = (providerId || "").toLowerCase();
  if (!p || p === "demo" || p === "brain" || p === "smart") return { ok: false, reason: "Not from a real engine." };
  const lower = a.toLowerCase();
  if (/^(sorry|maaf|i'?m sorry|i cannot|i can'?t|as an ai)/.test(lower)) return { ok: false, reason: "It is an apology." };
  if (lower.includes("you said:") || lower.includes("offline demo engine")) return { ok: false, reason: "Contains transcript noise." };
  if (lower.includes("may refer to:") || lower.includes("may also refer to")) return { ok: false, reason: "Disambiguation page." };
  if (/\b(request failed|error|unavailable|rate limit|quota)\b/.test(lower.slice(0, 120))) return { ok: false, reason: "Looks like an error." };

  const qTerms = terms(question);
  if (qTerms.length) {
    const aSet = new Set(terms(a));
    const covered = qTerms.filter((t) => aSet.has(t)).length;
    if (covered / qTerms.length < 0.3) return { ok: false, reason: "Does not address the question." };
  }
  return { ok: true };
}

export interface RememberInput {
  question: string;
  answer: string;
  providerId: string;
  modelId?: string;
  topic?: string | null;
}

export async function remember(input: RememberInput): Promise<{ saved: boolean; reason?: string }> {
  const gate = passesQualityGates(input.question, input.answer, input.providerId);
  if (!gate.ok) return { saved: false, reason: gate.reason };
  invalidateKnowledgeIndex();
  invalidateTrainingScores();
  const result = await saveKnowledge({
    question: input.question.trim(),
    questionNorm: normaliseQuestion(input.question),
    answer: input.answer.trim(),
    topic: input.topic ?? null,
    provider: input.providerId,
    model: input.modelId ?? null,
    quality: 1,
  });
  return { saved: result !== "kept", reason: result };
}

/* ───────────── question generator (English + Urdu + Roman Urdu) ───────────── */

export const TOPICS: Record<string, string[]> = {
  science: ["photosynthesis", "gravity", "DNA", "the water cycle", "evolution", "electricity", "the solar system", "vaccines", "climate change", "atoms"],
  math: ["prime numbers", "the Pythagorean theorem", "percentages", "probability", "algebra", "calculus", "matrices", "statistics", "fractions", "logarithms"],
  programming: ["recursion", "big O notation", "REST APIs", "Git branching", "SQL joins", "closures in JavaScript", "Python decorators", "unit testing", "Docker containers", "data structures"],
  technology: ["machine learning", "blockchain", "cloud computing", "5G networks", "cyber security", "quantum computing", "the internet of things", "GPS", "compression", "encryption"],
  health: ["a balanced diet", "good sleep", "diabetes", "blood pressure", "mental health", "exercise", "first aid", "hydration", "vitamins", "dental care"],
  history: ["the Indus Valley civilisation", "the Mughal empire", "the industrial revolution", "the silk road", "the partition of 1947", "ancient Egypt", "the renaissance", "world war two", "the Ottoman empire", "the moon landing"],
  geography: ["monsoons", "the Himalayas", "deserts", "rivers of Pakistan", "earthquakes", "time zones", "oceans", "glaciers", "volcanoes", "the equator"],
  business: ["inflation", "supply and demand", "a business plan", "marketing funnels", "profit margins", "freelancing", "e-commerce", "budgeting", "stock markets", "taxes"],
  language: ["the present perfect tense", "metaphors", "formal letters", "common idioms", "punctuation", "essay structure", "active and passive voice", "synonyms", "pronunciation", "note taking"],
  "islamic-studies": ["the five pillars of Islam", "zakat", "the Hajj", "Ramadan", "Islamic ethics", "the Hijri calendar", "prayer times", "charity in Islam", "halal food rules", "patience in Islam"],
  "daily-life": ["saving money", "cooking rice", "buying a used phone", "job interviews", "road safety", "growing plants at home", "cleaning a laptop", "booking train tickets", "writing a CV", "staying productive"],
  education: ["study techniques", "exam preparation", "taking notes", "choosing a degree", "learning English", "memory techniques", "online courses", "scholarships", "time management", "reading faster"],
};

export const TEMPLATES: ((s: string) => string)[] = [
  (s) => `What is ${s}? Explain simply.`,
  (s) => `Explain ${s} to a beginner with an example.`,
  (s) => `Why is ${s} important?`,
  (s) => `How does ${s} work, step by step?`,
  (s) => `What are the main benefits and drawbacks of ${s}?`,
  (s) => `Give me three real-world examples of ${s}.`,
  (s) => `What mistakes do people make with ${s}?`,
  (s) => `${s} ke baare mein Urdu mein aasan alfaz mein samjhayen.`,
  (s) => `${s} kya hai aur ye kaise kaam karta hai?`,
  (s) => `${s} ke faide aur nuqsan kya hain?`,
  (s) => `${s} کیا ہے؟ آسان الفاظ میں سمجھائیں۔`,
  (s) => `${s} سیکھنے کا بہترین طریقہ کیا ہے؟`,
];

/** Deterministic shuffle so every restart continues the same sequence. */
function seeded(n: number, seed: number): number {
  let x = Math.sin(seed + 1) * 10000;
  x = x - Math.floor(x);
  return Math.floor(x * n);
}

export function generateQuestion(index: number): { question: string; topic: string } {
  const topics = Object.keys(TOPICS);
  const topic = topics[index % topics.length];
  const subjects = TOPICS[topic];
  const subject = subjects[seeded(subjects.length, index * 7 + 3)];
  const template = TEMPLATES[seeded(TEMPLATES.length, index * 13 + 11)];
  return { question: template(subject), topic };
}

export function toJsonl(rows: KnowledgeRow[], systemPrompt: string): string {
  return rows
    .filter((r) => passesQualityGates(r.question, r.answer, r.provider || "").ok)
    .map((r) =>
      JSON.stringify({
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: r.question },
          { role: "assistant", content: cleanMarkup(r.answer) },
        ],
      }),
    )
    .join("\n");
}
