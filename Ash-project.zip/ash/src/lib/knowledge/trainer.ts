import { buildChain, providerFor, type RuntimeModel } from "@/lib/providers";
import { park, soonestExpiry } from "@/lib/providers/health";
import { ProviderError, isNetworkError } from "@/lib/providers/sse";
import { enqueueQuestion, knowledgeStats, nextQueued, queueCount, setQueueStatus } from "@/lib/db/repo";
import { getSettings, saveSettings } from "@/lib/settings";
import { buildSystemPrompt } from "@/lib/identity";
import { generateQuestion, passesQualityGates, remember } from "./index";

export const SPEEDS = {
  gentle: 2,
  normal: 4,
  fast: 8,
  turbo: 12,
} as const;
export type SpeedName = keyof typeof SPEEDS;

const ATTEMPT_TIMEOUT_MS = 45_000;
const CHAIN_TTL_MS = 15_000;
const MAX_ANSWER_CHARS = 24_000;

interface RecentItem {
  question: string;
  outcome: "saved" | "rejected" | "failed";
  reason?: string;
  ms: number;
  at: number;
}

interface TrainerState {
  running: boolean;
  desiredWorkers: number;
  /** what the governor currently allows — free tiers rate-limit hard */
  activeWorkers: number;
  liveWorkers: number;
  rateLimited: number;
  window: { attempts: number; limited: number; saved: number };
  generation: number;
  index: number;
  rotation: number;
  asked: number;
  saved: number;
  rejected: number;
  failed: number;
  startedAt: number;
  lastError: string | null;
  lastSaved: { question: string; at: number } | null;
  recent: RecentItem[];
}

const state: TrainerState = {
  running: false,
  desiredWorkers: 4,
  activeWorkers: 4,
  liveWorkers: 0,
  rateLimited: 0,
  window: { attempts: 0, limited: 0, saved: 0 },
  generation: 0,
  index: 0,
  rotation: 0,
  asked: 0,
  saved: 0,
  rejected: 0,
  failed: 0,
  startedAt: 0,
  lastError: null,
  lastSaved: null,
  recent: [],
};

/* ── the chain is identical for every worker, so build it once in a while ── */
let chainCache: { at: number; chain: RuntimeModel[] } | null = null;
let chainPromise: Promise<RuntimeModel[]> | null = null;

async function cachedChain(): Promise<RuntimeModel[]> {
  if (chainCache && Date.now() - chainCache.at < CHAIN_TTL_MS) return chainCache.chain;
  if (chainPromise) return chainPromise;
  chainPromise = buildChain(null, { realEnginesOnly: true, allModels: true })
    .then((chain) => {
      chainCache = { at: Date.now(), chain };
      chainPromise = null;
      return chain;
    })
    .catch((err) => {
      chainPromise = null;
      throw err;
    });
  return chainPromise;
}

let promptCache: { at: number; value: string } | null = null;
async function cachedSystemPrompt(): Promise<string> {
  if (promptCache && Date.now() - promptCache.at < CHAIN_TTL_MS) return promptCache.value;
  const settings = await getSettings();
  const value = buildSystemPrompt(settings.branding, settings.systemPrompt || null);
  promptCache = { at: Date.now(), value };
  return value;
}

/* ── question source, serialised so two workers never take the same row ── */
let pickLock: Promise<unknown> = Promise.resolve();
function serial<T>(fn: () => Promise<T>): Promise<T> {
  const run = pickLock.then(fn, fn);
  pickLock = run.then(
    () => undefined,
    () => undefined,
  );
  return run;
}

async function pickQuestion(): Promise<{ question: string; topic: string | null; queueId?: string }> {
  const queued = await nextQueued().catch(() => null);
  if (queued) {
    // claim it immediately so the next worker skips past it
    await setQueueStatus(queued.id, "working").catch(() => {});
    return { question: queued.question, topic: queued.topic, queueId: queued.id };
  }
  const generated = generateQuestion(state.index++);
  return { question: generated.question, topic: generated.topic };
}

function note(item: RecentItem) {
  state.recent.unshift(item);
  if (state.recent.length > 12) state.recent.pop();
}

async function askEngines(question: string, workerId: number): Promise<{ text: string; model: RuntimeModel } | null> {
  const chain = await cachedChain();
  if (!chain.length) {
    state.lastError = "No free engine is configured yet. Add one key in card 1.";
    return null;
  }
  const offset = (state.rotation++ + workerId) % chain.length;
  const rotated = [...chain.slice(offset), ...chain.slice(0, offset)];
  const system = await cachedSystemPrompt();

  for (const candidate of rotated) {
    if (!state.running) return null;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), ATTEMPT_TIMEOUT_MS);
    try {
      const provider = await providerFor(candidate);
      let text = "";
      for await (const chunk of provider.stream({
        model: candidate.modelId,
        messages: [{ role: "user", content: question }],
        system,
        temperature: 0.4,
        signal: controller.signal,
      })) {
        if (chunk) text += chunk;
        if (text.length > MAX_ANSWER_CHARS) break;
      }
      if (text.trim()) return { text: text.trim(), model: candidate };
    } catch (err) {
      const status = err instanceof ProviderError ? err.status : isNetworkError(err) ? 0 : 500;
      if (status === 429) {
        state.rateLimited++;
        state.window.limited++;
      }
      state.lastError = (err instanceof Error ? err.message : "Engine error").slice(0, 160);
      await park(candidate.key, status, state.lastError).catch(() => {});
      chainCache = null; // a parked engine should drop out of the rotation now
    } finally {
      clearTimeout(timer);
    }
  }
  return null;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function worker(id: number, generation: number) {
  state.liveWorkers++;
  let misses = 0;
  try {
    while (state.running && state.generation === generation) {
      if (id >= state.activeWorkers) {
        await sleep(2_500); // throttled back by the governor; stay ready
        continue;
      }
      const started = Date.now();
      let task: Awaited<ReturnType<typeof pickQuestion>> | null = null;
      try {
        task = await serial(pickQuestion);
        state.asked++;
        state.window.attempts++;
        const result = await askEngines(task.question, id);

        if (!result) {
          state.failed++;
          misses++;
          note({ question: task.question, outcome: "failed", reason: state.lastError ?? "no engine answered", ms: Date.now() - started, at: Date.now() });
          if (task.queueId) await setQueueStatus(task.queueId, "pending").catch(() => {});
          // Everything is cooling. Sleep until the first engine is genuinely
          // free again instead of spinning against a rate limit.
          const until = await soonestExpiry().catch(() => 0);
          await sleep(Math.min(60_000, Math.max(3_000, until || 2_000 * Math.min(misses, 8))));
          continue;
        }

        misses = 0;
        const gate = passesQualityGates(task.question, result.text, result.model.providerId);
        if (gate.ok) {
          const saved = await remember({
            question: task.question,
            answer: result.text,
            providerId: result.model.providerId,
            modelId: result.model.modelId,
            topic: task.topic,
          });
          if (saved.saved) {
            state.saved++;
            state.window.saved++;
            state.lastSaved = { question: task.question, at: Date.now() };
            note({ question: task.question, outcome: "saved", ms: Date.now() - started, at: Date.now() });
          } else {
            state.rejected++;
            note({ question: task.question, outcome: "rejected", reason: saved.reason, ms: Date.now() - started, at: Date.now() });
          }
        } else {
          state.rejected++;
          note({ question: task.question, outcome: "rejected", reason: gate.reason, ms: Date.now() - started, at: Date.now() });
        }
        if (task.queueId) await setQueueStatus(task.queueId, "done").catch(() => {});
      } catch (err) {
        state.failed++;
        state.lastError = (err instanceof Error ? err.message : "Training error").slice(0, 160);
        if (task?.queueId) await setQueueStatus(task.queueId, "pending").catch(() => {});
        await sleep(3_000);
      }
    }
  } finally {
    state.liveWorkers--;
  }
}

export async function trainerStatus() {
  const [{ total, fromAi }, queued] = await Promise.all([knowledgeStats(), queueCount()]);
  const minutes = state.running && state.startedAt ? (Date.now() - state.startedAt) / 60_000 : 0;
  return {
    running: state.running,
    workers: state.running ? Math.min(state.liveWorkers, state.activeWorkers) : state.liveWorkers,
    activeWorkers: state.activeWorkers,
    rateLimited: state.rateLimited,
    desiredWorkers: state.desiredWorkers,
    speed: (Object.keys(SPEEDS) as SpeedName[]).find((k) => SPEEDS[k] === state.desiredWorkers) ?? "custom",
    total,
    fromAi,
    queued,
    asked: state.asked,
    saved: state.saved,
    rejected: state.rejected,
    failed: state.failed,
    ratePerMin: minutes > 0.1 ? Math.round((state.saved / minutes) * 10) / 10 : 0,
    uptimeSec: state.startedAt ? Math.round((Date.now() - state.startedAt) / 1000) : 0,
    lastError: state.lastError,
    lastSaved: state.lastSaved,
    recent: state.recent,
  };
}

let governor: ReturnType<typeof setInterval> | null = null;

/**
 * Free tiers cap requests per minute. Rather than hammering them into a 429
 * storm, measure what actually gets through and settle on that many workers.
 */
function runGovernor() {
  if (governor) return;
  governor = setInterval(() => {
    if (!state.running) return;
    const w = state.window;
    state.window = { attempts: 0, limited: 0, saved: 0 };
    if (!w.attempts) return;

    const limitedShare = w.limited / w.attempts;
    if (limitedShare > 0.3 && state.activeWorkers > 1) {
      state.activeWorkers = Math.max(1, Math.floor(state.activeWorkers * 0.6));
    } else if (limitedShare === 0 && w.saved > 0 && state.activeWorkers < state.desiredWorkers) {
      state.activeWorkers += 1;
    }
  }, 20_000);
  if (typeof governor === "object" && governor && "unref" in governor) {
    (governor as unknown as { unref(): void }).unref();
  }
}

function spawn() {
  state.generation++;
  const generation = state.generation;
  // always run the full set; the governor decides how many are awake
  for (let i = 0; i < state.desiredWorkers; i++) void worker(i, generation);
  runGovernor();
}

export async function startTrainer(concurrency?: number): Promise<void> {
  if (typeof concurrency === "number" && concurrency > 0) {
    state.desiredWorkers = Math.min(12, Math.max(1, Math.round(concurrency)));
  }
  if (state.running) {
    // already going: respawn so a new worker count takes effect immediately
    spawn();
    return;
  }
  state.running = true;
  state.lastError = null;
  state.asked = 0;
  state.saved = 0;
  state.rejected = 0;
  state.failed = 0;
  state.rateLimited = 0;
  state.window = { attempts: 0, limited: 0, saved: 0 };
  state.activeWorkers = state.desiredWorkers;
  state.recent = [];
  state.startedAt = Date.now();
  chainCache = null;
  await saveSettings({ learning: { running: true, concurrency: state.desiredWorkers } });
  spawn();
}

export async function stopTrainer(): Promise<void> {
  state.running = false;
  state.generation++;
  await saveSettings({ learning: { running: false, concurrency: state.desiredWorkers } });
}

export async function setSpeed(concurrency: number): Promise<void> {
  state.desiredWorkers = Math.min(12, Math.max(1, Math.round(concurrency)));
  state.activeWorkers = state.desiredWorkers;
  await saveSettings({ learning: { running: state.running, concurrency: state.desiredWorkers } });
  if (state.running) spawn();
}

export async function resumeIfEnabled(): Promise<void> {
  if (state.running) return;
  const settings = await getSettings();
  if (settings.learning.concurrency) state.desiredWorkers = settings.learning.concurrency;
  if (settings.learning.running) await startTrainer();
}

export async function addQuestions(raw: string): Promise<number> {
  const lines = raw
    .split("\n")
    .map((l) => l.trim())
    .filter((l) => l.length > 3)
    .slice(0, 500);
  for (const line of lines) await enqueueQuestion(line).catch(() => {});
  return lines.length;
}
