"use client";

import { DEFAULT_VOICE_SETTINGS, type VoiceSettings } from "./useVoiceSession";

/** Languages Ash can be told to reply in. "auto" mirrors whatever you wrote. */
export const REPLY_LANGUAGES = [
  { code: "auto", label: "Match my message" },
  { code: "English", label: "English" },
  { code: "Urdu (Urdu script)", label: "اردو" },
  { code: "Roman Urdu", label: "Roman Urdu" },
  { code: "Hindi", label: "हिन्दी" },
  { code: "Arabic", label: "العربية" },
  { code: "Persian", label: "فارسی" },
  { code: "Punjabi", label: "ਪੰਜਾਬੀ" },
] as const;

/** Locales for speech recognition and synthesis. */
export const SPEECH_LANGUAGES = [
  { code: "auto", label: "Follow my device" },
  { code: "ur-PK", label: "اردو (Pakistan)" },
  { code: "en-US", label: "English (US)" },
  { code: "en-GB", label: "English (UK)" },
  { code: "hi-IN", label: "हिन्दी" },
  { code: "ar-SA", label: "العربية" },
  { code: "fa-IR", label: "فارسی" },
  { code: "pa-IN", label: "ਪੰਜਾਬੀ" },
  { code: "bn-BD", label: "বাংলা" },
  { code: "tr-TR", label: "Türkçe" },
  { code: "id-ID", label: "Bahasa Indonesia" },
  { code: "es-ES", label: "Español" },
  { code: "fr-FR", label: "Français" },
  { code: "de-DE", label: "Deutsch" },
  { code: "zh-CN", label: "中文" },
] as const;

export interface Prefs {
  model: string;
  systemPrompt: string;
  temperature: number;
  /** auto = let the server decide, on = always search, off = never */
  search: "auto" | "on" | "off";
  /** Language Ash should write in. Separate from the voice language. */
  replyLanguage: string;
  voice: VoiceSettings;
  /** Hold the mic button instead of tapping it. */
  pushToTalk: boolean;
  /** Let Ash answer from what it has learned before. */
  useMemory: boolean;
  /** Chat, the Cowork workspace, or Ash working on the real computer. */
  appMode: "chat" | "cowork" | "computer";
}

const KEY = "ash:prefs";

export const DEFAULT_PREFS: Prefs = {
  model: "",
  systemPrompt: "",
  temperature: 0.7,
  search: "auto",
  replyLanguage: "auto",
  voice: { ...DEFAULT_VOICE_SETTINGS },
  pushToTalk: false,
  useMemory: true,
  appMode: "chat",
};

export function loadPrefs(): Prefs {
  if (typeof window === "undefined") return { ...DEFAULT_PREFS, voice: { ...DEFAULT_VOICE_SETTINGS } };
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return { ...DEFAULT_PREFS, voice: { ...DEFAULT_VOICE_SETTINGS } };
    const parsed = JSON.parse(raw) as Partial<Prefs> & { voiceLang?: string };
    return {
      ...DEFAULT_PREFS,
      ...parsed,
      temperature: Math.min(1.2, Math.max(0, Number(parsed.temperature ?? DEFAULT_PREFS.temperature))),
      voice: {
        ...DEFAULT_VOICE_SETTINGS,
        // carry over the old single voiceLang field from earlier versions
        ...(parsed.voiceLang ? { voiceLang: parsed.voiceLang } : {}),
        ...(parsed.voice ?? {}),
      },
    };
  } catch {
    return { ...DEFAULT_PREFS, voice: { ...DEFAULT_VOICE_SETTINGS } };
  }
}

export function savePrefs(prefs: Prefs): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(prefs));
  } catch {
    /* private mode */
  }
}
