/**
 * THE one editable data file for engines.
 * Free quotas and model names move around a lot — edit this file (or add a
 * custom OpenAI-compatible engine from the Control Panel) and nothing else.
 *
 * `vendor` is owner-only information. It is never sent to the browser.
 */

export type ProviderKind = "gemini" | "openai" | "demo" | "brain" | "smart";

export interface CatalogModel {
  /** Real model id sent to the provider. Server-side only. */
  id: string;
  /** Public label shown to everyone. */
  label: string;
  description: string;
  vision?: boolean;
  thinking?: boolean;
}

export interface CatalogProvider {
  id: string;
  /** Owner-only, shown in the Control Panel only. */
  vendor: string;
  publicName: string;
  kind: ProviderKind;
  envKeys: string[];
  extraEnvKeys?: string[];
  signupUrl: string;
  note: string;
  baseUrl?: string;
  modelsEndpoint?: string;
  models: CatalogModel[];
  defaultEnabled: boolean;
  paid?: boolean;
  /** Z.ai style flag: ask the model not to stream its reasoning. */
  disableThinking?: boolean;
}

export const CATALOG: CatalogProvider[] = [
  {
    id: "gemini",
    vendor: "Google Gemini (AI Studio)",
    publicName: "Ash Pro",
    kind: "gemini",
    envKeys: ["GEMINI_API_KEY"],
    signupUrl: "https://aistudio.google.com/app/apikey",
    note: "Free, best all-round, supports images.",
    modelsEndpoint: "https://generativelanguage.googleapis.com/v1beta/models",
    defaultEnabled: true,
    models: [
      { id: "gemini-3.6-flash", label: "Ash Pro", description: "The main engine. Fast, reliable, and it reads images.", vision: true },
      { id: "gemini-3.5-flash-lite", label: "Ash Pro Lite", description: "Half-second replies for quick questions.", vision: true },
      { id: "gemini-3.8-flash", label: "Ash Pro Max", description: "The most capable one, for harder questions.", vision: true },
    ],
  },
  {
    id: "openrouter",
    vendor: "OpenRouter",
    publicName: "Ash Open",
    kind: "openai",
    envKeys: ["OPENROUTER_API_KEY"],
    signupUrl: "https://openrouter.ai/keys",
    note: "Free :free models (Llama, Qwen, DeepSeek, Gemma, Mistral…).",
    baseUrl: "https://openrouter.ai/api/v1",
    modelsEndpoint: "https://openrouter.ai/api/v1/models",
    defaultEnabled: true,
    models: [
      { id: "qwen/qwen3.8-27b:free", label: "Ash Open", description: "Fast open model that reads images too.", vision: true },
      { id: "nvidia/nemotron-3-ultra-550b-a55b:free", label: "Ash Open Max", description: "Very large open model, huge context." },
      { id: "nvidia/nemotron-3-super-120b-a12b:free", label: "Ash Open Deep", description: "Careful reasoning on long documents." },
      { id: "cohere/north-mini-code:free", label: "Ash Open Coder", description: "Tuned for writing code." },
      { id: "dots-studio/dots-3-note-preview:free", label: "Ash Open Mini", description: "Small, quick, reads images.", vision: true },
    ],
  },
  {
    id: "groq",
    vendor: "Groq",
    publicName: "Ash Turbo",
    kind: "openai",
    envKeys: ["GROQ_API_KEY"],
    signupUrl: "https://console.groq.com/keys",
    note: "Fastest free engine.",
    baseUrl: "https://api.groq.com/openai/v1",
    modelsEndpoint: "https://api.groq.com/openai/v1/models",
    defaultEnabled: true,
    models: [
      { id: "llama-3.3-70b-versatile", label: "Ash Turbo", description: "Very fast, very capable." },
      { id: "llama-3.1-8b-instant", label: "Ash Turbo Lite", description: "Instant short answers." },
      { id: "meta-llama/llama-4-scout-17b-16e-instruct", label: "Ash Turbo Vision", description: "Fast, and it can see images.", vision: true },
    ],
  },
  {
    id: "cerebras",
    vendor: "Cerebras",
    publicName: "Ash Turbo X",
    kind: "openai",
    envKeys: ["CEREBRAS_API_KEY"],
    signupUrl: "https://cloud.cerebras.ai/",
    note: "Very fast. Sign-up may ask for a card.",
    baseUrl: "https://api.cerebras.ai/v1",
    modelsEndpoint: "https://api.cerebras.ai/v1/models",
    defaultEnabled: true,
    models: [
      { id: "llama-3.3-70b", label: "Ash Turbo X", description: "Extremely fast large model." },
      { id: "qwen-3-32b", label: "Ash Turbo X Mini", description: "Fast mid-size model." },
    ],
  },
  {
    id: "mistral",
    vendor: "Mistral",
    publicName: "Ash Swift",
    kind: "openai",
    envKeys: ["MISTRAL_API_KEY"],
    signupUrl: "https://console.mistral.ai/api-keys",
    note: "Monthly free credits.",
    baseUrl: "https://api.mistral.ai/v1",
    modelsEndpoint: "https://api.mistral.ai/v1/models",
    defaultEnabled: true,
    models: [
      { id: "mistral-small-latest", label: "Ash Swift", description: "Balanced and neat.", vision: true },
      { id: "open-mistral-nemo", label: "Ash Swift Lite", description: "Small and quick." },
      { id: "pixtral-12b-2409", label: "Ash Swift Vision", description: "Built for pictures.", vision: true },
    ],
  },
  {
    id: "zai",
    vendor: "Z.ai (GLM)",
    publicName: "Ash Flash",
    kind: "openai",
    envKeys: ["ZAI_API_KEY"],
    signupUrl: "https://z.ai/manage-apikey/apikey-list",
    note: "Free GLM Flash models.",
    baseUrl: "https://api.z.ai/api/paas/v4",
    defaultEnabled: true,
    disableThinking: true,
    models: [
      { id: "glm-4.5-flash", label: "Ash Flash", description: "Free and quick." },
      { id: "glm-4-flash", label: "Ash Flash Lite", description: "Lighter free model." },
    ],
  },
  {
    id: "nvidia",
    vendor: "NVIDIA NIM",
    publicName: "Ash Nitro",
    kind: "openai",
    envKeys: ["NVIDIA_API_KEY"],
    signupUrl: "https://build.nvidia.com/",
    note: "Many free open models.",
    baseUrl: "https://integrate.api.nvidia.com/v1",
    modelsEndpoint: "https://integrate.api.nvidia.com/v1/models",
    defaultEnabled: true,
    models: [
      { id: "meta/llama-3.3-70b-instruct", label: "Ash Nitro", description: "Large open model." },
      { id: "qwen/qwen2.5-coder-32b-instruct", label: "Ash Nitro Coder", description: "Tuned for programming." },
      { id: "deepseek-ai/deepseek-r1", label: "Ash Nitro Think", description: "Thinks before it answers.", thinking: true },
    ],
  },
  {
    id: "cohere",
    vendor: "Cohere",
    publicName: "Ash Sage",
    kind: "openai",
    envKeys: ["COHERE_API_KEY"],
    signupUrl: "https://dashboard.cohere.com/api-keys",
    note: "Free trial key, good at long text.",
    baseUrl: "https://api.cohere.ai/compatibility/v1",
    defaultEnabled: true,
    models: [
      { id: "command-r-plus-08-2024", label: "Ash Sage", description: "Thoughtful long-form writing." },
      { id: "command-r7b-12-2024", label: "Ash Sage Lite", description: "Small and economical." },
    ],
  },
  {
    id: "scaleway",
    vendor: "Scaleway Generative APIs",
    publicName: "Ash Euro",
    kind: "openai",
    envKeys: ["SCALEWAY_API_KEY"],
    signupUrl: "https://console.scaleway.com/generative-api/models",
    note: "1M free tokens.",
    baseUrl: "https://api.scaleway.ai/v1",
    modelsEndpoint: "https://api.scaleway.ai/v1/models",
    defaultEnabled: true,
    models: [
      { id: "llama-3.3-70b-instruct", label: "Ash Euro", description: "Hosted in the EU." },
      { id: "mistral-nemo-instruct-2407", label: "Ash Euro Lite", description: "Small EU-hosted model." },
    ],
  },
  {
    id: "huggingface",
    vendor: "Hugging Face Router",
    publicName: "Ash Open+",
    kind: "openai",
    envKeys: ["HF_TOKEN"],
    signupUrl: "https://huggingface.co/settings/tokens",
    note: "Free token, huge model choice.",
    baseUrl: "https://router.huggingface.co/v1",
    modelsEndpoint: "https://router.huggingface.co/v1/models",
    defaultEnabled: true,
    models: [
      { id: "meta-llama/Llama-3.1-8B-Instruct", label: "Ash Open+", description: "Community-hosted open model." },
      { id: "Qwen/Qwen2.5-7B-Instruct", label: "Ash Open+ Mini", description: "Small community model." },
    ],
  },
  {
    id: "cloudflare",
    vendor: "Cloudflare Workers AI",
    publicName: "Ash Edge",
    kind: "openai",
    envKeys: ["CLOUDFLARE_API_TOKEN"],
    extraEnvKeys: ["CLOUDFLARE_ACCOUNT_ID"],
    signupUrl: "https://dash.cloudflare.com/profile/api-tokens",
    note: "Free daily allowance, runs at the edge.",
    baseUrl: "https://api.cloudflare.com/client/v4/accounts/{CLOUDFLARE_ACCOUNT_ID}/ai/v1",
    defaultEnabled: true,
    models: [
      { id: "@cf/meta/llama-3.3-70b-instruct-fp8-fast", label: "Ash Edge", description: "Fast edge model." },
      { id: "@cf/meta/llama-3.1-8b-instruct", label: "Ash Edge Lite", description: "Small edge model." },
    ],
  },
  {
    id: "local",
    vendor: "Local (Ollama / LM Studio)",
    publicName: "Ash Local",
    kind: "openai",
    envKeys: ["OPENAI_BASE_URL"],
    extraEnvKeys: ["OPENAI_API_KEY"],
    signupUrl: "https://ollama.com/download",
    note: "No limits at all — runs on your own machine or server.",
    defaultEnabled: true,
    models: [
      { id: "llama3.1", label: "Ash Local", description: "Runs on your own hardware." },
      { id: "qwen2.5:7b", label: "Ash Local Mini", description: "Smaller local model." },
    ],
  },
  {
    id: "openai",
    vendor: "OpenAI platform (paid)",
    publicName: "Ash Plus",
    kind: "openai",
    envKeys: ["OPENAI_PLATFORM_API_KEY"],
    signupUrl: "https://platform.openai.com/api-keys",
    note: "Optional and paid — off by default, never auto-selected.",
    baseUrl: "https://api.openai.com/v1",
    modelsEndpoint: "https://api.openai.com/v1/models",
    defaultEnabled: false,
    paid: true,
    models: [
      { id: "gpt-4o-mini", label: "Ash Plus", description: "Optional paid engine." },
    ],
  },
];

/** Always-available engines that need no key and no network. */
export const OFFLINE_CATALOG: CatalogProvider[] = [
  {
    id: "smart",
    vendor: "Ash internal",
    publicName: "Ash Smart",
    kind: "smart",
    envKeys: [],
    signupUrl: "",
    note: "Memory first, then the live engines.",
    defaultEnabled: true,
    models: [{ id: "auto", label: "Ash Smart", description: "Answers from memory instantly, otherwise asks a live engine." }],
  },
  {
    id: "brain",
    vendor: "Ash internal",
    publicName: "Ash Memory",
    kind: "brain",
    envKeys: [],
    signupUrl: "",
    note: "Only what Ash has already learned. Fully offline.",
    defaultEnabled: true,
    models: [{ id: "memory", label: "Ash Memory", description: "Only what Ash already remembers. Works offline." }],
  },
  {
    id: "demo",
    vendor: "Ash internal",
    publicName: "Ash Basic",
    kind: "demo",
    envKeys: [],
    signupUrl: "",
    note: "Tiny built-in engine. Always available.",
    defaultEnabled: true,
    models: [{ id: "offline", label: "Ash Basic", description: "Maths, time and identity. No keys needed." }],
  },
];

export function allCatalog(): CatalogProvider[] {
  return [...OFFLINE_CATALOG, ...CATALOG];
}

export function findProvider(id: string): CatalogProvider | undefined {
  return allCatalog().find((p) => p.id === id);
}

export function slugify(label: string): string {
  return label
    .trim()
    .toLowerCase()
    .replace(/\+/g, "-plus")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export const SEARCH_PROVIDERS = [
  { id: "duckduckgo", label: "DuckDuckGo", needsKey: false, needsUrl: false, note: "No key needed. Some data-centre IPs are rate-limited — test it." },
  { id: "wikipedia", label: "Wikipedia", needsKey: false, needsUrl: false, note: "No key needed. Encyclopaedic facts." },
  { id: "searxng", label: "SearXNG", needsKey: false, needsUrl: true, note: "Paste a self-hosted instance URL (needs the JSON API enabled)." },
  { id: "tavily", label: "Tavily", needsKey: true, needsUrl: false, note: "Free tier key, search built for AI.", signupUrl: "https://app.tavily.com/" },
  { id: "brave", label: "Brave Search", needsKey: true, needsUrl: false, note: "Free tier key, 2k queries/month.", signupUrl: "https://api.search.brave.com/app/keys" },
  { id: "serper", label: "Serper", needsKey: true, needsUrl: false, note: "Free trial credits.", signupUrl: "https://serper.dev/api-key" },
] as const;

export type SearchProviderId = (typeof SEARCH_PROVIDERS)[number]["id"];
