import type { Provider, StreamOptions } from "./types";
import { classifyIdentity, detectScript, identityAnswer, unknownAnswer, type Branding } from "@/lib/identity";

/* ───────────────────────── safe arithmetic ───────────────────────── */

type Tok = { t: "num"; v: number } | { t: "op"; v: string } | { t: "par"; v: "(" | ")" };

function tokenize(src: string): Tok[] | null {
  const out: Tok[] = [];
  let i = 0;
  while (i < src.length) {
    const c = src[i];
    if (c === " " || c === "," || c === "_") {
      i++;
      continue;
    }
    if (/[0-9.]/.test(c)) {
      let j = i;
      while (j < src.length && /[0-9.]/.test(src[j])) j++;
      const num = Number(src.slice(i, j));
      if (!Number.isFinite(num)) return null;
      out.push({ t: "num", v: num });
      i = j;
      continue;
    }
    if ("+-*/%^×÷".includes(c)) {
      out.push({ t: "op", v: c === "×" ? "*" : c === "÷" ? "/" : c });
      i++;
      continue;
    }
    if (c === "(" || c === ")") {
      out.push({ t: "par", v: c });
      i++;
      continue;
    }
    return null;
  }
  return out;
}

function evaluate(tokens: Tok[]): number | null {
  let pos = 0;
  const peek = () => tokens[pos];

  function parseExpr(): number | null {
    let left = parseTerm();
    if (left === null) return null;
    for (;;) {
      const tk = peek();
      if (tk && tk.t === "op" && (tk.v === "+" || tk.v === "-")) {
        pos++;
        const right = parseTerm();
        if (right === null) return null;
        left = tk.v === "+" ? left + right : left - right;
      } else break;
    }
    return left;
  }

  function parseTerm(): number | null {
    let left = parsePow();
    if (left === null) return null;
    for (;;) {
      const tk = peek();
      if (tk && tk.t === "op" && (tk.v === "*" || tk.v === "/" || tk.v === "%")) {
        pos++;
        const right = parsePow();
        if (right === null) return null;
        if ((tk.v === "/" || tk.v === "%") && right === 0) return null;
        left = tk.v === "*" ? left * right : tk.v === "/" ? left / right : left % right;
      } else break;
    }
    return left;
  }

  function parsePow(): number | null {
    const base = parseUnary();
    if (base === null) return null;
    const tk = peek();
    if (tk && tk.t === "op" && tk.v === "^") {
      pos++;
      const exp = parsePow();
      if (exp === null) return null;
      return Math.pow(base, exp);
    }
    return base;
  }

  function parseUnary(): number | null {
    const tk = peek();
    if (tk && tk.t === "op" && (tk.v === "-" || tk.v === "+")) {
      pos++;
      const v = parseUnary();
      if (v === null) return null;
      return tk.v === "-" ? -v : v;
    }
    return parseAtom();
  }

  function parseAtom(): number | null {
    const tk = peek();
    if (!tk) return null;
    if (tk.t === "num") {
      pos++;
      return tk.v;
    }
    if (tk.t === "par" && tk.v === "(") {
      pos++;
      const v = parseExpr();
      if (v === null) return null;
      const close = peek();
      if (!close || close.t !== "par" || close.v !== ")") return null;
      pos++;
      return v;
    }
    return null;
  }

  const value = parseExpr();
  if (value === null || pos !== tokens.length || !Number.isFinite(value)) return null;
  return value;
}

const MATH_PREFIX =
  /^(?:please\s+)?(?:can you\s+)?(?:what(?:'s| is)|whats|calculate|compute|evaluate|solve|how much is|kitna hai|kitna hota hai|kitne hote hain|hisab|jawab|answer)\s*[:=]?\s*/i;
const MATH_SUFFIX = /\s*(?:\?|=|kya hai|kitna hai|kitna hota hai|hota hai|kya hoga|please)?\s*$/i;

/** Only fires when the WHOLE message is an expression. */
export function tryArithmetic(raw: string): string | null {
  let t = raw.trim();
  if (!t || t.length > 120) return null;
  t = t.replace(MATH_PREFIX, "").replace(MATH_SUFFIX, "").trim();
  if (!t) return null;
  if (!/^[0-9+\-*/%().,\s^×÷_]+$/.test(t)) return null;
  if (!/[+\-*/%^×÷]/.test(t)) return null;
  if (!/^[\d(+\-]/.test(t) || !/[\d)]$/.test(t)) return null;
  const tokens = tokenize(t);
  if (!tokens || tokens.length < 3) return null;
  const value = evaluate(tokens);
  if (value === null) return null;
  const rounded = Math.round(value * 1e10) / 1e10;
  return `${t.replace(/\s+/g, " ")} = **${rounded}**`;
}

/* ───────────────────────── time and date ───────────────────────── */

const TIME_PATTERNS: RegExp[] = [
  /^what(?:'s| is)? the (?:current )?time(?: now| right now)?$/,
  /^what time is it(?: now| right now)?$/,
  /^(?:current |the )?time(?: now| right now)?$/,
  /^abhi kya (?:waqt|time|baje) (?:hai|hain|hua hai)$/,
  /^kya (?:waqt|time) (?:hai|hua hai|ho raha hai)$/,
  /^(?:abhi |is waqt )?kitne baje (?:hain|hai)$/,
  /^time kya (?:hai|hua hai)$/,
  /^ابھی کیا وقت ہے$/,
  /^کیا وقت ہوا ہے$/,
];

const DATE_PATTERNS: RegExp[] = [
  /^what(?:'s| is)? (?:the )?(?:today'?s? )?date(?: today)?$/,
  /^what(?:'s| is)? today'?s? date$/,
  /^what day is it(?: today)?$/,
  /^(?:today'?s? )?date$/,
  /^aaj ki (?:tareekh|tarikh|date) (?:kya hai|kya he)?$/,
  /^aaj (?:kaun|kon) si (?:tareekh|tarikh|date) hai$/,
  /^aaj (?:kaun|kon) sa din hai$/,
  /^aaj date kya hai$/,
  /^آج کی تاریخ(?: کیا ہے)?$/,
  /^آج کون سا دن ہے$/,
];

function normalise(raw: string): string {
  return raw
    .toLowerCase()
    .replace(/[?!.,۔]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function zone(): string {
  return process.env.AI_TIMEZONE || "Asia/Karachi";
}

export function tryTimeDate(raw: string, script: ReturnType<typeof detectScript>): string | null {
  const t = normalise(raw);
  if (!t || t.length > 60) return null;
  const now = new Date();
  const tz = zone();

  if (TIME_PATTERNS.some((re) => re.test(t))) {
    const time = new Intl.DateTimeFormat("en-GB", { hour: "2-digit", minute: "2-digit", timeZone: tz, hour12: true }).format(now);
    if (script === "arabic") return `ابھی ${time} بج رہے ہیں (${tz})۔`;
    if (script === "roman-urdu") return `Abhi ${time} baj rahe hain (${tz}).`;
    return `It's ${time} (${tz}).`;
  }

  if (DATE_PATTERNS.some((re) => re.test(t))) {
    const date = new Intl.DateTimeFormat("en-GB", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
      timeZone: tz,
    }).format(now);
    if (script === "arabic") return `آج ${date} ہے۔`;
    if (script === "roman-urdu") return `Aaj ${date} hai.`;
    return `Today is ${date}.`;
  }

  return null;
}

/* ───────────────────────── the engine ───────────────────────── */

export function offlineAnswer(question: string, branding: Branding): { text: string; known: boolean } {
  const script = detectScript(question);

  const math = tryArithmetic(question);
  if (math) return { text: math, known: true };

  const when = tryTimeDate(question, script);
  if (when) return { text: when, known: true };

  const kind = classifyIdentity(question);
  if (kind) return { text: identityAnswer(kind, branding, script), known: true };

  return { text: unknownAnswer(script), known: false };
}

export function createDemoProvider(branding: Branding, onUnknown?: (q: string) => void): Provider {
  return {
    id: "demo",
    label: "Ash Basic",
    isConfigured: () => true,
    async *stream(options: StreamOptions) {
      const lastUser = [...options.messages].reverse().find((m) => m.role === "user");
      const question = lastUser?.content ?? "";
      const { text, known } = offlineAnswer(question, branding);
      if (!known && question.trim()) onUnknown?.(question.trim());
      for (const chunk of text.match(/.{1,24}(\s|$)|.{1,24}/g) ?? [text]) {
        if (options.signal?.aborted) return;
        yield chunk;
        await new Promise((r) => setTimeout(r, 14));
      }
    },
  };
}
