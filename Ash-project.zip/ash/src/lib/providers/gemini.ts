import type { Provider, StreamOptions } from "./types";
import { assertOk, ProviderError, readSSE } from "./sse";

const ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models";

export function createGeminiProvider(label: string): Provider {
  return {
    id: "gemini",
    label,
    isConfigured: () => !!(process.env.GEMINI_API_KEY || "").trim(),
    async *stream(options: StreamOptions) {
      const key = (process.env.GEMINI_API_KEY || "").trim();
      if (!key) throw new ProviderError("No key configured for this engine.", 401);

      const contents: Array<{ role: "user" | "model"; parts: Array<Record<string, unknown>> }> = [];
      for (const m of options.messages) {
        if (m.role === "system") continue;
        contents.push({
          role: m.role === "assistant" ? "model" : "user",
          parts: [{ text: m.content }],
        });
      }
      if (options.images?.length) {
        const last = contents[contents.length - 1];
        const target = last && last.role === "user" ? last : (contents.push({ role: "user", parts: [] }), contents[contents.length - 1]);
        for (const img of options.images) {
          target.parts.unshift({ inlineData: { mimeType: img.mimeType, data: img.data } });
        }
      }

      const body = {
        contents,
        ...(options.system ? { systemInstruction: { parts: [{ text: options.system }] } } : {}),
        generationConfig: {
          temperature: typeof options.temperature === "number" ? options.temperature : 0.7,
          maxOutputTokens: 8192,
        },
        safetySettings: [
          "HARM_CATEGORY_HARASSMENT",
          "HARM_CATEGORY_HATE_SPEECH",
          "HARM_CATEGORY_SEXUALLY_EXPLICIT",
          "HARM_CATEGORY_DANGEROUS_CONTENT",
        ].map((category) => ({ category, threshold: "BLOCK_ONLY_HIGH" })),
      };

      const res = await fetch(`${ENDPOINT}/${encodeURIComponent(options.model)}:streamGenerateContent?alt=sse`, {
        method: "POST",
        cache: "no-store",
        headers: { "content-type": "application/json", "x-goog-api-key": key },
        body: JSON.stringify(body),
        signal: options.signal,
      });
      await assertOk(res);

      for await (const data of readSSE(res, options.signal)) {
        if (!data || data === "[DONE]") continue;
        let parsed: any;
        try {
          parsed = JSON.parse(data);
        } catch {
          continue;
        }
        const parts = parsed?.candidates?.[0]?.content?.parts;
        if (!Array.isArray(parts)) {
          yield "";
          continue;
        }
        let text = "";
        for (const p of parts) if (typeof p?.text === "string") text += p.text;
        if (text) yield text;
        else yield "";
      }
    },
  };
}
