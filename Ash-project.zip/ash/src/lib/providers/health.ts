import { clearProviderState, listProviderState, setProviderState } from "@/lib/db/repo";

export type HealthState = "healthy" | "cooling" | "daily" | "badkey";

export interface HealthEntry {
  id: string;
  state: HealthState;
  until: number;
  lastError: string | null;
}

let cache: Map<string, HealthEntry> | null = null;
let loadedAt = 0;
const TTL = 4_000;

async function load(): Promise<Map<string, HealthEntry>> {
  if (cache && Date.now() - loadedAt < TTL) return cache;
  const map = new Map<string, HealthEntry>();
  try {
    for (const r of await listProviderState()) {
      map.set(r.id, { id: r.id, state: r.state as HealthState, until: r.until, lastError: r.lastError });
    }
  } catch {
    /* DB not ready yet */
  }
  cache = map;
  loadedAt = Date.now();
  return map;
}

export async function health(): Promise<HealthEntry[]> {
  const map = await load();
  const now = Date.now();
  return [...map.values()].filter((e) => e.until > now);
}

export async function isCooling(id: string): Promise<boolean> {
  const map = await load();
  const entry = map.get(id);
  return !!entry && entry.until > Date.now();
}

export async function coolingInfo(id: string): Promise<HealthEntry | null> {
  const map = await load();
  const e = map.get(id);
  return e && e.until > Date.now() ? e : null;
}

/** Gemini sends "retryDelay":"33s"; others send Retry-After. Obey it. */
function parseRetryDelayMs(message: string): number | null {
  const m =
    message.match(/"retryDelay"\s*:\s*"?(\d+(?:\.\d+)?)s"?/i) ||
    message.match(/retry[-_ ]?after["':\s]+(\d+(?:\.\d+)?)/i) ||
    message.match(/try again in (\d+(?:\.\d+)?)\s*s/i);
  if (!m) return null;
  const secs = Number(m[1]);
  return Number.isFinite(secs) ? Math.ceil(secs * 1000) : null;
}

/** Only a real per-day cap should park an engine for an hour. */
const PER_DAY = /per[-_ ]?day|perday|requests per day|daily limit|RequestsPerDay|quota exceeded for the day|out of credits|insufficient[_ ]?credit/i;

const KEY_HINTS = /api[ _-]?key|api_key_invalid|unauthorized|unauthenticated|invalid[ _-]?(token|credential)|permission denied|forbidden/;

/** Quota language, whatever status code it arrives under. */
const RATE_LANGUAGE = /rate[- ]?limit|quota|too many requests|free-models-per-day|exceeded your current/i;

export function classifyFailure(status: number, message: string): { state: HealthState; ms: number } {
  const msg = (message || "").toLowerCase();

  // A used-up free allowance often arrives as 403/402, not 429. Parking that
  // key as "bad" for a day is wrong — it works again when the cap resets.
  if (RATE_LANGUAGE.test(message)) {
    const told = parseRetryDelayMs(message);
    if (PER_DAY.test(message)) {
      return { state: "daily", ms: Math.min(12 * 60 * 60 * 1000, Math.max(60 * 60 * 1000, told ?? 0)) };
    }
    return { state: "cooling", ms: Math.min(5 * 60_000, Math.max(15_000, told ?? 60_000)) };
  }

  if (status === 401 || status === 403) return { state: "badkey", ms: 24 * 60 * 60 * 1000 };
  if (status === 402) return { state: "daily", ms: 60 * 60 * 1000 };
  // Gemini and friends answer 400 when the key itself is wrong.
  if (status === 400 && KEY_HINTS.test(msg)) return { state: "badkey", ms: 24 * 60 * 60 * 1000 };
  if (status === 400) return { state: "cooling", ms: 5 * 60 * 1000 };
  if (status === 429) {
    // "You exceeded your current quota" is also what a per-MINUTE limit says,
    // so never assume a day-long outage from the word "quota" alone.
    if (PER_DAY.test(msg)) {
      const told = parseRetryDelayMs(message);
      return { state: "daily", ms: Math.min(12 * 60 * 60 * 1000, Math.max(60 * 60 * 1000, told ?? 0)) };
    }
    const told = parseRetryDelayMs(message);
    return { state: "cooling", ms: Math.min(5 * 60_000, Math.max(15_000, told ?? 60_000)) };
  }
  if (status === 503) return { state: "cooling", ms: 45 * 1000 }; // "model is overloaded" passes quickly
  if (status >= 500 || status === 0) return { state: "cooling", ms: 5 * 60 * 1000 };
  if (status === 404) return { state: "cooling", ms: 10 * 60 * 1000 };
  if (status === 408) return { state: "cooling", ms: 90 * 1000 };
  return { state: "cooling", ms: 60 * 1000 };
}

export async function park(id: string, status: number, message: string): Promise<HealthEntry> {
  const { state, ms } = classifyFailure(status, message);
  const until = Date.now() + ms;
  const entry: HealthEntry = { id, state, until, lastError: message.slice(0, 240) };
  const map = await load();
  map.set(id, entry);
  setProviderState(id, state, until, entry.lastError).catch(() => {});
  return entry;
}

export async function clearCooldown(id?: string): Promise<void> {
  const map = await load();
  if (id) {
    for (const key of [...map.keys()]) if (key === id || key.startsWith(`${id}:`)) map.delete(key);
  } else map.clear();
  await clearProviderState(id).catch(() => {});
  if (id) {
    // provider-level reset also clears its per-model entries
    try {
      for (const r of await listProviderState()) {
        if (r.id.startsWith(`${id}:`)) await clearProviderState(r.id);
      }
    } catch {
      /* ignore */
    }
  }
  loadedAt = 0;
}

/** ms until the first cooling engine frees up, so callers can wait exactly that long. */
export async function soonestExpiry(): Promise<number> {
  const live = await health();
  if (!live.length) return 0;
  return Math.max(0, Math.min(...live.map((e) => e.until)) - Date.now());
}

export function describeState(e: HealthEntry): string {
  const secs = Math.max(0, Math.ceil((e.until - Date.now()) / 1000));
  if (e.state === "badkey") return "Bad key";
  if (e.state === "daily") return "Daily limit";
  if (secs > 90) return `Cooling ${Math.ceil(secs / 60)}m`;
  return `Cooling ${secs}s`;
}
