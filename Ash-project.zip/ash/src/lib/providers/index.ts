import type { PublicModel } from "@/lib/types";
import { CATALOG, OFFLINE_CATALOG, slugify, type CatalogProvider } from "./catalog";
import { createGeminiProvider } from "./gemini";
import { createOpenAIProvider } from "./openai-compatible";
import { createDemoProvider } from "./demo";
import type { Provider } from "./types";
import { getKeys, getSettings, type Settings } from "@/lib/settings";
import { enqueueQuestion, knowledgeByProvider } from "@/lib/db/repo";
import { isCooling } from "./health";
import { DEFAULT_BRANDING } from "@/lib/identity";

export interface RuntimeModel {
  /** Real internal id: "provider:model". Never leaves the server. */
  key: string;
  providerId: string;
  modelId: string;
  /** Safe id for the browser, e.g. "ash-core". */
  publicCode: string;
  label: string;
  description: string;
  vision: boolean;
  thinking: boolean;
  group: "offline" | "full";
  configured: boolean;
  enabled: boolean;
  /** Owner-only. */
  vendor: string;
}

function localBaseUrl(): string {
  return (process.env.OPENAI_BASE_URL || "").trim();
}

export function catalogWithCustom(settings: Settings): CatalogProvider[] {
  const customs: CatalogProvider[] = settings.customEngines.map((c) => ({
    id: `custom-${c.id}`,
    vendor: `Custom · ${c.label}`,
    publicName: c.label,
    kind: "openai" as const,
    envKeys: [customKeyName(c.id)],
    signupUrl: "",
    note: c.note || "Custom OpenAI-compatible engine.",
    baseUrl: c.baseUrl,
    defaultEnabled: c.enabled,
    models: [{ id: c.model, label: c.label, description: c.note || "Custom engine." }],
  }));
  return [...OFFLINE_CATALOG, ...CATALOG, ...customs];
}

export function customKeyName(id: string): string {
  return `CUSTOM_${id.toUpperCase().replace(/[^A-Z0-9]/g, "_")}_KEY`;
}

export function providerConfigured(p: CatalogProvider): boolean {
  if (p.kind === "demo" || p.kind === "brain" || p.kind === "smart") return true;
  if (p.id === "local") return !!localBaseUrl();
  for (const name of p.envKeys) if (!(process.env[name] || "").trim()) return false;
  for (const name of p.extraEnvKeys || []) {
    if (name === "OPENAI_API_KEY") continue; // optional dummy key for local servers
    if (!(process.env[name] || "").trim()) return false;
  }
  return true;
}

/* ─────────────── how well trained each engine is ───────────────
   "Trained" = how many answers that engine contributed to Ash's memory.
   When the leading engine runs out of quota, the best-trained engine
   takes over instead of whatever happens to be next in the list. */

let trainingCache: { at: number; map: Record<string, number> } | null = null;

export async function trainingScores(): Promise<Record<string, number>> {
  if (trainingCache && Date.now() - trainingCache.at < 20_000) return trainingCache.map;
  const map = await knowledgeByProvider().catch(() => ({} as Record<string, number>));
  trainingCache = { at: Date.now(), map };
  return map;
}

export function invalidateTrainingScores(): void {
  trainingCache = null;
}

/**
 * Provider ids in the order Ash should reach for them:
 * the primary engine first, then the best-trained, then the owner's own order.
 */
export async function providerRanking(settings: Settings, extra: string[] = []): Promise<string[]> {
  const base = [...new Set([...settings.fallbackOrder, ...extra])];
  const primary = settings.primaryProvider;
  const rest = base.filter((id) => id !== primary);

  if (settings.preferTrainedFallback !== false) {
    const scores = await trainingScores();
    rest.sort((a, b) => (scores[b] ?? 0) - (scores[a] ?? 0) || base.indexOf(a) - base.indexOf(b));
  }
  return base.includes(primary) ? [primary, ...rest] : rest;
}

/** Full runtime model list. Owner-level detail — filter before sending to a browser. */
export async function runtimeModels(): Promise<RuntimeModel[]> {
  const settings = await getSettings();
  const providers = catalogWithCustom(settings);
  const used = new Set<string>();
  const out: RuntimeModel[] = [];

  for (const p of providers) {
    const prefs = settings.providers[p.id] ?? { enabled: p.defaultEnabled, models: p.models.map((m) => m.id) };
    const configured = providerConfigured(p);
    for (const m of p.models) {
      let code = slugify(m.label);
      if (used.has(code)) {
        let i = 2;
        while (used.has(`${code}-${i}`)) i++;
        code = `${code}-${i}`;
      }
      used.add(code);
      out.push({
        key: `${p.id}:${m.id}`,
        providerId: p.id,
        modelId: m.id,
        publicCode: code,
        label: m.label,
        description: m.description,
        vision: !!m.vision,
        thinking: !!m.thinking,
        group: p.kind === "demo" || p.kind === "brain" || p.kind === "smart" ? "offline" : "full",
        configured,
        enabled: prefs.enabled !== false && (prefs.models?.includes(m.id) ?? true),
        vendor: p.vendor,
      });
    }
  }
  return out;
}

/** Only what a visitor may see: no vendor names, no unconfigured engines. */
export async function publicModels(): Promise<PublicModel[]> {
  const [models, settings] = await Promise.all([runtimeModels(), getSettings()]);
  const ranking = await providerRanking(settings);
  const rank = (id: string) => {
    const i = ranking.indexOf(id);
    return i === -1 ? 999 : i;
  };
  return models
    .filter((m) => m.enabled && m.configured)
    .sort((a, b) => {
      if (a.group !== b.group) return a.group === "full" ? -1 : 1;
      if (a.group === "offline") return 0;
      return rank(a.providerId) - rank(b.providerId);
    })
    .map((m) => ({ id: m.publicCode, label: m.label, description: m.description, available: true, group: m.group }));
}

export async function resolveModel(input?: string | null): Promise<RuntimeModel | null> {
  if (!input) return null;
  const models = await runtimeModels();
  return (
    models.find((m) => m.publicCode === input) ??
    models.find((m) => m.key === input) ??
    models.find((m) => m.label.toLowerCase() === input.toLowerCase()) ??
    null
  );
}

export async function publicCodeFor(key: string): Promise<string> {
  const models = await runtimeModels();
  return models.find((m) => m.key === key)?.publicCode ?? "ash-basic";
}

export async function labelFor(key: string): Promise<string> {
  const models = await runtimeModels();
  return models.find((m) => m.key === key)?.label ?? "Ash Basic";
}

/**
 * What a visitor sees selected when they open Ash: the primary engine, or —
 * if it is out of quota — the engine that has trained Ash the most.
 */
export async function defaultModelId(): Promise<string> {
  const models = await runtimeModels();
  const settings = await getSettings();
  const ranking = await providerRanking(settings);
  const live = models.filter((m) => m.enabled && m.configured && m.group === "full");
  const rank = (id: string) => {
    const i = ranking.indexOf(id);
    return i === -1 ? 999 : i;
  };
  live.sort((a, b) => rank(a.providerId) - rank(b.providerId));

  for (const m of live) {
    if (!(await isCooling(m.key)) && !(await isCooling(m.providerId))) return m.publicCode;
  }
  if (live.length) return live[0].publicCode;
  const smart = models.find((m) => m.key === "smart:auto");
  return smart?.publicCode ?? "ash-basic";
}

export interface ChainOptions {
  needsVision?: boolean;
  /** Skip the offline engine (used by the training loop). */
  realEnginesOnly?: boolean;
  /**
   * Include every model of every engine, not just the first of each.
   * Free per-day quotas are counted per MODEL, so training gets far more
   * mileage by spreading across all of them.
   */
  allModels?: boolean;
}

/**
 * requested → same provider's other models → every other enabled provider in
 * the owner's fallback order → the offline engine, last.
 */
export async function buildChain(requested: RuntimeModel | null, opts: ChainOptions = {}): Promise<RuntimeModel[]> {
  const settings = await getSettings();
  const models = await runtimeModels();
  const usable = models.filter((m) => m.enabled && m.configured && m.group === "full" && (!opts.needsVision || m.vision));

  const chain: RuntimeModel[] = [];
  const push = (m: RuntimeModel | undefined) => {
    if (m && !chain.some((c) => c.key === m.key)) chain.push(m);
  };

  if (requested && requested.group === "full" && usable.some((m) => m.key === requested.key)) push(requested);

  if (requested && requested.group === "full") {
    for (const m of usable.filter((m) => m.providerId === requested.providerId)) push(m);
  }

  if (opts.needsVision && requested && requested.group === "full") {
    // With images we never cross to another provider's text-only engine.
    const visionChain = chain.filter((m) => m.vision);
    if (visionChain.length) return finish(visionChain, settings, opts);
  }

  const byProvider = new Map<string, RuntimeModel[]>();
  for (const m of usable) {
    const arr = byProvider.get(m.providerId) ?? [];
    arr.push(m);
    byProvider.set(m.providerId, arr);
  }
  const ranked = await providerRanking(settings, [...byProvider.keys()]);
  for (const pid of ranked) {
    if (requested && pid === requested.providerId) continue;
    const list = byProvider.get(pid) ?? [];
    if (opts.allModels) list.forEach(push);
    else push(list[0]);
  }

  return finish(chain, settings, opts);
}

async function finish(chain: RuntimeModel[], settings: Settings, opts: ChainOptions): Promise<RuntimeModel[]> {
  const healthy: RuntimeModel[] = [];
  const cooling: RuntimeModel[] = [];
  for (const m of chain) {
    if ((await isCooling(m.key)) || (await isCooling(m.providerId))) cooling.push(m);
    else healthy.push(m);
  }
  const ordered = [...healthy, ...cooling];
  if (!opts.realEnginesOnly && settings.allowMemoryFallback !== false) {
    const models = await runtimeModels();
    const demo = models.find((m) => m.key === "demo:offline");
    if (demo) ordered.push(demo);
  }
  return ordered;
}

const OPENROUTER_HEADERS = () => ({
  "HTTP-Referer": process.env.APP_URL || "http://localhost:3000",
  "X-Title": process.env.AI_NAME || "Ash",
});

export async function providerFor(model: RuntimeModel): Promise<Provider> {
  const settings = await getSettings();
  const all = catalogWithCustom(settings);
  const p = all.find((c) => c.id === model.providerId);
  if (!p) throw new Error("Unknown engine.");

  if (p.kind === "gemini") return createGeminiProvider(p.publicName);
  if (p.kind === "demo" || p.kind === "brain" || p.kind === "smart") {
    return createDemoProvider(
      {
        name: process.env.AI_NAME || DEFAULT_BRANDING.name,
        creator: process.env.AI_CREATOR || DEFAULT_BRANDING.creator,
        country: process.env.AI_COUNTRY || DEFAULT_BRANDING.country,
        city: process.env.AI_CITY || DEFAULT_BRANDING.city,
      },
      // Saying "I'm working on it" is only honest if it really is queued to learn.
      (question) => void enqueueQuestion(question).catch(() => {}),
    );
  }

  const keys = await getKeys();
  const isCustom = p.id.startsWith("custom-");
  const baseUrl = p.id === "local" ? localBaseUrl() : p.baseUrl || "";

  return createOpenAIProvider({
    id: p.id,
    label: p.publicName,
    baseUrl,
    apiKeyEnv: isCustom ? undefined : p.envKeys[0],
    apiKeyLiteral: isCustom ? keys[p.envKeys[0]] || "" : undefined,
    keyOptional: p.id === "local",
    headers: p.id === "openrouter" ? OPENROUTER_HEADERS() : undefined,
    disableThinking: p.disableThinking,
    requiredEnv: p.id === "cloudflare" ? ["CLOUDFLARE_ACCOUNT_ID"] : [],
    maxTokens: 4096,
  });
}

export { CATALOG, OFFLINE_CATALOG } from "./catalog";
export type { Provider } from "./types";
