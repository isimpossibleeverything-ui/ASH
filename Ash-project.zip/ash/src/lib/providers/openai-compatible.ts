import type { Provider, StreamOptions } from "./types";
import { assertOk, ProviderError, readSSE } from "./sse";

export interface OpenAICompatConfig {
  id: string;
  label: string;
  baseUrl: string;
  /** Env var holding the key, or a literal key for custom engines. */
  apiKeyEnv?: string;
  apiKeyLiteral?: string;
  /** Allows a configured-but-keyless engine such as a local Ollama server. */
  keyOptional?: boolean;
  headers?: Record<string, string>;
  disableThinking?: boolean;
  maxTokens?: number;
  /** Template placeholders like {CLOUDFLARE_ACCOUNT_ID} are filled from env. */
  requiredEnv?: string[];
}

function resolveTemplate(input: string): string {
  return input.replace(/\{([A-Z0-9_]+)\}/g, (_m, name: string) => (process.env[name] || "").trim());
}

function apiKeyOf(cfg: OpenAICompatConfig): string {
  if (cfg.apiKeyLiteral) return cfg.apiKeyLiteral;
  if (cfg.apiKeyEnv) return (process.env[cfg.apiKeyEnv] || "").trim();
  return "";
}

type Part = { type: "text"; text: string } | { type: "image_url"; image_url: { url: string } };
type WireMessage = { role: string; content: string | Part[] };

/** One factory for every OpenAI-compatible engine. */
export function createOpenAIProvider(cfg: OpenAICompatConfig): Provider {
  return {
    id: cfg.id,
    label: cfg.label,
    isConfigured() {
      const base = resolveTemplate(cfg.baseUrl || "");
      if (!base || base.includes("{")) return false;
      for (const name of cfg.requiredEnv || []) if (!(process.env[name] || "").trim()) return false;
      if (cfg.keyOptional) return true;
      return !!apiKeyOf(cfg);
    },
    async *stream(options: StreamOptions) {
      const base = resolveTemplate(cfg.baseUrl).replace(/\/+$/, "");
      if (!base || base.includes("{")) throw new ProviderError("This engine is not configured yet.", 401);
      const key = apiKeyOf(cfg);
      if (!key && !cfg.keyOptional) throw new ProviderError("No key configured for this engine.", 401);

      // Plain {role, content} only — internal fields never reach the wire.
      const wire: WireMessage[] = [];
      if (options.system) wire.push({ role: "system", content: options.system });
      for (const m of options.messages) {
        if (m.role === "system") continue;
        wire.push({ role: m.role, content: m.content });
      }

      if (options.images?.length) {
        const lastUser = [...wire].reverse().find((m) => m.role === "user");
        if (options.vision && lastUser) {
          const text = typeof lastUser.content === "string" ? lastUser.content : "";
          const parts: Part[] = options.images.map((img) => ({
            type: "image_url" as const,
            image_url: { url: `data:${img.mimeType};base64,${img.data}` },
          }));
          parts.push({ type: "text", text: text || "What is in this image?" });
          lastUser.content = parts;
        } else {
          wire.push({
            role: "system",
            content: `The user attached ${options.images.length} image(s) but this engine cannot see images — say so briefly instead of guessing.`,
          });
        }
      }

      const body: Record<string, unknown> = {
        model: options.model,
        messages: wire,
        stream: true,
        temperature: typeof options.temperature === "number" ? options.temperature : 0.7,
        max_tokens: cfg.maxTokens ?? 4096,
      };
      if (cfg.disableThinking) body.thinking = { type: "disabled" };

      const headers: Record<string, string> = {
        "content-type": "application/json",
        accept: "text/event-stream",
        ...(cfg.headers || {}),
      };
      if (key) headers.authorization = `Bearer ${key}`;

      const res = await fetch(`${base}/chat/completions`, {
        method: "POST",
        cache: "no-store",
        headers,
        body: JSON.stringify(body),
        signal: options.signal,
      });
      await assertOk(res);

      let emitted = false;
      let reasoning = "";

      for await (const data of readSSE(res, options.signal)) {
        if (!data) continue;
        if (data.trim() === "[DONE]") break;
        let parsed: any;
        try {
          parsed = JSON.parse(data);
        } catch {
          continue;
        }
        if (parsed?.error) {
          const msg = String(parsed.error.message || parsed.error || "The engine returned an error.");
          throw new ProviderError(msg, Number(parsed.error.status_code) || 500);
        }
        const choice = parsed?.choices?.[0];
        const delta = choice?.delta ?? choice?.message ?? {};
        const think = delta?.reasoning_content ?? delta?.reasoning;
        if (typeof think === "string" && think) {
          // Thinking text is never shown. It only proves the engine is alive.
          reasoning += think;
          yield "";
        }
        const content = delta?.content;
        if (typeof content === "string" && content) {
          emitted = true;
          yield content;
        } else if (Array.isArray(content)) {
          const text = content.map((c: any) => (typeof c?.text === "string" ? c.text : "")).join("");
          if (text) {
            emitted = true;
            yield text;
          }
        }
      }

      // Thinking-only reply: better to show the reasoning than an empty screen.
      if (!emitted && reasoning.trim()) yield reasoning.trim();
    },
  };
}

export { resolveTemplate };
