export class ProviderError extends Error {
  status: number;
  retriable: boolean;

  constructor(message: string, status: number) {
    super(message);
    this.name = "ProviderError";
    this.status = status;
    this.retriable = RETRIABLE.has(status) || status === 0;
  }
}

const RETRIABLE = new Set([401, 403, 404, 408, 429, 500, 502, 503, 504]);

const NETWORK_HINTS = [
  "fetch failed",
  "econnreset",
  "etimedout",
  "enotfound",
  "eai_again",
  "econnrefused",
  "socket hang up",
  "network",
  "und_err",
  "terminated",
  "other side closed",
];

/** A thrown value that should make the chat engine try the next engine. */
export function isNetworkError(err: unknown): boolean {
  const msg = String((err as Error)?.message || err || "").toLowerCase();
  const cause = String(((err as { cause?: unknown })?.cause as Error)?.message || "").toLowerCase();
  const code = String((err as { code?: string })?.code || "").toLowerCase();
  return NETWORK_HINTS.some((h) => msg.includes(h) || cause.includes(h) || code.includes(h));
}

export function friendlyStatus(status: number): string {
  switch (status) {
    case 400:
      return "That request was not accepted by the engine.";
    case 401:
      return "The engine key was rejected.";
    case 403:
      return "The engine refused this key.";
    case 404:
      return "That engine no longer offers this model.";
    case 408:
      return "The engine took too long to reply.";
    case 429:
      return "The engine is busy or out of free quota right now.";
    case 500:
    case 502:
    case 503:
    case 504:
      return "The engine is having trouble right now.";
    default:
      return "The engine could not answer.";
  }
}

/** Removes anything that looks like a secret before an error is ever shown. */
export function scrubSecrets(text: string): string {
  return text
    .replace(/\b(sk|gsk|csk|hf|xai|tvly|nvapi|or)[-_][A-Za-z0-9\-_]{8,}/gi, "«key»")
    .replace(/\bAIza[0-9A-Za-z\-_]{10,}\b/g, "«key»")
    .replace(/Bearer\s+[A-Za-z0-9._\-]{8,}/gi, "Bearer «key»")
    .replace(/([?&](key|api_key|token)=)[^&\s"']+/gi, "$1«key»");
}

export async function assertOk(res: Response): Promise<void> {
  if (res.ok) return;
  let detail = "";
  try {
    detail = (await res.text()).slice(0, 400);
  } catch {
    /* ignore */
  }
  const base = friendlyStatus(res.status);
  const extra = detail ? ` (${scrubSecrets(detail.replace(/\s+/g, " ").trim())})` : "";
  throw new ProviderError(`${base}${extra}`, res.status);
}

/**
 * Robust Server-Sent-Events reader: survives \r\n, split chunks, comment
 * lines and a trailing event with no blank line after it.
 */
export async function* readSSE(res: Response, signal?: AbortSignal): AsyncGenerator<string> {
  const body = res.body;
  if (!body) return;
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  const onAbort = () => {
    reader.cancel().catch(() => {});
  };
  signal?.addEventListener("abort", onAbort, { once: true });

  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      buffer = buffer.replace(/\r\n/g, "\n").replace(/\r/g, "\n");

      let sep: number;
      while ((sep = buffer.indexOf("\n\n")) !== -1) {
        const raw = buffer.slice(0, sep);
        buffer = buffer.slice(sep + 2);
        const payload = extractData(raw);
        if (payload !== null) yield payload;
      }
    }
    buffer += decoder.decode();
    const tail = extractData(buffer);
    if (tail !== null) yield tail;
  } finally {
    signal?.removeEventListener("abort", onAbort);
    try {
      reader.releaseLock();
    } catch {
      /* ignore */
    }
  }
}

function extractData(block: string): string | null {
  const lines = block.split("\n");
  const data: string[] = [];
  for (const line of lines) {
    if (!line || line.startsWith(":")) continue;
    if (line.startsWith("data:")) data.push(line.slice(5).replace(/^ /, ""));
  }
  if (!data.length) return null;
  return data.join("\n");
}

export function withTimeout(signal: AbortSignal | undefined, ms: number): { signal: AbortSignal; cancel: () => void } {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(new Error("timeout")), ms);
  const onAbort = () => controller.abort();
  signal?.addEventListener("abort", onAbort, { once: true });
  return {
    signal: controller.signal,
    cancel: () => {
      clearTimeout(t);
      signal?.removeEventListener("abort", onAbort);
    },
  };
}
