import type { InlineImage } from "@/lib/types";

export interface ProviderMessage {
  role: "user" | "assistant" | "system";
  content: string;
}

export interface StreamOptions {
  model: string;
  messages: ProviderMessage[];
  system?: string;
  temperature?: number;
  images?: InlineImage[];
  signal?: AbortSignal;
  vision?: boolean;
}

export interface Provider {
  id: string;
  /** Owner-only label. Never serialise this to the browser. */
  label: string;
  isConfigured(): boolean;
  stream(options: StreamOptions): AsyncGenerator<string>;
}
