/* Installing Ash as a real app.

   Chromium fires `beforeinstallprompt`; we keep that event and fire it back when
   the person actually asks. Safari has no such event — there we show the real
   steps instead of a button that would do nothing. */

export type InstallOutcome = "installed" | "dismissed" | "unavailable";
export type Platform = "ios" | "android" | "desktop";

interface InstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

let deferred: InstallPromptEvent | null = null;
let installed = false;
let started = false;
const listeners = new Set<() => void>();

const announce = (): void => {
  for (const fn of listeners) fn();
};

export function isStandalone(): boolean {
  if (typeof window === "undefined") return false;
  const navStandalone = (window.navigator as Navigator & { standalone?: boolean }).standalone;
  return window.matchMedia("(display-mode: standalone)").matches || navStandalone === true;
}

export function platform(): Platform {
  if (typeof navigator === "undefined") return "desktop";
  const ua = navigator.userAgent;
  // iPadOS 13+ reports as a Mac, so check for a touch-capable "Mac" too
  const iPadish = /Macintosh/.test(ua) && navigator.maxTouchPoints > 1;
  if (/iPhone|iPad|iPod/.test(ua) || iPadish) return "ios";
  if (/Android/.test(ua)) return "android";
  return "desktop";
}

/** True when a real install prompt is sitting ready. */
export function canInstall(): boolean {
  return deferred !== null && !installed && !isStandalone();
}

/** True when the app is installable but only by hand (Safari / iOS). */
export function needsManualInstall(): boolean {
  return !canInstall() && !installed && !isStandalone() && platform() === "ios";
}

export function onInstallChange(fn: () => void): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export async function promptInstall(): Promise<InstallOutcome> {
  if (!deferred) return "unavailable";
  const event = deferred;
  deferred = null;
  announce();
  await event.prompt();
  const { outcome } = await event.userChoice;
  if (outcome === "accepted") {
    installed = true;
    announce();
    return "installed";
  }
  return "dismissed";
}

/** Called once, from the root layout. Safe to call again. */
export function initPwa(): void {
  if (started || typeof window === "undefined") return;
  started = true;

  window.addEventListener("beforeinstallprompt", (e) => {
    e.preventDefault();
    deferred = e as InstallPromptEvent;
    announce();
  });

  window.addEventListener("appinstalled", () => {
    installed = true;
    deferred = null;
    announce();
  });

  if (!("serviceWorker" in navigator)) return;

  // In development Turbopack re-serves chunk URLs with new contents, which a
  // cache-first worker would happily poison. So: register in production, and
  // actively clean up any worker left behind on a dev machine.
  if (process.env.NODE_ENV !== "production") {
    void navigator.serviceWorker.getRegistrations().then((regs) => {
      for (const r of regs) void r.unregister();
    });
    return;
  }

  const register = (): void => {
    void navigator.serviceWorker
      .register("/sw.js", { scope: "/" })
      .then((reg) => {
        // a new version is waiting → let it take over on the next load
        reg.addEventListener("updatefound", () => {
          const sw = reg.installing;
          if (!sw) return;
          sw.addEventListener("statechange", () => {
            if (sw.state === "installed" && navigator.serviceWorker.controller) {
              sw.postMessage("skip-waiting");
            }
          });
        });
      })
      .catch(() => {
        /* a failed registration must never break the app */
      });
  };

  if (document.readyState === "complete") register();
  else window.addEventListener("load", register, { once: true });
}
