type Bucket = number[];
const buckets = new Map<string, Bucket>();

export interface LimitResult {
  ok: boolean;
  retryAfter: number;
  message?: string;
}

/** In-memory sliding window. Good for one instance; swap for a DB table when you scale out. */
export function hit(key: string, limit: number, windowMs: number, message: string): LimitResult {
  if (limit <= 0) return { ok: true, retryAfter: 0 };
  const now = Date.now();
  const arr = buckets.get(key) ?? [];
  const live = arr.filter((t) => now - t < windowMs);
  if (live.length >= limit) {
    const oldest = live[0] ?? now;
    const retryAfter = Math.max(1, Math.ceil((windowMs - (now - oldest)) / 1000));
    buckets.set(key, live);
    return { ok: false, retryAfter, message };
  }
  live.push(now);
  buckets.set(key, live);
  if (buckets.size > 10_000) {
    for (const [k, v] of buckets) {
      if (!v.length || now - v[v.length - 1] > windowMs) buckets.delete(k);
    }
  }
  return { ok: true, retryAfter: 0 };
}

export function clientIp(req: Request): string {
  const h = req.headers;
  const fwd = h.get("x-forwarded-for");
  if (fwd) return fwd.split(",")[0].trim();
  return h.get("x-real-ip") || h.get("cf-connecting-ip") || "0.0.0.0";
}
