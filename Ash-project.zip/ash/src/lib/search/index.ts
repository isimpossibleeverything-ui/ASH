import dns from "node:dns/promises";
import type { SearchHit } from "@/lib/types";
import { getSettings } from "@/lib/settings";
import { SEARCH_PROVIDERS } from "@/lib/providers/catalog";

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

/* ───────────────────────────── SSRF guard ───────────────────────────── */

function isPrivateIp(ip: string): boolean {
  if (ip.includes(":")) {
    const low = ip.toLowerCase();
    return low === "::1" || low.startsWith("fc") || low.startsWith("fd") || low.startsWith("fe80") || low === "::";
  }
  const p = ip.split(".").map(Number);
  if (p.length !== 4 || p.some((n) => Number.isNaN(n))) return true;
  const [a, b] = p;
  if (a === 10 || a === 127 || a === 0) return true;
  if (a === 172 && b >= 16 && b <= 31) return true;
  if (a === 192 && b === 168) return true;
  if (a === 169 && b === 254) return true;
  if (a === 100 && b >= 64 && b <= 127) return true;
  if (a >= 224) return true;
  return false;
}

export async function isSafeUrl(raw: string): Promise<boolean> {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    return false;
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") return false;
  const host = url.hostname.toLowerCase();
  if (host === "localhost" || host.endsWith(".localhost") || host.endsWith(".internal") || host.endsWith(".local")) return false;
  if (/^\d+\.\d+\.\d+\.\d+$/.test(host) || host.includes(":")) return !isPrivateIp(host);
  try {
    const records = await dns.lookup(host, { all: true });
    if (!records.length) return false;
    return records.every((r) => !isPrivateIp(r.address));
  } catch {
    return false;
  }
}

async function fetchWithTimeout(url: string, init: RequestInit & { timeout?: number } = {}): Promise<Response> {
  const { timeout = 9000, ...rest } = init;
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), timeout);
  try {
    return await fetch(url, { ...rest, cache: "no-store", signal: controller.signal, headers: { "user-agent": UA, ...(rest.headers || {}) } });
  } finally {
    clearTimeout(t);
  }
}

/* ───────────────────────────── providers ───────────────────────────── */

function decodeEntities(s: string): string {
  return s
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&#x27;/g, "'")
    .replace(/&nbsp;/g, " ");
}

function stripTags(s: string): string {
  return decodeEntities(s.replace(/<[^>]*>/g, "")).replace(/\s+/g, " ").trim();
}

async function duckduckgo(query: string, max: number): Promise<SearchHit[]> {
  // The HTML endpoint only answers a POSTed form from a normal browser agent.
  const res = await fetchWithTimeout("https://html.duckduckgo.com/html/", {
    method: "POST",
    headers: {
      "content-type": "application/x-www-form-urlencoded",
      accept: "text/html,application/xhtml+xml",
      "accept-language": "en-US,en;q=0.9",
    },
    body: new URLSearchParams({ q: query, kl: "wt-wt" }).toString(),
  });
  if (!res.ok) return [];
  const html = await res.text();
  const hits: SearchHit[] = [];
  const blocks = html.split("result__body").slice(1);
  for (const block of blocks) {
    const linkMatch = block.match(/<a[^>]+class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/);
    if (!linkMatch) continue;
    let url = decodeEntities(linkMatch[1]);
    const uddg = url.match(/[?&]uddg=([^&]+)/);
    if (uddg) url = decodeURIComponent(uddg[1]);
    if (url.startsWith("//")) url = `https:${url}`;
    if (!/^https?:\/\//.test(url)) continue;
    const snippetMatch = block.match(/class="result__snippet"[^>]*>([\s\S]*?)<\/a>/);
    hits.push({
      title: stripTags(linkMatch[2]).slice(0, 160),
      snippet: snippetMatch ? stripTags(snippetMatch[1]).slice(0, 320) : "",
      url,
      source: "DuckDuckGo",
    });
    if (hits.length >= max) break;
  }
  return hits;
}

/** Keyless official endpoint. Good for entities, quiet on breaking news. */
async function duckduckgoInstant(query: string, max: number): Promise<SearchHit[]> {
  const res = await fetchWithTimeout(
    `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&no_redirect=1&skip_disambig=1`,
    { headers: { accept: "application/json" } },
  );
  if (!res.ok) return [];
  const data = (await res.json()) as any;
  const hits: SearchHit[] = [];
  if (data?.AbstractText && data?.AbstractURL) {
    hits.push({
      title: String(data.Heading || query),
      snippet: String(data.AbstractText).slice(0, 320),
      url: String(data.AbstractURL),
      source: "DuckDuckGo",
    });
  }
  const walk = (items: any[]) => {
    for (const item of items ?? []) {
      if (hits.length >= max) return;
      if (Array.isArray(item?.Topics)) {
        walk(item.Topics);
        continue;
      }
      if (item?.FirstURL && item?.Text) {
        hits.push({
          title: String(item.Text).split(" - ")[0].slice(0, 160),
          snippet: String(item.Text).slice(0, 320),
          url: String(item.FirstURL),
          source: "DuckDuckGo",
        });
      }
    }
  };
  walk(data?.Results ?? []);
  walk(data?.RelatedTopics ?? []);
  return hits.slice(0, max);
}

async function wikipedia(query: string, max: number): Promise<SearchHit[]> {
  const lang = /[\u0600-\u06FF]/.test(query) ? "ur" : "en";
  const api = `https://${lang}.wikipedia.org/w/api.php`;
  const searchRes = await fetchWithTimeout(
    `${api}?action=query&list=search&srsearch=${encodeURIComponent(query)}&srlimit=${max}&format=json&origin=*`,
  );
  if (!searchRes.ok) return [];
  const data = (await searchRes.json()) as any;
  const results = data?.query?.search ?? [];
  return results.slice(0, max).map((r: any) => ({
    title: String(r.title),
    snippet: stripTags(String(r.snippet || "")),
    url: `https://${lang}.wikipedia.org/wiki/${encodeURIComponent(String(r.title).replace(/ /g, "_"))}`,
    source: "Wikipedia",
  }));
}

async function searxng(query: string, max: number, base: string): Promise<SearchHit[]> {
  if (!base || !(await isSafeUrl(base))) return [];
  const url = `${base.replace(/\/+$/, "")}/search?q=${encodeURIComponent(query)}&format=json&safesearch=1`;
  const res = await fetchWithTimeout(url, { headers: { accept: "application/json" } });
  if (!res.ok) return [];
  const data = (await res.json()) as any;
  return (data?.results ?? []).slice(0, max).map((r: any) => ({
    title: String(r.title || ""),
    snippet: String(r.content || "").slice(0, 320),
    url: String(r.url || ""),
    source: "SearXNG",
  }));
}

async function tavily(query: string, max: number): Promise<SearchHit[]> {
  const key = (process.env.TAVILY_API_KEY || "").trim();
  if (!key) return [];
  const res = await fetchWithTimeout("https://api.tavily.com/search", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ api_key: key, query, max_results: max, search_depth: "basic" }),
  });
  if (!res.ok) return [];
  const data = (await res.json()) as any;
  return (data?.results ?? []).slice(0, max).map((r: any) => ({
    title: String(r.title || ""),
    snippet: String(r.content || "").slice(0, 320),
    url: String(r.url || ""),
    source: "Tavily",
  }));
}

async function brave(query: string, max: number): Promise<SearchHit[]> {
  const key = (process.env.BRAVE_API_KEY || "").trim();
  if (!key) return [];
  const res = await fetchWithTimeout(`https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(query)}&count=${max}`, {
    headers: { accept: "application/json", "x-subscription-token": key },
  });
  if (!res.ok) return [];
  const data = (await res.json()) as any;
  return (data?.web?.results ?? []).slice(0, max).map((r: any) => ({
    title: String(r.title || ""),
    snippet: stripTags(String(r.description || "")).slice(0, 320),
    url: String(r.url || ""),
    source: "Brave",
  }));
}

async function serper(query: string, max: number): Promise<SearchHit[]> {
  const key = (process.env.SERPER_API_KEY || "").trim();
  if (!key) return [];
  const res = await fetchWithTimeout("https://google.serper.dev/search", {
    method: "POST",
    headers: { "content-type": "application/json", "x-api-key": key },
    body: JSON.stringify({ q: query, num: max }),
  });
  if (!res.ok) return [];
  const data = (await res.json()) as any;
  return (data?.organic ?? []).slice(0, max).map((r: any) => ({
    title: String(r.title || ""),
    snippet: String(r.snippet || "").slice(0, 320),
    url: String(r.link || ""),
    source: "Serper",
  }));
}

export async function runSearchProvider(id: string, query: string, max: number, url?: string): Promise<SearchHit[]> {
  switch (id) {
    case "duckduckgo": {
      const html = await duckduckgo(query, max).catch(() => [] as SearchHit[]);
      if (html.length) return html;
      // Some hosts are blocked from the HTML endpoint; fall back to the API.
      return duckduckgoInstant(query, max);
    }
    case "wikipedia":
      return wikipedia(query, max);
    case "searxng":
      return searxng(query, max, url || process.env.SEARXNG_URL || "");
    case "tavily":
      return tavily(query, max);
    case "brave":
      return brave(query, max);
    case "serper":
      return serper(query, max);
    default:
      return [];
  }
}

/** Reads a page and returns at most 8 KB of plain text. SSRF-safe. */
export async function readPage(url: string): Promise<string> {
  if (!(await isSafeUrl(url))) return "";
  try {
    const res = await fetchWithTimeout(url, { timeout: 8000, headers: { accept: "text/html,text/plain" } });
    if (!res.ok) return "";
    const type = res.headers.get("content-type") || "";
    if (!type.includes("text/html") && !type.includes("text/plain")) return "";
    const raw = (await res.text()).slice(0, 400_000);
    const body = raw
      .replace(/<script[\s\S]*?<\/script>/gi, " ")
      .replace(/<style[\s\S]*?<\/style>/gi, " ")
      .replace(/<noscript[\s\S]*?<\/noscript>/gi, " ")
      .replace(/<nav[\s\S]*?<\/nav>/gi, " ")
      .replace(/<footer[\s\S]*?<\/footer>/gi, " ");
    return stripTags(body).slice(0, 8192);
  } catch {
    return "";
  }
}

export interface SearchOutcome {
  hits: SearchHit[];
  pageText: string;
  usedProviders: string[];
}

export async function webSearch(query: string): Promise<SearchOutcome> {
  const settings = await getSettings();
  const max = Math.min(8, Math.max(3, settings.search.maxResults || 5));
  const entries = SEARCH_PROVIDERS.map((sp) => ({
    id: sp.id as string,
    ...(settings.search.providers[sp.id] ?? { enabled: false, order: 99, url: "" }),
  }))
    .filter((e) => e.enabled)
    .sort((a, b) => a.order - b.order);

  const hits: SearchHit[] = [];
  const used: string[] = [];
  for (const e of entries) {
    if (hits.length >= max) break;
    try {
      const got = await runSearchProvider(e.id, query, max - hits.length, e.url);
      if (got.length) {
        used.push(e.id);
        for (const h of got) {
          if (h.url && !hits.some((x) => x.url === h.url)) hits.push(h);
        }
      }
    } catch {
      /* a failed search must never break the chat */
    }
  }

  let pageText = "";
  if (settings.search.readPages && hits[0]?.url) {
    pageText = await readPage(hits[0].url);
  }
  return { hits: hits.slice(0, max), pageText, usedProviders: used };
}

const TIME_SENSITIVE =
  /\b(today|tonight|latest|current|currently|right now|news|price|prices|rate|rates|weather|score|scores|stock|update|updates|release[ds]?|who is|who was|who are|kaun hai|kaun hain|kon hai|aaj|abhi|taza|taaza|khabar|qeemat|keemat|mausam|hal hi|اب|آج|تازہ|خبر|قیمت|موسم|کون ہے|کون ہیں)\b/i;
const YEAR = /\b20(2[4-9]|3[0-9])\b/;
const GENERIC = /^(what is|what are|how many|how much|define|explain|kya hai|kya hota hai|kaise|how do i|how to)\b/i;

/** Auto mode: only search when the question actually needs fresh facts. */
export function shouldAutoSearch(message: string): boolean {
  const t = message.trim();
  if (!t || t.length > 600) return false;
  if (/\b(who is|who was|who are|kaun hai|kon hai|کون ہے)\b/i.test(t)) return true;
  if (GENERIC.test(t) && !TIME_SENSITIVE.test(t) && !YEAR.test(t)) return false;
  return TIME_SENSITIVE.test(t) || YEAR.test(t);
}

export function buildSearchContext(hits: SearchHit[], pageText: string): string {
  if (!hits.length) return "";
  const today = new Date().toISOString().slice(0, 10);
  const lines = hits.map((h, i) => `[${i + 1}] ${h.title}\n${h.snippet}\n${h.url}`).join("\n\n");
  const page = pageText ? `\n\nFull text of the first result (trimmed):\n${pageText}` : "";
  return [
    `\n\nLIVE WEB RESULTS (fetched ${today}). Use them to answer.`,
    lines,
    page,
    `\nRules for these results: rely on them for anything time-sensitive, mention the date or the source in the text, say plainly if they do not actually answer the question, and finish with a short "Sources" list of the links you used.`,
  ].join("\n");
}
