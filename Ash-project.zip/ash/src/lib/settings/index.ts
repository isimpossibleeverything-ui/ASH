import { getSetting, setSetting } from "@/lib/db/repo";
import { CATALOG, OFFLINE_CATALOG, SEARCH_PROVIDERS } from "@/lib/providers/catalog";
import { DEFAULT_BRANDING, DEFAULT_SYSTEM_PROMPT_TEMPLATE } from "@/lib/identity";

export interface ProviderPrefs {
  enabled: boolean;
  /** Real model ids of this provider that are exposed to visitors. */
  models: string[];
}

export interface CustomEngine {
  id: string;
  label: string;
  baseUrl: string;
  model: string;
  note: string;
  enabled: boolean;
}

export interface SearchPrefs {
  mode: "auto" | "always" | "never";
  maxResults: number;
  readPages: boolean;
  providers: Record<string, { enabled: boolean; order: number; url?: string }>;
}

export interface LimitPrefs {
  perVisitorHour: number;
  perIpMinute: number;
  maxMessageChars: number;
  /** Rough token budget for the history sent to the model. */
  contextTokens: number;
  maxImages: number;
  requireLogin: boolean;
  allowMedia: boolean;
  ownerCanViewChats: boolean;
}

export interface VoicePrefs {
  enabled: boolean;
  /** "browser" uses the device's own speech engine — free, instant, no key. */
  sttProvider: string;
  ttsProvider: string;
  ttsVoice: string;
  /** Language used for speech. "auto" follows the text language. */
  voiceLang: string;
  rate: number;
  volume: number;
  /** Read every assistant reply out loud automatically. */
  autoSpeak: boolean;
  /** Keep the microphone open and keep the conversation going. */
  continuous: boolean;
  /** Let spoken commands drive the app itself, not just dictate messages. */
  commands: boolean;
  /** Say this first and the rest of the sentence is treated as a command. */
  wakeWord: string;
}

export interface CoworkPrefs {
  /** The agentic workspace mode. */
  enabled: boolean;
  /** Let it delete files without stopping to ask. Off by default, on purpose. */
  autoApprove: boolean;
  /** Hard ceiling on steps per run. */
  maxSteps: number;
}

export interface Settings {
  branding: { name: string; creator: string; country: string; city: string };
  systemPrompt: string;
  providers: Record<string, ProviderPrefs>;
  customEngines: CustomEngine[];
  fallbackOrder: string[];
  /** The engine every new visitor starts on. */
  primaryProvider: string;
  /** When the leader is out of quota, pick the best-trained engine next. */
  preferTrainedFallback: boolean;
  allowMemoryFallback: boolean;
  search: SearchPrefs;
  limits: LimitPrefs;
  learning: { running: boolean; concurrency: number };
  /** Capability toggles for the agent orchestrator. */
  agents: Record<string, { enabled: boolean }>;
  voice: VoicePrefs;
  cowork: CoworkPrefs;
}

const SETTINGS_KEY = "app_settings_json";
const KEYS_KEY = "env_keys_json";

export function defaultSettings(): Settings {
  const providers: Record<string, ProviderPrefs> = {};
  for (const p of [...OFFLINE_CATALOG, ...CATALOG]) {
    providers[p.id] = { enabled: p.defaultEnabled, models: p.models.map((m) => m.id) };
  }
  const search: SearchPrefs["providers"] = {};
  SEARCH_PROVIDERS.forEach((sp, i) => {
    search[sp.id] = { enabled: sp.id === "duckduckgo" || sp.id === "wikipedia", order: i, url: "" };
  });
  return {
    branding: { ...DEFAULT_BRANDING },
    systemPrompt: "",
    providers,
    customEngines: [],
    fallbackOrder: CATALOG.filter((p) => !p.paid).map((p) => p.id),
    primaryProvider: "gemini",
    preferTrainedFallback: true,
    allowMemoryFallback: true,
    search: { mode: "auto", maxResults: 5, readPages: true, providers: search },
    limits: {
      perVisitorHour: 60,
      perIpMinute: 12,
      maxMessageChars: 8000,
      contextTokens: 12000,
      maxImages: 4,
      requireLogin: false,
      allowMedia: true,
      ownerCanViewChats: false,
    },
    learning: { running: false, concurrency: 4 },
    agents: { math: { enabled: true }, memory: { enabled: true }, search: { enabled: true } },
    voice: {
      enabled: true,
      sttProvider: "browser",
      ttsProvider: "browser",
      ttsVoice: "",
      voiceLang: "auto",
      rate: 1,
      volume: 1,
      autoSpeak: false,
      continuous: false,
      commands: true,
      wakeWord: "",
    },
    cowork: { enabled: true, autoApprove: false, maxSteps: 24 },
  };
}

let cache: { value: Settings; at: number } | null = null;
const TTL = 5_000;

function merge(base: Settings, patch: any): Settings {
  if (!patch || typeof patch !== "object") return base;
  const out: Settings = {
    ...base,
    ...patch,
    branding: { ...base.branding, ...(patch.branding || {}) },
    providers: { ...base.providers },
    search: {
      ...base.search,
      ...(patch.search || {}),
      providers: { ...base.search.providers },
    },
    limits: { ...base.limits, ...(patch.limits || {}) },
    learning: { ...base.learning, ...(patch.learning || {}) },
    agents: { ...base.agents, ...(patch.agents || {}) },
    voice: { ...base.voice, ...(patch.voice || {}) },
    cowork: { ...base.cowork, ...(patch.cowork || {}) },
    customEngines: Array.isArray(patch.customEngines) ? patch.customEngines : base.customEngines,
    fallbackOrder: Array.isArray(patch.fallbackOrder) && patch.fallbackOrder.length ? patch.fallbackOrder : base.fallbackOrder,
  };
  if (patch.providers && typeof patch.providers === "object") {
    for (const [id, v] of Object.entries<any>(patch.providers)) {
      out.providers[id] = { ...(base.providers[id] || { enabled: false, models: [] }), ...(v || {}) };
    }
  }
  if (patch.search?.providers && typeof patch.search.providers === "object") {
    for (const [id, v] of Object.entries<any>(patch.search.providers)) {
      out.search.providers[id] = { ...(base.search.providers[id] || { enabled: false, order: 99 }), ...(v || {}) };
    }
  }
  // keep fallbackOrder complete
  const known = CATALOG.map((p) => p.id);
  out.fallbackOrder = [
    ...out.fallbackOrder.filter((id) => known.includes(id)),
    ...known.filter((id) => !out.fallbackOrder.includes(id)),
  ];
  return out;
}

export async function getSettings(): Promise<Settings> {
  if (cache && Date.now() - cache.at < TTL) return cache.value;
  const base = defaultSettings();
  let value = base;
  try {
    const raw = await getSetting(SETTINGS_KEY);
    if (raw) value = merge(base, JSON.parse(raw));
  } catch {
    value = base;
  }
  cache = { value, at: Date.now() };
  return value;
}

export async function saveSettings(patch: any): Promise<Settings> {
  const current = await getSettings();
  const next = merge(current, patch);
  await setSetting(SETTINGS_KEY, JSON.stringify(next));
  cache = { value: next, at: Date.now() };
  return next;
}

export function invalidateSettings(): void {
  cache = null;
}

/* ───────────────────────────── API keys ───────────────────────────── */

let keyCache: { value: Record<string, string>; at: number } | null = null;

export async function getKeys(): Promise<Record<string, string>> {
  if (keyCache && Date.now() - keyCache.at < TTL) return keyCache.value;
  let value: Record<string, string> = {};
  try {
    const raw = await getSetting(KEYS_KEY);
    if (raw) value = JSON.parse(raw);
  } catch {
    value = {};
  }
  keyCache = { value, at: Date.now() };
  return value;
}

export async function setKey(name: string, value: string): Promise<void> {
  const keys = { ...(await getKeys()) };
  if (!value) delete keys[name];
  else keys[name] = value;
  await setSetting(KEYS_KEY, JSON.stringify(keys));
  keyCache = { value: keys, at: Date.now() };
  if (value) process.env[name] = value;
  else delete process.env[name];
}

/**
 * Merge database-stored keys into process.env. Called at the start of every
 * request so read-only hosts (Vercel) work without redeploying.
 */
export async function hydrateEnv(): Promise<void> {
  try {
    const keys = await getKeys();
    for (const [k, v] of Object.entries(keys)) {
      if (typeof v === "string" && v.trim()) process.env[k] = v.trim();
    }
    const settings = await getSettings();
    if (settings.branding.name) process.env.AI_NAME = settings.branding.name;
    if (settings.branding.creator) process.env.AI_CREATOR = settings.branding.creator;
    if (settings.branding.country) process.env.AI_COUNTRY = settings.branding.country;
    if (settings.branding.city) process.env.AI_CITY = settings.branding.city;
  } catch {
    /* first boot, before the DB exists — defaults still work */
  }
}

export function maskKey(value: string | undefined | null): string {
  if (!value) return "";
  const v = value.trim();
  if (v.length <= 8) return "••••";
  return `${v.slice(0, 4)}…${v.slice(-4)}`;
}

export async function brandingFromSettings() {
  const s = await getSettings();
  return s.branding;
}

export function defaultSystemPromptTemplate(): string {
  return DEFAULT_SYSTEM_PROMPT_TEMPLATE;
}
