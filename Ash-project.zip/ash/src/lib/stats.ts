import { getSetting, setSetting } from "@/lib/db/repo";

export interface DayStats {
  day: string;
  messages: number;
  errors: number;
  fallbacks: number;
  visitors: string[];
}

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

let mem: DayStats = { day: today(), messages: 0, errors: 0, fallbacks: 0, visitors: [] };
let loaded = false;
let dirty = false;
let timer: ReturnType<typeof setTimeout> | null = null;

async function load() {
  if (loaded) return;
  loaded = true;
  try {
    const raw = await getSetting(`stats:${today()}`);
    if (raw) mem = { ...JSON.parse(raw), day: today() };
  } catch {
    /* ignore */
  }
}

function flushSoon() {
  dirty = true;
  if (timer) return;
  timer = setTimeout(() => {
    timer = null;
    if (!dirty) return;
    dirty = false;
    setSetting(`stats:${mem.day}`, JSON.stringify(mem)).catch(() => {});
  }, 5_000);
  if (typeof timer === "object" && timer && "unref" in timer) (timer as unknown as { unref(): void }).unref();
}

function rollover() {
  const d = today();
  if (mem.day !== d) mem = { day: d, messages: 0, errors: 0, fallbacks: 0, visitors: [] };
}

export async function bumpStat(kind: "messages" | "errors" | "fallbacks", visitorId?: string) {
  await load();
  rollover();
  mem[kind] += 1;
  if (visitorId && !mem.visitors.includes(visitorId)) {
    mem.visitors.push(visitorId);
    if (mem.visitors.length > 5000) mem.visitors.shift();
  }
  flushSoon();
}

export async function readStats(): Promise<{ messages: number; errors: number; fallbacks: number; visitors: number; day: string }> {
  await load();
  rollover();
  return { messages: mem.messages, errors: mem.errors, fallbacks: mem.fallbacks, visitors: mem.visitors.length, day: mem.day };
}
