"use client";

export interface StreamHandlers {
  onMeta?: (data: { conversationId: string; userMessageId: string; model: string; title: string; downgraded: boolean }) => void;
  onNotice?: (data: { message: string }) => void;
  onModel?: (data: { model: string }) => void;
  onDelta?: (data: { text: string }) => void;
  onSources?: (data: { hits: { title: string; url: string; source?: string }[] }) => void;
  onError?: (data: { message: string }) => void;
  onDone?: (data: { assistantMessageId: string; content: string; model: string }) => void;
}

export interface ChatPayload {
  conversationId?: string;
  message?: string;
  model?: string;
  systemPrompt?: string;
  temperature?: number;
  regenerateFrom?: string;
  images?: { mimeType: string; data: string }[];
  search?: boolean;
  replyLanguage?: string;
  useMemory?: boolean;
}

/** Minimal SSE parser over fetch(). Survives split chunks and \r\n. */
export async function streamChat(payload: ChatPayload, handlers: StreamHandlers, signal?: AbortSignal): Promise<void> {
  const res = await fetch("/api/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(payload),
    signal,
  });

  if (!res.ok || !res.body) {
    let message = "The request failed.";
    try {
      const data = await res.json();
      if (data?.error) message = data.error;
    } catch {
      /* keep default */
    }
    handlers.onError?.({ message });
    handlers.onDone?.({ assistantMessageId: "", content: "", model: "" });
    return;
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  const dispatch = (event: string, raw: string) => {
    let data: any = {};
    try {
      data = raw ? JSON.parse(raw) : {};
    } catch {
      return;
    }
    switch (event) {
      case "meta":
        handlers.onMeta?.(data);
        break;
      case "notice":
        handlers.onNotice?.(data);
        break;
      case "model":
        handlers.onModel?.(data);
        break;
      case "delta":
        handlers.onDelta?.(data);
        break;
      case "sources":
        handlers.onSources?.(data);
        break;
      case "error":
        handlers.onError?.(data);
        break;
      case "done":
        handlers.onDone?.(data);
        break;
    }
  };

  const flush = (block: string) => {
    if (!block.trim()) return;
    let event = "message";
    const data: string[] = [];
    for (const line of block.split("\n")) {
      if (line.startsWith("event:")) event = line.slice(6).trim();
      else if (line.startsWith("data:")) data.push(line.slice(5).replace(/^ /, ""));
    }
    dispatch(event, data.join("\n"));
  };

  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      buffer = buffer.replace(/\r\n/g, "\n");
      let sep: number;
      while ((sep = buffer.indexOf("\n\n")) !== -1) {
        const block = buffer.slice(0, sep);
        buffer = buffer.slice(sep + 2);
        flush(block);
      }
    }
    buffer += decoder.decode();
    flush(buffer);
  } catch (err) {
    if ((err as Error)?.name !== "AbortError") {
      handlers.onError?.({ message: "The connection dropped while answering." });
    }
  }
}

/** Shrinks a picture in the browser: longest side 1280px, JPEG, under 5 MB. */
export async function downscaleImage(file: File, maxSide = 1280): Promise<{ mimeType: string; data: string; preview: string }> {
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
  const width = Math.max(1, Math.round(bitmap.width * scale));
  const height = Math.max(1, Math.round(bitmap.height * scale));
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not read that image.");
  ctx.drawImage(bitmap, 0, 0, width, height);
  bitmap.close?.();

  let quality = 0.86;
  let dataUrl = canvas.toDataURL("image/jpeg", quality);
  while (dataUrl.length > 5 * 1024 * 1024 && quality > 0.4) {
    quality -= 0.12;
    dataUrl = canvas.toDataURL("image/jpeg", quality);
  }
  return { mimeType: "image/jpeg", data: dataUrl.split(",")[1] ?? "", preview: dataUrl };
}
