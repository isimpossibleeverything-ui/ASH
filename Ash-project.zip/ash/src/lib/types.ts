export type Role = "user" | "assistant" | "system";

export interface InlineImage {
  mimeType: string;
  /** base64, no data: prefix */
  data: string;
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  role: Role;
  content: string;
  model?: string | null;
  createdAt: number;
}

export interface Conversation {
  id: string;
  title: string;
  model: string | null;
  systemPrompt: string | null;
  pinned: boolean;
  archived: boolean;
  createdAt: number;
  updatedAt: number;
}

/** What the browser is allowed to know about a model. No vendor names, ever. */
export interface PublicModel {
  id: string;
  label: string;
  description: string;
  available: boolean;
  group: "offline" | "full";
}

export interface SearchHit {
  title: string;
  snippet: string;
  url: string;
  source?: string;
}

export interface ChatRequestBody {
  conversationId?: string;
  message?: string;
  model?: string;
  systemPrompt?: string;
  temperature?: number;
  regenerateFrom?: string;
  images?: InlineImage[];
  search?: boolean;
  replyLanguage?: string;
  useMemory?: boolean;
}

export type SseEventName = "meta" | "notice" | "model" | "delta" | "error" | "done" | "sources";
