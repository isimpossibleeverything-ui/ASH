"use client";

import { useCallback, useEffect, useRef } from "react";
import { helpSentence, matchCommand, type CommandIntent, type CommandMatch } from "@/lib/voice/commands";

/**
 * Turns a spoken sentence into an action on the app itself.
 *
 * Dictation stays the default: unless the human used the wake word or switched
 * command mode on, only a tiny set of unmistakable words (stop, ruk jao) are
 * intercepted. Everything else is sent to Ash as a normal message.
 */

export interface VoiceActions {
  send: (text: string) => void;

  newChat: () => void;
  deleteChat: () => void;
  renameChat: (title: string) => void;

  openSettings: () => void;
  openPanel: () => void;
  close: () => void;

  stopGenerating: () => void;
  regenerate: () => void;
  readLast: () => void;
  stopReading: () => void;
  copyLast: () => void;
  runCode: () => void;
  scrollBottom: () => void;

  setTheme: (theme: "dark" | "light") => void;
  selectModel: (spokenName: string) => boolean;
  setAppMode: (mode: "chat" | "cowork") => void;

  coworkNew: (goal: string) => void;
  coworkRun: () => void;
  coworkPause: () => void;
  coworkApprove: () => void;
  coworkReject: () => void;
  coworkExport: () => void;

  makeImage: (prompt: string) => void;
  makeClip: (prompt: string) => void;
  webSearch: (query: string) => void;

  /** Short spoken/!written confirmation back to the human. */
  say: (text: string) => void;
}

export interface VoiceCommandOptions {
  enabled: boolean;
  /** Treat every utterance as a possible command. */
  commandMode: boolean;
  /** Assistant name plus any custom wake word from Settings. */
  wakeWords: string[];
}

const CONFIRM: Partial<Record<CommandIntent, string>> = {
  new_chat: "New chat.",
  delete_chat: "Chat deleted.",
  open_settings: "Settings.",
  open_panel: "Opening the control panel.",
  close: "Closed.",
  stop: "Stopped.",
  stop_reading: "",
  regenerate: "Trying again.",
  copy_last: "Copied.",
  theme_dark: "Dark mode.",
  theme_light: "Light mode.",
  mode_chat: "Back to chat.",
  mode_cowork: "Cowork.",
  cowork_run: "Carrying on.",
  cowork_pause: "Paused.",
  cowork_approve: "Approved.",
  cowork_reject: "Skipping that.",
  cowork_export: "Downloading the files.",
  run_code: "Running it.",
  scroll_bottom: "",
};

export function useVoiceCommands(actions: VoiceActions, options: VoiceCommandOptions) {
  const actionsRef = useRef(actions);
  const optsRef = useRef(options);
  // refs are synced after render; transcripts always arrive from async callbacks
  useEffect(() => {
    actionsRef.current = actions;
    optsRef.current = options;
  });

  const dispatch = useCallback((m: CommandMatch): boolean => {
    const a = actionsRef.current;
    switch (m.intent) {
      case "new_chat":
        a.newChat();
        break;
      case "delete_chat":
        a.deleteChat();
        break;
      case "rename_chat":
        a.renameChat(m.arg);
        a.say(`Renamed to ${m.arg}.`);
        return true;
      case "open_settings":
        a.openSettings();
        break;
      case "open_panel":
        a.openPanel();
        break;
      case "close":
        a.close();
        break;
      case "stop":
        a.stopReading();
        a.stopGenerating();
        a.coworkPause();
        break;
      case "stop_reading":
        a.stopReading();
        break;
      case "regenerate":
        a.regenerate();
        break;
      case "read_last":
        a.readLast();
        return true;
      case "copy_last":
        a.copyLast();
        break;
      case "run_code":
        a.runCode();
        break;
      case "scroll_bottom":
        a.scrollBottom();
        break;
      case "theme_dark":
        a.setTheme("dark");
        break;
      case "theme_light":
        a.setTheme("light");
        break;
      case "select_model": {
        const ok = a.selectModel(m.arg);
        a.say(ok ? `Switched to ${m.arg}.` : `I could not find an engine called ${m.arg}.`);
        return true;
      }
      case "mode_chat":
        a.setAppMode("chat");
        break;
      case "mode_cowork":
        a.setAppMode("cowork");
        break;
      case "cowork_new":
        a.setAppMode("cowork");
        a.coworkNew(m.arg);
        a.say("Starting work on that.");
        return true;
      case "cowork_run":
        a.coworkRun();
        break;
      case "cowork_pause":
        a.coworkPause();
        break;
      case "cowork_approve":
        a.coworkApprove();
        break;
      case "cowork_reject":
        a.coworkReject();
        break;
      case "cowork_export":
        a.coworkExport();
        break;
      case "make_image":
        a.makeImage(m.arg);
        a.say("Making that picture.");
        return true;
      case "make_clip":
        a.makeClip(m.arg);
        a.say("Making that clip.");
        return true;
      case "web_search":
        a.webSearch(m.arg);
        return true;
      case "send":
        a.send(m.arg);
        return true;
      case "help":
        a.say(helpSentence());
        return true;
      default:
        return false;
    }

    const confirm = CONFIRM[m.intent];
    if (confirm) a.say(confirm);
    return true;
  }, []);

  /** Returns true when the sentence was swallowed as a command. */
  const handleTranscript = useCallback(
    (text: string): boolean => {
      const o = optsRef.current;
      if (!o.enabled) return false;
      const match = matchCommand(text, { commandMode: o.commandMode, wakeWords: o.wakeWords });
      if (!match) return false;
      return dispatch(match);
    },
    [dispatch],
  );

  return { handleTranscript };
}
