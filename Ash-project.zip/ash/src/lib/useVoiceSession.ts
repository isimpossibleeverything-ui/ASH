"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  hasBrowserStt,
  hasBrowserTts,
  hasRecorder,
  primeBrowserVoices,
  speak as speakNow,
  startListening,
  stopSpeaking,
  type Listener,
  type Speaker,
  type VoiceState,
} from "./voice/client";

export interface VoiceSettings {
  sttProvider: string;
  ttsProvider: string;
  ttsVoice: string;
  voiceLang: string;
  rate: number;
  volume: number;
  autoSpeak: boolean;
  continuous: boolean;
  /** Let spoken sentences drive the app itself, not just dictate messages. */
  commands: boolean;
  /** Say this word first and the rest of the sentence becomes a command. */
  wakeWord: string;
}

export const DEFAULT_VOICE_SETTINGS: VoiceSettings = {
  sttProvider: "browser",
  ttsProvider: "browser",
  ttsVoice: "",
  voiceLang: "auto",
  rate: 1,
  volume: 1,
  autoSpeak: false,
  continuous: false,
  commands: true,
  wakeWord: "",
};

interface Options {
  settings: VoiceSettings;
  /** Called with a finished sentence — send it to the AI. */
  onTranscript: (text: string) => void;
  /** True while the AI is generating. */
  generating: boolean;
}

/**
 * One hook that owns the whole voice loop:
 *   listening → thinking → speaking → (continuous? listen again)
 * Speech is always interruptible: starting to listen cuts the reply off.
 */
export function useVoiceSession({ settings, onTranscript, generating }: Options) {
  const [state, setState] = useState<VoiceState>("idle");
  const [partial, setPartial] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [voicesReady, setVoicesReady] = useState(false);

  const listener = useRef<Listener | null>(null);
  const speaker = useRef<Speaker | null>(null);
  const wantListening = useRef(false);
  const settingsRef = useRef(settings);
  const transcriptRef = useRef(onTranscript);

  useEffect(() => {
    settingsRef.current = settings;
  }, [settings]);
  useEffect(() => {
    transcriptRef.current = onTranscript;
  }, [onTranscript]);

  // Detected after mount, never during render: the server has no microphone,
  // so reading this while rendering makes the first client paint disagree with
  // the server HTML and React throws the whole tree away.
  const [deviceCan, setDeviceCan] = useState({ listen: false, speak: false });
  const canListen = deviceCan.listen;
  const canSpeak = deviceCan.speak || settings.ttsProvider !== "browser";

  useEffect(() => {
    setDeviceCan({ listen: hasBrowserStt() || hasRecorder(), speak: hasBrowserTts() });
    primeBrowserVoices(() => setVoicesReady(true));
  }, []);

  /* the AI is working: show it, unless the user is already talking again */
  useEffect(() => {
    if (generating) {
      setState((s) => (s === "listening" ? s : "thinking"));
    } else {
      setState((s) => (s === "thinking" ? "idle" : s));
    }
  }, [generating]);

  const stopListening = useCallback(() => {
    wantListening.current = false;
    listener.current?.stop();
    listener.current = null;
    setPartial("");
    setState((s) => (s === "listening" ? "idle" : s));
  }, []);

  const halt = useCallback(() => {
    speaker.current?.stop();
    speaker.current = null;
    stopSpeaking();
    setState((s) => (s === "speaking" ? "idle" : s));
  }, []);

  const begin = useCallback(() => {
    if (listener.current) return;
    setError(null);
    // barge-in: the moment the user speaks, the assistant stops talking
    halt();
    wantListening.current = true;
    const s = settingsRef.current;

    listener.current = startListening({
      provider: s.sttProvider,
      lang: s.voiceLang,
      continuous: s.continuous,
      onStart: () => setState("listening"),
      onPartial: (t) => setPartial(t),
      onFinal: (text) => {
        setPartial("");
        if (!text.trim()) return;
        if (!s.continuous) {
          wantListening.current = false;
          listener.current?.stop();
          listener.current = null;
        }
        transcriptRef.current(text.trim());
      },
      onError: (message) => {
        setError(message);
        wantListening.current = false;
        listener.current = null;
        setState("idle");
      },
      onEnd: () => {
        listener.current = null;
        setPartial("");
        setState((prev) => (prev === "listening" ? "idle" : prev));
      },
    });
  }, [halt]);

  const toggleListening = useCallback(() => {
    if (listener.current) stopListening();
    else begin();
  }, [begin, stopListening]);

  /** Read a reply out loud. Returns immediately; state follows the audio. */
  const speak = useCallback(
    (text: string) => {
      const s = settingsRef.current;
      if (!text.trim()) return;
      halt();
      speaker.current = speakNow({
        text,
        provider: s.ttsProvider,
        voice: s.ttsVoice || undefined,
        lang: s.voiceLang,
        rate: s.rate,
        volume: s.volume,
        onStart: () => setState("speaking"),
        onEnd: () => {
          speaker.current = null;
          setState("idle");
          // hands-free: hand the microphone straight back to the user
          if (s.continuous && wantListening.current !== false && s.autoSpeak) {
            setTimeout(() => {
              if (!listener.current) begin();
            }, 250);
          }
        },
        onError: (m) => {
          setError(m);
          speaker.current = null;
          setState("idle");
        },
      });
    },
    [begin, halt],
  );

  /** Push-to-talk: hold to record, release to send. */
  const holdStart = useCallback(() => {
    if (!listener.current) begin();
  }, [begin]);
  const holdEnd = useCallback(() => {
    listener.current?.stop();
  }, []);

  useEffect(
    () => () => {
      listener.current?.abort();
      speaker.current?.stop();
      stopSpeaking();
    },
    [],
  );

  return {
    state,
    partial,
    error,
    clearError: () => setError(null),
    canListen,
    canSpeak,
    voicesReady,
    listening: state === "listening",
    speaking: state === "speaking",
    begin,
    stopListening,
    toggleListening,
    speak,
    stopSpeaking: halt,
    holdStart,
    holdEnd,
  };
}
