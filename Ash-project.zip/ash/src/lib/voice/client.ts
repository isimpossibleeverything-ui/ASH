"use client";

/**
 * Browser-side speech engines.
 *
 * Two families, one shape:
 *  • "browser"  — the device's own Web Speech engine. Free, offline, instant,
 *                 no key, and present in every modern browser. The default.
 *  • "server:*" — anything configured in the Control Panel (Whisper for
 *                 listening, a neural voice for speaking). Better quality,
 *                 costs a request, falls back to the browser when it fails.
 */

export type VoiceState = "idle" | "listening" | "thinking" | "speaking";

export interface BrowserVoice {
  id: string;
  label: string;
  lang: string;
  local: boolean;
}

/* ───────────────────────────── capability ───────────────────────────── */

export function hasBrowserStt(): boolean {
  if (typeof window === "undefined") return false;
  return !!((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);
}

export function hasBrowserTts(): boolean {
  return typeof window !== "undefined" && "speechSynthesis" in window;
}

export function hasRecorder(): boolean {
  return (
    typeof window !== "undefined" &&
    typeof MediaRecorder !== "undefined" &&
    !!navigator.mediaDevices?.getUserMedia
  );
}

export function resolveLang(lang: string | undefined, fallback = "en-US"): string {
  if (!lang || lang === "auto") {
    if (typeof navigator !== "undefined" && navigator.language) return navigator.language;
    return fallback;
  }
  return lang;
}

/* ───────────────────────────── listening ───────────────────────────── */

export interface ListenHandlers {
  onPartial?: (text: string) => void;
  onFinal: (text: string) => void;
  onError?: (message: string) => void;
  onStart?: () => void;
  onEnd?: () => void;
}

export interface Listener {
  stop(): void;
  abort(): void;
}

/** Device speech recognition. Restarts itself in continuous mode. */
function listenWithBrowser(opts: { lang: string; continuous: boolean } & ListenHandlers): Listener {
  const Ctor = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
  let stopped = false;
  let rec: any = null;

  const begin = () => {
    if (stopped) return;
    rec = new Ctor();
    rec.lang = opts.lang;
    rec.continuous = opts.continuous;
    rec.interimResults = true;
    rec.maxAlternatives = 1;

    rec.onstart = () => opts.onStart?.();
    rec.onresult = (event: any) => {
      let interim = "";
      let final = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const t = event.results[i][0].transcript;
        if (event.results[i].isFinal) final += t;
        else interim += t;
      }
      if (interim) opts.onPartial?.(interim);
      if (final.trim()) opts.onFinal(final.trim());
    };
    rec.onerror = (e: any) => {
      const code = String(e?.error || "");
      if (code === "no-speech" || code === "aborted") return; // normal, not a failure
      if (code === "not-allowed" || code === "service-not-allowed") {
        stopped = true;
        opts.onError?.("Microphone permission was refused. Allow it in your browser's address bar.");
        return;
      }
      opts.onError?.(`Could not hear you (${code || "unknown"}).`);
    };
    rec.onend = () => {
      if (stopped) {
        opts.onEnd?.();
        return;
      }
      if (opts.continuous) {
        // Chrome ends the session every ~60s; pick it straight back up.
        setTimeout(() => {
          if (!stopped) begin();
        }, 180);
      } else {
        opts.onEnd?.();
      }
    };

    try {
      rec.start();
    } catch {
      /* already running */
    }
  };

  begin();
  return {
    stop() {
      stopped = true;
      try {
        rec?.stop();
      } catch {
        /* ignore */
      }
    },
    abort() {
      stopped = true;
      try {
        rec?.abort();
      } catch {
        /* ignore */
      }
    },
  };
}

/**
 * Record, then send to the server engine.
 * Includes a small voice-activity detector so the user does not have to press
 * stop — it ends the clip after a beat of silence.
 */
function listenWithRecorder(
  opts: { lang: string; continuous: boolean; provider: string; silenceMs?: number } & ListenHandlers,
): Listener {
  let stopped = false;
  let recorder: MediaRecorder | null = null;
  let stream: MediaStream | null = null;
  let audioCtx: AudioContext | null = null;
  let raf = 0;

  const cleanup = () => {
    cancelAnimationFrame(raf);
    try {
      recorder?.state !== "inactive" && recorder?.stop();
    } catch {
      /* ignore */
    }
    stream?.getTracks().forEach((t) => t.stop());
    audioCtx?.close().catch(() => {});
    recorder = null;
    stream = null;
    audioCtx = null;
  };

  const run = async () => {
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      });
    } catch {
      opts.onError?.("Microphone permission was refused. Allow it in your browser's address bar.");
      opts.onEnd?.();
      return;
    }
    if (stopped) {
      cleanup();
      return;
    }

    const mime = MediaRecorder.isTypeSupported("audio/webm;codecs=opus")
      ? "audio/webm;codecs=opus"
      : MediaRecorder.isTypeSupported("audio/webm")
        ? "audio/webm"
        : "";
    recorder = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
    const chunks: BlobPart[] = [];
    recorder.ondataavailable = (e) => e.data.size && chunks.push(e.data);

    recorder.onstop = async () => {
      const blob = new Blob(chunks, { type: recorder?.mimeType || "audio/webm" });
      cleanup();
      if (blob.size < 2000) {
        opts.onEnd?.();
        return;
      }
      try {
        const form = new FormData();
        form.append("audio", blob, "speech.webm");
        form.append("provider", opts.provider);
        form.append("lang", opts.lang);
        const res = await fetch("/api/voice/stt", { method: "POST", body: form });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Could not understand that.");
        if (data.text) opts.onFinal(String(data.text).trim());
      } catch (err) {
        opts.onError?.((err as Error).message);
      } finally {
        opts.onEnd?.();
      }
    };

    recorder.start();
    opts.onStart?.();

    // voice-activity detection: stop after a short silence once speech began
    try {
      audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const source = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 1024;
      source.connect(analyser);
      const buf = new Uint8Array(analyser.frequencyBinCount);
      const silenceLimit = opts.silenceMs ?? 1400;
      let heardSpeech = false;
      let quietSince = performance.now();
      const started = performance.now();

      const tick = () => {
        if (stopped || !recorder || recorder.state === "inactive") return;
        analyser.getByteTimeDomainData(buf);
        let sum = 0;
        for (let i = 0; i < buf.length; i++) {
          const v = (buf[i] - 128) / 128;
          sum += v * v;
        }
        const rms = Math.sqrt(sum / buf.length);
        const now = performance.now();
        if (rms > 0.025) {
          heardSpeech = true;
          quietSince = now;
        }
        const tooLong = now - started > 60_000;
        if ((heardSpeech && now - quietSince > silenceLimit) || tooLong) {
          try {
            recorder.stop();
          } catch {
            /* ignore */
          }
          return;
        }
        raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    } catch {
      /* no analyser: the user stops it manually */
    }
  };

  void run();

  return {
    stop() {
      stopped = true;
      cancelAnimationFrame(raf);
      try {
        if (recorder && recorder.state !== "inactive") recorder.stop();
        else cleanup();
      } catch {
        cleanup();
      }
    },
    abort() {
      stopped = true;
      cleanup();
      opts.onEnd?.();
    },
  };
}

export function startListening(
  opts: { provider: string; lang: string; continuous: boolean } & ListenHandlers,
): Listener | null {
  const lang = resolveLang(opts.lang);
  const wantsServer = opts.provider && opts.provider !== "browser";

  if (!wantsServer && hasBrowserStt()) {
    return listenWithBrowser({ ...opts, lang });
  }
  if (wantsServer && hasRecorder()) {
    return listenWithRecorder({ ...opts, lang });
  }
  // asked for the browser but it is missing: try the server, and vice versa
  if (hasBrowserStt()) return listenWithBrowser({ ...opts, lang });
  if (hasRecorder()) return listenWithRecorder({ ...opts, lang, provider: "" });
  opts.onError?.("This browser cannot record speech. Type your message instead.");
  return null;
}

/* ───────────────────────────── speaking ───────────────────────────── */

let voicesCache: SpeechSynthesisVoice[] = [];

export function browserVoices(): BrowserVoice[] {
  if (!hasBrowserTts()) return [];
  if (!voicesCache.length) voicesCache = window.speechSynthesis.getVoices();
  return voicesCache.map((v) => ({ id: v.voiceURI, label: v.name, lang: v.lang, local: v.localService }));
}

/** getVoices() is empty until the engine warms up in Chrome. */
export function primeBrowserVoices(onReady?: () => void): void {
  if (!hasBrowserTts()) return;
  const load = () => {
    const list = window.speechSynthesis.getVoices();
    if (list.length) {
      voicesCache = list;
      onReady?.();
    }
  };
  load();
  window.speechSynthesis.onvoiceschanged = load;
}

function pickVoice(lang: string, preferredId?: string): SpeechSynthesisVoice | null {
  const list = voicesCache.length ? voicesCache : window.speechSynthesis.getVoices();
  if (!list.length) return null;
  if (preferredId) {
    const exact = list.find((v) => v.voiceURI === preferredId);
    if (exact) return exact;
  }
  const want = lang.toLowerCase();
  const base = want.split("-")[0];
  return (
    list.find((v) => v.lang.toLowerCase() === want) ??
    list.find((v) => v.lang.toLowerCase().startsWith(base)) ??
    list.find((v) => v.lang.toLowerCase().startsWith("en")) ??
    list[0] ??
    null
  );
}

/** Long text stalls Chrome's synthesiser, so feed it sentence by sentence. */
function chunkForSpeech(text: string, max = 220): string[] {
  const parts: string[] = [];
  let buf = "";
  for (const piece of text.split(/(?<=[.!?۔،,:;])\s+/)) {
    if ((buf + " " + piece).trim().length > max && buf) {
      parts.push(buf.trim());
      buf = piece;
    } else {
      buf = buf ? `${buf} ${piece}` : piece;
    }
  }
  if (buf.trim()) parts.push(buf.trim());
  return parts.length ? parts : [text];
}

export interface SpeakOptions {
  text: string;
  provider: string;
  voice?: string;
  lang: string;
  rate: number;
  volume: number;
  onStart?: () => void;
  onEnd?: () => void;
  onError?: (message: string) => void;
}

export interface Speaker {
  stop(): void;
}

let activeAudio: HTMLAudioElement | null = null;

export function stopSpeaking(): void {
  if (hasBrowserTts()) {
    try {
      window.speechSynthesis.cancel();
    } catch {
      /* ignore */
    }
  }
  if (activeAudio) {
    try {
      activeAudio.pause();
      activeAudio.src = "";
    } catch {
      /* ignore */
    }
    activeAudio = null;
  }
}

function speakWithBrowser(o: SpeakOptions): Speaker {
  if (!hasBrowserTts()) {
    o.onError?.("This browser has no speech voices.");
    o.onEnd?.();
    return { stop() {} };
  }
  const lang = resolveLang(o.lang);
  const voice = pickVoice(lang, o.voice);
  const chunks = chunkForSpeech(o.text);
  let cancelled = false;
  let index = 0;

  const next = () => {
    if (cancelled || index >= chunks.length) {
      if (!cancelled) o.onEnd?.();
      return;
    }
    const u = new SpeechSynthesisUtterance(chunks[index++]);
    u.lang = voice?.lang || lang;
    if (voice) u.voice = voice;
    u.rate = Math.min(2, Math.max(0.5, o.rate));
    u.volume = Math.min(1, Math.max(0, o.volume));
    u.onend = () => next();
    u.onerror = () => next();
    window.speechSynthesis.speak(u);
  };

  window.speechSynthesis.cancel();
  o.onStart?.();
  next();

  return {
    stop() {
      cancelled = true;
      try {
        window.speechSynthesis.cancel();
      } catch {
        /* ignore */
      }
    },
  };
}

/** Server voice, with an automatic drop back to the device voice. */
export function speak(o: SpeakOptions): Speaker {
  stopSpeaking();
  if (!o.text.trim()) {
    o.onEnd?.();
    return { stop() {} };
  }

  if (!o.provider || o.provider === "browser") return speakWithBrowser(o);

  const controller = new AbortController();
  let stopped = false;

  void (async () => {
    try {
      const res = await fetch("/api/voice/tts", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ text: o.text, provider: o.provider, voice: o.voice, lang: o.lang, rate: o.rate }),
        signal: controller.signal,
      });
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || "voice failed");
      const blob = await res.blob();
      if (stopped) return;

      const url = URL.createObjectURL(blob);
      const audio = new Audio(url);
      activeAudio = audio;
      audio.volume = Math.min(1, Math.max(0, o.volume));
      audio.onplay = () => o.onStart?.();
      audio.onended = () => {
        URL.revokeObjectURL(url);
        if (activeAudio === audio) activeAudio = null;
        o.onEnd?.();
      };
      audio.onerror = () => {
        URL.revokeObjectURL(url);
        if (activeAudio === audio) activeAudio = null;
        speakWithBrowser(o);
      };
      await audio.play();
    } catch (err) {
      if (stopped || (err as Error)?.name === "AbortError") return;
      // The whole point of the fallback: never leave the user in silence.
      speakWithBrowser(o);
    }
  })();

  return {
    stop() {
      stopped = true;
      controller.abort();
      stopSpeaking();
    },
  };
}
