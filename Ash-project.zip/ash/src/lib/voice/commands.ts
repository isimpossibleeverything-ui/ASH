/**
 * Spoken control for the whole app.
 *
 * Dictation and commands share one microphone, so the rule is deliberately
 * strict: a sentence is only treated as a command when the human either
 * (a) says the wake word first, (b) has command mode switched on, or
 * (c) says one of a few short, unmistakable words like "stop".
 *
 * Every phrase below is matched in English, Roman Urdu and Urdu script,
 * because that is how the people using this actually talk.
 */

export type CommandIntent =
  | "new_chat"
  | "delete_chat"
  | "rename_chat"
  | "open_settings"
  | "open_panel"
  | "close"
  | "stop"
  | "regenerate"
  | "read_last"
  | "stop_reading"
  | "copy_last"
  | "theme_dark"
  | "theme_light"
  | "select_model"
  | "mode_chat"
  | "mode_cowork"
  | "cowork_new"
  | "cowork_run"
  | "cowork_pause"
  | "cowork_approve"
  | "cowork_reject"
  | "cowork_export"
  | "make_image"
  | "make_clip"
  | "web_search"
  | "run_code"
  | "scroll_bottom"
  | "help"
  | "send";

export interface CommandMatch {
  intent: CommandIntent;
  /** The remainder of the sentence, when the command carries one. */
  arg: string;
  /** The text that was matched, for the "heard: …" line in the UI. */
  heard: string;
}

interface Rule {
  intent: CommandIntent;
  /** Patterns that must match the WHOLE utterance. */
  exact?: RegExp[];
  /** Patterns whose trailing text becomes the argument. */
  prefix?: RegExp[];
  /** Safe to fire without the wake word because it cannot be ordinary speech. */
  alwaysOn?: boolean;
}

/* The order matters: the first rule that matches wins, so put the
   argument-carrying phrases before the bare ones. */
const RULES: Rule[] = [
  /* ── urgent, always listened for ───────────────────────────────── */
  {
    intent: "stop",
    alwaysOn: true,
    exact: [
      /^(stop|stop it|cancel|abort|that's enough|enough)$/i,
      /^(ruk|ruko|ruk ja|ruk jao|ruk jaao|bas|bas karo|band karo|rok do|chup)$/i,
      /^(رکو|رک جاؤ|بس|بند کرو|چپ)$/,
    ],
  },
  {
    intent: "stop_reading",
    alwaysOn: true,
    exact: [/^(stop reading|be quiet|quiet|shush|stop talking)$/i, /^(chup ho ja|bolna band|mat bolo|chup karo)$/i, /^(چپ ہو جاؤ|مت بولو|بولنا بند)$/],
  },

  /* ── cowork: the goal-carrying forms come first ────────────────── */
  {
    intent: "cowork_new",
    prefix: [
      /^(?:start (?:a )?(?:new )?(?:cowork|task|job)(?: for me)?(?: to)?|cowork(?: task)?|new task|work on|do this task|take this task)\s*[:,-]?\s+/i,
      /^(?:cowork (?:shuru|shuroo) (?:karo|kar do)|naya kaam|ye kaam karo|yeh kaam karo|ye task karo|kaam shuru karo|mere liye ye karo)\s*[:,-]?\s+/i,
      /^(?:کووَرک شروع کرو|نیا کام|یہ کام کرو|یہ ٹاسک کرو)\s*[:,-]?\s+/,
    ],
  },
  { intent: "cowork_approve", exact: [/^(approve|approve it|yes do it|go ahead|allow it|permission granted)$/i, /^(haan karo|han karo|haan|kar do|ijazat hai|theek hai karo)$/i, /^(ہاں کرو|کر دو|اجازت ہے)$/] },
  { intent: "cowork_reject", exact: [/^(reject|refuse|don't do it|do not do it|deny|skip it)$/i, /^(mat karo|nahi karo|nahin karo|rehne do|chhor do|chor do)$/i, /^(مت کرو|نہیں کرو|رہنے دو)$/] },
  { intent: "cowork_pause", exact: [/^(pause|pause (?:the )?task|hold on|wait)$/i, /^(task rok do|kaam rok do|thamo|thehro|thehar jao)$/i, /^(کام روک دو|ٹھہرو|ٹھہر جاؤ)$/] },
  { intent: "cowork_run", exact: [/^(run it|continue|carry on|resume|keep going|start working)$/i, /^(chalao|chalu karo|jari rakho|aage barho|shuru karo|kaam karo)$/i, /^(چلاؤ|جاری رکھو|آگے بڑھو|شروع کرو)$/] },
  { intent: "cowork_export", exact: [/^(download (?:it|everything|the files)|export (?:it|the task)|give me the files)$/i, /^(files do|sab kuch download karo|download karo)$/i, /^(فائلیں دو|ڈاؤن لوڈ کرو)$/] },
  { intent: "mode_cowork", exact: [/^(cowork|cowork mode|open cowork|switch to cowork|work mode)$/i, /^(cowork khol do|cowork mode|kaam wala mode)$/i, /^(کووَرک|کووَرک موڈ)$/] },
  { intent: "mode_chat", exact: [/^(chat|chat mode|back to chat|normal mode|switch to chat)$/i, /^(chat par wapas|chat mode|wapas chat|normal mode)$/i, /^(چیٹ موڈ|واپس چیٹ)$/] },

  /* ── chats ─────────────────────────────────────────────────────── */
  { intent: "rename_chat", prefix: [/^(?:rename (?:this )?(?:chat )?to|call this|name this chat)\s+/i, /^(?:is chat ka naam rakho|naam rakho|is ka naam)\s+/i, /^(?:اس چیٹ کا نام رکھو|نام رکھو)\s+/] },
  { intent: "new_chat", exact: [/^(new chat|start a new chat|fresh chat|clear the chat|new conversation)$/i, /^(naya chat|nai chat|naya chat kholo|new chat karo|nayi baat)$/i, /^(نیا چیٹ|نئی چیٹ|نیا چیٹ کھولو)$/] },
  { intent: "delete_chat", exact: [/^(delete (?:this )?chat|remove this chat)$/i, /^(ye chat delete karo|is chat ko delete karo|chat mita do|chat hata do)$/i, /^(یہ چیٹ حذف کرو|چیٹ مٹا دو)$/] },

  /* ── the reply ─────────────────────────────────────────────────── */
  { intent: "regenerate", exact: [/^(regenerate|try again|answer again|redo that|say that again differently)$/i, /^(dobara|dubara|phir se|dobara batao|dobara karo|dusra jawab)$/i, /^(دوبارہ|پھر سے|دوبارہ بتاؤ)$/] },
  { intent: "read_last", exact: [/^(read (?:it|that|the answer)(?: out| aloud| to me)?|speak it|say it out loud)$/i, /^(parho|parh do|sunao|suna do|bol kar batao|awaz mein parho)$/i, /^(پڑھو|سناؤ|بول کر بتاؤ)$/] },
  { intent: "copy_last", exact: [/^(copy (?:it|that|the answer))$/i, /^(copy karo|ise copy karo|naqal karo)$/i, /^(کاپی کرو|نقل کرو)$/] },

  /* ── look and feel ─────────────────────────────────────────────── */
  { intent: "theme_dark", exact: [/^(dark mode|go dark|night mode|turn on dark mode)$/i, /^(dark mode|kala kar do|andhera kar do|raat wala mode)$/i, /^(ڈارک موڈ|کالا کر دو|رات والا موڈ)$/] },
  { intent: "theme_light", exact: [/^(light mode|go light|day mode|turn on light mode)$/i, /^(light mode|safed kar do|ujala kar do|din wala mode)$/i, /^(لائٹ موڈ|سفید کر دو|دن والا موڈ)$/] },
  { intent: "scroll_bottom", exact: [/^(scroll (?:to the )?bottom|go to the end|jump to the latest)$/i, /^(neeche jao|sab se neeche|aakhir mein jao)$/i, /^(نیچے جاؤ|سب سے نیچے)$/] },

  /* ── panels ────────────────────────────────────────────────────── */
  { intent: "open_settings", exact: [/^(settings|open settings|show settings|preferences)$/i, /^(settings kholo|settings|tarteebat)$/i, /^(سیٹنگز|سیٹنگز کھولو)$/] },
  { intent: "open_panel", exact: [/^(control panel|owner panel|open the control panel|admin panel)$/i, /^(control panel kholo|control panel|owner panel)$/i, /^(کنٹرول پینل|کنٹرول پینل کھولو)$/] },
  { intent: "close", exact: [/^(close|close it|close this|dismiss|go back)$/i, /^(band karo|bandh karo|wapas|peechay jao|close karo)$/i, /^(بند کرو|واپس|پیچھے جاؤ)$/] },

  /* ── doing things ──────────────────────────────────────────────── */
  { intent: "make_image", prefix: [/^(?:(?:make|draw|create|generate)(?: an?)? (?:image|picture|photo)(?: of| showing)?)\s*[:,-]?\s+/i, /^(?:tasveer banao|tasweer banao|image banao|photo banao|picture banao)\s*[:,-]?\s+/i, /^(?:تصویر بناؤ|تصویر بنا دو)\s*[:,-]?\s+/] },
  { intent: "make_clip", prefix: [/^(?:(?:make|create|generate)(?: a)? (?:clip|video|animation)(?: of| showing)?)\s*[:,-]?\s+/i, /^(?:clip banao|video banao|animation banao)\s*[:,-]?\s+/i, /^(?:ویڈیو بناؤ|کلپ بناؤ)\s*[:,-]?\s+/] },
  { intent: "web_search", prefix: [/^(?:search(?: the web)?(?: for)?|look up|google)\s*[:,-]?\s+/i, /^(?:search karo|dhoondo|dhundo|internet par dekho|talash karo)\s*[:,-]?\s+/i, /^(?:تلاش کرو|ڈھونڈو|سرچ کرو)\s*[:,-]?\s+/] },
  { intent: "select_model", prefix: [/^(?:(?:switch|change) to|use(?: the)?|engine)\s+/i, /^(?:(?:par|per) (?:jao|chalo|switch karo)|engine badlo|model badlo)\s*/i, /^(?:انجن بدلو|ماڈل بدلو)\s*/] },
  { intent: "run_code", exact: [/^(run (?:it|the code|this code)|execute (?:it|the code))$/i, /^(code chalao|chala kar dikhao|program chalao)$/i, /^(کوڈ چلاؤ|پروگرام چلاؤ)$/] },
  { intent: "send", prefix: [/^(?:ask|say|tell (?:me|him|her)|question)\s*[:,-]?\s+/i, /^(?:poocho|poochho|pucho|bolo|batao|sawal)\s*[:,-]?\s+/i, /^(?:پوچھو|بتاؤ|سوال)\s*[:,-]?\s+/] },

  /* ── help ──────────────────────────────────────────────────────── */
  { intent: "help", exact: [/^(help|what can you do|voice commands|commands|what can i say)$/i, /^(madad|kya kar sakte ho|commands kya hain|awaz ke commands)$/i, /^(مدد|آواز کے کمانڈ|کمانڈ کیا ہیں)$/] },
];

/** Strips filler, punctuation and the trailing politeness people add. */
function normalise(raw: string): string {
  return raw
    .trim()
    .replace(/^[\s,.!?۔،]+|[\s,.!?۔،]+$/g, "")
    .replace(/\s+/g, " ")
    .replace(/\b(please|plz|zara|zara se|thora|bhai|yaar|ji)\b/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function stripWake(text: string, wakeWords: string[]): { text: string; woke: boolean } {
  for (const w of wakeWords) {
    if (!w) continue;
    const re = new RegExp(`^${w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b[\\s,.:;!-]*`, "i");
    if (re.test(text)) return { text: text.replace(re, "").trim(), woke: true };
  }
  return { text, woke: false };
}

export interface MatchOptions {
  /** Treat every utterance as a possible command. */
  commandMode: boolean;
  /** The assistant's name plus any custom wake word. */
  wakeWords: string[];
}

export function matchCommand(raw: string, opts: MatchOptions): CommandMatch | null {
  const cleaned = normalise(raw);
  if (!cleaned) return null;

  const { text, woke } = stripWake(cleaned, opts.wakeWords);
  const candidate = normalise(text);
  if (!candidate) return null;

  const open = woke || opts.commandMode;

  for (const rule of RULES) {
    if (!open && !rule.alwaysOn) continue;

    for (const re of rule.exact ?? []) {
      if (re.test(candidate)) return { intent: rule.intent, arg: "", heard: candidate };
    }
    for (const re of rule.prefix ?? []) {
      const m = candidate.match(re);
      if (!m) continue;
      const arg = candidate.slice(m[0].length).trim();
      if (!arg) continue;
      return { intent: rule.intent, arg, heard: candidate };
    }
  }

  /* "ash pro par jao" / "switch to ash open" — the engine name trails the verb */
  if (open) {
    const m = candidate.match(/^(.+?)\s+(?:par|per)\s+(?:jao|chalo|switch karo|le jao)$/i);
    if (m?.[1]) return { intent: "select_model", arg: m[1].trim(), heard: candidate };
  }

  return null;
}

/** Shown in the voice panel and spoken back when the human asks for help. */
export const COMMAND_HELP: { group: string; items: string[] }[] = [
  {
    group: "Anytime",
    items: ["stop  ·  ruk jao", "stop reading  ·  chup ho ja"],
  },
  {
    group: "Chats",
    items: ["new chat  ·  naya chat", "delete this chat  ·  chat mita do", "rename this chat to …  ·  naam rakho …"],
  },
  {
    group: "The reply",
    items: ["read it out  ·  parho", "regenerate  ·  dobara", "copy it  ·  copy karo", "run the code  ·  code chalao"],
  },
  {
    group: "Make something",
    items: ["make a picture of …  ·  tasveer banao …", "make a clip of …  ·  video banao …", "search for …  ·  dhoondo …", "ask …  ·  poocho …"],
  },
  {
    group: "Cowork",
    items: [
      "cowork  ·  cowork mode",
      "work on …  ·  ye kaam karo …",
      "continue  ·  jari rakho",
      "pause  ·  rok do",
      "approve  ·  haan karo",
      "reject  ·  mat karo",
      "download the files  ·  files do",
    ],
  },
  {
    group: "The app",
    items: ["settings  ·  settings kholo", "control panel  ·  control panel kholo", "dark mode  ·  andhera kar do", "light mode  ·  ujala kar do", "close  ·  band karo"],
  },
];

export function helpSentence(): string {
  return "You can say: new chat, read it out, regenerate, make a picture of something, search for something, cowork, work on a task, continue, pause, approve, dark mode, settings, or stop. Roman Urdu bhi chalta hai — naya chat, parho, dobara, tasveer banao, ye kaam karo, jari rakho, rok do, haan karo, andhera kar do, settings kholo, ruk jao.";
}
