import type { SpeechToTextProvider, SttResult } from "./types";
import { MAX_STT_BYTES } from "./types";

/**
 * Server-side speech recognition.
 * Every entry is OpenAI-compatible multipart /audio/transcriptions, which is
 * what Groq, Hugging Face's router, a local Whisper server and OpenAI all speak.
 */
interface WhisperConfig {
  id: string;
  label: string;
  note: string;
  keyEnv: string | null;
  endpoint: string;
  model: string;
  /** Local servers may need no key at all. */
  keyOptional?: boolean;
}

const WHISPERS: WhisperConfig[] = [
  {
    id: "groq-whisper",
    label: "Fast Whisper",
    note: "Free tier, very fast, 90+ languages including Urdu.",
    keyEnv: "GROQ_API_KEY",
    endpoint: "https://api.groq.com/openai/v1/audio/transcriptions",
    model: "whisper-large-v3-turbo",
  },
  {
    id: "hf-whisper",
    label: "Open Whisper",
    note: "Free Hugging Face token, community hosted.",
    keyEnv: "HF_TOKEN",
    endpoint: "https://router.huggingface.co/v1/audio/transcriptions",
    model: "openai/whisper-large-v3",
  },
  {
    id: "local-whisper",
    label: "Local Whisper",
    note: "Any OpenAI-compatible server you run yourself. No limits.",
    keyEnv: "OPENAI_API_KEY",
    endpoint: "",
    model: "whisper-1",
    keyOptional: true,
  },
];

function localEndpoint(): string {
  const base = (process.env.OPENAI_BASE_URL || "").trim().replace(/\/+$/, "");
  return base ? `${base}/audio/transcriptions` : "";
}

function makeProvider(cfg: WhisperConfig): SpeechToTextProvider {
  const endpointOf = () => (cfg.id === "local-whisper" ? localEndpoint() : cfg.endpoint);
  return {
    id: cfg.id,
    label: cfg.label,
    note: cfg.note,
    requiresKey: cfg.keyEnv,
    isConfigured() {
      if (!endpointOf()) return false;
      if (cfg.keyOptional) return true;
      return !!(cfg.keyEnv && (process.env[cfg.keyEnv] || "").trim());
    },
    async transcribe({ audio, lang, signal }): Promise<SttResult> {
      const endpoint = endpointOf();
      if (!endpoint) throw new Error(`${cfg.label} is not configured.`);
      if (audio.size > MAX_STT_BYTES) throw new Error("That recording is too long.");

      const form = new FormData();
      form.append("file", audio, "speech.webm");
      form.append("model", cfg.model);
      form.append("response_format", "json");
      // A language hint improves accuracy a lot, but never force it for "auto".
      if (lang && lang !== "auto") form.append("language", lang.split("-")[0]);

      const headers: Record<string, string> = {};
      const key = cfg.keyEnv ? (process.env[cfg.keyEnv] || "").trim() : "";
      if (key) headers.authorization = `Bearer ${key}`;

      const res = await fetch(endpoint, { method: "POST", body: form, headers, cache: "no-store", signal });
      if (!res.ok) {
        const detail = (await res.text().catch(() => "")).slice(0, 180);
        throw new Error(`${cfg.label} returned ${res.status}${detail ? ` — ${detail}` : ""}`);
      }
      const data = (await res.json()) as { text?: string; language?: string };
      const text = String(data.text ?? "").trim();
      if (!text) throw new Error(`${cfg.label} heard nothing.`);
      return { text, language: data.language, provider: cfg.id };
    },
  };
}

export const STT_PROVIDERS: SpeechToTextProvider[] = WHISPERS.map(makeProvider);

export function sttProvider(id: string): SpeechToTextProvider | undefined {
  return STT_PROVIDERS.find((p) => p.id === id);
}

export function configuredStt(): SpeechToTextProvider[] {
  return STT_PROVIDERS.filter((p) => p.isConfigured());
}

/** Try the preferred provider, then every other configured one. */
export async function transcribeWithFallback(
  preferred: string | undefined,
  input: { audio: Blob; lang?: string; signal?: AbortSignal },
): Promise<SttResult> {
  const ordered = [
    ...configuredStt().filter((p) => p.id === preferred),
    ...configuredStt().filter((p) => p.id !== preferred),
  ];
  if (!ordered.length) throw new Error("No speech-recognition engine is set up on the server.");
  const problems: string[] = [];
  for (const p of ordered) {
    try {
      return await p.transcribe(input);
    } catch (err) {
      problems.push(`${p.label}: ${(err as Error).message}`);
    }
  }
  throw new Error(problems.join(" · "));
}
