import type { TextToSpeechProvider, TtsAudio, VoiceOption } from "./types";
import { MAX_TTS_CHARS } from "./types";

/**
 * Server-side speech synthesis.
 * The browser's own voices are the zero-setup default and live in the client
 * engine; these are the higher-quality options an owner can switch on.
 */

const OPENAI_VOICES = ["alloy", "echo", "fable", "onyx", "nova", "shimmer"];

interface SpeechConfig {
  id: string;
  label: string;
  note: string;
  keyEnv: string | null;
  endpoint: string;
  model: string;
  keyOptional?: boolean;
}

const OPENAI_COMPATIBLE: SpeechConfig[] = [
  {
    id: "local-speech",
    label: "Local Voice",
    note: "Any OpenAI-compatible speech server you run (Kokoro, Piper, openedai-speech). No limits.",
    keyEnv: "OPENAI_API_KEY",
    endpoint: "",
    model: "tts-1",
    keyOptional: true,
  },
  {
    id: "openai-speech",
    label: "Studio Voice",
    note: "Optional paid OpenAI-compatible speech endpoint.",
    keyEnv: "OPENAI_PLATFORM_API_KEY",
    endpoint: "https://api.openai.com/v1/audio/speech",
    model: "tts-1",
  },
];

function localEndpoint(): string {
  const base = (process.env.OPENAI_BASE_URL || "").trim().replace(/\/+$/, "");
  return base ? `${base}/audio/speech` : "";
}

function makeOpenAISpeech(cfg: SpeechConfig): TextToSpeechProvider {
  const endpointOf = () => (cfg.id === "local-speech" ? localEndpoint() : cfg.endpoint);
  return {
    id: cfg.id,
    label: cfg.label,
    note: cfg.note,
    requiresKey: cfg.keyEnv,
    isConfigured() {
      if (!endpointOf()) return false;
      if (cfg.keyOptional) return true;
      return !!(cfg.keyEnv && (process.env[cfg.keyEnv] || "").trim());
    },
    async voices(): Promise<VoiceOption[]> {
      return OPENAI_VOICES.map((v) => ({ id: v, label: v[0].toUpperCase() + v.slice(1), lang: "", local: false }));
    },
    async synthesize({ text, voice, rate, signal }): Promise<TtsAudio> {
      const endpoint = endpointOf();
      if (!endpoint) throw new Error(`${cfg.label} is not configured.`);
      const headers: Record<string, string> = { "content-type": "application/json" };
      const key = cfg.keyEnv ? (process.env[cfg.keyEnv] || "").trim() : "";
      if (key) headers.authorization = `Bearer ${key}`;

      const res = await fetch(endpoint, {
        method: "POST",
        cache: "no-store",
        signal,
        headers,
        body: JSON.stringify({
          model: cfg.model,
          input: text.slice(0, MAX_TTS_CHARS),
          voice: voice && OPENAI_VOICES.includes(voice) ? voice : "nova",
          response_format: "mp3",
          speed: Math.min(2, Math.max(0.5, rate ?? 1)),
        }),
      });
      if (!res.ok) {
        const detail = (await res.text().catch(() => "")).slice(0, 180);
        throw new Error(`${cfg.label} returned ${res.status}${detail ? ` — ${detail}` : ""}`);
      }
      const body = await res.arrayBuffer();
      if (body.byteLength < 512) throw new Error(`${cfg.label} returned no audio.`);
      return { body, mimeType: res.headers.get("content-type") || "audio/mpeg", provider: cfg.id };
    },
  };
}

/** Hugging Face hosts free multilingual TTS models, including Urdu. */
const HF_MODELS: Record<string, string> = {
  ur: "facebook/mms-tts-urd",
  hi: "facebook/mms-tts-hin",
  ar: "facebook/mms-tts-ara",
  fa: "facebook/mms-tts-fas",
  pa: "facebook/mms-tts-pan",
  bn: "facebook/mms-tts-ben",
  en: "facebook/mms-tts-eng",
};

const huggingFaceSpeech: TextToSpeechProvider = {
  id: "hf-speech",
  label: "Open Voice",
  note: "Free Hugging Face token. Has dedicated Urdu, Hindi, Arabic and Persian voices.",
  requiresKey: "HF_TOKEN",
  isConfigured: () => !!(process.env.HF_TOKEN || "").trim(),
  async voices(): Promise<VoiceOption[]> {
    return Object.keys(HF_MODELS).map((lang) => ({ id: lang, label: `Open Voice (${lang})`, lang, local: false }));
  },
  async synthesize({ text, lang, signal }): Promise<TtsAudio> {
    const token = (process.env.HF_TOKEN || "").trim();
    if (!token) throw new Error("Open Voice needs a free Hugging Face token.");
    const code = (lang || "en").split("-")[0].toLowerCase();
    const model = HF_MODELS[code] ?? HF_MODELS.en;
    const res = await fetch(`https://router.huggingface.co/hf-inference/models/${model}`, {
      method: "POST",
      cache: "no-store",
      signal,
      headers: { authorization: `Bearer ${token}`, "content-type": "application/json", accept: "audio/flac" },
      body: JSON.stringify({ inputs: text.slice(0, MAX_TTS_CHARS) }),
    });
    if (!res.ok) {
      const detail = (await res.text().catch(() => "")).slice(0, 180);
      throw new Error(`Open Voice returned ${res.status}${detail ? ` — ${detail}` : ""}`);
    }
    const body = await res.arrayBuffer();
    if (body.byteLength < 512) throw new Error("Open Voice returned no audio.");
    return { body, mimeType: res.headers.get("content-type") || "audio/flac", provider: "hf-speech" };
  },
};

const elevenLabs: TextToSpeechProvider = {
  id: "elevenlabs",
  label: "Natural Voice",
  note: "Free tier, 10k characters a month. The most natural sounding option.",
  requiresKey: "ELEVENLABS_API_KEY",
  isConfigured: () => !!(process.env.ELEVENLABS_API_KEY || "").trim(),
  async voices(): Promise<VoiceOption[]> {
    const key = (process.env.ELEVENLABS_API_KEY || "").trim();
    if (!key) return [];
    try {
      const res = await fetch("https://api.elevenlabs.io/v1/voices", {
        headers: { "xi-api-key": key },
        cache: "no-store",
        signal: AbortSignal.timeout(10_000),
      });
      if (!res.ok) return [];
      const data = (await res.json()) as { voices?: { voice_id: string; name: string }[] };
      return (data.voices ?? []).map((v) => ({ id: v.voice_id, label: v.name, lang: "", local: false }));
    } catch {
      return [];
    }
  },
  async synthesize({ text, voice, signal }): Promise<TtsAudio> {
    const key = (process.env.ELEVENLABS_API_KEY || "").trim();
    if (!key) throw new Error("Natural Voice needs an ElevenLabs key.");
    const id = voice || "21m00Tcm4TlvDq8ikWAM";
    const res = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(id)}`, {
      method: "POST",
      cache: "no-store",
      signal,
      headers: { "xi-api-key": key, "content-type": "application/json", accept: "audio/mpeg" },
      body: JSON.stringify({
        text: text.slice(0, MAX_TTS_CHARS),
        model_id: "eleven_multilingual_v2",
        voice_settings: { stability: 0.45, similarity_boost: 0.75 },
      }),
    });
    if (!res.ok) {
      const detail = (await res.text().catch(() => "")).slice(0, 180);
      throw new Error(`Natural Voice returned ${res.status}${detail ? ` — ${detail}` : ""}`);
    }
    const body = await res.arrayBuffer();
    if (body.byteLength < 512) throw new Error("Natural Voice returned no audio.");
    return { body, mimeType: "audio/mpeg", provider: "elevenlabs" };
  },
};

export const TTS_PROVIDERS: TextToSpeechProvider[] = [
  elevenLabs,
  huggingFaceSpeech,
  ...OPENAI_COMPATIBLE.map(makeOpenAISpeech),
];

export function ttsProvider(id: string): TextToSpeechProvider | undefined {
  return TTS_PROVIDERS.find((p) => p.id === id);
}

export function configuredTts(): TextToSpeechProvider[] {
  return TTS_PROVIDERS.filter((p) => p.isConfigured());
}

export async function synthesizeWithFallback(
  preferred: string | undefined,
  input: { text: string; voice?: string; lang?: string; rate?: number; signal?: AbortSignal },
): Promise<TtsAudio> {
  const ordered = [
    ...configuredTts().filter((p) => p.id === preferred),
    ...configuredTts().filter((p) => p.id !== preferred),
  ];
  if (!ordered.length) throw new Error("No server voice is set up — the browser voice will be used instead.");
  const problems: string[] = [];
  for (const p of ordered) {
    try {
      return await p.synthesize(input);
    } catch (err) {
      problems.push(`${p.label}: ${(err as Error).message}`);
    }
  }
  throw new Error(problems.join(" · "));
}
