/** Shared contracts for speech. Server and browser engines both implement these. */

export interface VoiceOption {
  id: string;
  label: string;
  lang: string;
  /** Browser voices are local; server voices cost a request. */
  local: boolean;
}

export interface SttResult {
  text: string;
  language?: string;
  provider: string;
}

export interface TtsAudio {
  /** Raw audio bytes. */
  body: ArrayBuffer;
  mimeType: string;
  provider: string;
}

export interface SpeechToTextProvider {
  id: string;
  label: string;
  /** Owner-only note explaining what it needs. */
  note: string;
  requiresKey: string | null;
  isConfigured(): boolean;
  transcribe(input: { audio: Blob; lang?: string; signal?: AbortSignal }): Promise<SttResult>;
}

export interface TextToSpeechProvider {
  id: string;
  label: string;
  note: string;
  requiresKey: string | null;
  isConfigured(): boolean;
  voices(): Promise<VoiceOption[]>;
  synthesize(input: { text: string; voice?: string; lang?: string; rate?: number; signal?: AbortSignal }): Promise<TtsAudio>;
}

export const MAX_TTS_CHARS = 1200;
export const MAX_STT_BYTES = 12 * 1024 * 1024;

/** Trim a reply down to something worth speaking: no code blocks, no markdown noise. */
export function speakableText(markdown: string, limit = MAX_TTS_CHARS): string {
  let t = markdown
    .replace(/```[\s\S]*?```/g, " … code block … ")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/!\[[^\]]*\]\([^)]*\)/g, " ")
    .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
    .replace(/^\s{0,3}#{1,6}\s+/gm, "")
    .replace(/\*\*([^*]+)\*\*/g, "$1")
    .replace(/\*([^*]+)\*/g, "$1")
    .replace(/^\s*[-*+]\s+/gm, "")
    .replace(/^\s*\d+\.\s+/gm, "")
    .replace(/^\s*>\s?/gm, "")
    .replace(/\|/g, " ")
    .replace(/^-{3,}$/gm, " ")
    .replace(/\n{2,}/g, ". ")
    .replace(/\s+/g, " ")
    .trim();
  if (t.length > limit) {
    const cut = t.slice(0, limit);
    const stop = Math.max(cut.lastIndexOf(". "), cut.lastIndexOf("۔ "), cut.lastIndexOf("، "));
    t = (stop > limit * 0.6 ? cut.slice(0, stop + 1) : cut).trim();
  }
  return t;
}
