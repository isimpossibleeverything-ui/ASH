import { NextResponse, type NextRequest } from "next/server";

/**
 * Security headers only. Nothing else lives here.
 * (Next 16 renamed the `middleware` convention to `proxy`.)
 */

/** Who may put Ash inside an iframe.
 *
 *  Production defaults to Ash itself and nothing else. If you want to embed Ash
 *  in your own page — or you are looking at it through a hosted preview panel —
 *  list those origins in ASH_FRAME_ANCESTORS, space separated, e.g.
 *      ASH_FRAME_ANCESTORS="https://mysite.com https://*.e2b.app"
 *  Development always allows the usual sandbox preview hosts.
 */
function frameAncestors(): { csp: string; allowAll: boolean } {
  const extra = (process.env.ASH_FRAME_ANCESTORS ?? "").trim();
  if (process.env.NODE_ENV !== "production") {
    return {
      csp: "'self' https://*.e2b.app https://*.app.github.dev https://*.gitpod.io http://localhost:*",
      allowAll: true,
    };
  }
  return { csp: extra ? `'self' ${extra}` : "'self'", allowAll: extra.length > 0 };
}

export function proxy(req: NextRequest) {
  const res = NextResponse.next();
  const frames = frameAncestors();

  res.headers.set("X-Content-Type-Options", "nosniff");
  // frame-ancestors supersedes X-Frame-Options wherever CSP is understood.
  res.headers.set("Content-Security-Policy", `frame-ancestors ${frames.csp}`);
  // X-Frame-Options cannot express an allowlist, so it is only safe to send
  // when the answer really is "same origin only".
  if (!frames.allowAll) res.headers.set("X-Frame-Options", "SAMEORIGIN");
  res.headers.set("Referrer-Policy", "strict-origin-when-cross-origin");
  res.headers.set("Permissions-Policy", "camera=(), geolocation=(), microphone=(self)");

  const { pathname } = req.nextUrl;
  if (pathname.startsWith("/api/")) {
    res.headers.set("Cache-Control", "no-store");
  }
  // the worker must be allowed to control the whole origin, and must never be
  // served from a stale HTTP cache or an update can never land
  if (pathname === "/sw.js") {
    res.headers.set("Service-Worker-Allowed", "/");
    res.headers.set("Cache-Control", "no-cache, max-age=0, must-revalidate");
  }
  return res;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
